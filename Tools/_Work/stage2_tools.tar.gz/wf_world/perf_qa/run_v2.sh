#!/bin/bash
# 월드 생성기 v2 비교용 성능 검사 (결과: $PERF_OUT). WORLD_DATA=<Data~> PERF_OUT=<결과 폴더> ./run_v2.sh
set -e
cd "$(dirname "$0")"
mkdir -p "$PERF_OUT"
nice python3 perf_assets.py 1 > $PERF_OUT/assets_bias1.txt
nice python3 perf_scan.py 8 1 > $PERF_OUT/scan_s8_b1.txt
nice python3 perf_grass.py 8 > $PERF_OUT/grass.txt
PERF_TAG=base nice python3 perf_total.py 16 70 0.75 1 > $PERF_OUT/total_base.txt
nice python3 perf_heatmap.py base > /dev/null
nice python3 perf_lights.py 4 > $PERF_OUT/lights.txt
nice python3 perf_cells.py > $PERF_OUT/cells.txt
nice python3 perf_radius.py 8 > $PERF_OUT/radius.txt
nice python3 perf_tree_sources.py > $PERF_OUT/tree_sources.txt
echo "끝: $PERF_OUT"
