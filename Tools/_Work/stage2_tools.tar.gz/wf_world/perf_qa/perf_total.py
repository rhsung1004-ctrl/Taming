# 같은 방향으로 본 화면 안 삼각형 합 = 소품 + 지형 나무 (LOD 반영) + 풀 (거리·밀도 반영). 방향 5도 72개 중 최대
#   python3 perf_total.py [격자 간격 m=16] [풀 거리=70] [풀 밀도=0.75] [lodBias=1] [풀 종류 배율 예: grass_a=0.67,grass_dead=0.75]
#   가정 바꾸기: PERF_OVERRIDE='{"dead_tree_a":{"cull":0.014}}'  개수 줄이기: PERF_DROP='{"grave_slab_a":0.3}'
# 지형 자체·물·입자·그림자 패스는 들어 있지 않다 (그림자는 perf_view.py 가 캐스케이드별로 센다)
import sys, os
import numpy as np
from perf_common import *

step = float(sys.argv[1]) if len(sys.argv) > 1 else 16.0
DD = float(sys.argv[2]) if len(sys.argv) > 2 else DETAIL_DISTANCE
DENS = float(sys.argv[3]) if len(sys.argv) > 3 else DETAIL_DENSITY
bias = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
gscale = {}
if len(sys.argv) > 5 and sys.argv[5] not in ('', '-'):
    for kv in sys.argv[5].split(','):
        k, v = kv.split('='); gscale[k] = float(v)
A = assets(bias)
h = load_height()
I = load_instances(A, h)
G, det = load_details()
names = [q['asset'] for q in det]
tri = np.array([A[n].tris[0] * gscale.get(n, 1.0) for n in names], np.float32)
gt = np.tensordot(tri, G, 1)[:2048, :2048] * DENS
g2 = gt.reshape(1024, 2, 1024, 2).sum((1, 3))              # 2 m 칸
r = int(np.ceil(DD / 2)) + 1
oy, ox = np.mgrid[-r:r + 1, -r:r + 1]
od = np.hypot(ox * 2 + 1, oy * 2 + 1)                       # 2 m 칸 가운데까지 (카메라는 칸 모서리 근처)
m = od <= DD
ox, oy = ox[m], oy[m]
ob = (np.degrees(np.arctan2(ox * 2 + 1, oy * 2 + 1)) % 360 / 5).astype(int) % 72

cx, cz, ng = walk_grid(step)
cy = height_at(h, cx, cz).astype(np.float32) + CAM_HEIGHT
C = len(cx); NB = 72; SEC = int(round(FOV_H / 5.0))
best = np.zeros(C); byaw = np.zeros(C); pt_at = np.zeros(C); gr_at = np.zeros(C); worst_light = np.zeros(C)
CH = 96
for c0 in range(0, C, CH):
    c1 = min(C, c0 + CH); n = c1 - c0
    dx = I.x[None, :] - cx[c0:c1, None]; dz = I.z[None, :] - cz[c0:c1, None]; dy = I.cy[None, :] - cy[c0:c1, None]
    d = np.sqrt(dx * dx + dz * dz + dy * dy)
    t = np.where(d < I.dend[None, :, 0], I.tris[None, :, 0], np.where(d < I.dend[None, :, 1], I.tris[None, :, 1], np.where(d < I.dend[None, :, 2], I.tris[None, :, 2], 0.0)))
    b = np.minimum(((np.degrees(np.arctan2(dx, dz)) % 360) / 5).astype(np.int32), NB - 1)
    idx = (np.arange(n)[:, None] * NB + b).ravel()
    bp = np.bincount(idx, weights=t.ravel().astype(np.float64), minlength=n * NB).reshape(n, NB)
    ix = (cx[c0:c1] // 2).astype(int); iz = (cz[c0:c1] // 2).astype(int)
    gx = np.clip(ix[:, None] + ox[None, :], 0, 1023); gz = np.clip(iz[:, None] + oy[None, :], 0, 1023)
    gv = g2[gz, gx]
    idx2 = (np.arange(n)[:, None] * NB + ob[None, :]).ravel()
    bg = np.bincount(idx2, weights=gv.ravel().astype(np.float64), minlength=n * NB).reshape(n, NB)
    tot = bp + bg
    def win(bb):
        ext = np.concatenate([bb, bb[:, :SEC]], 1)
        cs = np.concatenate([np.zeros((n, 1)), np.cumsum(ext, 1)], 1)
        return cs[:, SEC:SEC + NB] - cs[:, :NB]
    wt, wp, wg = win(tot), win(bp), win(bg)
    k = np.argmax(wt, 1)
    s_ = np.arange(n)
    best[c0:c1] = wt[s_, k]; byaw[c0:c1] = (k * 5 + SEC * 2.5) % 360; pt_at[c0:c1] = wp[s_, k]; gr_at[c0:c1] = wg[s_, k]

print("화면 안 삼각형 합 (소품+나무+풀, 같은 방향) — 간격 %.0f m %d 곳, 풀 거리 %.0f m 밀도 %.2f, lodBias %.1f%s%s%s" % (
    step, C, DD, DENS, bias, (", 풀 배율 %s" % gscale) if gscale else "", (", 가정 %s" % os.environ.get('PERF_OVERRIDE')) if os.environ.get('PERF_OVERRIDE') else "",
    (", 빼기 %s" % os.environ.get('PERF_DROP')) if os.environ.get('PERF_DROP') else ""))
for q in (50, 90, 99, 100):
    i = int(np.argmin(np.abs(best - np.percentile(best, q))))
    print("  %3d%%: %5.2fM (소품+나무 %4.2fM, 풀 %4.2fM)" % (q, np.percentile(best, q) / 1e6, pt_at[i] / 1e6, gr_at[i] / 1e6))
print("  5M 넘는 자리 %.1f%%, 8M 넘는 자리 %.1f%%, 10M 넘는 자리 %.1f%%" % ((best > 5e6).mean() * 100, (best > 8e6).mean() * 100, (best > 10e6).mean() * 100))
order = np.argsort(-best); got = []
for i in order:
    if all(np.hypot(cx[i] - cx[j], cz[i] - cz[j]) > 150 for j in got):
        got.append(i)
    if len(got) >= 8:
        break
print("  최악 자리:")
for i in got:
    print("   (%5.0f, %5.0f) %-26s 방향 %3.0f도: 합 %5.2fM = 소품+나무 %4.2fM + 풀 %4.2fM" % (cx[i], cz[i], nearest_poi(cx[i], cz[i]), byaw[i], best[i] / 1e6, pt_at[i] / 1e6, gr_at[i] / 1e6))
tag = os.environ.get('PERF_TAG', '')
if tag:
    np.savez_compressed(os.path.join(OUT, 'total_%s.npz' % tag), cx=cx, cz=cz, best=best, byaw=byaw, pt=pt_at, gr=gr_at)
