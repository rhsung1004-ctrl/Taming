# 성능 예산 분석 공통: 데이터 읽기, 소품별 LOD 거리·삼각형, 광원 위치, 풀 밀도
# Unity 쪽 규칙은 Assets/_Necro/Scripts/Editor 를 그대로 옮겼다:
#   NecroWorldImport.LodHeights (LOD 전환 화면 높이, 시야각 55도: 화면 높이 = 크기 / (1.04 × 거리))
#   NecroWorldBuilder: 풀 거리 DetailDistance 70, 밀도 DetailDensity 0.75, 나무 거리 1200, 그림자 거리 150 (NecroWorldTools)
#   LightCuller: 반지름 80, 여유 10, 최대 48
import os, sys, json, glob
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.abspath(os.path.join(HERE, '..', '..'))
DATA = os.environ.get('WORLD_DATA', os.path.join(SCR, 'world_out3', 'Data~'))
KIT = os.environ.get('KIT_OUT', os.path.join(SCR, 'kit_out'))
OUT = os.environ.get('PERF_OUT', os.path.join(HERE, 'out'))
os.makedirs(OUT, exist_ok=True)
sys.path.insert(0, HERE)

SIZE = 2048
HMAX = 320.0
# 걸을 수 있는 범위: world.json 의 bounds (정사각형)
_bw = json.load(open(os.path.join(DATA, 'world.json')))['bounds']
BOUNDS = (_bw['min'][0], _bw['max'][0])
FOV_V = 55.0
ASPECT = 16 / 9
FOV_H = 2 * np.degrees(np.arctan(np.tan(np.radians(FOV_V / 2)) * ASPECT))   # 85.3도
K_SCREEN = 2 * np.tan(np.radians(FOV_V / 2))                               # 1.041 (Unity 식의 1.04)

# Unity 설정 (현재 코드 값)
DETAIL_DISTANCE = 70.0
DETAIL_DENSITY = 0.75
TREE_DISTANCE = 1200.0
SHADOW_DISTANCE = 150.0
CASCADE_SPLITS = (10.0, 30.0, 70.0, 150.0)
CULLER_RADIUS, CULLER_HYST, CULLER_MAX = 80.0, 10.0, 48
# LightCuller 실제 규칙: 광원마다 끄는 거리 = LightCullDistance.far (objects.json lights / META.light 의 far) 또는 clamp(range × 12, 30, 200)
CULL_FACTOR, CULL_MIN, CULL_MAXR = 12.0, 30.0, 200.0


def cull_radius(rng, far):
    if far:
        return float(min(max(far, CULL_MIN), CULL_MAXR))
    return float(min(max(rng * CULL_FACTOR, CULL_MIN), CULL_MAXR))
CAM_HEIGHT = 3.0          # 카메라 높이 (주인공 키 1.8 + 궤도 카메라 거리 5 m 의 뒤·위)


def load_manifest():
    m = {}
    for f in sorted(glob.glob(os.path.join(KIT, 'manifest_*.json'))):
        m.update(json.load(open(f)))
    return m


def lod_table():
    """{이름: [LOD0, LOD1, ...] 삼각형} (FBX 에서 센다, out/lod_tris.json 에 캐시)"""
    cache = os.path.join(HERE, 'out', 'lod_tris.json' if os.path.basename(KIT.rstrip('/')) == 'kit_out' else 'lod_tris_%s.json' % os.path.basename(KIT.rstrip('/')))   # w4: 소품 폴더마다 캐시
    if os.path.exists(cache):
        return json.load(open(cache))
    import fbx_lods
    t = {}
    for f in sorted(glob.glob(os.path.join(KIT, '*.fbx'))):
        n = os.path.basename(f)[:-4]
        if n.startswith('_'):
            continue
        t[n] = fbx_lods.lod_tris(f)[0]
    json.dump(t, open(cache, 'w'), indent=0)
    return t


def lod_heights(n, size, cull, min_cull):
    """NecroWorldImport.LodHeights 그대로"""
    cull = min(max(cull, 0.0), 0.5)
    if min_cull > 0:
        cull = min(cull, size / (1.04 * min_cull))
    H = lambda d: size / (1.04 * max(d, 1.0))
    h = [0.0] * n
    if n == 1:
        return [cull]
    d0 = min(max(size * 8, 15), 90)
    d1 = min(max(size * 25, 45), 300)
    h[n - 1] = cull
    if n == 2:
        h[0] = max(H(d0), cull * 1.5 + 0.002)
    else:
        h[1] = max(H(d1), cull * 1.3 + 0.001)
        h[0] = max(H(d0), h[1] * 1.3 + 0.002)
        for i in range(2, n - 1):
            h[i] = h[1] + (cull - h[1]) * (i - 1) / (n - 2) + 0.0005
    return [min(h[i], 0.95 - i * 0.01) for i in range(n)]


class Asset:
    pass


def assets(lod_bias=1.0, override=None):
    """소품 이름 → Asset (크기, LOD 삼각형, LOD 끝 거리(크기 1 기준, m), 그림자, 광원)
    override: {"이름": {"cull": 0.014, "tris": [..], "shadows": false}} — 가정 바꿔 보기 (환경 변수 PERF_OVERRIDE 에 JSON 으로도)"""
    man = load_manifest()
    lt = lod_table()
    if override is None and os.environ.get('PERF_OVERRIDE'):
        override = json.loads(os.environ['PERF_OVERRIDE'])
    override = override or {}
    out = {}
    for n, v in man.items():
        meta = v.get('meta', {})
        a = Asset()
        a.name = n
        a.kind = meta.get('kind', 'prop')
        a.sink = float(meta.get('sink', 0.0))
        a.size3 = v['size']                      # Blender x, y, z
        a.size = max(v['size'])                  # LODGroup.size (가장 긴 축)
        a.tris = lt.get(n, [v.get('tris_lod0', 0)])
        a.tris0 = v.get('tris_lod0', a.tris[0])
        a.shadows = bool(meta.get('shadows', a.kind != 'detail'))
        a.light = meta.get('light') if a.kind != 'tree' else None
        a.cull = meta.get('cull', 0.0 if a.kind == 'detail' else 0.003 if a.kind == 'landmark' else 0.006 if a.kind == 'tree' else 0.012)
        ov = override.get(n, {})
        if 'cull' in ov: a.cull = ov['cull']
        if 'tris' in ov: a.tris = list(ov['tris'])
        if 'shadows' in ov: a.shadows = bool(ov['shadows'])
        min_cull = 50.0 if (a.light and a.kind != 'tree') else 30.0
        if a.kind == 'detail':
            a.hs = []
            a.dist = []
        else:
            a.hs = lod_heights(len(a.tris), a.size, a.cull, min_cull)
            # LOD i 가 끝나는 거리 (크기 배율 1, lodBias 반영)
            a.dist = [a.size * lod_bias / (K_SCREEN * h) for h in a.hs]
        out[n] = a
    return out


def load_height():
    h = np.fromfile(os.path.join(DATA, 'height.r16'), '<u2').reshape(2049, 2049).astype(np.float32) * (HMAX / 65535.0)
    return h        # [z, x]


def height_at(h, x, z):
    x = np.clip(np.asarray(x, float), 0, 2048); z = np.clip(np.asarray(z, float), 0, 2048)
    x0 = np.minimum(np.floor(x).astype(int), 2047); z0 = np.minimum(np.floor(z).astype(int), 2047)
    fx, fz = x - x0, z - z0
    return (h[z0, x0] * (1 - fx) * (1 - fz) + h[z0, x0 + 1] * fx * (1 - fz) + h[z0 + 1, x0] * (1 - fx) * fz + h[z0 + 1, x0 + 1] * fx * fz)


def qrot(q, v):
    """쿼터니언 (x,y,z,w) 들로 벡터 v (N×3) 회전"""
    q = np.asarray(q, float); v = np.asarray(v, float)
    u = q[:, :3]; w = q[:, 3:4]
    t = 2 * np.cross(u, v)
    return v + w * t + np.cross(u, t)


class Inst:
    """그리는 물체 하나하나 (소품 + 지형 나무)를 배열로"""
    pass


def load_instances(A, h=None, extra=None):
    """extra: [(이름, x, z, s), ...] — 아직 데이터에 없는 소품(예: 용 뼈)을 더해 본다"""
    if h is None:
        h = load_height()
    obj = json.load(open(os.path.join(DATA, 'objects.json')))
    tr = json.load(open(os.path.join(DATA, 'trees.json')))
    names, xs, ys, zs, ss, istree, culls = [], [], [], [], [], [], []
    for o in obj['objects']:
        names.append(o['a']); xs.append(o['p'][0]); ys.append(o['p'][1]); zs.append(o['p'][2]); ss.append(o['s']); istree.append(False)
        culls.append(float(o.get('cull', 0.0)))       # w4: objects[].cull (NecroWorldBuilder.RaiseCull 과 같은 규칙)
    protos = tr['prototypes']
    for p, x, z, yaw, s in tr['instances']:
        n = protos[int(p)]
        names.append(n); xs.append(x); zs.append(z); ss.append(s); istree.append(True)
        ys.append(float(height_at(h, x, z)) - A[n].sink * s)
        culls.append(0.0)
    if extra:
        for n, x, z, s in extra:
            names.append(n); xs.append(x); zs.append(z); ss.append(s); istree.append(A[n].kind == 'tree')
            ys.append(float(height_at(h, x, z)))
            culls.append(0.0)
    keep = np.ones(len(names), bool)
    drop = json.loads(os.environ['PERF_DROP']) if os.environ.get('PERF_DROP') else {}
    if drop:      # {"이름": 비율} 또는 {"이름@x0,z0,x1,z1": 비율} — 그 소품을 무작위로 그 비율만큼 뺀다 (개수 줄이기 어림)
        rng = np.random.default_rng(11)
        nm = np.array(names); X = np.array(xs); Z = np.array(zs)
        for key, frac in drop.items():
            a, _, box = key.partition('@')
            m = nm == a
            if box:
                bx0, bz0, bx1, bz1 = map(float, box.split(','))
                m &= (X >= bx0) & (X < bx1) & (Z >= bz0) & (Z < bz1)
            keep[np.nonzero(m)[0][rng.random(m.sum()) < frac]] = False
    sel = np.nonzero(keep)[0]
    names = [names[i] for i in sel]; xs = [xs[i] for i in sel]; ys = [ys[i] for i in sel]; zs = [zs[i] for i in sel]
    ss = [ss[i] for i in sel]; istree = [istree[i] for i in sel]; culls = [culls[i] for i in sel]
    I = Inst()
    I.name = np.array(names)
    I.x = np.array(xs, np.float32); I.y = np.array(ys, np.float32); I.z = np.array(zs, np.float32)
    I.s = np.array(ss, np.float32); I.tree = np.array(istree)
    n = len(names)
    I.cy = I.y + np.array([A[a].size3[2] for a in names], np.float32) * 0.5 * I.s     # LOD 기준점 (경계 상자 가운데 높이)
    I.tris = np.zeros((n, 3), np.float32)            # LOD0, LOD1, LOD2 (없으면 마지막 LOD 그대로가 아니라 0: 컬링 거리에서 끝)
    I.dend = np.zeros((n, 3), np.float32)            # LOD i 가 끝나는 거리 (m)
    I.tris0 = np.zeros(n, np.float32)
    I.shadow = np.zeros(n, bool)
    I.light = np.zeros(n, bool)
    for i, a in enumerate(names):
        aa = A[a]
        k = len(aa.tris)
        dist = aa.dist
        if culls[i] > 0 and aa.hs and culls[i] > aa.hs[-1]:
            h2 = list(aa.hs)
            h2[-1] = culls[i]
            for j in range(len(h2) - 2, -1, -1):
                if h2[j] <= h2[j + 1]:
                    h2[j] = min(0.99, h2[j + 1] + 0.002)
            dist = [aa.dist[j] * aa.hs[j] / h2[j] for j in range(len(h2))]
        for j in range(3):
            if j < k:
                I.tris[i, j] = aa.tris[j]
                I.dend[i, j] = dist[j] * I.s[i]
            else:
                I.tris[i, j] = 0
                I.dend[i, j] = I.dend[i, j - 1]
        I.tris0[i] = aa.tris0
        I.shadow[i] = aa.shadows
        I.light[i] = aa.light is not None
    # 지형 나무는 지형의 나무 거리(1200 m)에서도 잘린다
    I.dend[I.tree] = np.minimum(I.dend[I.tree], TREE_DISTANCE)
    if os.environ.get('PERF_NO_CLIFFS') != '1':
        add_cliffs(I, A)
    return I


def add_cliffs(I, A):
    """w6a: 산 벽 덮개 (Data~/cliffs.bin) 조각을 그리는 물체로 더한다. NecroWorldBuilder.BuildCliffs 와 같은 규칙:
    조각 하나 = LODGroup 하나 (렌더러 하나), 조각 가운데까지 거리로 LOD 를 고르고 (lodEnd 는 lodBias 1 기준 m), first 보다 고운 LOD 는 없다.
    그림자: LOD0·1 만 드리운다 (그림자 거리 150 m 안은 LOD0·1 뿐이라 조각 전체를 그림자 물체로 센다)"""
    path = os.path.join(DATA, 'cliffs.bin')
    if not os.path.exists(path):
        return
    sys.path.insert(0, '/home/user/Taming/Tools/WorldGen')
    import cliffskin
    cs = cliffskin.read(path, meshes=False)
    le = cs['lod_end']
    n = len(cs['chunks'])
    cx = np.zeros(n, np.float32); cy = np.zeros(n, np.float32); cz = np.zeros(n, np.float32)
    tr = np.zeros((n, 3), np.float32); de = np.zeros((n, 3), np.float32)
    for i, ch in enumerate(cs['chunks']):
        cx[i], cy[i], cz[i] = ch['center']
        lv = [ch['lv'][L]['nquads'] * 2 for L in range(len(le))]
        f = ch['first']
        for j in range(3):
            L = f + j
            if L < len(le):
                tr[i, j] = lv[L]; de[i, j] = le[L]
            else:
                tr[i, j] = 0; de[i, j] = de[i, j - 1]
    a = Asset()
    a.name = 'cliff_skin'; a.kind = 'cliff'; a.sink = 0.0; a.size3 = [cs['lod_size']] * 3; a.size = cs['lod_size']
    a.tris = [float(tr[:, 0].mean())] * 3 if n else [0]; a.tris0 = a.tris[0]; a.shadows = True; a.light = None; a.cull = 0.0
    a.hs = [cs['lod_size'] / (K_SCREEN * e) for e in le]; a.dist = list(le)
    A['cliff_skin'] = a
    I.name = np.concatenate([I.name, np.array(['cliff_skin'] * n)])
    I.x = np.concatenate([I.x, cx]); I.y = np.concatenate([I.y, cy]); I.z = np.concatenate([I.z, cz])
    I.s = np.concatenate([I.s, np.ones(n, np.float32)]); I.tree = np.concatenate([I.tree, np.zeros(n, bool)])
    I.cy = np.concatenate([I.cy, cy])
    I.tris = np.concatenate([I.tris, tr]); I.dend = np.concatenate([I.dend, de])
    I.tris0 = np.concatenate([I.tris0, tr[:, 0]])
    I.shadow = np.concatenate([I.shadow, np.ones(n, bool)]); I.light = np.concatenate([I.light, np.zeros(n, bool)])
    I.cliff = np.concatenate([np.zeros(len(I.x) - n, bool), np.ones(n, bool)])


def load_lights(A):
    """모든 점광원: (x, y, z, range, intensity, 출처 이름). 소품 광원은 META.light.offset 을 Unity 로컬로 바꿔 회전·크기 적용"""
    obj = json.load(open(os.path.join(DATA, 'objects.json')))
    L = []
    for o in obj['objects']:
        a = A.get(o['a'])
        if a is None or not a.light:
            continue
        b = a.light.get('offset', [0, 0, 0])
        loc = np.array([[-b[0], b[2], -b[1]]]) * o['s']
        p = np.array(o['p']) + qrot([o['q']], loc)[0]
        L.append((p[0], p[1], p[2], a.light.get('range', 8.0), a.light.get('intensity', 6.0), o['a'], o.get('far') or a.light.get('far', 0.0)))   # w3: 소품별 far (objects[].far)
    for l in obj['lights']:
        L.append((l['p'][0], l['p'][1], l['p'][2], l['r'], l['i'], '(lights far)' if l.get('far') else '(lights)', l.get('far', 0.0)))
    return L


def load_fx():
    return json.load(open(os.path.join(DATA, 'objects.json')))['fx']


def fx_particles(t, r, rate=1.0):
    """NecroWorldBuilder.MakeFx 의 maxParticles 와 정상 상태 입자 수, 평균 입자 넓이(m²)"""
    area = max(1.0, r * r)
    if t == 'mist':
        mp = int(np.clip(area * 0.08, 12, 160)); life = 19.0; em = mp / 20.0 * rate
        a, b = np.clip(r * 0.35, 4, 9), np.clip(r * 0.7, 8, 18)
    elif t == 'soulfire':
        mp = int(np.clip(area * 2, 40, 300)); life = 1.3; em = mp / 1.4 * rate; a, b = 0.12, 0.45
    elif t == 'fireflies':
        mp = int(np.clip(area * 0.12, 15, 220)); life = 6.0; em = mp / 6.0 * rate; a, b = 0.04, 0.1
    else:
        mp = int(np.clip(area * 0.3, 30, 500)); life = 7.5; em = mp / 8.0 * rate; a, b = 0.05, 0.2
    alive = min(mp, em * life)
    msz = (a * a + a * b + b * b) / 3.0          # 크기가 a~b 고르게일 때 size² 평균
    return mp, alive, msz


def load_details():
    """풀 기대 포기 수 [종류, z, x] (1 m 칸, 밀도 배율 전). PNG 맨 윗줄 = 북 → 뒤집어 행 0 = 남"""
    wj = json.load(open(os.path.join(DATA, 'world.json')))
    det = wj['details']
    chans = []
    for k, d in enumerate(det):
        png = Image.open(os.path.join(DATA, 'detail_%d.png' % (k // 4)))
        a = np.asarray(png.convert('RGBA'))[::-1, :, k % 4].astype(np.float32)
        chans.append(a / 255.0 * d['maxPerCell'])
    return np.stack(chans), det


def walk_grid(step):
    g = np.arange(BOUNDS[0] + step / 2, BOUNDS[1], step, dtype=np.float32)
    X, Z = np.meshgrid(g, g)
    return X.ravel(), Z.ravel(), len(g)


POIS = None


def nearest_poi(x, z):
    global POIS
    if POIS is None:
        POIS = json.load(open(os.path.join(DATA, 'world.json')))['pois']
    best, bd = None, 1e9
    for p in POIS:
        d = np.hypot(p['p'][0] - x, p['p'][2] - z)
        if d - p['r'] < bd:
            bd, best = d - p['r'], p
    if bd <= 0:
        return "%s 안" % best['name']
    return "%s 에서 %.0f m" % (best['name'], bd + best['r'])
