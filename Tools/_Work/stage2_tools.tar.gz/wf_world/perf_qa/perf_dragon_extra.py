# 아직 데이터에 없는 용 뼈(갈비뼈·등뼈·발톱·뼈 가시 70·흩어진 뼈 150)를 넣었을 때 용의 무덤 둘레 예산 변화
#   먼저: python3 perf_scan.py 16 1 ; python3 perf_scan.py 16 1 extra   그다음 python3 perf_dragon_extra.py
import numpy as np
from perf_common import *
a = np.load(os.path.join(OUT, 'scan_s16_b1.npz')); b = np.load(os.path.join(OUT, 'scan_s16_b1_extra.npz'))
m = np.hypot(a['cx'] - 470, a['cz'] - 1060) < 260
for k in ('tri_sec', 'draw_sec', 'sh_cnt_sec', 'sh_tri_sec', 'props80', 'p0_80', 'trees80', 'props150', 'p0_150'):
    i = int(np.argmax(b[k] * m))
    print("%-11s 용의 무덤 260 m 안 최대: 지금 %10.0f → 뼈 넣으면 %10.0f  (최대 자리 %.0f, %.0f)" % (k, (a[k] * m).max(), (b[k] * m).max(), a['cx'][i], a['cz'][i]))
# 용의 무덤 가운데 근처 (470, 1060) 에서 가장 가까운 격자 자리
i = int(np.argmin(np.hypot(a['cx'] - 470, a['cz'] - 1060)))
print("가운데 자리 (%.0f, %.0f):" % (a['cx'][i], a['cz'][i]))
for k in ('tri_sec', 'draw_sec', 'sh_cnt_sec', 'sh_tri_sec', 'props80', 'p0_80', 'trees80', 't0_80', 'props150', 'p0_150', 'trees150'):
    print("   %-11s 지금 %10.0f → 뼈 넣으면 %10.0f" % (k, a[k][i], b[k][i]))
