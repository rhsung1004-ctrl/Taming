# 카메라 자리마다 화면 안 삼각형(LOD 반영)·그리는 물체 수·그림자 물체 수, 반지름 80/150 m 안 소품·나무 수와 LOD0 합
#   python3 perf_scan.py [격자 간격 m=16] [lodBias=1] [extra]
#     extra: 아직 데이터에 없는 용 뼈(갈비뼈 1, 등뼈 3, 발톱 4, 뼈 가시 70, 흩어진 뼈 150)를 worldgen.lay_dragon 규칙대로 어림해 넣는다
# 화면 안 = 카메라 높이(지형 + 3 m)에서 가로 시야 85.6도(세로 55도, 16:9) 부채꼴. 방향은 5도 간격 72개 중 가장 무거운 쪽.
# 가림(지형·건물에 가려진 것)은 빼지 않는다 (Unity 는 가림 컬링을 굽지 않으면 화면 밖이 아닌 것은 모두 그린다)
import sys, math
import numpy as np
from perf_common import *

step = float(sys.argv[1]) if len(sys.argv) > 1 else 16.0
bias = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
use_extra = len(sys.argv) > 3 and sys.argv[3] == 'extra'
A = assets(bias)
h = load_height()

extra = None
if use_extra:
    # worldgen.lay_dragon 을 그대로 따라 자리를 어림한다 (DRAGON (470,1060), 반지름 215-15, 몸 축)
    rng = np.random.default_rng(5)
    cx, cz = 470.0, 1060.0
    a = np.array([0.78, -0.62]); a /= np.linalg.norm(a)
    side = np.array([-a[1], a[0]])
    head = np.array([cx + 26.0, cz - 20.0])
    at = lambda t, off=0.0: head - a * t + side * off
    extra = []
    for t, off, s, n in ((9.5, 0.8, 0.7, 'dragon_spine'), (19.5, -0.5, 1.0, 'dragon_ribs'), (31.5, 1.5, 1.0, 'dragon_spine'), (41.0, -1.5, 0.75, 'dragon_spine'),
                         (15.5, 8.5, 1.0, 'dragon_claw'), (17.0, -8.5, 0.9, 'dragon_claw'), (27.0, 8.5, 0.85, 'dragon_claw'), (28.5, -8.5, 0.8, 'dragon_claw')):
        p = at(t, off); extra.append((n, float(p[0]), float(p[1]), s))
    for n, k in (('bone_spike', 70), ('bones_scatter', 150)):
        for i in range(k):
            ang = rng.uniform(0, 2 * math.pi); d = math.sqrt(rng.uniform(0, 1)) * 200.0
            extra.append((n, cx + math.cos(ang) * d, cz + math.sin(ang) * d, 1.0))

I = load_instances(A, h, extra)
N = len(I.x)
cx, cz, ng = walk_grid(step)
cy = height_at(h, cx, cz).astype(np.float32) + CAM_HEIGHT
C = len(cx)
NB = 72
SEC = int(round(FOV_H / 5.0))        # 17 칸 = 85도
print("카메라 자리 %d (간격 %.0f m), 물체 %d (소품 %d, 지형 나무 %d), lodBias %.1f%s" % (C, step, N, (~I.tree).sum(), I.tree.sum(), bias, ", 용 뼈 어림 포함" if extra else ""))

keys = ['tri_sec', 'tri_all', 'draw_sec', 'draw_max', 'draw_max_yaw', 'cliff_draw', 'cliff_tri', 'draw_all', 'sh_cnt_sec', 'sh_tri_sec', 'sh_cnt_all', 'sh_tri_all', 'tree_draw_sec', 'tree_tri_sec',
        'props80', 'props150', 'trees80', 'trees150', 'p0_80', 'p0_150', 't0_80', 't0_150', 'yaw']
R = {k: np.zeros(C, np.float32) for k in keys}

def circ_max(b):
    """b: (C, NB) → 연속 SEC 칸 합의 최댓값과 그 가운데 방향(도)"""
    ext = np.concatenate([b, b[:, :SEC]], 1)
    cs = np.concatenate([np.zeros((b.shape[0], 1)), np.cumsum(ext, 1)], 1)
    win = cs[:, SEC:SEC + NB] - cs[:, :NB]
    k = np.argmax(win, 1)
    return win[np.arange(b.shape[0]), k], k, win

CH = 96
tris = I.tris; dend = I.dend
for c0 in range(0, C, CH):
    c1 = min(C, c0 + CH)
    n = c1 - c0
    dx = I.x[None, :] - cx[c0:c1, None]
    dz = I.z[None, :] - cz[c0:c1, None]
    dy = I.cy[None, :] - cy[c0:c1, None]
    d2 = np.hypot(dx, dz)
    d = np.sqrt(d2 * d2 + dy * dy)
    t = np.where(d < dend[None, :, 0], tris[None, :, 0], np.where(d < dend[None, :, 1], tris[None, :, 1], np.where(d < dend[None, :, 2], tris[None, :, 2], 0.0)))
    drawn = t > 0
    ang = (np.degrees(np.arctan2(dx, dz)) % 360.0)
    b = np.minimum((ang / 5.0).astype(np.int32), NB - 1)
    idx = (np.arange(n)[:, None] * NB + b).ravel()
    def binsum(w):
        return np.bincount(idx, weights=w.ravel().astype(np.float64), minlength=n * NB).reshape(n, NB)
    bt = binsum(t)
    v, k, win = circ_max(bt)
    sel = np.arange(n)
    R['tri_sec'][c0:c1] = v
    R['yaw'][c0:c1] = (k * 5.0 + SEC * 2.5) % 360.0
    R['tri_all'][c0:c1] = bt.sum(1)
    # 같은 방향(가장 무거운 부채꼴) 안의 다른 값
    def at_best(bb):
        ext = np.concatenate([bb, bb[:, :SEC]], 1)
        cs = np.concatenate([np.zeros((n, 1)), np.cumsum(ext, 1)], 1)
        return cs[sel, k + SEC] - cs[sel, k]
    bd = binsum(drawn.astype(np.float32))
    R['draw_sec'][c0:c1] = at_best(bd); R['draw_all'][c0:c1] = bd.sum(1)
    # w6a: 그리는 물체가 가장 많은 방향 (삼각형 최악 방향과 따로). 산 벽 덮개 조각 수·삼각형도 그 방향에서
    vmax, kmax, _ = circ_max(bd)
    R['draw_max'][c0:c1] = vmax; R['draw_max_yaw'][c0:c1] = (kmax * 5.0 + SEC * 2.5) % 360.0
    if hasattr(I, 'cliff'):
        cm = drawn & I.cliff[None, :]
        bc = binsum(cm.astype(np.float32)); btc = binsum(np.where(cm, t, 0))
        ext = np.concatenate([bc, bc[:, :SEC]], 1); cs_ = np.concatenate([np.zeros((n, 1)), np.cumsum(ext, 1)], 1)
        R['cliff_draw'][c0:c1] = cs_[sel, kmax + SEC] - cs_[sel, kmax]
        ext = np.concatenate([btc, btc[:, :SEC]], 1); cs_ = np.concatenate([np.zeros((n, 1)), np.cumsum(ext, 1)], 1)
        R['cliff_tri'][c0:c1] = cs_[sel, kmax + SEC] - cs_[sel, kmax]
    shm = drawn & I.shadow[None, :] & (d < SHADOW_DISTANCE)
    bs = binsum(shm.astype(np.float32)); bst = binsum(np.where(shm, t, 0))
    R['sh_cnt_sec'][c0:c1] = at_best(bs); R['sh_tri_sec'][c0:c1] = at_best(bst)
    R['sh_cnt_all'][c0:c1] = bs.sum(1); R['sh_tri_all'][c0:c1] = bst.sum(1)
    tm = drawn & I.tree[None, :]
    R['tree_draw_sec'][c0:c1] = at_best(binsum(tm.astype(np.float32)))
    R['tree_tri_sec'][c0:c1] = at_best(binsum(np.where(tm, t, 0)))
    for rr in (80, 150):
        m = d2 < rr
        R['props%d' % rr][c0:c1] = (m & ~I.tree[None, :]).sum(1)
        R['trees%d' % rr][c0:c1] = (m & I.tree[None, :]).sum(1)
        R['p0_%d' % rr][c0:c1] = np.where(m & ~I.tree[None, :], I.tris0[None, :], 0).sum(1)
        R['t0_%d' % rr][c0:c1] = np.where(m & I.tree[None, :], I.tris0[None, :], 0).sum(1)

tag = "s%d_b%g%s" % (step, bias, "_extra" if extra else "")
np.savez_compressed(os.path.join(OUT, 'scan_%s.npz' % tag), cx=cx, cz=cz, ng=ng, **R)

def top(key, k=8, sep=120.0, extra_keys=()):
    v = R[key]
    order = np.argsort(-v)
    got = []
    for i in order:
        if all(np.hypot(cx[i] - cx[j], cz[i] - cz[j]) > sep for j in got):
            got.append(i)
        if len(got) >= k:
            break
    for i in got:
        ex = "  ".join("%s %s" % (e, fmt(e, R[e][i])) for e in extra_keys)
        print("   (%5.0f, %5.0f) %-24s %s %s  %s" % (cx[i], cz[i], nearest_poi(cx[i], cz[i]), key, fmt(key, v[i]), ex))

def fmt(k, x):
    if 'tri' in k or k.startswith('p0') or k.startswith('t0'):
        return "%.2fM" % (x / 1e6)
    if k in ('yaw', 'draw_max_yaw'):
        return "%.0f도" % x
    return "%.0f" % x

print("\n[분포] 화면 안 삼각형 (소품+지형 나무, LOD 반영, 풀·지형 제외)")
for q in (50, 90, 99, 100):
    print("  %3d%% 자리: %.2fM" % (q, np.percentile(R['tri_sec'], q) / 1e6))
print("  4M 넘는 자리 %.1f%%, 5M 넘는 자리 %.1f%%" % ((R['tri_sec'] > 4e6).mean() * 100, (R['tri_sec'] > 5e6).mean() * 100))
print("\n[최악] 화면 안 삼각형")
top('tri_sec', 10, extra_keys=('yaw', 'tree_tri_sec', 'draw_sec', 'sh_cnt_sec', 'sh_tri_sec'))
print("\n[최악] 화면 안 그리는 물체 수 (LODGroup 하나 = 렌더러 하나)")
top('draw_sec', 6, extra_keys=('yaw', 'tree_draw_sec', 'tri_sec'))
print("\n[최악] 그리는 물체 수, 가장 많은 방향 (w6a: 삼각형 최악 방향과 따로 찾는다. 산 벽 덮개 조각 포함)")
top('draw_max', 6, extra_keys=('draw_max_yaw', 'cliff_draw', 'cliff_tri'))
print("  산 벽 덮개: 그 방향 조각 수 최대 %.0f, 삼각형 최대 %.2fM" % (R['cliff_draw'].max(), R['cliff_tri'].max() / 1e6))
print("\n[최악] 그림자 거리 150 m 안·화면 쪽 그림자 그리는 물체 수 (캐스케이드 겹침 전)")
top('sh_cnt_sec', 6, extra_keys=('sh_tri_sec', 'sh_cnt_all', 'sh_tri_all'))
for rr in (80, 150):
    print("\n[최악] 반지름 %d m 안 소품 수 (지형 나무 제외)" % rr)
    top('props%d' % rr, 6, extra_keys=('p0_%d' % rr, 'trees%d' % rr, 't0_%d' % rr))
    print("[최악] 반지름 %d m 안 지형 나무 수" % rr)
    top('trees%d' % rr, 4, extra_keys=('t0_%d' % rr, 'props%d' % rr))
    print("[최악] 반지름 %d m 안 LOD0 삼각형 합 (소품)" % rr)
    top('p0_%d' % rr, 4, extra_keys=('props%d' % rr,))
