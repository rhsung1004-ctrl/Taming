# 소품별 LOD 삼각형·LOD 전환 거리·컬링 거리와 월드 안 개수
#   python3 perf_assets.py [lodBias]
import sys, json, os, collections
from perf_common import *

bias = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
A = assets(bias)
I = load_instances(A)
cnt = collections.Counter(I.name.tolist())
print("lodBias %.1f, 시야각 %.0f (가로 %.1f)" % (bias, FOV_V, FOV_H))
print("%-16s %-8s %5s %6s %-22s %-22s %5s %4s" % ("이름", "kind", "개수", "크기", "LOD 삼각형", "LOD 끝 거리 m (크기1)", "그림자", "광원"))
rows = []
for n, a in A.items():
    rows.append((cnt.get(n, 0) * a.tris0, n, a))
tot0 = 0
for _, n, a in sorted(rows, key=lambda r: -r[0]):
    c = cnt.get(n, 0)
    tot0 += c * a.tris0
    print("%-16s %-8s %5d %6.2f %-22s %-22s %5s %4s  LOD0합 %8.0fk" % (n, a.kind, c, a.size, a.tris, [round(d) for d in a.dist], a.shadows, 'Y' if a.light else '-', c * a.tris0 / 1e3))
print("월드 전체 LOD0 삼각형 합 %.1fM (소품 %d + 나무 %d)" % (tot0 / 1e6, (~I.tree).sum(), I.tree.sum()))
