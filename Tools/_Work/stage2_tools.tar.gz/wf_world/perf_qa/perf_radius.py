# 카메라(주인공) 반지름 80 m · 150 m 원 안의 최악 자리 표: 소품 수, 소품 LOD0 합, 지형 나무 수, 나무 LOD0 합, 광원 수, 풀 포기(밀도 1/0.75), 효과 수·입자
#   python3 perf_radius.py [격자 간격 m=8]
import sys
import numpy as np
from perf_common import *

step = float(sys.argv[1]) if len(sys.argv) > 1 else 8.0
A = assets(); h = load_height(); I = load_instances(A, h)
L = load_lights(A); FX = load_fx()
G, det = load_details()
cnt = G.sum(0)[:2048, :2048]
cx, cz, ng = walk_grid(step)
lp = np.array([[l[0], l[2]] for l in L]); fp = np.array([[f['p'][0], f['p'][2]] for f in FX]); fa = np.array([fx_particles(f['type'], f['r'])[1] for f in FX])
S = 2048 + 320
F = np.fft.rfft2(np.pad(cnt, ((0, 320), (0, 320))))
def disk_sum(R):
    r = int(R) + 1
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1]
    ker = (np.hypot(xx, yy) <= R).astype(np.float32)
    K = np.zeros((S, S), np.float32); K[:ker.shape[0], :ker.shape[1]] = ker[::-1, ::-1]
    out = np.fft.irfft2(F * np.fft.rfft2(K), s=(S, S))
    return np.roll(np.roll(out, -r, 0), -r, 1)[:2048, :2048]
for R in (80, 150):
    res = {}
    n = len(cx)
    keys = ['소품', '소품 LOD0', '지형 나무', '나무 LOD0', '광원', '효과', '효과 입자']
    for k in keys: res[k] = np.zeros(n)
    for c0 in range(0, n, 512):
        sl = slice(c0, c0 + 512)
        d = np.hypot(I.x[None, :] - cx[sl, None], I.z[None, :] - cz[sl, None]) < R
        res['소품'][sl] = (d & ~I.tree).sum(1); res['지형 나무'][sl] = (d & I.tree).sum(1)
        res['소품 LOD0'][sl] = (d * (I.tris0 * ~I.tree)).sum(1); res['나무 LOD0'][sl] = (d * (I.tris0 * I.tree)).sum(1)
        dl = np.hypot(lp[None, :, 0] - cx[sl, None], lp[None, :, 1] - cz[sl, None]) < R
        res['광원'][sl] = dl.sum(1)
        df = np.hypot(fp[None, :, 0] - cx[sl, None], fp[None, :, 1] - cz[sl, None]) < R
        res['효과'][sl] = df.sum(1); res['효과 입자'][sl] = (df * fa).sum(1)
    gs = disk_sum(R)[np.clip(cz.astype(int), 0, 2047), np.clip(cx.astype(int), 0, 2047)]
    res['풀 (밀도 1)'] = gs
    print("\n== 반지름 %d m 원 (간격 %.0f m, %d 곳) ==" % (R, step, n))
    for k, v in res.items():
        i = int(np.argmax(v))
        fmt = (lambda x: "%.2fM" % (x / 1e6)) if 'LOD0' in k else (lambda x: "%.0fk (밀도 0.75: %.0fk)" % (x / 1e3, x * 0.75 / 1e3)) if '풀' in k else (lambda x: "%.0f" % x)
        print("   %-12s 최대 %-26s 중앙값 %-12s at (%5.0f, %5.0f) %s" % (k, fmt(v[i]), fmt(np.median(v)), cx[i], cz[i], nearest_poi(cx[i], cz[i])))
