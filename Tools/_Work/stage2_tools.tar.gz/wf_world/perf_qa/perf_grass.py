# 풀(지형 detail) 인스턴스·삼각형 예산
#   python3 perf_grass.py [격자 간격 m=8]
# 칸 값 = detail PNG / 255 × maxPerCell (NecroWorldGrid.TileDetails 의 기대값), × 밀도 배율 (지금 DetailDensity 0.75).
# 풀 거리 70 (지금 빌더 상수), 80 (할 일 #12), 110 (과제 설명의 값) 을 모두 센다.
# 하한 = 거리 안 1 m 칸만, 상한 = 거리에 걸친 32 m 패치 전체 (Unity 는 패치 단위로 그린다. 패치 안 거리 컷 여부는 확인 못 함)
# 화면 안 = 가로 85.6도 부채꼴, 방향 16개 (22.5도) 중 최대
import sys
import numpy as np
from perf_common import *

step = float(sys.argv[1]) if len(sys.argv) > 1 else 8.0
A = assets()
G, det = load_details()                      # [k, z, x] 칸당 기대 포기 수 (밀도 1)
names = [d['asset'] for d in det]
tri = np.array([A[n].tris[0] for n in names], np.float32)
cnt = G.sum(0)                                # 밀도 1
trimap = np.tensordot(tri, G, 1)
print("풀 종류 %s, 포기당 삼각형 %s" % (names, tri.astype(int).tolist()))
tot = G.sum((1, 2))
print("월드 전체 풀 포기 (밀도 1): %s  합 %.1fM  → 밀도 0.75: %.1fM" % (", ".join("%s %.1fM" % (n, t / 1e6) for n, t in zip(names, tot)), tot.sum() / 1e6, tot.sum() * 0.75 / 1e6))
print("1 m 칸 최대 포기 (밀도 1): %.1f, 평균 %.2f (걸을 수 있는 범위 안 %.2f)" % (cnt.max(), cnt.mean(), cnt[BOUNDS[0]:BOUNDS[1], BOUNDS[0]:BOUNDS[1]].mean()))

# 2 m 로 줄여 FFT 합성곱
c2 = cnt[:2048, :2048].reshape(1024, 2, 1024, 2).sum((1, 3))
t2 = trimap[:2048, :2048].reshape(1024, 2, 1024, 2).sum((1, 3))
F_c = np.fft.rfft2(np.pad(c2, ((0, 128), (0, 128))))
F_t = np.fft.rfft2(np.pad(t2, ((0, 128), (0, 128))))
S = 1024 + 128

def conv(F, ker):
    kh = ker.shape[0] // 2
    K = np.zeros((S, S), np.float32)
    K[:ker.shape[0], :ker.shape[1]] = ker[::-1, ::-1]
    out = np.fft.irfft2(F * np.fft.rfft2(K), s=(S, S))
    return np.roll(np.roll(out, -kh, 0), -kh, 1)[:1024, :1024]

cx, cz, ng = walk_grid(step)
ix = np.clip((cx / 2).astype(int), 0, 1023); iz = np.clip((cz / 2).astype(int), 0, 1023)
res = {}
for D in (70, 80, 110):
    r = int(np.ceil(D / 2)) + 1
    yy, xx = np.mgrid[-r:r + 1, -r:r + 1].astype(np.float32)
    dist = np.hypot(xx * 2, yy * 2)
    disk = (dist <= D).astype(np.float32)
    ang = np.degrees(np.arctan2(xx, yy)) % 360          # 0 = 북(+z), 시계 방향 = 동
    best_c = np.zeros(len(cx)); best_t = np.zeros(len(cx)); best_y = np.zeros(len(cx))
    for yaw in np.arange(0, 360, 22.5):
        da = np.abs((ang - yaw + 180) % 360 - 180)
        ker = disk * (da <= FOV_H / 2)
        cc = conv(F_c, ker)[iz, ix]; tt = conv(F_t, ker)[iz, ix]
        m = tt > best_t
        best_t = np.where(m, tt, best_t); best_c = np.where(m, cc, best_c); best_y = np.where(m, yaw, best_y)
    all_c = conv(F_c, disk)[iz, ix]; all_t = conv(F_t, disk)[iz, ix]
    res[D] = (all_c, all_t, best_c, best_t, best_y)

# 패치(32 m) 단위 상한: 거리에 걸친 패치는 통째로
P = cnt[:2048, :2048].reshape(64, 32, 64, 32).sum((1, 3))
PT = trimap[:2048, :2048].reshape(64, 32, 64, 32).sum((1, 3))
pz, px = np.mgrid[0:64, 0:64]
def patch_upper(D):
    out_c = np.zeros(len(cx)); out_t = np.zeros(len(cx))
    for c0 in range(0, len(cx), 2000):
        x = cx[c0:c0 + 2000, None]; z = cz[c0:c0 + 2000, None]
        nx = np.clip(x, (px.ravel() * 32)[None, :], (px.ravel() * 32 + 32)[None, :])
        nz = np.clip(z, (pz.ravel() * 32)[None, :], (pz.ravel() * 32 + 32)[None, :])
        m = np.hypot(nx - x, nz - z) <= D
        out_c[c0:c0 + 2000] = (m * P.ravel()[None, :]).sum(1)
        out_t[c0:c0 + 2000] = (m * PT.ravel()[None, :]).sum(1)
    return out_c, out_t

for D in (70, 80, 110):
    all_c, all_t, sc, st, sy = res[D]
    pu_c, pu_t = patch_upper(D)
    print("\n== 풀 거리 %d m ==" % D)
    for dens in (1.0, 0.75, 0.5):
        print("  밀도 %.2f: 거리 안(360도) 포기 최대 %6.0fk (중앙값 %5.0fk, 99%% %5.0fk) · 패치 상한 최대 %6.0fk | 화면 안 포기 최대 %5.0fk, 삼각형 최대 %5.2fM (중앙값 %4.2fM, 99%% %4.2fM) · 거리 안 삼각형 최대 %5.2fM"
              % (dens, all_c.max() * dens / 1e3, np.median(all_c) * dens / 1e3, np.percentile(all_c, 99) * dens / 1e3, pu_c.max() * dens / 1e3,
                 sc.max() * dens / 1e3, st.max() * dens / 1e6, np.median(st) * dens / 1e6, np.percentile(st, 99) * dens / 1e6, all_t.max() * dens / 1e6))
    for dens in (0.75,):
        print("  밀도 %.2f 에서 거리 안 포기 3만 넘는 자리 %.1f%%, 5만 넘는 자리 %.1f%%; 화면 안 풀 삼각형 3M 넘는 자리 %.1f%%"
              % (dens, (all_c * dens > 3e4).mean() * 100, (all_c * dens > 5e4).mean() * 100, (st * dens > 3e6).mean() * 100))
    # 최악 자리 (서로 150 m 떨어진 것)
    order = np.argsort(-st)
    got = []
    for i in order:
        if all(np.hypot(cx[i] - cx[j], cz[i] - cz[j]) > 150 for j in got):
            got.append(i)
        if len(got) >= 6:
            break
    for i in got:
        print("   (%5.0f, %5.0f) %-26s 방향 %5.1f도: 화면 안 %5.1fk 포기 / %5.2fM 삼각형, 거리 안 %5.1fk 포기 / %5.2fM, 패치 상한 %5.1fk  (밀도 0.75)"
              % (cx[i], cz[i], nearest_poi(cx[i], cz[i]), sy[i], sc[i] * .75 / 1e3, st[i] * .75 / 1e6, all_c[i] * .75 / 1e3, all_t[i] * .75 / 1e6, pu_c[i] * .75 / 1e3))
    np.savez_compressed(os.path.join(OUT, 'grass_D%d.npz' % D), cx=cx, cz=cz, all_c=all_c, all_t=all_t, sc=sc, st=st, sy=sy, pu_c=pu_c, pu_t=pu_t)

# 종류별로 어느 풀이 무거운지 (화면 안 삼각형이 가장 큰 자리 기준, 거리 70)
all_c, all_t, sc, st, sy = res[70]
i = int(np.argmax(st))
x, z = cx[i], cz[i]
yy, xx = np.mgrid[0:2048, 0:2048]
sel = (np.hypot(xx + 0.5 - x, yy + 0.5 - z) <= 70) & (np.abs((np.degrees(np.arctan2(xx + 0.5 - x, yy + 0.5 - z)) % 360 - sy[i] + 180) % 360 - 180) <= FOV_H / 2)
print("\n거리 70 m 최악 자리 (%.0f, %.0f) 방향 %.1f도의 종류별 (밀도 0.75):" % (x, z, sy[i]))
for k, n in enumerate(names):
    c = G[k][:2048, :2048][sel].sum() * 0.75
    print("   %-11s %6.0f 포기 × %3d = %5.2fM 삼각형" % (n, c, tri[k], c * tri[k] / 1e6))

# 지역별 평균 밀도 (반지름 안 1 m 칸 평균 포기 수, 밀도 1)
print("\n장소별 1 m 칸 평균 풀 포기 (밀도 1, 반지름 안):")
import json
for p in json.load(open(os.path.join(DATA, 'world.json')))['pois']:
    m = np.hypot(xx + 0.5 - p['p'][0], yy + 0.5 - p['p'][2]) <= p['r']
    sub = G[:, :2048, :2048][:, m].mean(1)
    print("   %-10s r %3d: 합 %.2f  (%s)" % (p['id'], p['r'], sub.sum(), ", ".join("%s %.2f" % (n, v) for n, v in zip(names, sub) if v > 0.05)))
