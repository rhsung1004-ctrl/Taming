# perf_total.py 결과(PERF_TAG=base 로 저장한 out/total_base.npz)를 위에서 본 그림으로: 화면 안 삼각형 합 (빨강 = 10M 이상, 초록 = 5M 이하)
#   PERF_TAG=base python3 perf_total.py 16 ; python3 perf_heatmap.py base
import sys, json
import numpy as np
from PIL import Image, ImageDraw
from perf_common import *
tag = sys.argv[1] if len(sys.argv) > 1 else 'base'
d = np.load(os.path.join(OUT, 'total_%s.npz' % tag))
ng = int(np.sqrt(len(d['cx'])))
v = d['best'].reshape(ng, ng)[::-1] / 1e6
t = np.clip((v - 5.0) / 5.0, 0, 1)
rgb = np.stack([255 * t, 255 * (1 - t), 40 + 0 * t], -1).astype(np.uint8)
im = Image.fromarray(rgb).resize((ng * 8, ng * 8), Image.NEAREST)
dr = ImageDraw.Draw(im)
for p in json.load(open(os.path.join(DATA, 'world.json')))['pois']:
    x = (p['p'][0] - BOUNDS[0]) / (BOUNDS[1] - BOUNDS[0]) * im.width; y = (1 - (p['p'][2] - BOUNDS[0]) / (BOUNDS[1] - BOUNDS[0])) * im.height
    dr.ellipse([x - 4, y - 4, x + 4, y + 4], outline=(255, 255, 255)); dr.text((x + 6, y - 6), p['id'], fill=(255, 255, 255))
im.save(os.path.join(OUT, 'total_%s.png' % tag))
print("저장", os.path.join(OUT, 'total_%s.png' % tag), "범위 %.1f~%.1fM" % (v.min(), v.max()))
