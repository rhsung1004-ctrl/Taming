#!/bin/bash
# 성능 예산 분석 전부 다시 돌리기 (결과: out/*.txt, out/*.npz, out/total_base.png). 약 3분, Python(numpy, PIL)만 쓴다.
# 데이터 위치를 바꾸려면: WORLD_DATA=<Data~ 폴더> KIT_OUT=<manifest·fbx 폴더> ./run_all.sh
set -e
cd "$(dirname "$0")"
python3 perf_assets.py 1 > out/assets_bias1.txt            # 소품별 LOD 삼각형·전환 거리·개수
python3 perf_scan.py 8 1 > out/scan_s8_b1.txt               # 소품+지형 나무 화면 안 삼각형·물체 수·그림자 (8 m 격자)
python3 perf_grass.py 8 > out/grass.txt                     # 풀 거리 70/80/110, 밀도 1/0.75/0.5
python3 perf_grass_patch.py 70 0.75 32 > out/grass_patch_70.txt   # 풀 32 m 패치 단위 상한
PERF_TAG=base python3 perf_total.py 16 70 0.75 1 > out/total_base.txt   # 같은 방향 합 (지금 빌더 설정)
python3 perf_heatmap.py base > /dev/null
python3 perf_total.py 16 80 0.75 1 > out/total_d80.txt
python3 perf_total.py 16 70 0.75 2 > out/total_bias2.txt
python3 perf_total.py 16 70 0.75 1 grass_a=0.667,grass_dead=0.75 > out/total_grass_cut.txt
PERF_DROP='{"dead_tree_a":0.3,"dead_tree_b":0.3,"dead_tree_c":0.3}' python3 perf_total.py 16 70 0.75 1 grass_a=0.667,grass_dead=0.75 > out/total_grass_trees_cut.txt
PERF_OVERRIDE='{"dead_tree_a":{"tris":[8419,2993,1010]},"dead_tree_b":{"tris":[6759,2400,811]},"dead_tree_c":{"tris":[9148,4026,1098]}}' python3 perf_total.py 16 70 0.75 1 > out/total_tree_lod2.txt
python3 perf_lights.py 4 > out/lights.txt                   # 광원 몰림, LightCuller 흉내
python3 perf_cells.py > out/cells.txt                       # 256 m 칸 표, 효과, 안개 겹침
python3 perf_radius.py 8 > out/radius.txt                   # 반지름 80/150 m 최악 자리
python3 perf_tree_sources.py > out/tree_sources.txt         # 지형 나무 지역별
python3 perf_scan.py 16 1 > out/scan_s16_b1.txt && python3 perf_scan.py 16 1 extra > out/scan_s16_b1_extra.txt && python3 perf_dragon_extra.py > out/dragon_extra.txt
for s in "1158 806" "998 798" "1044 872" "966 830" "446 574" "430 640" "1545 935" "1470 1400" "1390 430" "1010 1478" "1000 520"; do
  python3 perf_view.py $s auto > "out/view_${s// /_}.txt"   # 자리별 자세히 (방향 자동)
done
echo "끝: $(pwd)/out"
