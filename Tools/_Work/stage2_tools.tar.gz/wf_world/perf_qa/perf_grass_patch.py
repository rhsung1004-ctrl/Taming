# 풀 화면 안 상한: Unity 는 풀을 32 m 패치(SetDetailResolution(1024, 32)) 단위로 화면·거리 컬링해 패치를 통째로 그린다고 보면
# 부채꼴(가로 85.6도, 거리 D)에 걸친 패치의 풀을 모두 센다. 하한(1 m 칸)과 함께 본다.
#   python3 perf_grass_patch.py [풀 거리=70] [밀도=0.75] [격자 간격 m=16]
import sys
import numpy as np
from perf_common import *

DD = float(sys.argv[1]) if len(sys.argv) > 1 else DETAIL_DISTANCE
DENS = float(sys.argv[2]) if len(sys.argv) > 2 else DETAIL_DENSITY
step = float(sys.argv[3]) if len(sys.argv) > 3 else 16.0
A = assets()
G, det = load_details()
names = [q['asset'] for q in det]
tri = np.array([A[n].tris[0] for n in names], np.float32)
cnt = G.sum(0)[:2048, :2048] * DENS
tm = np.tensordot(tri, G, 1)[:2048, :2048] * DENS
Pc = cnt.reshape(64, 32, 64, 32).sum((1, 3)).ravel(); Pt = tm.reshape(64, 32, 64, 32).sum((1, 3)).ravel()
pz, px = np.mgrid[0:64, 0:64]; pz = pz.ravel() * 32.0; px = px.ravel() * 32.0
u = np.linspace(0, 32, 9)
sx, sz = np.meshgrid(u, u); sx = sx.ravel(); sz = sz.ravel()          # 패치 안 81 점
cx, cz, ng = walk_grid(step)
yaws = np.arange(0, 360, 22.5)
bestc = np.zeros(len(cx)); bestt = np.zeros(len(cx)); lowc = np.zeros(len(cx)); lowt = np.zeros(len(cx))
for i in range(len(cx)):
    near = np.nonzero((np.abs(px + 16 - cx[i]) < DD + 24) & (np.abs(pz + 16 - cz[i]) < DD + 24))[0]
    X = px[near, None] + sx[None, :] - cx[i]; Z = pz[near, None] + sz[None, :] - cz[i]
    dd = np.hypot(X, Z); aa = np.degrees(np.arctan2(X, Z)) % 360
    inr = dd <= DD
    for yw in yaws:
        ins = inr & (np.abs((aa - yw + 180) % 360 - 180) <= FOV_H / 2)
        hit = ins.any(1)
        tt = Pt[near[hit]].sum()
        if tt > bestt[i]:
            bestt[i] = tt; bestc[i] = Pc[near[hit]].sum()
print("풀 화면 안 패치 상한 (거리 %.0f m, 밀도 %.2f, 간격 %.0f m %d 곳): 포기 중앙값 %.1fk 최대 %.1fk, 삼각형 중앙값 %.2fM 99%% %.2fM 최대 %.2fM"
      % (DD, DENS, step, len(cx), np.median(bestc) / 1e3, bestc.max() / 1e3, np.median(bestt) / 1e6, np.percentile(bestt, 99) / 1e6, bestt.max() / 1e6))
i = int(np.argmax(bestt))
print("  최악 (%.0f, %.0f) %s" % (cx[i], cz[i], nearest_poi(cx[i], cz[i])))
