# 256 m 칸(Unity 의 Cell_x_z 부모와 같은 칸)마다: 소품 수, 소품 LOD0 삼각형 합, 광원 (소품 광원 + lights), 지형 나무 수와 LOD0 합,
# 풀 포기 수 (밀도 1 과 0.75), 효과 수와 입자 수. 그리고 안개(mist) 입자가 겹치는 층 수 (지면 픽셀 겹쳐 그리기 어림)
#   python3 perf_cells.py
import collections, json
import numpy as np
from perf_common import *

A = assets()
h = load_height()
I = load_instances(A, h)
L = load_lights(A)
FX = load_fx()
G, det = load_details()
cnt = G.sum(0)[:2048, :2048]
g256 = cnt.reshape(8, 256, 8, 256).sum((1, 3))

def cell(x, z):
    return (np.clip(np.asarray(z) // 256, 0, 7).astype(int), np.clip(np.asarray(x) // 256, 0, 7).astype(int))

T = {k: np.zeros((8, 8)) for k in ('props', 'p0', 'trees', 't0', 'lights', 'fx', 'part', 'shadow')}
cz, cx = cell(I.x, I.z)
np.add.at(T['props'], (cz[~I.tree], cx[~I.tree]), 1)
np.add.at(T['p0'], (cz[~I.tree], cx[~I.tree]), I.tris0[~I.tree])
np.add.at(T['trees'], (cz[I.tree], cx[I.tree]), 1)
np.add.at(T['t0'], (cz[I.tree], cx[I.tree]), I.tris0[I.tree])
np.add.at(T['shadow'], (cz, cx), I.shadow.astype(float))
lz, lx = cell([l[0] for l in L], [l[2] for l in L])
np.add.at(T['lights'], (lz, lx), 1)
for f in FX:
    z_, x_ = cell(f['p'][0], f['p'][2])
    T['fx'][z_, x_] += 1
    T['part'][z_, x_] += fx_particles(f['type'], f['r'])[1]

def show(key, title, fmt="%6.0f", scale=1.0):
    print("\n%s (행 = 북→남 z7..z0, 열 = 서→동 x0..x7)" % title)
    print("       " + "".join("%7s" % ("x%d" % i) for i in range(8)))
    for z in range(7, -1, -1):
        print("  z%d  " % z + "".join("%7s" % (fmt % (T[key][z, x] * scale) if key in T else fmt % (g256[z, x] * scale)) for x in range(8)))

show('props', "소품 수 (objects.json)")
show('p0', "소품 LOD0 삼각형 합 (M)", "%6.2f", 1e-6)
show('trees', "지형 나무 수 (trees.json)")
show('t0', "지형 나무 LOD0 삼각형 합 (M)", "%6.2f", 1e-6)
show('lights', "점광원 수 (소품 광원 + lights)")
show('grass', "풀 포기 수 (밀도 1, 천)", "%6.0f", 1e-3)
show('fx', "효과 수")
show('part', "효과 입자 (정상 상태 살아 있는 수)")

print("\n칸별 최댓값:")
for key, nm in (('props', '소품'), ('p0', '소품 LOD0'), ('trees', '나무'), ('t0', '나무 LOD0'), ('lights', '광원'), ('fx', '효과')):
    k = np.unravel_index(np.argmax(T[key]), (8, 8))
    print("   %-8s Cell_%d_%d (x %4d~%4d, z %4d~%4d) %s = %.0f" % (nm, k[1], k[0], k[1] * 256, k[1] * 256 + 256, k[0] * 256, k[0] * 256 + 256, nearest_poi(k[1] * 256 + 128, k[0] * 256 + 128), T[key][k]))
k = np.unravel_index(np.argmax(g256), (8, 8))
print("   풀       Cell_%d_%d = %.0fk 포기 (밀도 1)" % (k[1], k[0], g256[k] / 1e3))
print("\n월드 합: 소품 %d, 소품 LOD0 %.1fM, 지형 나무 %d, 나무 LOD0 %.1fM, 광원 %d, 효과 %d (입자 %.0f), 풀 %.1fM 포기 (밀도 1)"
      % (T['props'].sum(), T['p0'].sum() / 1e6, T['trees'].sum(), T['t0'].sum() / 1e6, T['lights'].sum(), T['fx'].sum(), T['part'].sum(), g256.sum() / 1e6))

# 효과
print("\n효과 종류별:")
for t, c in collections.Counter(f['type'] for f in FX).most_common():
    rs = [f['r'] for f in FX if f['type'] == t]
    ps = [fx_particles(t, r) for r in rs]
    print("   %-9s %3d 개, r %.0f~%.0f m, maxParticles 합 %d, 정상 상태 입자 합 %.0f" % (t, c, min(rs), max(rs), sum(p[0] for p in ps), sum(p[1] for p in ps)))
# 반지름 150 m 안 효과 최대
cxg, czg, ng = walk_grid(8)
fp = np.array([[f['p'][0], f['p'][2]] for f in FX]); fa = np.array([fx_particles(f['type'], f['r'])[1] for f in FX])
d = np.hypot(fp[None, :, 0] - cxg[:, None], fp[None, :, 1] - czg[:, None])
n150 = (d < 150).sum(1); p150 = ((d < 150) * fa[None, :]).sum(1)
i = int(np.argmax(n150)); j = int(np.argmax(p150))
print("반지름 150 m 안 효과 최대 %d 개 at (%.0f, %.0f) %s; 입자 최대 %.0f at (%.0f, %.0f) %s  (+ 주인공을 따라다니는 효과 3: 안개 r38, 불티 r32, 반딧불 r26)"
      % (n150[i], cxg[i], czg[i], nearest_poi(cxg[i], czg[i]), p150[j], cxg[j], czg[j], nearest_poi(cxg[j], czg[j])))

# 안개(mist) 겹침 층: 칸마다 Σ (살아 있는 입자 × 평균 크기²) / 상자 넓이 (2r)². 가로로 누운 판이라 아래를 보는 화면 한 점 = 그 칸의 층 수
lay = np.zeros((2048, 2048), np.float32)
for f in FX:
    if f['type'] != 'mist':
        continue
    mp, alive, msz = fx_particles('mist', f['r'])
    r = f['r']; x, z = f['p'][0], f['p'][2]
    e = r + np.sqrt(msz) / 2
    x0, x1 = int(max(0, x - e)), int(min(2047, x + e)); z0, z1 = int(max(0, z - e)), int(min(2047, z + e))
    lay[z0:z1 + 1, x0:x1 + 1] += alive * msz / ((2 * r) * (2 * r))
mp, alive, msz = fx_particles('mist', 38.0, 0.8)
amb = alive * msz / (76.0 * 76.0)
k = np.unravel_index(np.argmax(lay), lay.shape)
print("안개 판 겹침 층 (지면 한 점 위): 놓인 안개 최대 %.1f 층 at (%d, %d) %s, + 주인공 따라다니는 안개 %.1f 층 = %.1f 층" % (lay.max(), k[1], k[0], nearest_poi(k[1], k[0]), amb, lay.max() + amb))
for nm in ('swamp', 'graveyard', 'lake', 'dragon', 'forest'):
    p = [q for q in json.load(open(os.path.join(DATA, 'world.json')))['pois'] if q['id'] == nm][0]
    yy, xx = np.mgrid[0:2048, 0:2048]
    m = np.hypot(xx - p['p'][0], yy - p['p'][2]) < p['r']
    print("   %-9s 평균 %.1f 층, 최대 %.1f 층" % (nm, lay[m].mean() + amb, lay[m].max() + amb))
