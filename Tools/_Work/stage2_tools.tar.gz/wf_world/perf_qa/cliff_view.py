# w6a: 산 벽 덮개만 따로 — 자리마다 85° 부채꼴 안 덮개 조각 수·삼각형의 최대 방향 (그 방향의 소품+나무 그리는 물체·삼각형 합도)
#   WORLD_DATA=<Data~> KIT_OUT=<소품> python3 cliff_view.py [간격 m=8]
import sys
import numpy as np
from perf_common import *
step = float(sys.argv[1]) if len(sys.argv) > 1 else 8.0
A = assets(); h = load_height(); I = load_instances(A, h)
cx, cz, ng = walk_grid(step); cy = height_at(h, cx, cz).astype(np.float32) + CAM_HEIGHT
NB = 72; SEC = int(round(FOV_H / 5.0)); C = len(cx)
cl = I.cliff if hasattr(I, 'cliff') else np.zeros(len(I.x), bool)
R = {k: np.zeros(C, np.float32) for k in ('ctri', 'cdraw', 'tot_tri', 'tot_draw', 'yaw')}
for c0 in range(0, C, 96):
    c1 = min(C, c0 + 96); n = c1 - c0
    dx = I.x[None, :] - cx[c0:c1, None]; dz = I.z[None, :] - cz[c0:c1, None]; dy = I.cy[None, :] - cy[c0:c1, None]
    d = np.sqrt(dx * dx + dz * dz + dy * dy)
    t = np.where(d < I.dend[None, :, 0], I.tris[None, :, 0], np.where(d < I.dend[None, :, 1], I.tris[None, :, 1], np.where(d < I.dend[None, :, 2], I.tris[None, :, 2], 0.0)))
    b = np.minimum(((np.degrees(np.arctan2(dx, dz)) % 360) / 5).astype(np.int32), NB - 1)
    idx = (np.arange(n)[:, None] * NB + b).ravel()
    def bs(w):
        return np.bincount(idx, weights=w.ravel().astype(np.float64), minlength=n * NB).reshape(n, NB)
    def win(bb):
        ext = np.concatenate([bb, bb[:, :SEC]], 1); cs = np.concatenate([np.zeros((n, 1)), np.cumsum(ext, 1)], 1)
        return cs[:, SEC:SEC + NB] - cs[:, :NB]
    wct = win(bs(np.where(cl[None, :], t, 0))); k = np.argmax(wct, 1); s_ = np.arange(n)
    R['ctri'][c0:c1] = wct[s_, k]; R['yaw'][c0:c1] = (k * 5 + SEC * 2.5) % 360
    R['cdraw'][c0:c1] = win(bs((t > 0) & cl[None, :]))[s_, k]
    R['tot_tri'][c0:c1] = win(bs(t))[s_, k]; R['tot_draw'][c0:c1] = win(bs(t > 0))[s_, k]
print("산 벽 덮개만 (간격 %.0f m %d 곳): 덮개 삼각형이 가장 많은 방향" % (step, C))
for q in (50, 90, 99, 100):
    print("  %3d%%: 덮개 삼각형 %.2fM, 조각 %.0f" % (q, np.percentile(R['ctri'], q) / 1e6, np.percentile(R['cdraw'], q)))
o = np.argsort(-R['ctri'])[:6]
for i in o:
    print("   (%5.0f, %5.0f) 방향 %3.0f도: 덮개 %.2fM · %d 조각, 그 방향 전체(소품+나무+덮개) %.2fM · 그리는 물체 %d" % (cx[i], cz[i], R['yaw'][i], R['ctri'][i] / 1e6, R['cdraw'][i], R['tot_tri'][i] / 1e6, R['tot_draw'][i]))
o = np.argsort(-R['cdraw'])[:4]
for i in o:
    print("   조각 최다 (%5.0f, %5.0f) 방향 %3.0f도: %d 조각, 그 방향 그리는 물체 %d" % (cx[i], cz[i], R['yaw'][i], R['cdraw'][i], R['tot_draw'][i]))
