# w4: 한 카메라 자리·방향에서 그리는 물체 수를 소품 종류별로 (perf_scan 과 같은 규칙). python3 w4_draw_breakdown.py x z yaw
import sys, math, collections
import numpy as np
from perf_common import *
x0, z0, yaw = float(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3])
A = assets(1.0); h = load_height(); I = load_instances(A, h, None)
cy = float(height_at(h, np.array([x0]), np.array([z0]))[0]) + CAM_HEIGHT
dx, dz, dy = I.x - x0, I.z - z0, I.cy - cy
d = np.sqrt(dx * dx + dz * dz + dy * dy)
t = np.where(d < I.dend[:, 0], I.tris[:, 0], np.where(d < I.dend[:, 1], I.tris[:, 1], np.where(d < I.dend[:, 2], I.tris[:, 2], 0.0)))
ang = np.degrees(np.arctan2(dx, dz)) % 360.0
rel = (ang - yaw + 180) % 360 - 180
sel = (t > 0) & (np.abs(rel) <= FOV_H / 2)
names = np.array(I.name) if hasattr(I, 'name') else None
print("그리는 물체", int(sel.sum()))
if names is not None:
    c = collections.Counter(names[sel])
    dist = collections.defaultdict(list)
    for n_, dd in zip(names[sel], np.hypot(dx, dz)[sel]): dist[n_].append(dd)
    for k, v in c.most_common(30):
        print("  %-16s %5d  거리 중앙값 %5.0f m" % (k, v, np.median(dist[k])))
