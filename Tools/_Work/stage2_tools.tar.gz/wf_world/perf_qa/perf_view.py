# 한 자리·한 방향의 화면 예산을 자세히: 소품·나무 종류별(거리 띠별) 삼각형, 풀 종류별, 그림자 캐스케이드별 물체 수, 광원
#   python3 perf_view.py x z yaw|auto [lodBias=1] [풀거리=70] [풀밀도=0.75]
#     auto: 소품+나무+풀 삼각형 합이 가장 큰 방향 (5도 간격)
# yaw: 0 = 북(+z), 90 = 동. 카메라 높이 = 지형 + 3 m, 아래로 10도 숙임, 세로 시야 55도, 16:9
import sys, collections
import numpy as np
from perf_common import *

x0, z0 = float(sys.argv[1]), float(sys.argv[2])
yaw_arg = sys.argv[3]
bias = float(sys.argv[4]) if len(sys.argv) > 4 else 1.0
DD = float(sys.argv[5]) if len(sys.argv) > 5 else DETAIL_DISTANCE
DENS = float(sys.argv[6]) if len(sys.argv) > 6 else DETAIL_DENSITY
A = assets(bias)
h = load_height()
I = load_instances(A, h)
y0 = float(height_at(h, x0, z0)) + CAM_HEIGHT
G, det = load_details()
names = [q['asset'] for q in det]
dx, dz, dy = I.x - x0, I.z - z0, I.cy - y0
d2 = np.hypot(dx, dz); d = np.sqrt(d2 * d2 + dy * dy)
lvl = np.where(d < I.dend[:, 0], 0, np.where(d < I.dend[:, 1], 1, np.where(d < I.dend[:, 2], 2, 3)))
t = np.where(lvl < 3, I.tris[np.arange(len(d)), np.minimum(lvl, 2)], 0)
ang = np.degrees(np.arctan2(dx, dz)) % 360
r = int(DD) + 2
zs, xs = slice(max(0, int(z0) - r), int(z0) + r), slice(max(0, int(x0) - r), int(x0) + r)
yy, xx = np.mgrid[zs, xs]
gd = np.hypot(xx + 0.5 - x0, yy + 0.5 - z0)
ga = np.degrees(np.arctan2(xx + 0.5 - x0, yy + 0.5 - z0)) % 360
gtri = np.tensordot(np.array([A[n].tris[0] for n in names], np.float32), G[:, zs, xs], 1) * DENS
def total(yw):
    ins = np.abs((ang - yw + 180) % 360 - 180) <= FOV_H / 2
    gmm = (gd <= DD) & (np.abs((ga - yw + 180) % 360 - 180) <= FOV_H / 2)
    return t[ins].sum() + gtri[gmm].sum()
if yaw_arg == 'auto':
    cand = np.arange(0, 360, 5.0)
    tots = [total(yw) for yw in cand]
    yaw = float(cand[int(np.argmax(tots))])
    print("방향 자동: 소품+나무+풀 합이 가장 큰 방향 %.0f도 (가장 가벼운 방향 %.0f도 %.2fM)" % (yaw, cand[int(np.argmin(tots))], min(tots) / 1e6))
else:
    yaw = float(yaw_arg)
print("자리 (%.0f, %.0f) %s, 방향 %.0f도, 카메라 높이 %.1f m, lodBias %.1f, 풀 거리 %.0f m 밀도 %.2f" % (x0, z0, nearest_poi(x0, z0), yaw, y0, bias, DD, DENS))

insec = np.abs((ang - yaw + 180) % 360 - 180) <= FOV_H / 2
vis = insec & (t > 0)
bands = [(0, 30), (30, 80), (80, 150), (150, 400), (400, 1300)]
print("\n[소품·지형 나무] 화면 안 %d 개, 삼각형 %.2fM (지형 나무 %d 개 %.2fM)" % (vis.sum(), t[vis].sum() / 1e6, (vis & I.tree).sum(), t[vis & I.tree].sum() / 1e6))
print("  거리 띠별 삼각형: " + ", ".join("%d~%d m %.2fM (%d개)" % (a, b, t[vis & (d >= a) & (d < b)].sum() / 1e6, (vis & (d >= a) & (d < b)).sum()) for a, b in bands))
fogk = 0.0048
print("  (Exp2 안개 %.4f: 보이는 비율 = exp(-(밀도×거리)²) → 150 m %.0f%%, 300 m %.0f%%, 400 m %.0f%%, 600 m %.1f%%)" % (fogk, *[100 * np.exp(-(fogk * r) ** 2) for r in (150, 300, 400, 600)]))
rows = collections.defaultdict(lambda: [0, 0.0, 0, 0.0])
for i in np.nonzero(vis)[0]:
    r = rows[I.name[i]]
    r[0] += 1; r[1] += t[i]
    if d[i] >= 400:
        r[2] += 1; r[3] += t[i]
print("  종류별 (삼각형 큰 순): 이름 개수 삼각형 | 그중 400 m 너머")
for n, (c, tt, c4, t4) in sorted(rows.items(), key=lambda kv: -kv[1][1])[:16]:
    print("    %-15s %5d %6.2fM | %5d %5.2fM" % (n, c, tt / 1e6, c4, t4 / 1e6))

# 풀
gm = (gd <= DD) & (np.abs((ga - yaw + 180) % 360 - 180) <= FOV_H / 2)
gall = gd <= DD
gt = 0; gc = 0
parts = []
for k, n in enumerate(names):
    c = G[k][zs, xs][gm].sum() * DENS
    gc += c; gt += c * A[n].tris[0]
    if c > 0:
        parts.append("%s %.1fk" % (n, c / 1e3))
print("\n[풀] 화면 안 %.1fk 포기, %.2fM 삼각형 (%s); 거리 안(360도) %.1fk 포기" % (gc / 1e3, gt / 1e6, ", ".join(parts), G[:, zs, xs][:, gall].sum() * DENS / 1e3))
print("\n[합] 소품+나무+풀 = %.2fM 삼각형 (지형 자체·물·입자·그림자 패스 제외)" % ((t[vis].sum() + gt) / 1e6))

# 그림자: 캐스케이드 4 (10/30/70/150 m). 조각 절두체 꼭짓점을 감싸는 구 안의 그림자 물체 (물체 경계 구가 닿으면)
pitch = np.radians(-10)
fwd = np.array([np.sin(np.radians(yaw)) * np.cos(pitch), np.sin(pitch), np.cos(np.radians(yaw)) * np.cos(pitch)])
right = np.array([np.cos(np.radians(yaw)), 0, -np.sin(np.radians(yaw))])
up = np.cross(right, fwd)
th = np.tan(np.radians(FOV_V / 2)); tw = th * ASPECT
cam = np.array([x0, y0, z0])
splits = (0.2,) + CASCADE_SPLITS
P = np.stack([I.x, I.cy, I.z], 1)
rad = np.array([A[n].size for n in I.name]) * I.s * 0.5
tot_c = 0; tot_t = 0
print("\n[그림자] 달빛 캐스케이드별 그림자 그리는 물체 (LOD 는 카메라 기준)")
for k in range(4):
    n_, f_ = splits[k], splits[k + 1]
    corners = []
    for dist in (n_, f_):
        for sx in (-1, 1):
            for sy in (-1, 1):
                corners.append(cam + fwd * dist + right * sx * tw * dist + up * sy * th * dist)
    corners = np.array(corners)
    c = corners.mean(0); R = np.max(np.linalg.norm(corners - c, axis=1))
    m = (np.linalg.norm(P - c, axis=1) < R + rad) & I.shadow & (t > 0)
    tot_c += m.sum(); tot_t += t[m].sum()
    print("  %d: %5.0f~%3.0f m, 구 반지름 %5.1f m → %4d 개 %.2fM 삼각형 (지형 나무 %d)" % (k, n_, f_, R, m.sum(), t[m].sum() / 1e6, (m & I.tree).sum()))
print("  합: 그림자 그리기 %d 번, %.2fM 삼각형 (지형 그림자 제외)" % (tot_c, tot_t / 1e6))

# 광원
L = load_lights(A)
Lp = np.array([[l[0], l[2]] for l in L]); Lr = np.array([l[3] for l in L])
ld = np.hypot(Lp[:, 0] - x0, Lp[:, 1] - z0)
srt = np.sort(ld)
print("\n[광원] 반지름 80 m 안 %d 개 (90 m 안 %d), 가까운 48번째 %.1f m, 49번째 %.1f m" % ((ld < 80).sum(), (ld < 90).sum(), srt[47], srt[48]))
src = collections.Counter(L[i][5] for i in np.nonzero(ld < 80)[0])
print("  출처: " + ", ".join("%s %d" % kv for kv in src.most_common()))
