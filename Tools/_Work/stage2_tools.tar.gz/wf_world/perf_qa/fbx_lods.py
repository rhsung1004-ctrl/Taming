# FBX(바이너리) 안의 모델 이름별 삼각형 수를 센다 → LOD 별 삼각형 수 (perf_common 이 캐시해서 쓴다)
#   python3 fbx_lods.py <kit_out 폴더> [이름,...]     → 이름마다 LOD 별 삼각형 출력
import os, sys, re, json, struct, zlib
import numpy as np


def _read_prop(b, o):
    t = chr(b[o]); o += 1
    if t == 'Y':
        return struct.unpack_from('<h', b, o)[0], o + 2
    if t == 'C':
        return b[o] != 0, o + 1
    if t == 'I':
        return struct.unpack_from('<i', b, o)[0], o + 4
    if t == 'F':
        return struct.unpack_from('<f', b, o)[0], o + 4
    if t == 'D':
        return struct.unpack_from('<d', b, o)[0], o + 8
    if t == 'L':
        return struct.unpack_from('<q', b, o)[0], o + 8
    if t in 'fdlib':
        n, enc, cl = struct.unpack_from('<III', b, o); o += 12
        raw = b[o:o + cl]; o += cl
        if enc == 1:
            raw = zlib.decompress(raw)
        dt = {'f': '<f4', 'd': '<f8', 'l': '<i8', 'i': '<i4', 'b': 'u1'}[t]
        return np.frombuffer(raw, dt, n), o
    if t in 'SR':
        n = struct.unpack_from('<I', b, o)[0]; o += 4
        v = b[o:o + n]; o += n
        return (v.decode('utf8', 'replace') if t == 'S' else v), o
    raise ValueError("알 수 없는 속성 형식 %r" % t)


def _read_node(b, o, v64):
    if v64:
        end, nprop, plen = struct.unpack_from('<QQQ', b, o); o += 24
    else:
        end, nprop, plen = struct.unpack_from('<III', b, o); o += 12
    nl = b[o]; o += 1
    if end == 0:
        return None, o
    name = b[o:o + nl].decode('ascii', 'replace'); o += nl
    props = []
    for _ in range(nprop):
        p, o = _read_prop(b, o)
        props.append(p)
    kids = []
    null = 25 if v64 else 13
    while o < end:
        if end - o == null:
            break
        k, o2 = _read_node(b, o, v64)
        o = o2
        if k is None:
            break
        kids.append(k)
    return (name, props, kids), end


def parse(path):
    b = open(path, 'rb').read()
    assert b[:18] == b'Kaydara FBX Binary', "바이너리 FBX 아님"
    ver = struct.unpack_from('<I', b, 23)[0]
    v64 = ver >= 7500
    o = 27
    top = []
    while o < len(b):
        n, o = _read_node(b, o, v64)
        if n is None:
            break
        top.append(n)
    return top


def find(nodes, name):
    return [n for n in nodes if n[0] == name]


def model_tris(path):
    """{모델 이름: 삼각형 수} (모델에 붙은 Geometry 의 폴리곤을 부채꼴로 나눈 수)"""
    top = parse(path)
    objs = find(top, 'Objects')[0][2]
    conns = find(top, 'Connections')[0][2]
    geoms = {}
    for g in find(objs, 'Geometry'):
        pv = find(g[2], 'PolygonVertexIndex')
        if not pv:
            continue
        idx = pv[0][1][0]
        ends = np.nonzero(idx < 0)[0]
        sizes = np.diff(np.concatenate([[-1], ends]))
        geoms[g[1][0]] = int(np.sum(np.maximum(sizes - 2, 0)))
    models = {m[1][0]: m[1][1].split('\x00')[0] for m in find(objs, 'Model')}
    out = {}
    for c in conns:
        p = c[1]
        if p[0] == 'OO' and p[1] in geoms and p[2] in models:
            nm = models[p[2]]
            out[nm] = out.get(nm, 0) + geoms[p[1]]
    return out


def lod_tris(path):
    """[LOD0 삼각형, LOD1, ...] (이름의 _LODn 기준. 이름에 _LOD 가 없는 모델은 LOD0 에 넣는다)"""
    mt = model_tris(path)
    lv = {}
    for nm, t in mt.items():
        m = re.search(r'_LOD(\d+)', nm)
        k = int(m.group(1)) if m else 0
        lv[k] = lv.get(k, 0) + t
    return [lv[k] for k in sorted(lv)], mt


if __name__ == "__main__":
    kit = sys.argv[1]
    names = sys.argv[2].split(',') if len(sys.argv) > 2 else sorted(f[:-4] for f in os.listdir(kit) if f.endswith('.fbx') and not f.startswith('_'))
    for n in names:
        l, mt = lod_tris(os.path.join(kit, n + '.fbx'))
        print("%-20s LOD 삼각형 %s  모델 %s" % (n, l, mt))
