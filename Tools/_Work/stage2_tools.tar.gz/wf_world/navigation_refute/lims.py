import sys, time
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
h = nc.load_height()
G = nc.build_walk(1.0, "large", True, cell=1.0, h=h)
sl, XX, ZZ = G["sl"], G["XX"], G["ZZ"]
base = ~G["deep"] & ~G["pblock"]
base[G["deck"]] = True
world = G["world"]
sp = world["spawn"]["p"]
(b0x,b0z),(b1x,b1z) = world["bounds"]["min"], world["bounds"]["max"]
inb = (XX > b0x) & (XX < b1x) & (ZZ > b0z) & (ZZ < b1z)
for lim in [1.19, 1.0, 0.95, 0.9, 0.85, 0.8, 0.7, 0.6]:
    walk = base & (sl <= lim)
    lab, n = nc.label4(walk)
    L0 = lab[int(sp[2]), int(sp[0])]
    r = lab == L0
    edge = r[0,:].any() or r[-1,:].any() or r[:,0].any() or r[:,-1].any()
    band = r & ((XX < 12) | (XX > 2036) | (ZZ < 12) | (ZZ > 2036))
    sides = []
    for nm, m in (("W", XX<12),("E",XX>2036),("S",ZZ<12),("N",ZZ>2036)):
        mm = band & m
        if mm.any():
            zs, xs = np.nonzero(mm)
            sides.append("%s:%d cells x%d-%d z%d-%d" % (nm, mm.sum(), xs.min(), xs.max(), zs.min(), zs.max()))
    print("lim %.2f reach %.2f km2 outside %.0f m2 edgehit %s band %d %s" % (lim, r.sum()/1e6, (r & ~inb).sum(), edge, band.sum(), sides), flush=True)
