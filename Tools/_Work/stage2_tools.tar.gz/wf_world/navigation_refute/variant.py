import sys, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import navcommon as nc
from terrain import ss, fbm
h0 = nc.load_height()
ax = np.arange(nc.RES, dtype=np.float32); X, Z = np.meshgrid(ax, ax)
ZN, ZB = 1828.0, 1866.0
dx = np.abs(X - 1010.0)
dout = np.maximum.reduce([170 - X, X - 1878, 170 - Z, Z - ZN])
jit = 9.0 * fbm(X, Z, 1 / 110.0, 3, 930)                 # 벽 발치 선을 ±십여 m 구불구불하게
amp = 60.0 + 15.0 * fbm(X, Z, 1 / 260.0, 2, 940)
d2 = dout + jit
gap = ss(dx, 8.5, 13.0)
fade = ss(-dout, -140, -60)
wall = amp * ss(d2, -5, 25) * fade * np.where((Z > 1700) & (Z < ZB + 30), gap, 1.0)
back = amp * ss(Z - ZB + jit, -5, 25) * fade * (1 - gap) * (Z > 1700)
h = h0 + np.maximum(wall, back)
print("jitter range %.1f..%.1f, amp %.0f..%.0f, clipped(>=319) m2 %d, foot min dout %.1f" % (jit.min(), jit.max(), amp.min(), amp.max(), (h >= 319).sum(), dout[(wall > 0.5)].min()))
h = np.minimum(h, 319).astype(np.float32)
for lim in (1.0, 1.19):
    G = nc.build_walk(lim, "large", True, cell=1.0, h=h)
    reach, lab, L0 = nc.reach_from_spawn(G)
    XX, ZZ, hc = G["XX"], G["ZZ"], G["hc"]
    inb = (XX > 170) & (XX < 1878) & (ZZ > 170) & (ZZ < ZN)
    ok = ~G["pblock"]; ok[G["deck"]] = True
    sp = G["world"]["spawn"]["p"]
    fw = nc.flood_dir(hc, ok, (int(sp[0]), int(sp[2])), 1.0, lim, 1e9)
    band12 = ((XX < 12) | (XX > 2036) | (ZZ < 12) | (ZZ > 2036))
    print("lim %.2f reach %.2f km2, outside(bounds z<=%d) %d m2, edge12 %d, fall-allowed edge3 %d, maxdist out %.1f" % (
        lim, reach.sum() / 1e6, ZN, (reach & ~inb).sum(), (reach & band12).sum(),
        (fw & ((XX < 3) | (XX > 2045) | (ZZ < 3) | (ZZ > 2045))).sum(),
        float(np.max(np.where(reach, np.maximum.reduce([170 - XX, XX - 1878, 170 - ZZ, ZZ - ZN]), -1e9)))), flush=True)
    miss = []
    for p in G["world"]["pois"]:
        x, _, z = p["p"]; R = p["r"]
        if not ((np.hypot(XX - x, ZZ - z) <= R) & reach).any(): miss.append(p["id"])
    print("  unreached POIs:", miss)
G = nc.build_walk(1.0, "large", True, cell=1.0, h=h)
reach, lab, L0 = nc.reach_from_spawn(G)
XX, ZZ = G["XX"], G["ZZ"]
do = np.maximum.reduce([170 - XX, XX - 1878, 170 - ZZ, ZZ - ZN])
o = reach & (do > 3)
ol, on = nc.label4(o)
for k in range(1, on + 1):
    zs, xs = np.nonzero(ol == k)
    if len(xs) > 20:
        print("out cluster x %d-%d z %d-%d n %d maxdout %.1f" % (xs.min(), xs.max(), zs.min(), zs.max(), len(xs), do[ol == k].max()))
