import numpy as np
from collections import deque
D="/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_out3/Data~/"
h=np.fromfile(D+"height.r16",dtype="<u2").reshape(2049,2049).astype(np.float64)*320/65535
gx=((h[:-1,1:]+h[1:,1:])-(h[:-1,:-1]+h[1:,:-1]))/2
gz=((h[1:,:-1]+h[1:,1:])-(h[:-1,:-1]+h[:-1,1:]))/2
s=np.hypot(gx,gz)
ZZ,XX=np.mgrid[0:2048,0:2048]+0.5
corr=(np.abs(XX-1010)<70)&(ZZ>1700)
def flood(w,sz,sx):
    r=np.zeros(w.shape,bool); q=deque([(sz,sx)]); r[sz,sx]=True
    H,W=w.shape
    while q:
        z,x=q.popleft()
        for dz,dx in ((1,0),(-1,0),(0,1),(0,-1)):
            a,b=z+dz,x+dx
            if 0<=a<H and 0<=b<W and w[a,b] and not r[a,b]:
                r[a,b]=True; q.append((a,b))
    return r
for lim in ():
    r=flood((s<=lim)&~corr,492,1000)
    print(lim,{k:int(v.sum()) for k,v in (("W",r[:,:3]),("E",r[:,-3:]),("S",r[:3,:]),("N",r[-3:,:]))},flush=True)
print("--- 12m band, min distance to edge")
for lim in (1.19,1.0,0.9,0.8):
    r=flood((s<=lim)&~corr,492,1000)
    zs,xs=np.nonzero(r)
    out={}
    for k,v in (("W",r[:,:12]),("E",r[:,-12:]),("S",r[:12,:]),("N",r[-12:,:])):
        out[k]=int(v.sum())
    i=np.argmin(xs); j=np.argmax(zs); k=np.argmax(xs); l=np.argmin(zs)
    print(lim,out,"minx (%d,%d) h%.0f maxz (%d,%d) h%.0f maxx %d minz %d"%(xs[i],zs[i],h[zs[i],xs[i]],xs[j],zs[j],h[zs[j],xs[j]],xs.max(),zs.min()),
          "outside bounds m2", int((r&((XX<170)|(XX>1878)|(ZZ<170)|(ZZ>1878))).sum()),flush=True)
