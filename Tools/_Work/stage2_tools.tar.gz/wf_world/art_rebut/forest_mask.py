import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import numpy as np
import artcommon as C
from terrain import fbm, ss, disk
W = C.world(); dets = W["details"]; names = [d["asset"] for d in dets]
maxpc = np.array([d["maxPerCell"] for d in dets], np.float32)
dt = C.detail()[..., :len(names)]
inst = (dt * maxpc)[:2048, :2048]
man = C.manifest()
sc2 = np.array([(d["maxScale"]**3 - d["minScale"]**3) / 3 / (d["maxScale"] - d["minScale"]) for d in dets])
top = np.array([man[n]["size"][0] * man[n]["size"][1] for n in names]) * sc2
side = np.array([math.sqrt(man[n]["size"][0] * man[n]["size"][1]) * man[n]["size"][2] for n in names]) * sc2
n = 2049
ax = np.arange(n, dtype=np.float32); X, Z = np.meshgrid(ax, ax)
sl = C.slope()
F = np.zeros((n, n), np.float32)
for (c, R), seed in ((((430, 640), 235), 1301), (((1470, 1420), 175), 1311)):
    rs, cs, d = disk((n, n), c[0], c[1], R + 40)
    edge = R + 45 * fbm(X[rs, cs], Z[rs, cs], 1 / 120, 3, seed)
    m = np.zeros((n, n), np.float32)
    m[rs, cs] = ss(-(d / edge), -1.0, -0.6) * (0.55 + 0.45 * ss(fbm(X[rs, cs], Z[rs, cs], 1 / 60, 3, seed + 1), -0.4, 0.4))
    m *= (sl < 0.7)
    F = np.maximum(F, m)
F = F[:2048, :2048]
np.save("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art_rebut/forest.npy", F)
wm = C.water_mask()[:2048, :2048]
wk = C.walkable()[:2048, :2048]
sp = C.splat()[:2048, :2048]
lay = [l["name"] for l in W["layers"]]
for th in (0.3, 0.6, 0.85):
    m = (F >= th) & ~wm & wk
    x = inst[m]; cnt = x.mean(0); ta = (x * top).mean(0); sa = (x * side).mean(0); occ = np.minimum(x, 1).mean(0)
    print("W.forest ≥ %.2f: %d 칸 (%.1f ha), leaves 층 평균 %.2f" % (th, m.sum(), m.sum() / 1e4, sp[..., lay.index('leaves')][m].mean()))
    for k, nm in enumerate(names):
        print("   %-10s 포기 %.2f/m² (%4.1f%%)  ≥1칸 %4.1f%%  위넓이 %4.1f%%  옆넓이 %4.1f%%" % (nm, cnt[k], 100 * cnt[k] / cnt.sum(), 100 * occ[k], 100 * ta[k] / ta.sum(), 100 * sa[k] / sa.sum()))
    print("   합계 %.2f/m², 위넓이 %.2f m²/m²" % (cnt.sum(), ta.sum()))
# 숲 소품(나무·덤불) 밀도
t = C.trees()
tp = t["prototypes"]
cnt = {}
for i in t["instances"]:
    xi, zi = int(i[1]), int(i[2])
    if 0 <= xi < 2048 and 0 <= zi < 2048 and F[zi, xi] >= 0.6:
        cnt[tp[i[0]]] = cnt.get(tp[i[0]], 0) + 1
area = ((F >= 0.6) & wk).sum() / 1e4
print("W.forest≥0.6 안 지형 나무 (그루/ha):", {k: round(v / area, 1) for k, v in cnt.items()})
