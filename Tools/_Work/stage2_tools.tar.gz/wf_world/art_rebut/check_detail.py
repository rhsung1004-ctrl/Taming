import sys, os, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C
W = C.world(); dets = W["details"]; names = [d["asset"] for d in dets]
maxpc = np.array([d["maxPerCell"] for d in dets], np.float32)
dt = C.detail()[..., :len(names)]
# Unity: 칸 c = 화소 c, c+1 (가로세로) 평균
d4 = (dt[:-1, :-1] + dt[1:, :-1] + dt[:-1, 1:] + dt[1:, 1:]) / 4 if dt.shape[0] > 2048 else None
v = dt.copy()
v4 = np.zeros_like(v)
v4[:-1, :-1] = (v[:-1, :-1] + v[1:, :-1] + v[:-1, 1:] + v[1:, 1:]) / 4
v4[-1, :] = v[-1, :]; v4[:, -1] = v[:, -1]
inst = v4 * maxpc
man = C.manifest()
sc = np.array([(d["minScale"] + d["maxScale"]) / 2 for d in dets])
sc2 = np.array([(d["maxScale"]**3 - d["minScale"]**3) / 3 / (d["maxScale"] - d["minScale"]) for d in dets])  # E[s^2]
top = np.array([man[n]["size"][0] * man[n]["size"][1] for n in names]) * sc2    # 위에서 본 넓이 m²
side = np.array([math.sqrt(man[n]["size"][0] * man[n]["size"][1]) * man[n]["size"][2] for n in names]) * sc2  # 옆에서 본 넓이 m²
print("포기 1개 넓이 (위 m², 옆 m²):", {n: (round(a, 3), round(b, 3)) for n, a, b in zip(names, top, side)})
wk = C.walkable()[:2048, :2048]; sl = C.slope()[:2048, :2048]
field = wk & (sl < 0.58)
I = inst[:2048, :2048]
sp = C.splat()[:2048, :2048]
lay = [l["name"] for l in W["layers"]]
ax = np.arange(2048); X, Z = np.meshgrid(ax, ax)
wm = C.water_mask()[:2048, :2048]

def report(label, m):
    x = I[m]
    cnt = x.mean(0)
    occ = np.minimum(x, 1).mean(0)                # 확률 반올림: 포기 1개 이상일 확률 = min(기대값,1)
    ta = (x * top).mean(0); sa = (x * side).mean(0)
    print("%-26s n=%7d" % (label, m.sum()))
    print("   %-10s %6s %6s %7s %7s %7s" % ("", "포기/m²", "개수%", "≥1칸%", "위넓이%", "옆넓이%"))
    for k, n in enumerate(names):
        print("   %-10s %6.2f %6.1f %7.1f %7.1f %7.1f" % (n, cnt[k], 100 * cnt[k] / cnt.sum(), 100 * occ[k], 100 * ta[k] / ta.sum(), 100 * sa[k] / sa.sum()))
    print("   합계 %.2f/m², 위넓이 합 %.2f m²/m², 옆넓이 합 %.2f" % (cnt.sum(), ta.sum(), sa.sum()))

report("들판 전체(art_detail 기준)", field)
# 숲: leaves 층 무게 / 지형 나무 밀도로 숲 바닥을 잡는다
leaves = sp[..., lay.index("leaves")]; ash = sp[..., lay.index("ash")]; grass = sp[..., lay.index("grass")]
for pid, nm, px, pz, r in C.poi_list():
    if pid in ("forest", "tree", "dragon"):
        m = ((X - px) ** 2 + (Z - pz) ** 2 <= r * r) & ~wm
        report("POI " + pid + " 원 전체", m)
# 나무 밀도
t = C.trees(); tn = np.zeros((2048 // 16, 2048 // 16))
for i in t["instances"]:
    tn[min(int(i[2]) // 16, 127), min(int(i[1]) // 16, 127)] += 1
print("나무 프로토타입:", t["prototypes"])
tdens = np.kron(tn, np.ones((16, 16))) / 256 * 1e4   # 그루/ha
report("leaves 층 ≥ 0.5 (낙엽 바닥)", (leaves >= 0.5) & field)
report("나무 ≥ 40그루/ha (숲 속)", (tdens >= 40) & field)
report("ash 층 ≥ 0.5 (잿빛 바닥)", (ash >= 0.5) & ~wm)
report("ash 층 ≥ 0.8", (ash >= 0.8) & ~wm)
dm = ((X - 470) ** 2 + (Z - 1060) ** 2 <= 160 ** 2) & ~wm
print("용의 무덤 원 안 ash 층 평균 %.2f, ash≥0.5 칸 %.1f %%" % (ash[dm].mean(), 100 * (ash[dm] >= 0.5).mean()))
print("용의 무덤 원 안 층 평균:", {l: round(float(sp[..., k][dm].mean()), 2) for k, l in enumerate(lay)})
