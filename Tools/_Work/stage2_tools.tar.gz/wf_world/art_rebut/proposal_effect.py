import sys, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C
W = C.world(); dets = W["details"]; names = [d["asset"] for d in dets]
maxpc = np.array([d["maxPerCell"] for d in dets], np.float32)
dt = C.detail()[:2048, :2048, :len(names)]
sp = C.splat()[:2048, :2048]; lay = [l["name"] for l in W["layers"]]
F = np.load("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art_rebut/forest.npy")
A = sp[..., lay.index("leaves")] * 0.7 + sp[..., lay.index("moss")] * 0.45
ratio = (A + 1.1 * F) / (A + 0.5 * F + 1e-6)
kf = names.index("fern_a")
fern_now = dt[..., kf] * maxpc[kf]
fern_new = np.minimum(dt[..., kf] * ratio, 1) * maxpc[kf]
man = C.manifest()
print("forest 안 작은 발광·꽃 소품 둘레(0.8~2.5 m) 고사리 포기/m²: 지금 → 제안 후 (추정)")
objs = collections.defaultdict(list)
for o in C.objects()["objects"]:
    a = o["a"]
    if a not in ("mushroom_glow", "mushroom_toxic", "flower_lily", "roots"):
        continue
    x, z = o["p"][0], o["p"][2]
    xi, zi = int(x), int(z)
    if not (3 <= xi < 2045 and 3 <= zi < 2045) or F[zi, xi] < 0.3:
        continue
    zz, xx = np.mgrid[zi - 3:zi + 4, xi - 3:xi + 4]
    d = np.sqrt((xx + 0.5 - x) ** 2 + (zz + 0.5 - z) ** 2)
    ring = (d >= 0.8) & (d <= 2.5)
    objs[a].append((fern_now[zi - 3:zi + 4, xi - 3:xi + 4][ring].mean(), fern_new[zi - 3:zi + 4, xi - 3:xi + 4][ring].mean()))
for a, v in objs.items():
    v = np.array(v)
    print("  %-15s 키 %.2f m %3d 개: %.2f → %.2f /m² (고사리 0.64 m 가 더 큼)" % (a, C.prop_height(a, 1.0), len(v), v[:, 0].mean(), v[:, 1].mean()))
m = F >= 0.6
print("W.forest≥0.6 고사리 포기/m²: 지금 %.2f → 제안 후 %.2f" % (fern_now[m].mean(), fern_new[m].mean()))
# 빛: 숲 광원 중 버섯 비율
L = W.get("lights")
