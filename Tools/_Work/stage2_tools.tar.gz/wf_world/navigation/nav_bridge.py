#!/usr/bin/env python3
# 끊어진 개울 다리: 자리·회전·높이가 개울·둑·길 끝과 맞는지, 건너갈 수 있는지
#   python3 nav_bridge.py
# 다리 모양 (Tools/BlenderKit/assets_landmarks.py bridge_ruin): 경간 로컬 X ±7.0 m, 상판 deck(u) = 0.12 + 1.78(1-(u/7)²),
#   포장 윗면 ≈ deck + 0.02, 걷는 폭 |v| ≤ 1.55 (벽 |v| = 2.0), 아치 구멍 |u| ≤ 4.6 (시작 높이 -1.6, 꼭대기 아랫면 +1.0)
import math
import numpy as np
import navcommon as nc

h = nc.load_height()
sl = nc.cell_slope(h)
objs = nc.load_objects()
world = nc.load_world()
C = nc.Curves()
lev = nc.water_surface(objs)
br = [o for o in objs["objects"] if o["a"] == "bridge_ruin"][0]
bx, by, bz = br["p"]
yaw = nc.yaw_of_q(br["q"])
au, av = nc.local_axes(yaw)
XL, SP, ZS, ZT = 7.0, 4.6, -1.6, 1.0
deck = lambda u: 0.12 + 1.78 * np.maximum(0.0, 1 - (u / XL) ** 2)
pool = world["levels"]["creekPool"]
print("bridge_ruin: p (%.3f, %.3f, %.3f), yaw %.2f°, 로컬 X(경간) = (%.4f, %.4f), 크기 s %.2f" % (bx, by, bz, yaw, au[0], au[1], br["s"]))
print("  worldgen 다시 계산: 다리 자리 (%.3f, %.3f), 경간 방향 (%.4f, %.4f), 개울 방향 (%.4f, %.4f), 경간·개울 사잇각 %.1f°" % (
    C.bridge_p[0], C.bridge_p[1], C.bridge_axis[0], C.bridge_axis[1], C.creek_dir[0], C.creek_dir[1],
    math.degrees(math.acos(abs(float(np.dot(au, C.creek_dir)))))))
print("  둑 높이(bridge_bank) = y + 0.02 = %.3f, 웅덩이 수면 %.3f, 개울 바닥(설계) = 둑 − 2.1 = %.3f" % (by + 0.02, pool, by + 0.02 - 2.1))

# 개울 곡선이 다리 가운데를 지나는지 (곡선까지 거리)
d_c = np.min(np.hypot(C.creek[:, 0] - bx, C.creek[:, 1] - bz))
print("  다리 가운데 ↔ 개울 곡선 거리 %.2f m" % d_c)

print("\n경간 줄 (v=0) 과 양쪽 난간 안쪽 (v=±1.55): u 마다 지형 높이 − 상판 윗면 높이 (양수 = 지형이 상판을 뚫고 올라옴), 수면")
print("   u     지형(v=0)  상판    차이   | 차이(v=-1.55) 차이(v=+1.55) | 수면   물깊이  지형기울기")
rows = []
for u in np.arange(-16, 16.01, 1.0):
    vals = []
    for v in (0.0, -1.55, 1.55):
        x = bx + au[0] * u + av[0] * v
        z = bz + au[1] * u + av[1] * v
        vals.append(float(nc.bilinear(h, [x], [z])[0]))
    x = bx + au[0] * u; z = bz + au[1] * u
    top = by + float(deck(u)) + 0.02 if abs(u) <= XL else float("nan")
    wl = lev[int(round(z)), int(round(x))]
    s_ = sl[int(z), int(x)]
    print("  %+5.1f  %8.3f  %8.3f  %+6.3f |   %+6.3f      %+6.3f     | %6.2f  %5.2f  %.2f" % (
        u, vals[0], top, vals[0] - top, vals[1] - top, vals[2] - top, wl if wl > -1e9 else float("nan"), (wl - vals[0]) if wl > -1e9 else 0, s_))
    rows.append((u, vals, top))

# 상판 끝 ↔ 둑·길 이음
print("\n상판 끝 이음 (CharacterController stepOffset 0.35)")
for sgn, nm in ((1, "동쪽 끝 (묘지 쪽)"), (-1, "서쪽 끝 (용의 무덤 쪽)")):
    u = sgn * XL
    top = by + float(deck(u)) + 0.02
    for du in (0.0, 0.3, 0.6, 1.0, 2.0, 4.0):
        uu = u + sgn * du
        hs = [float(nc.bilinear(h, [bx + au[0] * uu + av[0] * v], [bz + au[1] * uu + av[1] * v])[0]) for v in (-1.55, 0, 1.55)]
        print("  %s u=%+5.1f: 지형 %.3f / %.3f / %.3f (v=-1.55/0/+1.55), 상판 끝 윗면 %.3f → 턱 %+.3f ~ %+.3f" % (
            nm, uu, hs[0], hs[1], hs[2], top, top - max(hs), top - min(hs)))
# 길 끝 (worldgen: 경간 ±7.6 m)
for sgn in (1, -1):
    x = bx + au[0] * 7.6 * sgn; z = bz + au[1] * 7.6 * sgn
    print("  길 끝 (%.1f, %.1f) 지형 %.3f, 둑 설계 높이 %.3f (+0.12 = %.3f)" % (x, z, nc.bilinear(h, [x], [z])[0], by + 0.02, by + 0.14))

# 아치 아래: 개울 폭 (수면 높이에서 물 폭, 둑 높이에서 골 폭) 과 아치 구멍 비교
print("\n아치 아래 개울 단면 (v=0 줄, 경간 방향 = 개울을 가로지름)")
us = np.arange(-9, 9.01, 0.1)
hh = np.array([nc.bilinear(h, [bx + au[0] * u], [bz + au[1] * u])[0] for u in us])
wet = us[hh < pool]
print("  웅덩이 수면 %.3f 에서 물 폭: u %.1f ~ %.1f (%.1f m), 바닥 최저 %.3f (물 깊이 %.2f)" % (pool, wet.min(), wet.max(), wet.max() - wet.min(), hh.min(), pool - hh.min()))
bank = by + 0.02
dry = us[hh < bank - 0.05]
print("  둑 높이 −0.05 아래 골 폭: u %.1f ~ %.1f (%.1f m)  ↔ 아치 구멍 |u| ≤ %.1f (%.1f m), 다리 길이 %.1f m" % (dry.min(), dry.max(), dry.max() - dry.min(), SP, 2 * SP, 2 * XL))
r = (SP * SP + (ZT - ZS) ** 2) / (2 * (ZT - ZS))
zc = ZT - r
for u in (0.0, 2.0, 3.0, 3.5, 4.0, 4.6):
    under = by + (zc + math.sqrt(max(0, r * r - u * u)) if abs(u) < SP else ZS)
    g = float(nc.bilinear(h, [bx + au[0] * u], [bz + au[1] * u])[0])
    print("  u=%+.1f: 아치 아랫면 %.2f, 지형 %.2f, 머리 위 틈 %.2f m%s" % (u, under, g, under - g, "  (지형이 아치 시작 높이보다 높음 → 아치 다리가 묻힘)" if g > by + ZS else ""))
# 흐르는 방향 양쪽: 웅덩이 바닥이 다리 밖으로 이어지는지
print("\n개울을 따라 (u=0, v 방향) 바닥 높이·물깊이 (상류 +v? 하류 -v?)")
for v in range(-40, 41, 5):
    x = bx + av[0] * v; z = bz + av[1] * v
    g = float(nc.bilinear(h, [x], [z])[0]); wl = lev[int(round(z)), int(round(x))]
    print("  v=%+3d (%.1f, %.1f): 바닥 %.2f 수면 %s 깊이 %s" % (v, x, z, g, "%.2f" % wl if wl > -1e9 else "-", "%.2f" % (wl - g) if wl > -1e9 else "-"))
