import sys, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import navcommon as nc, worldgen as wg
C = nc.Curves(); c, s = C.creek, C.creek_s
(z0, z1), (x0, x1), dist, along = wg.polyline_field(c, 44, wg.RES)
idx = np.clip(np.searchsorted(s, along), 0, len(s) - 1); sa = s[idx]
H0 = np.load("h_precreek.npy")
for tag in sys.argv[1:]:
    h = np.load(tag); sl = nc.cell_slope(h)[z0:z1-1, x0:x1-1]
    d = dist[:-1, :-1]; S = sa[:-1, :-1]
    print(tag)
    for lo, hi in [(0, 230), (230, 440), (440, 640), (640, 960), (960, 1100)]:
        m = (S >= lo) & (S < hi)
        for a, b in [(0, 10), (10, 20), (20, 30), (30, 36), (36, 44)]:
            mm = m & (d >= a) & (d < b)
            if mm.any():
                print("   s %4d-%4d dist %2d-%2d: max %.2f  p99 %.2f  >1.0 %d칸  >0.58 %d칸" % (lo, hi, a, b, sl[mm].max(), np.percentile(sl[mm], 99), (sl[mm] > 1).sum(), (sl[mm] > 0.58).sum()))
    # 흙 옮긴 양
    dh = (h - np.load("h_base.npy"))
    print("   base 대비 높이 차: 최소 %.1f, 1 m 넘게 낮아진 칸 %d" % (dh.min(), (dh < -1).sum()))
