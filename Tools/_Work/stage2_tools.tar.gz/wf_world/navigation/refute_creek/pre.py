# worldgen build_height 를 개울 직전까지 돌려 높이를 저장 (worldgen 은 고치지 않음)
import sys, numpy as np, time
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import worldgen as wg
saved = {}
def fake_carve(W):
    saved['h'] = W.h.copy()
    raise SystemExit
wg.carve_creek = fake_carve
W = wg.World()
try:
    wg.build_height(W)
except SystemExit:
    pass
np.save("h_precreek.npy", saved['h'])
np.save("swamp_lake.npy", np.array([W.swamp_level, W.lake_level]))
print("saved", saved['h'].shape)
