# 개울 파기 변형 비교 (worldgen.carve_creek 를 복사해 식만 바꿈). 데이터·worldgen 은 그대로
import sys, numpy as np
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import worldgen as wg
from worldgen import *  # noqa
import navcommon as nc

H0 = np.load("h_precreek.npy")
sw, lk = np.load("swamp_lake.npy")

def carve(W, mode):
    h = W.h
    c = wobble(catmull(CREEK, 2.0), 4.0, 1 / 55.0, 701)
    seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)]); L = s[-1]
    ib = int(np.argmin(np.linalg.norm(c - np.array(BRIDGE_AT), axis=1)))
    sb = s[ib]; bx, bz = c[ib]
    dvec = c[min(ib + 3, len(c) - 1)] - c[max(ib - 3, 0)]; dvec /= np.linalg.norm(dvec)
    W.creek, W.creek_s, W.creek_dir_b = c, s, dvec
    W.bridge_bank = flatten(h, bx, bz, 15, 34)
    W.bridge_p = (float(bx), float(bz))
    hb = box_blur(h, 6)
    hs = np.array([sample(hb, x, z) for x, z in c])
    def depth(si):
        if si < 230:
            return 2.4 + 7.0 * ssf(230 - si, 0, 150)
        return 2.2 if si < L - 200 else 1.6
    D = np.array([depth(si) for si in s])
    raw = hs - D
    Bb = W.bridge_bank - 2.1
    B = raw.copy()
    pool = (s > sb - 38) & (s < sb + 38); B[pool] = Bb
    up = s <= sb - 38
    B[up] = np.maximum(raw[up], Bb)
    for i in range(int(np.max(np.nonzero(up)[0])) - 1, -1, -1):
        B[i] = max(B[i], B[i + 1])
    dn = np.nonzero(s >= sb + 38)[0]
    B[dn] = np.minimum(raw[dn], Bb)
    for i in dn[1:]:
        B[i] = min(B[i], B[i - 1])
    if mode.startswith("cap"):
        cap = float(mode[3:])
        B[dn] = np.maximum(B[dn], hs[dn] - cap)
    tail = s > L - 70
    B[tail] = np.minimum(B[tail], W.lake_level - 0.8 + (B[tail] - W.lake_level + 0.8) * np.clip((L - s[tail]) / 70.0, 0, 1))
    W.creek_bed = B; W.hs = hs; W.raw = raw
    def widths(si):
        if si < 230:
            dd = depth(si); return 3.0, 3.0 + dd * 0.75
        if abs(si - sb) < 45:
            return 2.6, 5.6
        return 2.8, 6.5
    wb = np.array([widths(si)[0] for si in s]); wt = np.array([widths(si)[1] for si in s])
    pad = 40 if mode in ("slope", "slope_lim") else 16
    (z0, z1), (x0, x1), dist, along = polyline_field(c, pad, RES)
    idx = np.clip(np.searchsorted(s, along), 0, len(s) - 1)
    Bc, wbc, wtc = B[idx].astype(np.float32), wb[idx].astype(np.float32), wt[idx].astype(np.float32)
    sub = h[z0:z1, x0:x1]
    bank = sub - Bc
    if mode in ("slope", "slope_lim"):
        # 제안: 둑 기울기 고정 0.55 (단, 얕은 곳은 지금 폭 유지: 지금 식과 0.55 식 중 낮은 쪽이 아니라 제안대로 0.55)
        prof = Bc + np.maximum(dist - wbc, 0) * 0.55
        wt_eff = wbc + np.maximum(wtc - wbc, (sub - Bc) / 0.55)
        w = ss(-dist, -(wt_eff + 6), -wt_eff)
    else:
        prof = Bc + np.where(dist < wbc, 0, (dist - wbc) / np.maximum(wtc - wbc, 0.5) * np.maximum(bank, 0.5))
        w = ss(-dist, -(wtc + 10), -wtc)
    prof += 0.25 * perlin(np.arange(x1 - x0)[None, :] * 0.2 + x0 * 0.2, np.arange(z1 - z0)[:, None] * 0.2 + z0 * 0.2, 707) * (dist < wbc)
    k = 1.2
    new = -k * np.log(np.exp(-sub / k) + np.exp(-prof / k))
    sub[:] = sub * (1 - w) + np.minimum(sub, new) * w
    W.creek_win = ((z0, z1), (x0, x1)); W.creek_dist = dist; W.creek_wt = wtc
    W.pool_level = Bb + 0.42; W.pool_range = (sb - 36, sb + 36)

def run(mode):
    W = World(); W.h = H0.copy(); W.swamp_level, W.lake_level = sw, lk
    carve(W, mode)
    wg.lay_roads(W)
    return W

def report(W, name, smin=640, smax=1000, step=20):
    h = W.h; sl = nc.cell_slope(h); c, s = W.creek, W.creek_s
    print("==", name)
    rows = []
    for si in np.arange(smin, smax, step):
        i = min(int(np.searchsorted(s, si)), len(c) - 1)
        d = c[min(i+2,len(c)-1)] - c[max(i-2,0)]; d /= np.linalg.norm(d); n = np.array([-d[1], d[0]])
        ts = np.arange(-40, 40.01, 0.5)
        pts = c[i][None, :] + ts[:, None] * n[None, :]
        hh = nc.bilinear(h, pts[:, 0], pts[:, 1])
        bed = hh[np.abs(ts) <= 3].min()
        sm16 = sl[pts[np.abs(ts) <= 16, 1].astype(int), pts[np.abs(ts) <= 16, 0].astype(int)].max()
        sm40 = sl[pts[:, 1].astype(int), pts[:, 0].astype(int)].max()
        # 단면 폭: 바닥보다 1 m 넘게 높아지는 곳까지
        rows.append((si, bed, W.hs[i], W.creek_bed[i], hh[0], hh[-1], sm16, sm40))
        print("  s=%4d bed %.2f hs %.2f B %.2f  양끝(±40) %.1f/%.1f  기울기max ±16 %.2f ±40 %.2f" % rows[-1])
    return rows

if __name__ == "__main__":
    for m in sys.argv[1:]:
        W = run(m); report(W, m)
        np.save("h_%s.npy" % m, W.h)
