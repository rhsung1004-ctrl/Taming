import sys, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import navcommon as nc
C = nc.Curves()
name, rc, hw = C.roads[10]
seg = np.linalg.norm(np.diff(rc, axis=0), axis=1); rs = np.concatenate([[0], np.cumsum(seg)])
for tag in sys.argv[1:]:
    h = np.load(tag) if tag.endswith(".npy") else nc.load_height()
    sl = nc.cell_slope(h)
    # 개울 근처 구간 (x 640~750)
    m = (rc[:, 0] > 640) & (rc[:, 0] < 750)
    pts = rc[m]
    hh = nc.bilinear(h, pts[:, 0], pts[:, 1])
    ds = rs[m]
    grade = np.abs(np.diff(hh) / np.maximum(np.diff(ds), 1e-6))
    smax = [sl[int(z)-2:int(z)+3, int(x)-2:int(x)+3].max() for x, z in pts]
    print(tag, "길 높이 min %.1f max %.1f, 오르내림 기울기 최대 %.2f, 길 폭 안 최대 기울기 %.2f" % (hh.min(), hh.max(), grade.max(), max(smax)))
