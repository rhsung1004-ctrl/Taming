#!/usr/bin/env python3
# 봉인문 북쪽 골짜기: z 마다 x=1010 을 품은 '기울기 ≤ 한계' 이어진 구간의 폭 (지형만)
#   python3 nav_pass.py [한계=1.0]
import sys
import numpy as np
import navcommon as nc
lim = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
h = nc.load_height(); sl = nc.cell_slope(h)
for z in range(1800, 2048, 12):
    row = sl[z, :] <= lim
    x = 1010
    if not row[x]:
        k = np.nonzero(row[900:1120])[0]
        if len(k) == 0:
            print("z=%d: x 900~1120 에 걸을 칸 없음" % z); continue
        x = 900 + k[np.argmin(np.abs(k + 900 - 1010))]
    a = x
    while a > 0 and row[a - 1]: a -= 1
    b = x
    while b < 2047 and row[b + 1]: b += 1
    print("z=%4d: x %4d~%4d (폭 %4d m), 바닥 x=1010 높이 %.1f, 양 끝 높이 %.1f / %.1f" % (z, a, b, b - a + 1, h[z, 1010], h[z, a], h[z, b]))
