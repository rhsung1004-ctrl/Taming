import numpy as np, navcommon as nc
h = nc.load_height(); C = nc.Curves(); c, s = C.creek, C.creek_s
for si in [460, 680, 720, 760, 800, 840, 880, 920, 960]:
    i = min(int(np.searchsorted(s, si)), len(c)-1)
    d = c[min(i+2,len(c)-1)] - c[max(i-2,0)]; d/=np.linalg.norm(d); n = np.array([-d[1], d[0]])
    ts = np.arange(-30, 30.01, 1.0)
    pts = c[i][None,:] + ts[:,None]*n[None,:]
    hh = nc.bilinear(h, pts[:,0], pts[:,1])
    g = np.diff(hh)
    print("s=%d (%.1f,%.1f) n=(%.2f,%.2f)" % (si, c[i][0], c[i][1], n[0], n[1]))
    print("  t   :" + " ".join("%5d" % t for t in ts[::2]))
    print("  h   :" + " ".join("%5.1f" % v for v in hh[::2]))
    print("  grad:" + " ".join("%5.2f" % v for v in g[::2]))
