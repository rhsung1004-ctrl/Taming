#!/usr/bin/env python3
# 걸을 수 있는 칸 플러드필: 시작 위치 → 13 장소에 닿는지, 지도 가장자리로 빠지는지
#   python3 nav_flood.py [슬로프한계=1.0] [소품=large|all|none] [다리=1|0]
#   환경변수 NAV_DATA (Data~ 폴더), NAV_KIT (manifest 폴더), NAV_OUT (결과 폴더) 로 바꿀 수 있다
# 걸을 수 있는 칸 = 지형 삼각형 기울기 ≤ 한계, 수면 아래 0.6 m 보다 얕음, 소품 충돌(+주인공 반지름 0.4 m) 밖
# 격자 0.5 m. 4방향 연결
import sys, json, math, time
import numpy as np
from PIL import Image
import navcommon as nc

T0 = time.time()
lim = float(sys.argv[1]) if len(sys.argv) > 1 else nc.SLOPE_MAX
which = sys.argv[2] if len(sys.argv) > 2 else "large"
use_bridge = (sys.argv[3] != "0") if len(sys.argv) > 3 else True
CELL = 0.5
N = int(2048 / CELL)
out = nc.ensure_out()
tag = "lim%.2f_%s_br%d" % (lim, which, int(use_bridge))


def log(*a):
    print("[%5.1fs]" % (time.time() - T0), *a, flush=True)


h = nc.load_height()
world = nc.load_world()
objs = nc.load_objects()
trees = nc.load_trees()
man = nc.load_manifest()
C = nc.Curves()

# 1 m 칸 기울기 → 0.5 m
sl1 = nc.cell_slope(h)                               # 2048 x 2048
sl = np.repeat(np.repeat(sl1, 2, 0), 2, 1)
# 0.5 m 칸 가운데 높이
ax = (np.arange(N) + 0.5) * CELL
XX, ZZ = np.meshgrid(ax, ax)
hc = nc.bilinear(h, XX.ravel(), ZZ.ravel()).reshape(N, N).astype(np.float32)
# 수면 (1 m 꼭짓점 격자에서 구해 0.5 m 로)
lev1 = nc.water_surface(objs)
lev = lev1[(ZZ).astype(int), (XX).astype(int)]
depth = lev - hc
log("높이·기울기·물 준비")

shapes = [] if which == "none" else nc.prop_shapes(objs, trees, man, which)
pblock, pwho = nc.raster_props(shapes, CELL, N) if shapes else (np.zeros((N, N), bool), np.full((N, N), -1, np.int32))
log("소품 충돌", len(shapes), "개, 막힌 칸 %.0f m²" % (pblock.sum() * CELL * CELL))

steep = sl > lim
deep = depth > nc.WADE
walk = ~steep & ~deep & ~pblock

# 다리 상판: 상판 위 칸은 걸을 수 있음 (끝 높이는 nav_bridge.py 에서 따로 확인)
bx, bz = C.bridge_p
r = C.bridge_axis
yaw_b = math.degrees(math.atan2(-r[1], r[0]))
axu, axv = nc.local_axes(yaw_b)
U = (XX - bx) * axu[0] + (ZZ - bz) * axu[1]
V = (XX - bx) * axv[0] + (ZZ - bz) * axv[1]
deck = (np.abs(U) <= 7.0) & (np.abs(V) <= 1.55 - nc.AGENT_R)
side = (np.abs(U) <= 7.0) & (np.abs(V) > 1.55 - nc.AGENT_R) & (np.abs(V) <= 2.0 + 0.45 + nc.AGENT_R)
if use_bridge:
    walk[deck] = True
    # 난간 벽 (앞쪽 -V 가운데는 무너졌지만 그쪽은 개울로 떨어지는 곳이라 막힘으로 둔다)
    walk[side & (np.abs(U) > 4.6)] = False

sp = world["spawn"]["p"]
seed = (int(sp[0] / CELL), int(sp[2] / CELL))
lab, ncomp = nc.label4(walk)
L0 = lab[seed[1], seed[0]]
if L0 == 0:
    log("시작 칸이 걸을 수 없는 칸이다! 기울기 %.2f 물깊이 %.2f 소품 %s" % (sl[seed[1], seed[0]], depth[seed[1], seed[0]], pwho[seed[1], seed[0]]))
reach = lab == L0
sizes = np.bincount(lab.ravel())
log("묶음 %d 개, 시작 묶음 넓이 %.2f km²" % (ncomp, reach.sum() * CELL * CELL / 1e6))

res = {"limit": lim, "props": which, "bridge": use_bridge, "reach_km2": float(reach.sum() * CELL * CELL / 1e6), "pois": []}
print("\n장소별 도달 (r = 발견 반지름)")
print("%-10s %-16s %8s %8s %8s  %s" % ("id", "이름", "r", "닿음", "가장가까움", "중심 칸 상태"))
for p in world["pois"]:
    x, _, z = p["p"]
    R = p["r"]
    i0, i1 = max(0, int((z - R) / CELL)), min(N, int((z + R) / CELL) + 1)
    j0, j1 = max(0, int((x - R) / CELL)), min(N, int((x + R) / CELL) + 1)
    sub = reach[i0:i1, j0:j1]
    dd = np.hypot(XX[i0:i1, j0:j1] - x, ZZ[i0:i1, j0:j1] - z)
    inr = sub & (dd <= R)
    dmin = float(dd[sub].min()) if sub.any() else float("inf")
    frac = float(inr.sum() / max(1, (dd <= R).sum()))
    ci, cj = int(z / CELL), int(x / CELL)
    st = "기울기 %.2f 물 %.2f 소품 %s 묶음 %d" % (sl[ci, cj], depth[ci, cj], shapes[pwho[ci, cj]][0] if pwho[ci, cj] >= 0 else "-", lab[ci, cj])
    print("%-10s %-16s %8.0f %8s %8.1f  %s  (반지름 안 %.0f%%)" % (p["id"], p["name"], R, "예" if inr.any() else "아니오", dmin, st, frac * 100))
    res["pois"].append({"id": p["id"], "reached": bool(inr.any()), "closest_m": dmin, "frac_in_r": frac})

# 가장자리
(b0x, b0z), (b1x, b1z) = world["bounds"]["min"], world["bounds"]["max"]
outside = reach & ((XX < b0x) | (XX > b1x) | (ZZ < b0z) | (ZZ > b1z))
oc = int(outside.sum())
edge_d = np.minimum.reduce([XX - b0x, b1x - XX, ZZ - b0z, b1z - ZZ])   # 음수 = bounds 밖
print("\nbounds(%d~%d) 밖의 닿는 칸: %.0f m²" % (b0x, b1x, oc * CELL * CELL))
if oc:
    far = float(-edge_d[outside].min())
    k = np.argmin(np.where(outside, edge_d, 1e9))
    print("  가장 멀리 나간 곳: (%.1f, %.1f) bounds 밖 %.1f m, 높이 %.1f" % (XX.flat[k], ZZ.flat[k], far, hc.flat[k]))
    # 방향별
    for nm, m in (("서", XX < b0x), ("동", XX > b1x), ("남", ZZ < b0z), ("북", ZZ > b1z)):
        mm = reach & m
        if mm.any():
            dd = np.where(mm, edge_d, 1e9)
            k = np.argmin(dd)
            print("  %s쪽 밖 %.0f m², 가장 먼 곳 (%.1f, %.1f) %.1f m 밖" % (nm, mm.sum() * CELL * CELL, XX.flat[k], ZZ.flat[k], -dd.flat[k]))
    res["outside_m2"] = oc * CELL * CELL
    res["outside_max_m"] = far
edge_hit = reach[0, :].any() or reach[-1, :].any() or reach[:, 0].any() or reach[:, -1].any()
near_edge = reach & ((XX < 20) | (XX > 2028) | (ZZ < 20) | (ZZ > 2028))
print("지형 끝(0/2048) 칸에 닿음:", edge_hit, " 끝 20 m 안 칸 %.0f m²" % (near_edge.sum() * CELL * CELL))
res["edge_hit"] = bool(edge_hit)

# 시작 묶음 밖인데 넓은 걸을 수 있는 땅 (갇힌 곳·못 가는 곳)
inside = (XX > b0x) & (XX < b1x) & (ZZ > b0z) & (ZZ < b1z)
big = [(int(c), float(sizes[c] * CELL * CELL)) for c in np.argsort(-sizes)[:40] if c != 0 and c != L0 and sizes[c] * CELL * CELL > 400]
print("\n시작 묶음과 이어지지 않은 걸을 수 있는 땅 (400 m² 넘는 것, bounds 안 부분)")
res["islands"] = []
for c, area in big:
    m = lab == c
    mi = m & inside
    ai = mi.sum() * CELL * CELL
    if ai < 400:
        continue
    zs, xs = np.nonzero(mi)
    cx, cz = xs.mean() * CELL, zs.mean() * CELL
    print("  묶음 %d: %.0f m² (bounds 안 %.0f), 가운데 (%.0f, %.0f), 범위 x %.0f~%.0f z %.0f~%.0f, 평균 높이 %.1f" % (
        c, area, ai, cx, cz, xs.min() * CELL, xs.max() * CELL, zs.min() * CELL, zs.max() * CELL, hc[mi].mean()))
    res["islands"].append({"label": c, "area": area, "inside": float(ai), "center": [cx, cz]})

np.save(out + "/reach_%s.npy" % tag, np.packbits(reach))
# 그림: 회색 = 닿음, 빨강 = 가파름, 파랑 = 깊은 물, 노랑 = 소품, 검정 = 다른 묶음
img = np.zeros((N, N, 3), np.uint8)
img[reach] = (150, 150, 150)
img[walk & ~reach] = (40, 40, 40)
img[steep] = (170, 40, 40)
img[deep & ~steep] = (40, 60, 190)
img[pblock & ~steep & ~deep] = (230, 200, 40)
img[outside] = (120, 255, 120)
im = Image.fromarray(np.flipud(img)).resize((2048, 2048), Image.NEAREST)
from PIL import ImageDraw
dr = ImageDraw.Draw(im)
for p in world["pois"]:
    x, _, z = p["p"]
    X, Y = x, 2048 - z
    dr.ellipse([X - p["r"], Y - p["r"], X + p["r"], Y + p["r"]], outline=(255, 0, 255), width=3)
    dr.text((X + 4, Y + 4), p["id"], fill=(255, 255, 255))
dr.rectangle([b0x, 2048 - b1z, b1x, 2048 - b0z], outline=(0, 255, 255), width=2)
im.save(out + "/reach_%s.png" % tag)
json.dump(res, open(out + "/flood_%s.json" % tag, "w"), ensure_ascii=False, indent=1)
log("저장", out + "/reach_%s.png" % tag)
