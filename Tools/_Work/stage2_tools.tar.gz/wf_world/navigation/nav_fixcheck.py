#!/usr/bin/env python3
# 고칠 안 미리 보기: 현재 height.r16 사본에 제안한 높이 수정을 더해 같은 검사를 다시 돌린다 (데이터·worldgen 은 그대로)
#   python3 nav_fixcheck.py [기울기한계=1.0]
# 수정 A (가장자리 벽): dout = bounds 밖 거리 (북쪽 선은 봉인문 줄 z=ZN 으로 당김). h += WALL * ss(dout, -5, 25)
#   봉인문 자리 |x-1010| < 8.5 만 벽을 연다 (ss(|dx|, 8.5, 13)), 그 뒤 z ≥ ZB 에 막다른 벽
# 수정 B (다리 끝): 경간 |u| 6.2~11 m (5.6~6.2 에서 섞기 시작), |v| ≤ 3.5 m 를 둑 높이 + 0.10 으로, |u| 11~16 / |v| 3.5~6 에서 원래 높이로 섞음
import sys, math
import numpy as np
import navcommon as nc
from terrain import ss

lim = float(sys.argv[1]) if len(sys.argv) > 1 else nc.SLOPE_MAX
WALL, ZN, ZB = 60.0, 1828.0, 1866.0
h0 = nc.load_height()
h = h0.copy()
ax = np.arange(nc.RES, dtype=np.float32)
X, Z = np.meshgrid(ax, ax)
dx = np.abs(X - 1010.0)
dout = np.maximum.reduce([170 - X, X - 1878, 170 - Z, Z - ZN])
gap = ss(dx, 8.5, 13.0)                                   # 문 자리만 연다
wall = WALL * ss(dout, -5, 25) * np.where(Z < ZB + 30, gap, 1.0)
back = WALL * ss(Z - ZB, -5, 25) * (1 - gap)              # 문 뒤 막다른 벽
h += np.maximum(wall, back)
# 다리 끝
world = nc.load_world(); objs = nc.load_objects()
br = [o for o in objs["objects"] if o["a"] == "bridge_ruin"][0]
bx, by, bz = br["p"]
au, av = nc.local_axes(nc.yaw_of_q(br["q"]))
U = (X - bx) * au[0] + (Z - bz) * au[1]
V = (X - bx) * av[0] + (Z - bz) * av[1]
bank = by + 0.02
wgt = ss(np.abs(U), 5.6, 6.2) * ss(-np.abs(U), -16, -11) * ss(-np.abs(V), -6, -3.5)
h = h * (1 - wgt) + np.maximum(h, bank + 0.10) * wgt

G = nc.build_walk(lim, "large", True, cell=1.0, h=h.astype(np.float32))
reach, lab, L0 = nc.reach_from_spawn(G)
XX, ZZ, hc = G["XX"], G["ZZ"], G["hc"]
inb = (XX > 170) & (XX < 1878) & (ZZ > 170) & (ZZ < 1878)
print("수정 후 (한계 %.2f): 시작 묶음 %.2f km², bounds 밖 %d m², 지형 끝 12 m 띠 %d 칸" % (
    lim, reach.sum() / 1e6, (reach & ~inb).sum(), (reach & ((XX < 12) | (XX > 2036) | (ZZ < 12) | (ZZ > 2036))).sum()))
ok = ~G["pblock"]; ok[G["deck"]] = True
sp = world["spawn"]["p"]
fw = nc.flood_dir(hc, ok, (int(sp[0]), int(sp[2])), 1.0, lim, 1e9)
print("  떨어짐 허용: 갈 수 있음 %.2f km², bounds 밖 %d m², 지형 끝 3 m 띠 %d 칸" % (fw.sum() / 1e6, (fw & ~inb).sum(),
      (fw & ((XX < 3) | (XX > 2045) | (ZZ < 3) | (ZZ > 2045))).sum()))
north = (ZZ > 1834) & (np.abs(XX - 1010) < 60)
print("  봉인문 북쪽 (z>1834, |x-1010|<60) 닿는 칸: %d" % (reach & north).sum())
Gn = nc.build_walk(lim, "large", True, cell=1.0, h=h.astype(np.float32), skip=("gate_great",))
rn, _, _ = nc.reach_from_spawn(Gn)
print("  (문 충돌을 빼면 북쪽 칸 %d, 지형 끝 띠 %d → 문만 막고 있음을 확인)" % ((rn & north).sum(), (rn & ((ZZ > 2036))).sum()))
for p in world["pois"]:
    x, _, z = p["p"]; R = p["r"]
    m = (np.hypot(XX - x, ZZ - z) <= R) & reach
    print("  %-10s 닿음 %s (반지름 안 %d m²)" % (p["id"], bool(m.any()), m.sum()))
# 다리 끝 턱
for sgn in (1, -1):
    hs = [float(nc.bilinear(h, [bx + au[0] * 7 * sgn + av[0] * v], [bz + au[1] * 7 * sgn + av[1] * v])[0]) for v in (-1.55, 0, 1.55)]
    print("  다리 %s 끝 u=%+d: 지형 %.3f/%.3f/%.3f, 상판 끝 %.3f → 턱 %.2f~%.2f" % ("동" if sgn > 0 else "서", 7 * sgn, *hs, by + 0.14, by + 0.14 - max(hs), by + 0.14 - min(hs)))
# 벽이 가장 가파른 곳·폭
sl = G["sl"]
ring = (dout > -5) & (dout < 25) & (gap > 0.99)
print("  벽 띠 (dout -5~25): 기울기 > 1.0 비율 %.0f%%" % ((sl[:2048, :2048][ring[:2048, :2048]] > 1.0).mean() * 100))
