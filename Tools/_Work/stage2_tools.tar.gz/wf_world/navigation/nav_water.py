#!/usr/bin/env python3
# 물 검사: 늪·호수·개울 웅덩이 깊이, 깊은 물(1 m)로 갈라진 섬, 개울을 건널 곳, 떨어지면 못 나오는 곳(갇힘)
#   python3 nav_water.py
# 참고: Unity 물(NecroWorldBuilder.BuildWater)은 보이기만 하는 평면이다 (충돌·헤엄 없음) → 주인공은 물 바닥을 걷는다
import math, json
import numpy as np
import navcommon as nc
import worldgen as wg

CELL = 1.0
G = nc.build_walk(nc.SLOPE_MAX, "large", True, cell=CELL)
XX, ZZ, hc, sl, depth, walk = G["XX"], G["ZZ"], G["hc"], G["sl"], G["depth"], G["walk"]
world = G["world"]
lv = world["levels"]
reach, lab, L0 = nc.reach_from_spawn(G)
res = {}

print("== 물 깊이 (넓이 m²)")
bodies = {"늪": (wg.SWAMP, wg.SWAMP_R + 40, lv["swamp"]), "호수": (wg.LAKE, wg.LAKE_R + 30, lv["lake"])}
for nm, ((cx, cz), R, L) in bodies.items():
    m = (np.abs(XX - cx) <= R) & (np.abs(ZZ - cz) <= R)
    d = np.where(m, depth, -1)
    print("  %s (수면 %.2f): 물 %d, 0.6 m 넘음 %d, 1.0 m 넘음 %d, 1.8 m(머리까지) 넘음 %d, 가장 깊은 곳 %.2f m at %s" % (
        nm, L, (d > 0).sum(), (d > 0.6).sum(), (d > 1.0).sum(), (d > 1.8).sum(), d.max(),
        tuple(int(v) for v in np.unravel_index(np.argmax(d), d.shape)[::-1])))
    res[nm] = dict(level=L, wet=int((d > 0).sum()), d06=int((d > 0.6).sum()), d10=int((d > 1.0).sum()), d18=int((d > 1.8).sum()), dmax=float(d.max()))
pm = np.isfinite(G["lev"]) & (np.abs(G["lev"] - lv["creekPool"]) < 1e-3)
dp = np.where(pm, depth, -1)
print("  개울 웅덩이 (수면 %.2f): 물 %d, 0.6 m 넘음 %d, 1.0 m 넘음 %d, 가장 깊은 곳 %.2f" % (lv["creekPool"], (dp > 0).sum(), (dp > 0.6).sum(), (dp > 1.0).sum(), dp.max()))

# 늪: 수면 1 m 보다 깊은 물로 갈라진 땅 (기울기·소품은 그대로)
print("\n== 늪·호수의 섬 (물 깊이 기준 %.1f m 와 1.0 m 로 갈라 본다)" % nc.WADE)
for thr in (nc.WADE, 1.0):
    w2 = ~G["steep"] & ~G["pblock"] & ~(depth > thr)
    w2[G["deck"]] = True
    lb, _ = nc.label4(w2)
    sp = world["spawn"]["p"]
    l0 = lb[int(sp[2]), int(sp[0])]
    for nm, ((cx, cz), R, L) in bodies.items():
        box = (np.abs(XX - cx) <= R) & (np.abs(ZZ - cz) <= R)
        dry = box & w2 & (lb != l0) & (hc > L)           # 물 위로 나온 땅인데 시작 묶음과 안 이어짐
        ids, cnt = np.unique(lb[dry], return_counts=True)
        big = sorted([(c, i) for i, c in zip(ids, cnt) if c >= 4], reverse=True)
        print("  깊이 %.1f 기준 %s: 시작 묶음과 떨어진 마른 땅 %d 조각, 합 %d m² — 큰 것: %s" % (
            thr, nm, len(big), sum(c for c, _ in big),
            "; ".join("%d m² at (%.0f,%.0f) 높이 %.2f(수면+%.2f)" % (c, XX[lb == i].mean(), ZZ[lb == i].mean(), hc[lb == i].max(), hc[lb == i].max() - L) for c, i in big[:6])))
        # 그 섬 위의 소품 (가 볼 만한 것이 있는지)
        if big:
            objs = G["objs"]["objects"]
            on = []
            for o in objs:
                x, _, z = o["p"]
                i, j = int(z), int(x)
                if 0 <= i < G["N"] and 0 <= j < G["N"] and lb[i, j] in [b for _, b in big] and o["a"] not in ("lotus_glow",):
                    on.append(o["a"])
            if on:
                from collections import Counter
                print("     그 조각들 위 소품: %s" % dict(Counter(on)))

# 호수 가장자리: 물가까지 걸어 내려갈 수 있는 둘레 비율
print("\n== 호수 둘레 (수면선) 에 닿는지")
(cx, cz), R, L = bodies["호수"]
ang = np.linspace(0, 2 * math.pi, 360, endpoint=False)
ok = 0
bad = []
for a in ang:
    # 가운데에서 바깥으로 가며 처음 수면 위로 나오는 칸
    for d in np.arange(20, R + 60, 0.5):
        x, z = cx + math.cos(a) * d, cz + math.sin(a) * d
        i, j = int(z), int(x)
        if hc[i, j] > L:
            if reach[i, j] or reach[min(i + 1, 2047), j] or reach[i, min(j + 1, 2047)]:
                ok += 1
            else:
                bad.append((a, x, z, sl[i, j]))
            break
print("  360 방향 중 물가 칸이 시작 묶음에 드는 방향 %d (%.0f%%)" % (ok, ok / 3.6))
if bad:
    runs = []
    cur = [bad[0]]
    for b in bad[1:]:
        if abs(b[0] - cur[-1][0]) < 0.03:
            cur.append(b)
        else:
            runs.append(cur); cur = [b]
    runs.append(cur)
    for r in runs[:8]:
        print("    못 닿는 물가: 각 %.0f°~%.0f° (%.0f,%.0f)~(%.0f,%.0f), 물가 기울기 최대 %.2f" % (
            math.degrees(r[0][0]), math.degrees(r[-1][0]), r[0][1], r[0][2], r[-1][1], r[-1][2], max(q[3] for q in r)))
# 호수 그릇 테두리: 수면 위 0~30 m 높이 띠의 기울기
rim = (np.hypot(XX - cx, ZZ - cz) < R + 60) & (hc > L) & (hc < L + 30)
print("  호수 그릇 (수면 위 0~30 m, 가운데에서 %d m 안): 넓이 %d m², 기울기 >0.58 %.0f%%, >1.0 %.0f%%, 최대 %.2f" % (
    R + 60, rim.sum(), (sl[rim] > 0.58).mean() * 100, (sl[rim] > 1.0).mean() * 100, sl[rim].max()))

# 개울: 곡선을 따라 가로지를 수 있는지 (개울 곡선에 직각인 선 위 모든 칸이 걸을 수 있음)
print("\n== 개울 가로지르기 (곡선 2 m 마다, 직각으로 ±16 m 선 위 칸이 모두 걸을 수 있으면 건널 수 있음)")
C = G["curves"]
c, s = C.creek, C.creek_s
ok_s = []
info = []
for i in range(0, len(c), 1):
    if i % 1:
        continue
    j0, j1 = max(0, i - 2), min(len(c) - 1, i + 2)
    d = c[j1] - c[j0]
    d = d / np.linalg.norm(d)
    nrm = np.array([-d[1], d[0]])
    ts = np.arange(-16, 16.01, 0.5)
    pts = c[i][None, :] + ts[:, None] * nrm[None, :]
    ii = np.clip(pts[:, 1].astype(int), 0, 2047)
    jj = np.clip(pts[:, 0].astype(int), 0, 2047)
    w_ = walk[ii, jj]
    ok_s.append(bool(w_.all()))
    info.append((s[i], c[i][0], c[i][1], float(sl[ii, jj].max()), float(depth[ii, jj].max()), bool(G["pblock"][ii, jj].any()), bool(G["deck"][ii, jj].any())))
ok_s = np.array(ok_s)
S = np.array([q[0] for q in info])
print("  개울 길이 %.0f m, 건널 수 있는 자리 비율 %.0f%%" % (s[-1], ok_s.mean() * 100))
# 못 건너는 구간
idx = np.nonzero(~ok_s)[0]
if len(idx):
    for r in np.split(idx, np.nonzero(np.diff(idx) > 1)[0] + 1):
        a, b = info[r[0]], info[r[-1]]
        smax = max(info[k][3] for k in r)
        dmax = max(info[k][4] for k in r)
        pb = any(info[k][5] for k in r)
        print("    못 건넘 s %.0f~%.0f (%.0f m): (%.0f,%.0f)→(%.0f,%.0f), 둑 기울기 최대 %.2f, 물 깊이 최대 %.2f%s" % (
            a[0], b[0], b[0] - a[0], a[1], a[2], b[1], b[2], smax, dmax, ", 소품 있음" if pb else ""))
idx = np.nonzero(ok_s)[0]
if len(idx):
    rr = np.split(idx, np.nonzero(np.diff(idx) > 1)[0] + 1)
    print("  건널 수 있는 구간 %d 개: %s" % (len(rr), "; ".join("s %.0f~%.0f (%.0f,%.0f)" % (info[r[0]][0], info[r[-1]][0], info[r[0]][1], info[r[0]][2]) for r in rr[:12])))

# 다리 웅덩이 앞뒤: 곡선을 따라 지형·설계 바닥·수면
print("\n== 다리 웅덩이 앞뒤 (개울 곡선 위, s = 북쪽 시작에서 잰 길이, 다리 s=%.0f)" % C.sb)
for k in range(-70, 71, 5):
    si = C.sb + k
    i = int(np.searchsorted(s, si))
    x, z = c[min(i, len(c) - 1)]
    lw = G["lev"][int(z), int(x)]
    print("  s=%4.0f (%.0f) (%.1f, %.1f): 지형 %.2f 수면 %s%s" % (si, k, x, z, hc[int(z), int(x)], "%.2f" % lw if np.isfinite(lw) else "-",
          "  ← 수면이 이 칸 지형보다 %.2f m 높은데 물 평면이 바로 옆에서 끊김" % (lv["creekPool"] - hc[int(z), int(x)]) if (not np.isfinite(lw) and hc[int(z), int(x)] < lv["creekPool"]) else ""))

# 갇힘: 내려가기는 아무 기울기나 (떨어짐), 오르기는 ≤ 1.0. 물은 막지 않음 (바닥을 걷는다), 큰 소품은 막음
print("\n== 떨어지면 못 나오는 곳 (내려감 무제한, 오름 ≤ 1.0, 1 m 칸)")
ok = ~G["pblock"]
ok[G["deck"]] = True
sp = world["spawn"]["p"]
fw = nc.flood_dir(hc, ok, (int(sp[0]), int(sp[2])), CELL, nc.SLOPE_MAX, 1e9)
bw = nc.flood_dir(hc, ok, (int(sp[0]), int(sp[2])), CELL, 1e9, nc.SLOPE_MAX)
trap = fw & ~bw
(b0x, b0z), (b1x, b1z) = world["bounds"]["min"], world["bounds"]["max"]
inb = (XX > b0x) & (XX < b1x) & (ZZ > b0z) & (ZZ < b1z)
tl, tn = nc.label4(trap)
cnt = np.bincount(tl.ravel())
order = np.argsort(-cnt)
print("  갈 수 있음 %.2f km², 돌아올 수 있음 %.2f km², 갇힘 %d m² (%d 조각, bounds 안 %d m²)" % (fw.sum() / 1e6, bw.sum() / 1e6, trap.sum(), tn, (trap & inb).sum()))
res["trap_m2"] = int(trap.sum())
for k in order[:15]:
    if k == 0 or cnt[k] < 6:
        continue
    m = tl == k
    zs, xs = np.nonzero(m)
    mi = m & inb
    print("    %d m² (bounds 안 %d) 가운데 (%.0f,%.0f) 범위 x %d~%d z %d~%d, 바닥 높이 %.1f, 둘레 최고 %.1f" % (
        cnt[k], mi.sum(), xs.mean(), zs.mean(), xs.min(), xs.max(), zs.min(), zs.max(), hc[m].min(),
        hc[max(0, zs.min() - 3):zs.max() + 4, max(0, xs.min() - 3):xs.max() + 4].max()))
json.dump(res, open(nc.ensure_out() + "/water.json", "w"), ensure_ascii=False, indent=1)
