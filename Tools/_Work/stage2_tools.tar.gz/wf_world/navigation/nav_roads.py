#!/usr/bin/env python3
# 길 기울기 프로파일: worldgen.ROADS (+ 다리 앞뒤 길) 을 worldgen 과 같은 식으로 다시 만들어 실제 높이로 잰다
#   python3 nav_roads.py [자세히 볼 길 번호들(쉼표)]
# 길을 따라 1 m 마다: 오르내림 기울기(길 방향 dh/ds, 2 m 중앙차분), 지형 기울기(사방 최대, 삼각형), 옆 기울기
# 30°(0.58) 넘는 구간, 45°(1.0) 넘는 구간을 좌표·길이로
import sys, json
import numpy as np
import navcommon as nc

h = nc.load_height()
sl = nc.cell_slope(h)
gz, gx = np.gradient(h)
C = nc.Curves()
objs = nc.load_objects()
lev = nc.water_surface(objs)
detail = set(int(a) for a in sys.argv[1].split(",")) if len(sys.argv) > 1 else set()


def resample(c, step=1.0):
    seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    t = np.arange(0, s[-1], step)
    x = np.interp(t, s, c[:, 0])
    z = np.interp(t, s, c[:, 1])
    return t, x, z


def runs(mask, t, x, z, extra=None):
    out = []
    idx = np.nonzero(mask)[0]
    if len(idx) == 0:
        return out
    for r in np.split(idx, np.nonzero(np.diff(idx) > 2)[0] + 1):    # 2 m 안의 틈은 한 구간으로
        out.append((t[r[0]], t[r[-1]] + 1, x[r[0]], z[r[0]], x[r[-1]], z[r[-1]]))
    return out


report = []
for ri, (name, c, hw) in enumerate(C.roads):
    t, x, z = resample(c)
    hh = nc.bilinear(h, x, z)
    grade = np.gradient(hh, t)                          # 길 방향 오르내림
    dx, dz = np.gradient(x), np.gradient(z)
    n = np.hypot(dx, dz) + 1e-9
    gxa = nc.bilinear(gx, x, z); gza = nc.bilinear(gz, x, z)
    cross = np.abs((gxa * -dz + gza * dx) / n)          # 옆 기울기
    tri = sl[np.clip(z.astype(int), 0, 2047), np.clip(x.astype(int), 0, 2047)]
    # 길 폭 안(가운데 ± 반폭) 최대 삼각형 기울기
    wmax = tri.copy()
    for o in (-hw, -hw / 2, hw / 2, hw):
        xo = x + (-dz / n) * o
        zo = z + (dx / n) * o
        wmax = np.maximum(wmax, sl[np.clip(zo.astype(int), 0, 2047), np.clip(xo.astype(int), 0, 2047)])
    wet = lev[np.clip(np.round(z).astype(int), 0, 2048), np.clip(np.round(x).astype(int), 0, 2048)] - hh
    g_abs = np.abs(grade)
    r30 = runs(g_abs > nc.SLOPE_EASY, t, x, z)
    r45 = runs(g_abs > nc.SLOPE_MAX, t, x, z)
    w30 = runs(wmax > nc.SLOPE_EASY, t, x, z)
    w45 = runs(wmax > nc.SLOPE_MAX, t, x, z)
    wet_r = runs(wet > 0.0, t, x, z)
    print("[%d] %s: 길이 %.0f m, 반폭 %.1f, 높이 %.1f → %.1f (최저 %.1f 최고 %.1f), 오르내림 최대 %.2f (%.0f°) 평균 %.3f, 옆 기울기 최대 %.2f, 길 폭 안 지형 최대 %.2f" % (
        ri, name, t[-1], hw, hh[0], hh[-1], hh.min(), hh.max(), g_abs.max(), np.degrees(np.arctan(g_abs.max())), g_abs.mean(), cross.max(), wmax.max()))
    k = int(np.argmax(g_abs))
    print("     가장 가파른 곳 s=%.0f (%.1f, %.1f) 오르내림 %.2f" % (t[k], x[k], z[k], grade[k]))
    for lab_, rr in (("오르내림 >0.58", r30), ("오르내림 >1.0", r45), ("길 폭 안 지형 >0.58", w30), ("길 폭 안 지형 >1.0", w45), ("물에 잠김", wet_r)):
        if rr:
            tot = sum(b - a for a, b, *_ in rr)
            print("     %s: %d 구간 합 %.0f m — %s" % (lab_, len(rr), tot, "; ".join("s %.0f~%.0f (%.1f,%.1f)→(%.1f,%.1f)" % r for r in rr[:8])))
    if ri in detail:
        print("     프로파일 (10 m 마다 s: 높이 / 오르내림 / 길폭최대):")
        for i in range(0, len(t), 10):
            print("       s=%4.0f (%7.1f,%7.1f) %6.2f  %+5.2f  %4.2f" % (t[i], x[i], z[i], hh[i], grade[i], wmax[i]))
    report.append(dict(road=name, length=float(t[-1]), gmax=float(g_abs.max()), wmax=float(wmax.max()),
                       over30=[list(map(float, r)) for r in r30], over45=[list(map(float, r)) for r in r45],
                       wide30=[list(map(float, r)) for r in w30], wide45=[list(map(float, r)) for r in w45], wet=[list(map(float, r)) for r in wet_r]))
json.dump(report, open(nc.ensure_out() + "/roads.json", "w"), ensure_ascii=False, indent=1)
