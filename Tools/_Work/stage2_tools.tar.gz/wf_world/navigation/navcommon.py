# 월드 검사 "navigation" 공통: 데이터 읽기, 기울기, 길·개울 곡선 다시 만들기
#   데이터 폴더(Data~)와 manifest 폴더는 읽기만 한다. worldgen.py 는 고치지 않고 함수만 가져다 쓴다
import os, sys, json, math, glob
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad"
DATA = os.environ.get("NAV_DATA", SCR + "/world_out3/Data~")
KIT = os.environ.get("NAV_KIT", SCR + "/kit_out")
OUT = os.environ.get("NAV_OUT", HERE + "/out")
WG = os.environ.get("NAV_WG", "/home/user/Taming/Tools/WorldGen")
sys.path.insert(0, WG)
import worldgen as wg                         # noqa: E402  (main() 은 돌지 않는다)
from terrain import catmull, wobble, sample   # noqa: E402

RES = 2049
SLOPE_MAX = 1.0        # 45° (과제 기준)
SLOPE_CC = math.tan(math.radians(50))   # NecroSetupTools 의 cc.slopeLimit = 50° → 1.19
SLOPE_EASY = 0.58      # 30°
WADE = 0.6             # 수면 아래 이만큼까지는 걸어 들어간다
AGENT_R = 0.4


def load_height():
    h = np.fromfile(os.path.join(DATA, "height.r16"), dtype="<u2").reshape(RES, RES).astype(np.float32)
    return h * (320.0 / 65535.0)


def load_world():
    return json.load(open(os.path.join(DATA, "world.json")))


def load_objects():
    return json.load(open(os.path.join(DATA, "objects.json")))


def load_trees():
    return json.load(open(os.path.join(DATA, "trees.json")))


def load_manifest():
    man = {}
    for f in sorted(glob.glob(os.path.join(KIT, "manifest_*.json"))):
        for k, v in json.load(open(f)).items():
            man[k] = v
    return man


def cell_slope(h):
    """지형 충돌 삼각형 기준 기울기 (칸 [i,j] = 꼭짓점 (i,j)-(i+1,j+1) 사이 1m 칸). 두 삼각형 중 큰 값.
    결과 크기 (RES-1, RES-1). 행 = Z, 열 = X"""
    h00 = h[:-1, :-1]; h10 = h[:-1, 1:]; h01 = h[1:, :-1]; h11 = h[1:, 1:]
    # 삼각형 A: (0,0),(1,0),(1,1)  B: (0,0),(0,1),(1,1)
    ga = np.hypot(h10 - h00, h11 - h10)
    gb = np.hypot(h11 - h01, h01 - h00)
    tri = np.maximum(ga, gb)
    # 다른 대각선으로 나눌 수도 있으니 그쪽도 본다 (Unity 지형은 칸마다 대각선 방향이 같지 않을 수 있음)
    gc = np.hypot(h10 - h00, h01 - h00)
    gd = np.hypot(h11 - h01, h11 - h10)
    tri2 = np.maximum(gc, gd)
    return np.maximum(tri, tri2)


def vertex_slope(h):
    gz, gx = np.gradient(h)
    return np.sqrt(gx * gx + gz * gz)


def yaw_of_q(q):
    """Unity 쿼터니언 (x,y,z,w) 의 Y 회전(도). 기울기는 무시"""
    x, y, z, w = q
    # 로컬 +X 를 돌린 방향의 XZ 성분으로
    fx = 1 - 2 * (y * y + z * z)
    fz = 2 * (x * z - w * y)
    return math.degrees(math.atan2(-fz, fx))


def local_axes(yaw_deg):
    """Unity Y 회전 θ: 로컬 +X → (cosθ, −sinθ), 로컬 +Z → (sinθ, cosθ)  (x, z)"""
    t = math.radians(yaw_deg)
    return np.array([math.cos(t), -math.sin(t)]), np.array([math.sin(t), math.cos(t)])


class Curves:
    """worldgen 과 같은 방식으로 개울·다리·길 곡선을 다시 만든다 (노이즈 씨앗이 같으므로 결과도 같다)"""

    def __init__(self):
        c = wobble(catmull(wg.CREEK, 2.0), 4.0, 1 / 55.0, 701)
        seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
        s = np.concatenate([[0], np.cumsum(seg)])
        ib = int(np.argmin(np.linalg.norm(c - np.array(wg.BRIDGE_AT), axis=1)))
        bx, bz = c[ib]
        d = c[min(ib + 3, len(c) - 1)] - c[max(ib - 3, 0)]
        d = d / np.linalg.norm(d)
        r = np.array([d[1], -d[0]])
        if r[0] < 0:
            r = -r
        self.creek, self.creek_s, self.ib, self.sb = c, s, ib, s[ib]
        self.creek_dir = d
        self.bridge_p = (float(bx), float(bz))
        self.bridge_axis = r
        east_end = (bx + r[0] * 7.6, bz + r[1] * 7.6)
        west_end = (bx - r[0] * 7.6, bz - r[1] * 7.6)
        roads = list(wg.ROADS)
        roads.append((wg.ROAD_TO_BRIDGE_E + [(bx + r[0] * 20, bz + r[1] * 20), east_end], 1.9))
        roads.append(([west_end, (bx - r[0] * 20, bz - r[1] * 20)] + wg.ROAD_FROM_BRIDGE_W, 1.9))
        names = list(getattr(wg, "ROAD_NAMES", [])) or ["제단→묘지→납골당", "납골당→대성당", "대성당→북쪽 봉인문", "묘지 동서 길",
                 "묘지→안개 늪", "제단→버려진 마을", "제단→달그림자 호수", "용의 무덤→망루", "늪→고목", "고목→북쪽 길",
                 "제단 북쪽→검은 숲", "묘지 서쪽→다리 동쪽", "다리 서쪽→용의 무덤"]
        names += ["길 %d" % i for i in range(len(names), len(roads))]
        self.roads = []
        for i, (pts, hw) in enumerate(roads):
            cc = wobble(catmull(pts, 2.0), 3.2, 1 / 70.0, 900 + i)
            self.roads.append((names[i], cc, hw))


def sample_arr(a, x, z):
    return sample(a, x, z)


def bilinear(h, xs, zs):
    xs = np.clip(np.asarray(xs, np.float64), 0, RES - 1 - 1e-4)
    zs = np.clip(np.asarray(zs, np.float64), 0, RES - 1 - 1e-4)
    j = xs.astype(int); i = zs.astype(int)
    fx = xs - j; fz = zs - i
    a = h[i, j] * (1 - fx) + h[i, j + 1] * fx
    b = h[i + 1, j] * (1 - fx) + h[i + 1, j + 1] * fx
    return a * (1 - fz) + b * fz


def water_surface(objs, shape=(RES, RES)):
    """칸마다 수면 높이 (물 없으면 -inf). 물 평면은 yaw 돌린 직사각형"""
    lev = np.full(shape, -np.inf, np.float32)
    zz, xx = np.mgrid[0:shape[0], 0:shape[1]]
    for w in objs["water"]:
        cx, y, cz = w["p"]
        sx, sz = w["size"]
        t = math.radians(w.get("yaw", 0))
        R = max(sx, sz) / 2 * 1.5 + 2
        z0, z1 = max(0, int(cz - R)), min(shape[0], int(cz + R) + 1)
        x0, x1 = max(0, int(cx - R)), min(shape[1], int(cx + R) + 1)
        X = xx[z0:z1, x0:x1] - cx
        Z = zz[z0:z1, x0:x1] - cz
        ax, az = local_axes(w.get("yaw", 0))
        u = X * ax[0] + Z * ax[1]
        v = X * az[0] + Z * az[1]
        m = (np.abs(u) <= sx / 2) & (np.abs(v) <= sz / 2)
        sub = lev[z0:z1, x0:x1]
        sub[m] = np.maximum(sub[m], y)
    return lev


def ensure_out():
    os.makedirs(OUT, exist_ok=True)
    return OUT


# ─────────────── C 도우미 (navfast.c) ───────────────
import ctypes, subprocess   # noqa: E402
_LIB = None


def lib():
    global _LIB
    if _LIB is None:
        so = os.path.join(HERE, "navfast.so")
        src = os.path.join(HERE, "navfast.c")
        if not os.path.exists(so) or os.path.getmtime(so) < os.path.getmtime(src):
            subprocess.check_call(["gcc", "-O2", "-shared", "-fPIC", "-o", so, src, "-lm"])
        L = ctypes.CDLL(so)
        P = ctypes.c_void_p
        L.label4.argtypes = [P, ctypes.c_int, ctypes.c_int, P]
        L.flood_dir.argtypes = [P, P, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_float, ctypes.c_float, ctypes.c_float, P]
        L.dijkstra8.argtypes = [P, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, P, P]
        _LIB = L
    return _LIB


def label4(walk):
    walk = np.ascontiguousarray(walk.astype(np.uint8))
    lab = np.zeros(walk.shape, np.int32)
    n = lib().label4(walk.ctypes.data, walk.shape[1], walk.shape[0], lab.ctypes.data)
    return lab, n


def flood_dir(hc, ok, seed_xz, cell, up_lim, down_lim):
    hc = np.ascontiguousarray(hc.astype(np.float32))
    ok = np.ascontiguousarray(ok.astype(np.uint8))
    out = np.zeros(ok.shape, np.uint8)
    lib().flood_dir(hc.ctypes.data, ok.ctypes.data, ok.shape[1], ok.shape[0], int(seed_xz[0]), int(seed_xz[1]),
                    float(cell), float(up_lim), float(down_lim), out.ctypes.data)
    return out.astype(bool)


def dijkstra(cost, s_xz, t_xz):
    cost = np.ascontiguousarray(cost.astype(np.float32))
    dist = np.zeros(cost.shape, np.float32)
    prev = np.zeros(cost.shape, np.int32)
    lib().dijkstra8(cost.ctypes.data, cost.shape[1], cost.shape[0], int(s_xz[0]), int(s_xz[1]), int(t_xz[0]), int(t_xz[1]),
                    dist.ctypes.data, prev.ctypes.data)
    W = cost.shape[1]
    path = []
    i = int(t_xz[1]) * W + int(t_xz[0])
    while i >= 0:
        path.append((i % W, i // W))
        if i == int(s_xz[1]) * W + int(s_xz[0]):
            break
        i = int(prev.flat[i])
    return dist, path[::-1]


# ─────────────── 소품 충돌 → 격자 ───────────────
STEP = 0.35            # NecroSetupTools cc.stepOffset


def prop_shapes(objs, trees, man, which="large"):
    """충돌하는 소품을 (이름, 종류('box'|'circle'), 중심 x,z, 반폭 u, 반폭 v 또는 반지름, yaw, 높이) 로.
    which: 'large' = footprint×s ≥ 1.0 m 인 것, 'all' = 충돌 있는 것 전부 (나무 줄기 포함)
    bridge_ruin 은 넣지 않는다 (상판 위를 걷는다 → nav_bridge.py 에서 따로 본다)"""
    out = []
    for k, o in enumerate(objs["objects"]):
        a = o["a"]
        v = man.get(a)
        if v is None or a == "bridge_ruin":
            continue
        mt = v["meta"]
        col = mt.get("collider", "mesh")
        if col == "none":
            continue
        s = o["s"]
        sx, sy, sz = v["size"]
        hgt = sz * s - mt.get("sink", 0) * s
        if hgt < STEP + 0.05:
            continue
        fp = mt.get("footprint", 0.5) * s
        if which == "large" and fp < 1.0 and mt.get("kind") != "landmark":
            continue
        x, _, z = o["p"]
        yaw = yaw_of_q(o["q"])
        if col == "capsule":
            tags = mt.get("tags", [])
            if any(t in tags for t in ("rock", "cliff", "ruin")):
                rad = min(sx, sy) * 0.45 * s
            else:
                rad = max(0.2, min(1.0, min(sx, sy) * 0.12)) * s     # TrunkRadius 의 대체값 (실제 줄기 반지름은 Unity 가 정점으로 잰다)
            out.append((a, "circle", x, z, rad, rad, yaw, hgt, k))
        else:
            out.append((a, "box", x, z, sx * s / 2, sy * s / 2, yaw, hgt, k))
    if which == "all":
        protos = trees["prototypes"]
        for t in trees["instances"]:
            a = protos[t[0]]
            v = man.get(a)
            mt = v["meta"]
            if mt.get("collider", "capsule") == "none":
                continue
            s = t[4]
            sx, sy, sz = v["size"]
            tags = mt.get("tags", [])
            if any(tg in tags for tg in ("rock", "cliff", "ruin")):
                rad = min(sx, sy) * 0.45 * s
            else:
                rad = max(0.2, min(1.0, min(sx, sy) * 0.12)) * s
            hgt = sz * s
            if hgt < STEP + 0.05:
                continue
            out.append((a, "circle", t[1], t[2], rad, rad, t[3], hgt, -1))
    return out


def raster_props(shapes, cell, n, inflate=AGENT_R):
    """칸 크기 cell (m), 한 변 n 칸 격자에 소품(+주인공 반지름)을 칠한다. 막힘 bool, 소품 번호(-1 없음)"""
    block = np.zeros((n, n), bool)
    who = np.full((n, n), -1, np.int32)
    for idx, (a, kind, x, z, hu, hv, yaw, hgt, k) in enumerate(shapes):
        R = math.hypot(hu, hv) + inflate + cell
        i0, i1 = max(0, int((z - R) / cell)), min(n, int((z + R) / cell) + 2)
        j0, j1 = max(0, int((x - R) / cell)), min(n, int((x + R) / cell) + 2)
        if i1 <= i0 or j1 <= j0:
            continue
        zz = (np.arange(i0, i1) + 0.5) * cell - z
        xx = (np.arange(j0, j1) + 0.5) * cell - x
        X, Z = np.meshgrid(xx, zz)
        if kind == "circle":
            m = X * X + Z * Z <= (hu + inflate) ** 2
        else:
            ax, az = local_axes(yaw)
            u = X * ax[0] + Z * ax[1]
            v = X * az[0] + Z * az[1]
            m = (np.abs(u) <= hu + inflate) & (np.abs(v) <= hv + inflate)
        block[i0:i1, j0:j1] |= m
        w = who[i0:i1, j0:j1]
        w[m] = idx
    return block, who


# ─────────────── 걸을 수 있는 칸 격자 (nav_flood 와 같은 규칙) ───────────────
def build_walk(lim=SLOPE_MAX, which="large", use_bridge=True, cell=0.5, wade=WADE, skip=(), h=None):
    """돌려줌: dict(walk, steep, deep, pblock, pwho, shapes, hc, sl, depth, XX, ZZ, N, cell, deck, world, objs, curves, h)
    skip: 충돌에서 뺄 소품 이름 (예: ('gate_great',))"""
    N = int(2048 / cell)
    if h is None:
        h = load_height()
    world = load_world()
    objs = load_objects()
    trees = load_trees()
    man = load_manifest()
    C = Curves()
    sl1 = cell_slope(h)
    rep = int(round(1 / cell))
    sl = np.repeat(np.repeat(sl1, rep, 0), rep, 1)
    ax = (np.arange(N) + 0.5) * cell
    XX, ZZ = np.meshgrid(ax, ax)
    hc = bilinear(h, XX.ravel(), ZZ.ravel()).reshape(N, N).astype(np.float32)
    lev1 = water_surface(objs)
    lev = lev1[ZZ.astype(int), XX.astype(int)]
    depth = lev - hc
    shapes = [] if which == "none" else [s for s in prop_shapes(objs, trees, man, which) if s[0] not in skip]
    if shapes:
        pblock, pwho = raster_props(shapes, cell, N)
    else:
        pblock, pwho = np.zeros((N, N), bool), np.full((N, N), -1, np.int32)
    steep = sl > lim
    deep = depth > wade
    walk = ~steep & ~deep & ~pblock
    bx, bz = C.bridge_p
    r = C.bridge_axis
    yaw_b = math.degrees(math.atan2(-r[1], r[0]))
    axu, axv = local_axes(yaw_b)
    U = (XX - bx) * axu[0] + (ZZ - bz) * axu[1]
    V = (XX - bx) * axv[0] + (ZZ - bz) * axv[1]
    deck = (np.abs(U) <= 7.0) & (np.abs(V) <= 1.55 - AGENT_R)
    side = (np.abs(U) <= 7.0) & (np.abs(V) > 1.55 - AGENT_R) & (np.abs(V) <= 2.0 + 0.45 + AGENT_R)
    if use_bridge:
        walk[deck] = True
        walk[side & (np.abs(U) > 4.6)] = False
    return dict(walk=walk, steep=steep, deep=deep, pblock=pblock, pwho=pwho, shapes=shapes, hc=hc, sl=sl, depth=depth,
                XX=XX, ZZ=ZZ, N=N, cell=cell, deck=deck, world=world, objs=objs, curves=C, h=h, sl1=sl1, lev=lev)


def reach_from_spawn(G):
    sp = G["world"]["spawn"]["p"]
    c = G["cell"]
    lab, n = label4(G["walk"])
    L0 = lab[int(sp[2] / c), int(sp[0] / c)]
    return lab == L0, lab, L0


def why(G, i, j):
    """칸이 왜 막혔는지 글로"""
    r = []
    if G["steep"][i, j]:
        r.append("기울기 %.2f" % G["sl"][i, j])
    if G["deep"][i, j]:
        r.append("물깊이 %.2f" % G["depth"][i, j])
    if G["pblock"][i, j]:
        r.append("소품 %s" % G["shapes"][G["pwho"][i, j]][0])
    return ", ".join(r) if r else "걸을 수 있음"
