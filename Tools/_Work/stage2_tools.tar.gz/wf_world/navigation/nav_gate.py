#!/usr/bin/env python3
# 북쪽 봉인문: 고갯길 폭과 문 크기 비교, 문을 돌아 북쪽으로 빠지는 길이 있는지
#   python3 nav_gate.py [기울기한계=1.0]
import sys, math
import numpy as np
import navcommon as nc

lim = float(sys.argv[1]) if len(sys.argv) > 1 else nc.SLOPE_MAX
CELL = 0.5
G = nc.build_walk(lim, "large", True, cell=CELL)
XX, ZZ, hc, sl, walk = G["XX"], G["ZZ"], G["hc"], G["sl"], G["walk"]
man = nc.load_manifest()
gate = [o for o in G["objs"]["objects"] if o["a"] == "gate_great"][0]
gx, gy, gz = gate["p"]
gs = gate["s"]
sx, sy, sz = man["gate_great"]["size"]
gyaw = nc.yaw_of_q(gate["q"])
ax_u, ax_v = nc.local_axes(gyaw)
print("gate_great: 자리 (%.1f, %.2f, %.1f) yaw %.1f 크기 %.2f(폭) × %.2f(두께) × %.2f(높이) m → x %.1f~%.1f, z %.1f~%.1f" % (
    gx, gy, gz, gyaw, sx * gs, sy * gs, sz * gs, gx - abs(ax_u[0]) * sx / 2 - abs(ax_v[0]) * sy / 2, gx + abs(ax_u[0]) * sx / 2 + abs(ax_v[0]) * sy / 2,
    gz - abs(ax_u[1]) * sx / 2 - abs(ax_v[1]) * sy / 2, gz + abs(ax_u[1]) * sx / 2 + abs(ax_v[1]) * sy / 2))

print("\n고갯길 가로 단면 (x 880~1140): 기울기 ≤ %.2f 인 이어진 구간 (소품 빼고 지형만), 그 구간의 바닥 높이" % lim)
for z in list(range(1780, 1880, 6)) + [1822]:
    i = int(z / CELL)
    js = np.arange(int(880 / CELL), int(1140 / CELL))
    ok = sl[i, js] <= lim
    idx = js[ok]
    if len(idx) == 0:
        print("  z=%d: 없음" % z)
        continue
    runs = np.split(idx, np.nonzero(np.diff(idx) > 1)[0] + 1)
    runs = [r for r in runs if len(r) * CELL >= 2]
    desc = []
    for r in runs:
        x0, x1 = r[0] * CELL, (r[-1] + 1) * CELL
        hh = hc[i, r]
        desc.append("x %.0f~%.0f (%.0f m, 높이 %.1f~%.1f)" % (x0, x1, x1 - x0, hh.min(), hh.max()))
    print("  z=%d: %s" % (z, "; ".join(desc)))

# 문 줄(z = gz)에서 x 별 기울기·높이
i = int(gz / CELL)
print("\n문 줄 z=%.0f 단면 (5 m 간격): x: 높이 / 기울기" % gz)
print("  " + "  ".join("%d:%.1f/%.2f" % (x, hc[i, int(x / CELL)], sl[i, int(x / CELL)]) for x in range(930, 1095, 5)))

# 문을 넣고 / 빼고 북쪽 칸에 닿는지
reach, lab, L0 = nc.reach_from_spawn(G)
north = (ZZ > gz + 15) & (np.abs(XX - gx) < 200)
print("\n문(충돌 상자 + 반지름 0.4) 이 있을 때 문 북쪽 15 m 밖 칸에 닿음: %s (%.0f m²)" % (bool((reach & north).any()), (reach & north).sum() * CELL * CELL))
if (reach & north).any():
    cost = np.where(walk, 1.0, 1e5).astype(np.float32)
    sp = G["world"]["spawn"]["p"]
    t = (int(gx / CELL), int((gz + 40) / CELL))
    if not reach[t[1], t[0]]:
        zs, xs = np.nonzero(reach & north)
        k = np.argmin((xs - t[0]) ** 2 + (zs - t[1]) ** 2)
        t = (int(xs[k]), int(zs[k]))
    dist, path = nc.dijkstra(cost, (int(sp[0] / CELL), int(sp[2] / CELL)), t)
    P = np.array(path) * CELL
    # 문 줄을 지나는 자리
    k = np.argmin(np.abs(P[:, 1] - gz))
    near = P[(P[:, 1] > gz - 30) & (P[:, 1] < gz + 30)]
    print("  돌아가는 길이 문 줄 z=%.0f 를 지나는 자리: x=%.1f (문 가운데에서 %.1f m), 높이 %.1f, 그 근처 가장 가파름 %.2f" % (
        gz, P[k, 0], P[k, 0] - gx, hc[int(P[k, 1] / CELL), int(P[k, 0] / CELL)],
        max(sl[int(z / CELL), int(x / CELL)] for x, z in near)))
    print("  그 길 z %.0f~%.0f 구간 점: %s" % (gz - 30, gz + 30, " ".join("(%.0f,%.0f)" % (x, z) for x, z in near[::8])))
# 문 북쪽 고갯길이 지형 끝까지 이어지는지 (문 빼고, 문 북쪽 칸에서)
G2 = nc.build_walk(lim, "large", True, cell=CELL, skip=("gate_great",))
lab2, _ = nc.label4(G2["walk"])
t = lab2[int((gz + 20) / CELL), int(gx / CELL)]
m = lab2 == t
print("\n문 북쪽 (%.0f, %.0f) 칸의 묶음: 지형 북쪽 끝 z>2040 칸 %.0f m², 시작 묶음과 같음: %s" % (
    gx, gz + 20, (m & (ZZ > 2040)).sum() * CELL * CELL, t == lab2[int(G2['world']['spawn']['p'][2] / CELL), int(G2['world']['spawn']['p'][0] / CELL)]))
