import sys
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
D = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation/refute_pool/"
h0 = nc.load_height()
win = (slice(900, 1110), slice(660, 790))
s0 = nc.cell_slope(h0[win])
for nm in ("prop", "B", "C"):
    h = np.load(D + "h_%s.npy" % nm)
    s1 = nc.cell_slope(h[win])
    ch = np.abs(h[win] - h0[win])[:-1, :-1] > 0.01
    new = (s1 > 1.0) & ~(s0 > 1.0)
    new58 = (s1 > 0.58) & ~(s0 > 0.58)
    print("%-5s 바뀐 칸 근처 새로 45° 넘는 칸 %d (최대 기울기 %.2f), 새로 30° 넘는 칸 %d; 원래 45° 넘던 칸 중 고쳐진 칸 %d" % (
        nm, new.sum(), s1[ch].max() if ch.any() else 0, new58.sum(), ((s0 > 1.0) & ~(s1 > 1.0)).sum()))
    zz, xx = np.nonzero(new)
    if len(zz):
        print("      새 가파른 칸 예: " + ", ".join("(%d,%d)" % (x + 660, z + 900) for z, x in list(zip(zz, xx))[:: max(1, len(zz) // 6)]))
print("지금 이 창에서 45° 넘는 칸 %d, 그중 웅덩이 상자 옆 띠 (h≈수면+0.4) 쪽" % (s0 > 1.0).sum())
lv = 44.667
rib = np.abs(h0[win] - (lv + 0.4)) < 0.01
print("  수면+0.4 로 올린 칸 %d" % rib.sum())
