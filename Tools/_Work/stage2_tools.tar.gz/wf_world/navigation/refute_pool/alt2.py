import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation/refute_pool")
import numpy as np
import poolfix as pf, alt
import navcommon as nc
from terrain import ss
h0, lv, sb, along, dist, wt = pf.h0, pf.lv, pf.sb, pf.along, pf.dist, pf.wt
z0, z1, x0, x1 = pf.z0, pf.z1, pf.x0, pf.x1
win = (slice(900, 1110), slice(660, 790))
s0 = nc.cell_slope(h0[win])

def sills2(sub, lo, hi, lat_in, lat_out, ramp):
    lat = ss(-dist, -(wt + lat_out), -(wt + lat_in))
    tgt = np.maximum(sub, lv + 0.2)
    wN = np.where((along >= lo - 6) & (along <= lo + 2), 1.0, ss(along, lo - 6 - ramp, lo - 6) * (along < lo - 6))
    wS = np.where((along >= hi - 2) & (along <= hi + 6), 1.0, ss(-along, -(hi + 6 + ramp), -(hi + 6)) * (along > hi + 6))
    w = np.maximum(wN, wS) * lat
    return sub * (1 - w) + tgt * w

for lo, lat_in, lat_out, ramp in ((sb - 36, 2, 14, 25), (sb - 24, 2, 14, 25), (sb - 24, 2, 14, 15), (sb - 24, 2, 20, 15)):
    pf.rects[:] = alt.planes(lo, sb + 36); pf.BND[:] = pf.boundary()
    h = h0.copy(); sub = h[z0:z1, x0:x1]; sub[:] = sills2(sub, lo, sb + 36, lat_in, lat_out, ramp)
    pf.report(h, "북끝 sb%+.0f, 옆 wt+%d~wt+%d 섞기, 경사로 %d m" % (lo - sb, lat_in, lat_out, ramp))
    s1 = nc.cell_slope(h[win]); d = h - h0
    print("    새 45° 칸 %d, 새 30° 칸 %d, 올림 최대 %.2f m, 흙 %.0f m³" % (((s1 > 1) & ~(s0 > 1)).sum(), ((s1 > 0.58) & ~(s0 > 0.58)).sum(), d.max(), d[d > 0].sum()))
