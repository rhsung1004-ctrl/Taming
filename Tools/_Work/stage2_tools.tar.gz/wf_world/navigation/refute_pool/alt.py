# 대안 비교: (B) 웅덩이 구간을 '메우기'까지 (바닥 Bb, 둑 수면+0.3, 양끝 문턱)  (C) 웅덩이 북쪽 끝을 sb-24 로 당기고 작은 문턱
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation/refute_pool")
import numpy as np
import poolfix as pf
import navcommon as nc
from terrain import ss
h0, lv, sb, along, dist, wt = pf.h0, pf.lv, pf.sb, pf.along, pf.dist, pf.wt
z0, z1, x0, x1 = pf.z0, pf.z1, pf.x0, pf.x1
c, s = pf.c, pf.s
Bb = lv - 0.42

def sills(sub, lo, hi, lat_extra, h_add=0.2, ramp=25):
    lat = ss(-dist, -(wt + lat_extra + 3), -(wt + lat_extra))
    tgt = np.maximum(sub, lv + h_add)
    wN = np.where((along >= lo - 8) & (along <= lo + 2), 1.0, ss(along, lo - 8 - ramp, lo - 8) * (along < lo - 8))
    wS = np.where((along >= hi - 2) & (along <= hi + 6), 1.0, ss(-along, -(hi + 6 + ramp), -(hi + 6)) * (along > hi + 6))
    w = np.maximum(wN, wS) * lat
    return sub * (1 - w) + tgt * w

def fix_B(h):
    h = h.copy(); sub = h[z0:z1, x0:x1]
    zone = ss(-np.abs(along - sb), -46, -40)                       # 웅덩이 구간 (+-40 m, 46 m 까지 섞기)
    wb = 2.6
    fill = np.where(dist < wb, Bb, Bb + (dist - wb) / (wt - wb) * (lv + 0.3 - Bb))
    fill = np.minimum(fill, lv + 0.3)
    wl = ss(-dist, -(wt + 12), -(wt + 4))                          # 둑은 곡선에서 wt+4 까지 꼭, wt+12 까지 섞기
    sub[:] = np.maximum(sub, sub * (1 - zone * wl) + fill * zone * wl)
    sub[:] = sills(sub, sb - 36, sb + 36, 4)
    return h

def planes(s0, s1):
    rects = []
    k = s0
    while k < s1 - 1:
        k2 = min(k + 18, s1)
        i0, i1 = int(np.searchsorted(s, k)), min(int(np.searchsorted(s, k2)), len(c) - 1)
        a, b = c[i0], c[i1]; mid = (a + b) / 2; dv = b - a
        ln = float(np.linalg.norm(dv)) + 0.6
        yaw = math.degrees(math.atan2(dv[0], dv[1])); t = math.radians(yaw)
        rects.append((mid, np.array([math.cos(t), -math.sin(t)]), np.array([math.sin(t), math.cos(t)]), 7.5, ln / 2))
        k = k2
    return rects

def fix_C(h):
    h = h.copy(); sub = h[z0:z1, x0:x1]
    sub[:] = sills(sub, sb - 24, sb + 36, 4)
    return h

if __name__ == "__main__":
    hB = fix_B(h0)
    pf.report(hB, "B: 웅덩이 구간 메우기 + 양끝 문턱")
    np.save(pf.__file__.replace("poolfix.py", "h_B.npy"), hB)
    pf.rects[:] = planes(sb - 24, sb + 36); pf.BND[:] = pf.boundary()
    pf.report(h0, "C 전: 북쪽 끝 sb-24 로 당김 (지형 그대로)")
    hC = fix_C(h0)
    pf.report(hC, "C: 북쪽 끝 sb-24 + 작은 문턱")
    np.save(pf.__file__.replace("poolfix.py", "h_C.npy"), hC)
    for nm, hh in (("제안", np.load(pf.__file__.replace("poolfix.py", "h_prop.npy"))), ("B", hB), ("C", hC)):
        d = hh - h0
        print("%s: 높이 바뀐 칸 %d, 올림 최대 %.2f m, 흙 %.0f m³" % (nm, (np.abs(d) > 0.01).sum(), d.max(), d[d > 0].sum()))
