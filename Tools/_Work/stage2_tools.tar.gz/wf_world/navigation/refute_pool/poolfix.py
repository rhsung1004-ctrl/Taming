# 다리 웅덩이 물 평면 둘레가 지형 위로 뜨는지, 제안 수정(양끝 문턱)과 대안을 높이 사본에 더해 다시 본다
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
import worldgen as wg
from terrain import ss, polyline_field

h0 = nc.load_height()
o = nc.load_objects()
lv = nc.load_world()["levels"]["creekPool"]
rects = []
for w in o["water"]:
    if abs(w["p"][1] - lv) > 1e-3:
        continue
    t = math.radians(w["yaw"])
    ax = np.array([math.cos(t), -math.sin(t)]); az = np.array([math.sin(t), math.cos(t)])
    rects.append((np.array([w["p"][0], w["p"][2]]), ax, az, w["size"][0] / 2, w["size"][1] / 2))

def inside(p, k, tol=0.02):
    c, ax, az, hx, hz = rects[k]
    d = p - c
    return abs(d @ ax) < hx - tol and abs(d @ az) < hz - tol

def boundary(step=0.25):
    pts = []
    for k, (c, ax, az, hx, hz) in enumerate(rects):
        corners = [c + ax * a * hx + az * b * hz for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
        for e in range(4):
            p0, p1 = corners[e], corners[(e + 1) % 4]
            n = int(np.linalg.norm(p1 - p0) / step)
            for i in range(n):
                p = p0 + (p1 - p0) * (i + 0.5) / n
                if any(inside(p, j) for j in range(len(rects)) if j != k):
                    continue
                pts.append((k, e, p))
    return pts

BND = boundary()

def report(h, name):
    P = np.array([p for _, _, p in BND])
    hh = nc.bilinear(h, P[:, 0], P[:, 1])
    gap = lv - hh
    fl = gap > 0.05
    print("[%s] 물 판 둘레 %.0f m 중 지형보다 뜬 곳 %.1f m (0.5 m 넘게 %.1f m, 1 m 넘게 %.1f m), 가장 크게 뜬 높이 %.2f m" % (
        name, len(P) * 0.25, fl.sum() * 0.25, (gap > 0.5).sum() * 0.25, (gap > 1.0).sum() * 0.25, gap.max()))
    # 판·변별
    for k in range(len(rects)):
        for e in range(4):
            m = np.array([(kk == k and ee == e) for kk, ee, _ in BND])
            if m.any() and (fl & m).any():
                q = P[m & fl]
                print("    판%d 변%d: 뜬 길이 %.1f m, 최대 %.2f m, 대표 (%.1f, %.1f)" % (k, e, (fl & m).sum() * 0.25, gap[m].max(), q[len(q) // 2][0], q[len(q) // 2][1]))
    # 판 안 깊이
    xs = np.arange(680, 760, 0.5); zs = np.arange(950, 1060, 0.5)
    XX, ZZ = np.meshgrid(xs, zs)
    pts = np.stack([XX.ravel(), ZZ.ravel()], 1)
    inn = np.zeros(len(pts), bool)
    for (c, ax, az, hx, hz) in rects:
        d = pts - c
        inn |= (np.abs(d @ ax) <= hx) & (np.abs(d @ az) <= hz)
    dep = lv - nc.bilinear(h, pts[inn, 0], pts[inn, 1])
    print("    판 안 물 넓이 %.0f m², 깊이 >0.6 m %.0f m², >1.0 m %.0f m², >1.6 m %.0f m², 최대 %.2f m" % (
        (dep > 0).sum() * 0.25, (dep > 0.6).sum() * 0.25, (dep > 1.0).sum() * 0.25, (dep > 1.6).sum() * 0.25, dep.max()))

C = nc.Curves(); c, s = C.creek, C.creek_s; sb = C.sb
L = s[-1]
(z0, z1), (x0, x1), dist, along = polyline_field(c, 16, nc.RES)[:4]
wt = np.where(np.abs(along - sb) < 45, 5.6, np.where(along < 230, 3.0 + (2.4 + 7.0 * 0) * 0.75, 6.5)).astype(np.float32)

def fix_proposed(h):
    h = h.copy(); sub = h[z0:z1, x0:x1]
    lat = dist <= wt + 4
    tgt = np.maximum(sub, lv + 0.2)
    wN = np.where((along >= sb - 42) & (along <= sb - 34), 1.0, ss(along, sb - 67, sb - 42) * (along < sb - 42))
    wS = np.where((along >= sb + 34) & (along <= sb + 42), 1.0, ss(-along, -(sb + 67), -(sb + 42)) * (along > sb + 42))
    w = np.maximum(wN, wS) * lat
    sub[:] = sub * (1 - w) + tgt * w
    return h

if __name__ == "__main__":
    report(h0, "지금")
    h1 = fix_proposed(h0)
    report(h1, "제안(양끝 문턱)")
    np.save("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation/refute_pool/h_prop.npy", h1)
