import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
h = nc.load_height() if len(sys.argv) < 2 else np.load(sys.argv[1])
lv = 44.667
C = nc.Curves(); c, s = C.creek, C.creek_s; sb = C.sb
print("sb=%.1f  pool s=[%.1f, %.1f]" % (sb, sb - 36, sb + 36))
ts = np.arange(-16, 16.01, 2)
print("  ds   " + " ".join("%6.0f" % t for t in ts))
for ds in list(range(-80, -20, 4)) + list(range(28, 80, 6)):
    si = sb + ds
    i = min(int(np.searchsorted(s, si)), len(c) - 1)
    j0, j1 = max(0, i - 2), min(len(c) - 1, i + 2)
    d = c[j1] - c[j0]; d /= np.linalg.norm(d); n = np.array([-d[1], d[0]])
    pts = c[i][None] + ts[:, None] * n[None]
    hh = nc.bilinear(h, pts[:, 0], pts[:, 1]) - lv
    print("%+4d  " % ds + " ".join("%+6.2f" % v for v in hh))
