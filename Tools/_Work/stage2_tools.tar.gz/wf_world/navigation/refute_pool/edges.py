import sys, json, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
h = nc.load_height()
o = nc.load_objects()
lv = nc.load_world()["levels"]["creekPool"]
pools = [w for w in o["water"] if abs(w["p"][1] - lv) < 1e-3]
print("수면", lv)
def axes(yaw):
    t = math.radians(yaw)
    return np.array([math.cos(t), -math.sin(t)]), np.array([math.sin(t), math.cos(t)])
for k in (0, len(pools) - 1):
    w = pools[k]
    c = np.array([w["p"][0], w["p"][2]]); ax, az = axes(w["yaw"]); sx, sz = w["size"]
    print("\n판", k, w)
    # 0번 판은 -Z 쪽 끝(북쪽), 마지막 판은 +Z 쪽 끝(남쪽)
    sign = -1 if k == 0 else 1
    for off in (-3, -1, -0.3, 0, 0.3, 1, 3, 6, 10):
        d = sz / 2 + off
        row = []
        for u in np.arange(-7.5, 7.51, 1.5):
            p = c + az * sign * d + ax * u
            row.append(nc.bilinear(h, np.array([p[0]]), np.array([p[1]]))[0] - lv)
        p0 = c + az * sign * d
        print("끝에서 %+5.1f m (%.1f,%.1f): 지형-수면 " % (off, p0[0], p0[1]) + " ".join("%+5.2f" % r for r in row))
