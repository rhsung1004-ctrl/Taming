#!/usr/bin/env python3
# 가장자리 산 단면: bounds 선에서 지형 끝까지 바깥으로 가며 높이·기울기 (지정한 줄)
#   python3 nav_rim.py            기본 줄들
#   python3 nav_rim.py W 1008     서쪽, z=1008 줄 (W/E 는 z, S/N 은 x 를 준다)
# 그리고 bounds 둘레 전체에서 "bounds 선 → 바깥 60 m 안에 기울기 > 1.0 인 벽이 있는 비율"과
# worldgen 의 산 무게 m (= ss(-d_edge, -300, -70)) 을 다시 계산해 bounds 선에서의 값을 본다
import sys
import numpy as np
import navcommon as nc
from terrain import fbm, ss

h = nc.load_height()
sl = nc.cell_slope(h)
lines = [("W", 1008), ("W", 1300), ("W", 500), ("E", 800), ("E", 1300), ("S", 466), ("S", 1400), ("N", 1885), ("N", 1010), ("N", 1300)]
if len(sys.argv) > 2:
    lines = [(sys.argv[1], int(sys.argv[2]))]
for side, c in lines:
    if side == "W":
        pts = [(x, c) for x in range(170, -1, -10)]
    elif side == "E":
        pts = [(x, c) for x in range(1878, 2048, 10)]
    elif side == "S":
        pts = [(c, z) for z in range(170, -1, -10)]
    else:
        pts = [(c, z) for z in range(1878, 2048, 10)]
    s = " ".join("%.0f/%.2f" % (h[z, x], sl[min(z, 2047), min(x, 2047)]) for x, z in pts)
    print("%s %d: bounds 선에서 바깥으로 10 m 마다 높이/기울기: %s" % (side, c, s))

# bounds 둘레: 바깥 0~60 m, 0~120 m 띠 안에서 '안→밖' 줄마다 기울기 > 1.0 칸이 하나라도 있는가
print("\nbounds 둘레의 줄마다 (bounds 선에서 바깥으로) 처음 기울기 > 1.0 칸까지 거리")
for side in "WESN":
    first = []
    for c in range(170, 1879):
        if side == "W":
            prof = sl[c, 170::-1]
        elif side == "E":
            prof = sl[c, 1878:]
        elif side == "S":
            prof = sl[170::-1, c]
        else:
            prof = sl[1878:, c]
        k = np.nonzero(prof > 1.0)[0]
        first.append(k[0] if len(k) else 9999)
    f = np.array(first)
    print("  %s: 60 m 안에 벽 있음 %.0f%%, 120 m 안 %.0f%%, 끝까지 없음 %.0f%% (중앙값 %s m)" % (
        side, (f <= 60).mean() * 100, (f <= 120).mean() * 100, (f == 9999).mean() * 100, int(np.median(f))))

# worldgen 산 무게 다시 계산 (build_height 의 식 그대로)
ax = np.arange(nc.RES, dtype=np.float32)
X, Z = np.meshgrid(ax, ax)
wob = 150 * fbm(X, Z, 1 / 520, 3, 300) + 45 * fbm(X, Z, 1 / 150, 3, 310)
k = 140.0
a = -k * np.log(np.exp(-X / k) + np.exp(-(2048 - X) / k))
b = -k * np.log(np.exp(-Z / k) + np.exp(-(2048 - Z) / k))
d_edge = -k * np.log(np.exp(-a / k) + np.exp(-b / k)) + 95 + wob
m = ss(-d_edge, -300, -70)
print("\nworldgen 산 무게 m (1 = 다 자란 산): wob 범위 %.0f ~ %.0f m" % (wob.min(), wob.max()))
for side, sel in (("W x=170", m[170:1879, 170]), ("E x=1878", m[170:1879, 1878]), ("S z=170", m[170, 170:1879]), ("N z=1878", m[1878, 170:1879])):
    print("  bounds 선 %s: m 평균 %.2f, 최소 %.2f, m<0.3 비율 %.0f%%" % (side, sel.mean(), sel.min(), (sel < 0.3).mean() * 100))
for side, sel in (("W x=40", m[170:1879, 40]), ("E x=2008", m[170:1879, 2008]), ("S z=40", m[40, 170:1879]), ("N z=2008", m[2008, 170:1879])):
    print("  끝에서 40 m %s: m 평균 %.2f, 최소 %.2f" % (side, sel.mean(), sel.min()))
print("  문 자리 (1010,1822): m %.2f, d_edge %.0f; 고갯길 양옆 (950,1822) m %.2f, (1070,1822) m %.2f" % (
    m[1822, 1010], d_edge[1822, 1010], m[1822, 950], m[1822, 1070]))
for x in (900, 940, 980, 1010, 1040, 1080, 1120):
    print("    x=%d z=1822 높이 %.1f, z=1900 높이 %.1f, z=2000 높이 %.1f, m(1900) %.2f" % (x, h[1822, x], h[1900, x], h[2000, x], m[1900, x]))
