#!/usr/bin/env python3
# 개울 곡선을 따라 실제 바닥 높이, 양쪽 둑 높이(곡선에서 ±16 m), 둑 기울기 최대, 파인 깊이
#   python3 nav_creek.py [간격 m=20]
# 개울은 북쪽(805,1395)에서 s=0, 호수(720,400)에서 s≈1010. worldgen 은 아래로 갈수록 바닥이 낮아지게(단조) 만들려 한다
import sys
import numpy as np
import navcommon as nc

step = float(sys.argv[1]) if len(sys.argv) > 1 else 20
h = nc.load_height()
sl = nc.cell_slope(h)
C = nc.Curves()
c, s = C.creek, C.creek_s
print("  s     (x, z)        바닥   왼둑(-16) 오른둑(+16)  파인깊이  둑기울기최대  바닥이 위쪽(s 작은 쪽)보다 높음")
prev = None
rows = []
for si in np.arange(0, s[-1], step):
    i = int(np.searchsorted(s, si)); i = min(i, len(c) - 1)
    j0, j1 = max(0, i - 2), min(len(c) - 1, i + 2)
    d = c[j1] - c[j0]; d = d / np.linalg.norm(d); nrm = np.array([-d[1], d[0]])
    ts = np.arange(-16, 16.01, 0.5)
    pts = c[i][None, :] + ts[:, None] * nrm[None, :]
    hh = nc.bilinear(h, pts[:, 0], pts[:, 1])
    bed = hh[np.abs(ts) <= 3].min()
    lb, rb = hh[0], hh[-1]
    smax = sl[pts[:, 1].astype(int), pts[:, 0].astype(int)].max()
    up = "  ▲ +%.2f" % (bed - prev) if prev is not None and bed > prev + 0.3 else ""
    print("%5.0f (%6.1f,%7.1f) %6.2f  %7.2f  %7.2f   %6.2f    %5.2f%s" % (si, c[i][0], c[i][1], bed, lb, rb, min(lb, rb) - bed, smax, up))
    prev = bed
