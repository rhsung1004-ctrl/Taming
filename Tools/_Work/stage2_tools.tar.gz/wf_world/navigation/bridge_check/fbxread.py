import struct, zlib, sys
import numpy as np

def read_fbx(path):
    data = open(path, 'rb').read()
    assert data[:20] == b'Kaydara FBX Binary  '
    ver = struct.unpack('<I', data[23:27])[0]
    big = ver >= 7500
    pos = 27
    def read_prop(p):
        t = chr(data[p]); p += 1
        if t == 'Y': return struct.unpack('<h', data[p:p+2])[0], p+2
        if t == 'C': return data[p] != 0, p+1
        if t == 'I': return struct.unpack('<i', data[p:p+4])[0], p+4
        if t == 'F': return struct.unpack('<f', data[p:p+4])[0], p+4
        if t == 'D': return struct.unpack('<d', data[p:p+8])[0], p+8
        if t == 'L': return struct.unpack('<q', data[p:p+8])[0], p+8
        if t in 'SR':
            n = struct.unpack('<I', data[p:p+4])[0]; return data[p+4:p+4+n], p+4+n
        if t in 'fdlibc':
            n, enc, clen = struct.unpack('<III', data[p:p+12]); p += 12
            raw = data[p:p+clen]; p += clen
            if enc == 1: raw = zlib.decompress(raw)
            dt = {'f': '<f4', 'd': '<f8', 'l': '<i8', 'i': '<i4', 'b': 'u1', 'c': 'u1'}[t]
            return np.frombuffer(raw, dt), p
        raise ValueError(t)
    def read_node(p):
        if big:
            end, nprop, plen = struct.unpack('<QQQ', data[p:p+24]); p += 24
        else:
            end, nprop, plen = struct.unpack('<III', data[p:p+12]); p += 12
        nl = data[p]; p += 1
        name = data[p:p+nl].decode(); p += nl
        if end == 0: return None, p
        props = []
        for _ in range(nprop):
            v, p = read_prop(p); props.append(v)
        kids = []
        while p < end:
            n, p2 = read_node(p)
            if n is None: p = p2; break
            kids.append(n); p = p2
        return (name, props, kids), end
    nodes = []
    while pos < len(data) - 200:
        n, pos = read_node(pos)
        if n is None: break
        nodes.append(n)
    return nodes

def find(nodes, name):
    return [n for n in nodes if n[0] == name]
