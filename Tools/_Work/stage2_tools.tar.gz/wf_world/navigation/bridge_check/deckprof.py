import fbxread as F, numpy as np, sys
nodes = F.read_fbx('/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_out/bridge_ruin.fbx')
obj = F.find(nodes,'Objects')[0]
G={}
for o in obj[2]:
    if o[0]=='Geometry':
        nm=o[1][1].split(b'\x00')[0].decode()
        V=[k for k in o[2] if k[0]=='Vertices'][0][1][0].reshape(-1,3)
        I=[k for k in o[2] if k[0]=='PolygonVertexIndex'][0][1][0]
        G[nm]=(V,I)
V,I=G['bridge_ruin_LOD1']
tris=[]; poly=[]
for idx in I:
    if idx<0:
        poly.append(~idx)
        for k in range(1,len(poly)-1): tris.append((poly[0],poly[k],poly[k+1]))
        poly=[]
    else: poly.append(idx)
T=np.array(tris)
A=V[T[:,0]];B=V[T[:,1]];C=V[T[:,2]]
def hits(px,pz):
    x0,z0=A[:,0],A[:,2];x1,z1=B[:,0],B[:,2];x2,z2=C[:,0],C[:,2]
    d=(z1-z2)*(x0-x2)+(x2-x1)*(z0-z2)
    with np.errstate(all='ignore'):
        l0=((z1-z2)*(px-x2)+(x2-x1)*(pz-z2))/d
        l1=((z2-z0)*(px-x2)+(x0-x2)*(pz-z2))/d
    l2=1-l0-l1
    m=(l0>=0)&(l1>=0)&(l2>=0)&(np.abs(d)>1e-12)
    return np.sort(l0[m]*A[m,1]+l1[m]*B[m,1]+l2[m]*C[m,1])
for a in (0.0, -1.0, 1.0):
    print('a=%+.1f'%a)
    for x in list(np.arange(-7.1,-6.0,0.05))+[0.0]+list(np.arange(6.0,7.1,0.05)):
        h=hits(x,a)
        print('  x=%+.2f top %s  (hits %d, lowest %s)'%(x, '%.3f'%h[-1] if len(h) else '-', len(h), '%.2f'%h[0] if len(h) else '-'))
