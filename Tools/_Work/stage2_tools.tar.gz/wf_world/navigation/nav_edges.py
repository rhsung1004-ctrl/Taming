#!/usr/bin/env python3
# 지도 가장자리 검사: bounds(170~1878) 밖으로, 지형 끝(0/2048)까지 걸어 나가는 통로가 있는지
#   python3 nav_edges.py [기울기한계=1.0]
# 통로마다: 시작 위치에서 가는 최단 걸음 길, bounds 를 넘는 자리, 그 길에서 가장 가파른 기울기, 높이
import sys, math, json
import numpy as np
import navcommon as nc

lim = float(sys.argv[1]) if len(sys.argv) > 1 else nc.SLOPE_MAX
CELL = 1.0
G = nc.build_walk(lim, "large", True, cell=CELL)
reach, lab, L0 = nc.reach_from_spawn(G)
XX, ZZ, hc, sl, N = G["XX"], G["ZZ"], G["hc"], G["sl"], G["N"]
world = G["world"]
(b0x, b0z), (b1x, b1z) = world["bounds"]["min"], world["bounds"]["max"]
inb = (XX > b0x) & (XX < b1x) & (ZZ > b0z) & (ZZ < b1z)
print("기울기 한계 %.2f (%.0f°): 시작 묶음 %.2f km², bounds 밖 %.0f m²" % (lim, math.degrees(math.atan(lim)), reach.sum() / 1e6, (reach & ~inb).sum()))

# 지형 끝 띠(바깥 3 m)에 닿은 칸을 묶음으로
band = reach & ((XX < 12) | (XX > 2036) | (ZZ < 12) | (ZZ > 2036))
bl, bn = nc.label4(band)
print("지형 끝 12 m 띠에서 닿는 곳: %d 군데" % bn)
cost = np.where(G["walk"], 1.0, 1e5).astype(np.float32)
sp = world["spawn"]["p"]
s_xz = (int(sp[0]), int(sp[2]))
res = []
groups = []
for k in range(1, bn + 1):
    zs, xs = np.nonzero(bl == k)
    groups.append((len(xs), int(np.median(xs)), int(np.median(zs)), xs.min(), xs.max(), zs.min(), zs.max()))
groups.sort(key=lambda g: -g[0])
for (cnt, tx, tz, x0, x1, z0, z1) in groups[:12]:
    # 띠 안에서 실제로 닿은 칸으로
    zs, xs = np.nonzero(reach[max(0, tz - 3):tz + 4, max(0, tx - 3):tx + 4])
    tx, tz = int(xs[0] + max(0, tx - 3)), int(zs[0] + max(0, tz - 3))
    dist, path = nc.dijkstra(cost, s_xz, (tx, tz))
    P = np.array(path)
    px, pz = P[:, 0], P[:, 1]
    ob = ~inb[pz, px]
    i_cross = int(np.argmax(ob))
    cx, cz = px[i_cross], pz[i_cross]
    outside = P[i_cross:]
    smax = float(sl[outside[:, 1], outside[:, 0]].max())
    hcross = float(hc[cz, cx])
    hend = float(hc[tz, tx])
    hmax = float(hc[outside[:, 1], outside[:, 0]].max())
    ln = len(outside)
    blocked = int((~G["walk"][pz, px]).sum())
    side = "서" if tx < 12 else "동" if tx > 2036 else "남" if tz < 12 else "북"
    print("  %s쪽 끝 (%d, %d) 띠 %d칸 [x %d~%d z %d~%d]: bounds 넘는 곳 (%d, %d) 높이 %.1f → 끝 높이 %.1f, 밖 구간 %d m, 가장 높은 곳 %.1f, 가장 가파름 %.2f, 막힌 칸 %d" % (
        side, tx, tz, cnt, x0, x1, z0, z1, cx, cz, hcross, hend, ln, hmax, smax, blocked))
    res.append(dict(side=side, edge=[tx, tz], cross=[int(cx), int(cz)], h_cross=hcross, h_end=hend, out_len=ln, smax=smax, blocked=blocked))

# bounds 선을 따라: 닿는 칸이 bounds 를 넘는 자리 (선 위 칸 중 시작 묶음에 들고 바로 바깥 칸도 닿는 곳)
print("\nbounds 선 위에서 바깥으로 이어지는 구간 (선 밖 1 m 칸이 닿음)")
segs = []
for nm, line_in, line_out, along in (
        ("서 x=%d" % b0x, reach[:, int(b0x) + 1], reach[:, int(b0x) - 1], "z"),
        ("동 x=%d" % b1x, reach[:, int(b1x) - 1], reach[:, int(b1x) + 1], "z"),
        ("남 z=%d" % b0z, reach[int(b0z) + 1, :], reach[int(b0z) - 1, :], "x"),
        ("북 z=%d" % b1z, reach[int(b1z) - 1, :], reach[int(b1z) + 1, :], "x")):
    m = line_in & line_out
    idx = np.nonzero(m)[0]
    if len(idx) == 0:
        print("  %s: 없음" % nm)
        continue
    runs = np.split(idx, np.nonzero(np.diff(idx) > 1)[0] + 1)
    runs = [r for r in runs if len(r) >= 2]
    tot = sum(len(r) for r in runs)
    print("  %s: %d 구간, 합 %d m — 긴 것: %s" % (nm, len(runs), tot,
          ", ".join("%s %d~%d (%d m)" % (along, r[0], r[-1], len(r)) for r in sorted(runs, key=len, reverse=True)[:6])))
    segs.append(dict(line=nm, runs=len(runs), total=tot))
json.dump(dict(limit=lim, edge_paths=res, bound_segments=segs), open(nc.ensure_out() + "/edges_lim%.2f.json" % lim, "w"), ensure_ascii=False, indent=1)

# 떨어짐 허용 (오름 ≤ 한계, 내림 무제한): 지형 끝 3 m 띠에 닿는 곳
ok = ~G["pblock"]
ok[G["deck"]] = True
fw = nc.flood_dir(hc, ok, s_xz, CELL, lim, 1e9)
eb = fw & ((XX < 3) | (XX > 2045) | (ZZ < 3) | (ZZ > 2045))
el, en = nc.label4(eb)
print("\n떨어짐 허용 (오름 ≤ %.2f, 내림 무제한): 갈 수 있음 %.2f km², bounds 밖 %.0f m², 지형 끝 3 m 띠 %d 칸 / %d 군데" % (
    lim, fw.sum() / 1e6, (fw & ~inb).sum(), eb.sum(), en))
for k in range(1, en + 1):
    zs, xs = np.nonzero(el == k)
    if len(xs) >= 3:
        print("  끝 (%d~%d, %d~%d) %d 칸, 높이 %.0f" % (xs.min(), xs.max(), zs.min(), zs.max(), len(xs), hc[zs, xs].mean()))
