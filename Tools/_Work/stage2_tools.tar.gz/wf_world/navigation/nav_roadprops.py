#!/usr/bin/env python3
# 길 위에 놓인 충돌 소품: 길 가운데선에서 반폭 안으로 들어온 소품(충돌 상자 + 주인공 반지름 0.4)
#   python3 nav_roadprops.py
# 길 폭 중 막히지 않은 폭도 잰다 (가로 단면을 0.1 m 로 훑음)
import math
import numpy as np
import navcommon as nc

objs = nc.load_objects(); trees = nc.load_trees(); man = nc.load_manifest()
C = nc.Curves()
shapes = nc.prop_shapes(objs, trees, man, "all")
pts, owner = [], []
for ri, (nm, c, hw) in enumerate(C.roads):
    for p in c:
        pts.append(p); owner.append(ri)
pts = np.array(pts); owner = np.array(owner)
hits = []
for (a, kind, x, z, hu, hv, yaw, hgt, k) in shapes:
    d = np.hypot(pts[:, 0] - x, pts[:, 1] - z)
    i = int(np.argmin(d))
    ri = owner[i]
    hw = C.roads[ri][2]
    rad = (hu if kind == "circle" else math.hypot(hu, hv))
    if d[i] - rad < hw:
        # 가로 단면에서 실제로 막힌 폭
        c = C.roads[ri][1]
        j = int(np.argmin(np.hypot(c[:, 0] - x, c[:, 1] - z)))
        t = c[min(j + 1, len(c) - 1)] - c[max(j - 1, 0)]; t = t / np.linalg.norm(t); nrm = np.array([-t[1], t[0]])
        free = 0.0
        for o in np.arange(-hw, hw + 1e-6, 0.1):
            px, pz = c[j] + nrm * o
            X, Z = px - x, pz - z
            if kind == "circle":
                blocked = X * X + Z * Z <= (hu + nc.AGENT_R) ** 2
            else:
                au, av = nc.local_axes(yaw)
                u = X * au[0] + Z * au[1]; v = X * av[0] + Z * av[1]
                blocked = abs(u) <= hu + nc.AGENT_R and abs(v) <= hv + nc.AGENT_R
            free += 0 if blocked else 0.1
        hits.append((C.roads[ri][0], a, x, z, d[i], hw, free, k))
print("길 반폭 안에 들어온 충돌 소품 %d 개 (나무 줄기 포함)" % len(hits))
for h in sorted(hits, key=lambda q: q[6]):
    print("  %-14s %-14s (%.1f, %.1f) 길 가운데에서 %.1f m, 길 폭 %.1f m 중 지나갈 폭(주인공 반지름 뺌) %.1f m%s" % (
        h[0], h[1], h[2], h[3], h[4], 2 * h[5], h[6], "  ← 막힘" if h[6] < 0.2 else ""))
