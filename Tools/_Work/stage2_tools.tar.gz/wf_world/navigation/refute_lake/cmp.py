import sys, math, numpy as np
SCR = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad"
hd = np.fromfile(SCR + "/world_out3/Data~/height.r16", dtype="<u2").reshape(2049, 2049).astype(np.float64) * 320 / 65535
L = 28.116
cx, cz, R = 720, 330, 135
def stats(h, tag):
    sub = h[cz-R:cz+R+1, cx-R:cx+R+1]
    d = L - sub
    i = np.unravel_index(np.argmax(d), d.shape)
    print("%-6s wet %6d >0.6 %6d >1.0 %6d >1.2 %6d >1.4 %6d >1.6 %6d >1.8 %6d max %.2f at (%d,%d) center %.2f" % (
        tag, (d > 0).sum(), (d > .6).sum(), (d > 1).sum(), (d > 1.2).sum(), (d > 1.4).sum(), (d > 1.6).sum(), (d > 1.8).sum(), d.max(), i[1]+cx-R, i[0]+cz-R, L - h[cz, cx]))
    # 1.8 m 넘는 곳 위치 (개울 끝 자국인지)
    m = d > 1.8
    if m.any():
        zz, xx = np.nonzero(m)
        print("        >1.8 칸 x %d~%d z %d~%d" % (xx.min()+cx-R, xx.max()+cx-R, zz.min()+cz-R, zz.max()+cz-R))
    m = d > 1.4
    if m.any():
        zz, xx = np.nonzero(m)
        print("        >1.4 칸 x %d~%d z %d~%d" % (xx.min()+cx-R, xx.max()+cx-R, zz.min()+cz-R, zz.max()+cz-R))
stats(hd, "data")
for t in sys.argv[1:]:
    h = np.load("h_%s.npy" % t).astype(np.float64)
    if t == "base":
        print("   base vs data: max |diff| over lake box %.3f, whole %.3f" % (np.abs(h - hd)[cz-R:cz+R, cx-R:cx+R].max(), np.abs(h - hd).max()))
    stats(h, t)
