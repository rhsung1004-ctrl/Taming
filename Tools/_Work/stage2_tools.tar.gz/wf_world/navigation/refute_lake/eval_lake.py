import sys, os
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
D = os.path.dirname(os.path.abspath(__file__))
Z0, Z1, X0, X1 = 100, 600, 450, 1000
hf = nc.load_height()
ho = np.load(D + "/h_old.npy")
diff = hf[Z0:Z1, X0:X1] - ho
print("최종 - 재현(old): 평균 %.3f, |차| 95%% %.3f, 최대 %.3f" % (diff.mean(), np.percentile(np.abs(diff), 95), np.abs(diff).max()))
LEV = 28.116
C = nc.Curves()
name, c, hw = C.roads[6]

def prof(h, c, hw, label):
    seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    t = np.arange(0, s[-1], 1.0)
    x = np.interp(t, s, c[:, 0]); z = np.interp(t, s, c[:, 1])
    hh = nc.bilinear(h, x, z)
    gr = np.gradient(hh, t)
    sl = nc.cell_slope(h)
    dx, dz = np.gradient(x), np.gradient(z); n = np.hypot(dx, dz)
    wmax = sl[z.astype(int), x.astype(int)]
    for o in (-hw, -hw/2, hw/2, hw):
        wmax = np.maximum(wmax, sl[(z + dx/n*o).astype(int), (x - dz/n*o).astype(int)])
    k = np.argmax(np.abs(gr))
    over = np.abs(gr) > 0.58
    wet = hh < LEV
    print("%s: 오르내림 최대 %.2f (%.0f°) s=%.0f (%.1f,%.1f); >0.58 %d m; 길폭 최대 %.2f, 길폭>0.58 %d m; 물에 잠김 %d m (첫 s=%s)" % (
        label, abs(gr[k]), np.degrees(np.arctan(abs(gr[k]))), t[k], x[k], z[k], over.sum(), wmax.max(), (wmax > 0.58).sum(), wet.sum(),
        t[np.argmax(wet)] if wet.any() else "-"))
    return t, x, z, hh, gr

for k in ("old", "prop", "prop_disk100"):
    hv = np.load(D + "/h_%s.npy" % k)
    h = hf.copy()
    h[Z0:Z1, X0:X1] += hv - ho
    prof(h, c, hw, k)
    # 호수 둘레 링 기울기 (원판 경계 d=145 부근)
    zz, xx = np.mgrid[0:2049, 0:2049]
    d = np.hypot(xx - 720, zz - 330)
    sl = nc.cell_slope(h)
    dd = d[:-1, :-1]
    for r0, r1 in ((140, 150), (100, 140), (60, 100)):
        m = (dd >= r0) & (dd < r1)
        print("    d %d~%d: 기울기 >0.58 %.1f%%, >1.0 %.1f%%, 최대 %.2f" % (r0, r1, (sl[m] > 0.58).mean()*100, (sl[m] > 1.0).mean()*100, sl[m].max()))
    # 물 평면 사각형(반 135) 밖인데 수면보다 낮은 곳 / 사각형 안 수면 아래 넓이
    sq = (np.abs(xx - 720) <= 135) & (np.abs(zz - 330) <= 135)
    below = h < LEV
    near = d < 260
    print("    수면 아래: 사각형 안 %d m², 사각형 밖(d<260) %d m²" % ((below & sq).sum(), (below & ~sq & near).sum()))
    np.save(D + "/hfull_%s.npy" % k, h[Z0:Z1, X0:X1])
