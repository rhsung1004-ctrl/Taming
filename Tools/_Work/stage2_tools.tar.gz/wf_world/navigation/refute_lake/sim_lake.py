# 호수 혼합 띠 변경 효과를 높이 단계(build_height)만 다시 만들어 차이(delta)로 현재 height 에 더해 본다
import sys, os, inspect, time, pickle
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
wg = nc.wg
from terrain import ss, fbm, disk

OUTD = os.path.dirname(os.path.abspath(__file__))
src = inspect.getsource(wg.build_height)
pre, post = src.split("    # 호수\n")
# pre: 함수 정의 ~ 늪까지. 끝에서 h 를 돌려주게
pre_fn = pre.replace("def build_height(W):", "def pre_height(W):") + "    W.h = h\n    return W\n"
g = dict(wg.__dict__)
exec(pre_fn, g)

class Obj: pass

cache = OUTD + "/pre_h.npy"
W = Obj()
if os.path.exists(cache):
    ax = np.arange(wg.RES, dtype=np.float32); W.X, W.Z = np.meshgrid(ax, ax)
    W.h = np.load(cache)
    W.swamp_level = float(open(OUTD + "/swamp_level.txt").read())
else:
    t = time.time()
    g["pre_height"](W)
    np.save(cache, W.h)
    open(OUTD + "/swamp_level.txt", "w").write(repr(W.swamp_level))
    print("pre_height %.0fs" % (time.time() - t))


def lake(h0, lo, hi, extra_r=40):
    W2 = Obj(); W2.X, W2.Z = W.X, W.Z
    h = h0.copy()
    X, Z = W.X, W.Z
    rs, cs, d = disk(h.shape, wg.LAKE[0], wg.LAKE[1], wg.LAKE_R + 40)
    ring = h[rs, cs][(d > wg.LAKE_R + 5) & (d < wg.LAKE_R + 25)]
    lev = float(np.percentile(ring, 6)) - 2.0
    rs, cs, d = disk(h.shape, wg.LAKE[0], wg.LAKE[1], wg.LAKE_R + extra_r)
    Xs, Zs = X[rs, cs], Z[rs, cs]
    edge = wg.LAKE_R + 18 * fbm(Xs, Zs, 1 / 70, 3, 640)
    target = lev - 0.4 - 4.0 * ss(-(d / edge), -0.95, -0.3) + 0.6 * fbm(Xs, Zs, 1 / 20, 3, 650)
    w = ss(-(d / edge), lo, hi)
    h[rs, cs] = h[rs, cs] * (1 - w) + target * w
    W2.lake_level = lev
    W2.lake_box = (rs, cs, w)
    W2.h = h
    W2.swamp_level = W.swamp_level
    wg.carve_creek(W2)
    wg.lay_roads(W2)
    return W2

variants = {"old": (-1.15, -0.8, 40), "prop": (-1.6, -0.8, 40), "prop_disk100": (-1.6, -0.8, 100)}
for k in sys.argv[1:] or variants:
    lo, hi, er = variants[k]
    t = time.time()
    W2 = lake(W.h, lo, hi, er)
    # 호수 주변만 저장
    np.save(OUTD + "/h_%s.npy" % k, W2.h[100:600, 450:1000])
    print(k, "lake_level %.3f" % W2.lake_level, "%.0fs" % (time.time() - t))
