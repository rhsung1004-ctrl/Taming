# 호수 바닥 식 바꾸기 시뮬레이션: worldgen 높이 단계만 돌려서 호수·개울 끝 깊이 비교 (worldgen.py 는 고치지 않음)
import sys, types, time, math
import numpy as np
WG = "/home/user/Taming/Tools/WorldGen"
sys.path.insert(0, WG)
src0 = open(WG + "/worldgen.py").read()
OLD = "target = W.lake_level - 0.4 - 4.0 * ss(-(d / edge), -0.95, -0.3) + 0.6 * fbm(Xs, Zs, 1 / 20, 3, 650)"
assert OLD in src0

def run(src, tag):
    m = types.ModuleType("wg_" + tag)
    m.__file__ = WG + "/worldgen.py"
    exec(compile(src, WG + "/worldgen.py", "exec"), m.__dict__)
    m.log = lambda *a: None
    W = m.World()
    W.lights, W.fx = [], []
    t = time.time()
    m.build_height(W)
    pads = m.lay_landmarks(W, None)
    m.finish_height(W, pads)
    return m, W

variants = {} if "--nobase" in sys.argv else {"base": src0}
sys.argv = [a for a in sys.argv if a != "--nobase"]
TAIL = "B[tail] = np.minimum(B[tail], W.lake_level - 0.8 + (B[tail] - W.lake_level + 0.8) * np.clip((L - s[tail]) / 70.0, 0, 1))"
assert TAIL in src0
for arg in sys.argv[1:]:
    name, rest = arg.split("=", 1)
    parts = rest.split("||")
    src = src0.replace(OLD, parts[0])
    if len(parts) > 1:
        src = src.replace(TAIL, TAIL + "\n    " + parts[1])
    variants[name] = src
out = {}
for tag, src in variants.items():
    m, W = run(src, tag)
    np.save("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation/refute_lake/h_%s.npy" % tag, W.h.astype(np.float32))
    print(tag, "lake_level %.3f" % W.lake_level)
