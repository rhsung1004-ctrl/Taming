# 길 6 경유점을 바꿔 lay_roads 까지 다시 돌리고 (호수 혼합은 그대로) 최종 높이에 차이로 더해 잰다
import sys, os
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
import numpy as np
import navcommon as nc
wg = nc.wg
D = os.path.dirname(os.path.abspath(__file__))
sys.argv = [sys.argv[0]]
import importlib.util
spec = importlib.util.spec_from_file_location("sim_lake", D + "/sim_lake.py")
sim = importlib.util.module_from_spec(spec)
sys.argv = ["x", "old"]
spec.loader.exec_module(sim)          # pre_h 캐시 사용, old 다시 만듦
import eval_lake as ev  # noqa  (출력 한 번)
Z0, Z1, X0, X1 = 100, 600, 450, 1000
hf = nc.load_height(); ho = np.load(D + "/h_old.npy")
cands = {
    "R0 현재": [(960, 505), (860, 460), (790, 415), (760, 400)],
    "R1 검사자 대안": [(960, 505), (860, 460), (790, 415), (775, 385), (765, 372)],
    "R2 동쪽 비탈": [(960, 505), (920, 440), (890, 380), (850, 340), (808, 326)],
    "R3 동쪽 비탈2": [(960, 505), (900, 470), (880, 410), (860, 360), (815, 330)],
}
orig = list(wg.ROADS)
for k, pts in cands.items():
    wg.ROADS[:] = orig
    wg.ROADS[6] = (pts, 2.0)
    W2 = sim.lake(sim.W.h, -1.15, -0.8, 40)
    h = hf.copy()
    h[Z0:Z1, X0:X1] += W2.h[Z0:Z1, X0:X1] - ho
    C = nc.Curves()
    name, c, hw = C.roads[6]
    t, x, z, hh, gr = ev.prof(h, c, hw, k)
    print("     길이 %.0f m, 끝 (%.1f,%.1f) 높이 %.2f (수면 28.12)" % (t[-1], x[-1], z[-1], hh[-1]))
wg.ROADS[:] = orig
