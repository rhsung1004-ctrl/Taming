# 미술 검사 공통: 월드 데이터 읽기 (읽기 전용), 소품 분류, 광원 목록, 걸을 수 있는 칸
# 환경 변수 WORLD_DATA (Data~ 폴더), KIT_OUT (소품 manifest 폴더) 로 다른 결과도 검사할 수 있다
import os, sys, json, glob, math
import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.abspath(os.path.join(HERE, "..", ".."))
DATA = os.environ.get("WORLD_DATA", os.path.join(SCR, "world_out3", "Data~"))
KIT = os.environ.get("KIT_OUT", os.path.join(SCR, "kit_out"))
WG = os.environ.get("WORLDGEN", "/home/user/Taming/Tools/WorldGen")
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)

_cache = {}


def world():
    if "w" not in _cache:
        _cache["w"] = json.load(open(os.path.join(DATA, "world.json")))
    return _cache["w"]


def height():
    if "h" not in _cache:
        w = world()
        n = w["heightRes"]
        _cache["h"] = np.fromfile(os.path.join(DATA, "height.r16"), "<u2").reshape(n, n).astype(np.float64) / 65535.0 * w["height"]
    return _cache["h"]


def slope():
    if "sl" not in _cache:
        gz, gx = np.gradient(height())
        _cache["sl"] = np.sqrt(gx * gx + gz * gz)
    return _cache["sl"]


def objects():
    if "o" not in _cache:
        _cache["o"] = json.load(open(os.path.join(DATA, "objects.json")))
    return _cache["o"]


def trees():
    if "t" not in _cache:
        _cache["t"] = json.load(open(os.path.join(DATA, "trees.json")))
    return _cache["t"]


def manifest():
    if "m" not in _cache:
        man = {}
        for f in sorted(glob.glob(os.path.join(KIT, "manifest_*.json"))):
            for k, v in json.load(open(f)).items():
                man[k] = v
        _cache["m"] = man
    return _cache["m"]


def png_grid(name):
    """splat/detail PNG → 배열 [z, x, 4] (행 0 = 남쪽), 0~1"""
    a = np.asarray(Image.open(os.path.join(DATA, name)).convert("RGBA")).astype(np.float32) / 255.0
    return np.flipud(a)


def splat():
    if "sp" not in _cache:
        _cache["sp"] = np.concatenate([png_grid("splat_0.png"), png_grid("splat_1.png")], -1)
    return _cache["sp"]


def detail():
    if "dt" not in _cache:
        _cache["dt"] = np.concatenate([png_grid("detail_0.png"), png_grid("detail_1.png")], -1)
    return _cache["dt"]


def hsample(h, x, z):
    x = np.asarray(x, np.float64)
    z = np.asarray(z, np.float64)
    n = h.shape[0] - 1
    xc = np.clip(x, 0, n - 1e-6)
    zc = np.clip(z, 0, n - 1e-6)
    i = zc.astype(np.int64)
    j = xc.astype(np.int64)
    fz, fx = zc - i, xc - j
    a = h[i, j] * (1 - fx) + h[i, j + 1] * fx
    b = h[i + 1, j] * (1 - fx) + h[i + 1, j + 1] * fx
    return a * (1 - fz) + b * fz


def walkable(cell=1):
    """걸을 수 있는 칸 (bounds 안, 경사 ≤ 1.0, 물 밖). 2049 격자 bool"""
    if "wk" not in _cache:
        w = world()
        h = height()
        n = h.shape[0]
        ax = np.arange(n)
        X, Z = np.meshgrid(ax, ax)
        (bx0, bz0), (bx1, bz1) = w["bounds"]["min"], w["bounds"]["max"]
        m = (X >= bx0) & (X <= bx1) & (Z >= bz0) & (Z <= bz1) & (slope() <= 1.0)
        m &= ~water_mask()
        _cache["wk"] = m
    return _cache["wk"]


def water_mask():
    """물 평면 아래 칸 (물 평면 사각형 안이면서 높이 < 수면)"""
    if "wm" not in _cache:
        h = height()
        n = h.shape[0]
        ax = np.arange(n)
        X, Z = np.meshgrid(ax, ax)
        m = np.zeros(h.shape, bool)
        for wp in objects()["water"]:
            px, py, pz = wp["p"]
            sx, sz = wp["size"]
            a = math.radians(wp.get("yaw", 0))
            # 판의 로컬 X = (cos a, -sin a) , 로컬 Z = (sin a, cos a)  (Unity Y 회전)
            dx, dz = X - px, Z - pz
            u = dx * math.cos(a) - dz * math.sin(a)
            v = dx * math.sin(a) + dz * math.cos(a)
            inside = (np.abs(u) <= sx / 2) & (np.abs(v) <= sz / 2)
            m |= inside & (h < py)
        _cache["wm"] = m
    return _cache["wm"]


# 소품 분류 (미술 관점)
#   landmark: 멀리서 보이는 큰 구조물. feature: 다가가 볼 만한 것 (무덤·폐허·석상·등불·큰 고목 무리)
#   filler: 바닥 채움 (돌·덤불·해골·그루터기)
FEATURE = {"grave_slab_a", "grave_slab_b", "grave_slab_c", "grave_cross", "grave_sunken", "grave_obelisk", "coffin", "grave_tomb",
           "wall_ruin_a", "wall_ruin_b", "arch_ruin", "pillar_a", "pillar_b", "stair_ruin", "statue_angel", "statue_reaper",
           "lantern", "fence_gate", "well", "bone_pile", "candles", "cliff_a", "cliff_b", "cliff_c"}
GLOW = {"mushroom_glow", "mushroom_toxic", "lotus_glow", "candles", "lantern", "grave_tomb", "statue_reaper"}
FILLER = {"rock_a", "rock_b", "rock_c", "rock_flat", "bush_dead", "bramble", "skull", "stump", "rubble", "roots", "flower_lily",
          "log_fallen", "dead_tree_a", "dead_tree_b", "dead_tree_c"}


def all_props():
    """[(이름, x, z, 크기)] 게임 오브젝트 + 지형 나무"""
    out = [(o["a"], o["p"][0], o["p"][2], o["s"]) for o in objects()["objects"]]
    t = trees()
    out += [(t["prototypes"][i[0]], i[1], i[2], i[4]) for i in t["instances"]]
    return out


def kind(a):
    m = manifest().get(a, {}).get("meta", {})
    return m.get("kind", "prop")


def prop_height(a, s=1.0):
    """소품 키 (m) = Blender size z × 크기"""
    v = manifest().get(a)
    if not v:
        return 0.0
    return float(v["size"][2]) * s


def all_lights():
    """[(x, y, z, 색 rgb, 세기, 범위, 출처)] 소품 META.light + objects.json lights"""
    man = manifest()
    out = []
    for o in objects()["objects"]:
        m = man.get(o["a"], {}).get("meta", {})
        L = m.get("light")
        if L:
            # 오프셋은 Blender 축 (x, y, z) → Unity (x, z, y) 대략 (회전 무시, 수 m 이내)
            off = L.get("offset", [0, 0, 0])
            out.append((o["p"][0] + off[0] * o["s"], o["p"][1] + off[2] * o["s"], o["p"][2] + off[1] * o["s"],
                        tuple(L["color"]), float(L["intensity"]), float(L["range"]) * o["s"], o["a"]))
    for l in objects()["lights"]:
        out.append((l["p"][0], l["p"][1], l["p"][2], tuple(l["c"]), float(l["i"]), float(l["r"]), "free"))
    return out


def poi_list():
    return [(p["id"], p["name"], p["p"][0], p["p"][2], p["r"]) for p in world()["pois"]]


def downsample_any(mask, k):
    n = (mask.shape[0] // k) * k
    m = mask[:n, :n].reshape(n // k, k, n // k, k)
    return m.any(axis=(1, 3))


def downsample_mean(a, k):
    n = (a.shape[0] // k) * k
    m = a[:n, :n].reshape(n // k, k, n // k, k)
    return m.mean(axis=(1, 3))


def dist_to_points(px, pz, grid_xy, chunk=4096):
    """grid_xy: [N,2] 질의점, (px, pz) 대상점 → 각 질의점의 최근접 거리"""
    P = np.stack([np.asarray(px, np.float64), np.asarray(pz, np.float64)], -1)
    out = np.full(len(grid_xy), np.inf)
    if len(P) == 0:
        return out
    for i in range(0, len(grid_xy), chunk):
        q = grid_xy[i:i + chunk]
        best = np.full(len(q), np.inf)
        for j in range(0, len(P), 2048):
            d = ((q[:, None, :] - P[None, j:j + 2048, :]) ** 2).sum(-1)
            best = np.minimum(best, d.min(1))
        out[i:i + chunk] = np.sqrt(best)
    return out
