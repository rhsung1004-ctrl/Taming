#!/usr/bin/env python3
# 지형 층(splat) 검사: 전체 비율, 가장 센 층의 넓이, 장소마다 바닥 색, 층 텍스처 평균 색 (서로 구별되는가)
#   python3 art_splat.py → 표준 출력 + out/splat_dominant.png (칸마다 가장 센 층 색) + out/splat_albedo.png (층 무게 × 텍스처 평균 색)
import os, math, colorsys
import numpy as np
from PIL import Image, ImageDraw
import artcommon as C

W = C.world()
names = [l["name"] for l in W["layers"]]
sp = C.splat()[..., :len(names)]                     # [2048, 2048, 8], 행 0 = 남쪽
wk = C.walkable()[:2048, :2048]
sl = C.slope()[:2048, :2048]
field = wk & (sl < 0.58)

TER = os.path.join(os.path.dirname(C.DATA), "Terrain")
alb = {}
for nm in names:
    im = Image.open(os.path.join(TER, "ground_%s_albedo.jpg" % nm)).convert("RGB")
    a = np.asarray(im.resize((256, 256), Image.BILINEAR)).astype(np.float32) / 255.0
    lin = np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)
    alb[nm] = (a.reshape(-1, 3).mean(0), lin.reshape(-1, 3).mean(0), a.reshape(-1, 3).std(0).mean())
print("층 텍스처 평균 색 (sRGB 0~255, 명도 L*, 색상 H°, 채도)")
for nm in names:
    c, lin, sd = alb[nm]
    Y = 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
    Ls = 116 * Y ** (1 / 3) - 16 if Y > 0.008856 else 903.3 * Y
    hh, ll, ss_ = colorsys.rgb_to_hls(*c)
    print("  %-7s (%3d,%3d,%3d)  L* %4.1f  H %3.0f°  S %.2f  얼룩(표준편차) %.3f" % (nm, *(c * 255), Ls, hh * 360, ss_, sd))

print("\n걸을 수 있는 들판 전체의 층 비율 (무게 평균) / 가장 센 층인 칸의 비율")
w = sp[field]
dom = np.argmax(sp, -1)
for k, nm in enumerate(names):
    print("  %-7s 무게 %5.1f %%   가장 센 층 %5.1f %%" % (nm, 100 * w[:, k].mean(), 100 * np.mean(dom[field] == k)))
# 한 층이 0.7 이상인 칸 (단색 구역)
print("  한 층 무게 ≥ 0.7 인 칸: %.0f %%, 풀(grass) ≥ 0.5: %.0f %%, grass+moss ≥ 0.8: %.0f %%" % (
    100 * np.mean(w.max(1) >= 0.7), 100 * np.mean(w[:, 0] >= 0.5), 100 * np.mean(w[:, 0] + w[:, 1] >= 0.8)))

ax = np.arange(2048)
X, Z = np.meshgrid(ax, ax)
print("\n장소마다 바닥 층 (반지름 안, 물 아래 제외) — 상위 3 층, 평균 색 (텍스처 평균 × 무게)")
pc = {}
wm = C.water_mask()[:2048, :2048]
for pid, nm, px, pz, r in C.poi_list():
    m = ((X - px) ** 2 + (Z - pz) ** 2 <= r * r) & ~wm
    v = sp[m].mean(0)
    col = sum(v[k] * alb[names[k]][0] for k in range(len(names)))
    pc[pid] = col
    top = np.argsort(-v)[:3]
    print("  %-10s " % pid + ", ".join("%s %.0f%%" % (names[k], 100 * v[k]) for k in top) + "   색 (%3d,%3d,%3d)" % tuple(col * 255))
# 들판 (장소 밖)
m = field.copy()
for pid, nm, px, pz, r in C.poi_list():
    m &= (X - px) ** 2 + (Z - pz) ** 2 > (r + 20) ** 2
v = sp[m].mean(0)
col = sum(v[k] * alb[names[k]][0] for k in range(len(names)))
top = np.argsort(-v)[:4]
print("  %-10s " % "들판" + ", ".join("%s %.0f%%" % (names[k], 100 * v[k]) for k in top) + "   색 (%3d,%3d,%3d)" % tuple(col * 255))
pc["들판"] = col
# 장소 바닥 색이 들판과 얼마나 다른가 (sRGB 거리)
print("\n장소 바닥 평균 색과 들판 평균 색의 차이 (sRGB 0~255 유클리드)")
for k, c in pc.items():
    if k != "들판":
        print("  %-10s %5.1f" % (k, np.linalg.norm((c - pc["들판"]) * 255)))

# 큰 단색 구역: 64 m 칸에서 같은 층이 가장 센 칸이 90 % 이상
B = 64
print("\n64 m 칸에서 grass 가 가장 센 칸이 90 %% 이상인 칸 비율 (들판 칸 중): ", end="")
cnt, tot = 0, 0
for i in range(0, 2048, B):
    for j in range(0, 2048, B):
        f = field[i:i + B, j:j + B]
        if f.mean() < 0.8:
            continue
        tot += 1
        if np.mean(dom[i:i + B, j:j + B][f] == 0) >= 0.9:
            cnt += 1
print("%d / %d (%.0f %%)" % (cnt, tot, 100 * cnt / max(tot, 1)))

# 그림
pal = np.array([alb[nm][0] for nm in names])
img = np.einsum("zxk,kc->zxc", sp, pal)
img = np.clip(img * 1.6, 0, 1)
Image.fromarray((np.flipud(img) * 255).astype(np.uint8)).resize((1024, 1024), Image.BILINEAR).save(C.OUT + "/splat_albedo.png")
dpal = np.array([[60, 140, 60], [30, 90, 70], [150, 110, 70], [70, 50, 40], [130, 130, 140], [220, 200, 160], [170, 70, 40], [200, 200, 220]], np.uint8)
dimg = dpal[dom]
Image.fromarray(np.flipud(dimg)).resize((1024, 1024), Image.NEAREST).save(C.OUT + "/splat_dominant.png")
print("\n그림:", C.OUT + "/splat_albedo.png", C.OUT + "/splat_dominant.png",
      "(가장 센 층 색: grass 초록, moss 청록, dirt 갈색, mud 진갈, rock 회색, path 베이지, leaves 주황, ash 연보라회색)")
