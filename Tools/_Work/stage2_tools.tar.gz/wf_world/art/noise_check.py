# worldgen.paint()/details() 에 쓰인 노이즈 값의 분포 (문턱값이 얼마나 자주 넘는지)
import sys, numpy as np
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
from terrain import fbm, ss
ax = np.arange(0, 2049, 2, dtype=np.float32)
X, Z = np.meshgrid(ax, ax)
for nm, f, o, s in (("m1 moss 1/320", 1/320, 3, 1004), ("m2 dry 1/260", 1/260, 3, 1005), ("m3 leaves 1/200", 1/200, 3, 1006),
                    ("n1 1/90", 1/90, 4, 1001), ("n2 1/35", 1/35, 3, 1002), ("n3 1/14", 1/14, 2, 1003)):
    v = fbm(X, Z, f, o, s)
    print("%-16s p5 %.2f p25 %.2f p50 %.2f p75 %.2f p95 %.2f max %.2f" % (nm, *np.percentile(v, [5, 25, 50, 75, 95]), v.max()))
m2 = fbm(X, Z, 1/260, 3, 1005)
dry = ss(m2, 0.12, 0.45)
print("W.dry > 0.5: %.1f %%, > 0.9: %.1f %%" % (100*np.mean(dry > 0.5), 100*np.mean(dry > 0.9)))
m1 = fbm(X, Z, 1/320, 3, 1004)
print("moss 첫 칠 ss(m1,0.05,0.4)*0.65 > 0.5 인 곳: %.1f %%" % (100*np.mean(ss(m1,0.05,0.4)*0.65 > 0.5)))
