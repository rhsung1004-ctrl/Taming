#!/usr/bin/env python3
# 기타: 들판 잔 굴곡(매끈함), 늪의 물/뭍 비율, 장소별 가장 가까운 '빛 ≥ 5' 개수
import math, numpy as np
import artcommon as C
h = C.height(); sl = C.slope(); wk = C.walkable()
n = h.shape[0]
ax = np.arange(n); X, Z = np.meshgrid(ax, ax)
def box_blur(a, r):
    k = 2 * r + 1
    p = np.pad(a, r, mode="edge"); s = p.cumsum(0).cumsum(1); s = np.pad(s, ((1, 0), (1, 0)))
    return (s[k:, k:] - s[:-k, k:] - s[k:, :-k] + s[:-k, :-k]) / (k * k)
field = wk & (sl < 0.58)
for r in (2, 5, 10):
    d = (h - box_blur(h, r))[field]
    print("잔 굴곡 (반지름 %2d m 평균에서 벗어남): 표준편차 %.3f m, 99%% %.2f m" % (r, d.std(), np.percentile(np.abs(d), 99)))
# 길 위 등
W = C.world(); lev = W["levels"]["swamp"]
d = np.sqrt((X - 1545) ** 2 + (Z - 935) ** 2)
m = d < 300
wat = C.water_mask()
print("늪 (반지름 300 m): 물 %.0f %%, 뭍 %.0f %% (뭍 중 수면 위 0.5 m 이하 %.0f %%)" % (100 * wat[m].mean(), 100 * (~wat[m]).mean(),
      100 * ((h[m & ~wat] - lev) < 0.5).mean()))
d = np.sqrt((X - 720) ** 2 + (Z - 330) ** 2)
m = d < 105
print("호수 (반지름 105 m): 물 %.0f %%" % (100 * wat[m].mean()))
