#!/usr/bin/env python3
# 지형 성격 검사: 들판 구릉 진폭, 장소마다 분지·고원·골짜기 성격, 산 능선(실루엣) 모양
#   python3 art_terrain.py → 표준 출력 + out/skyline_<자리>.png (눈높이에서 본 360° 지형 윤곽)
import math
import numpy as np
from PIL import Image, ImageDraw
import artcommon as C

h = C.height()
sl = C.slope()
wk = C.walkable()
n = h.shape[0]
W = C.world()
(bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]


def box_blur(a, r):
    """적분 영상으로 (2r+1)² 상자 평균 (가장자리는 잘린 상자)"""
    k = 2 * r + 1
    p = np.pad(a, r, mode="edge")
    s = p.cumsum(0).cumsum(1)
    s = np.pad(s, ((1, 0), (1, 0)))
    return (s[k:, k:] - s[:-k, k:] - s[k:, :-k] + s[:-k, :-k]) / (k * k)


field = wk & (sl < 0.58)
# 장소·물 자리 빼고 순수 들판
ax = np.arange(n)
X, Z = np.meshgrid(ax, ax)
pure = field.copy()
for pid, nm, px, pz, r in C.poi_list():
    pure &= (X - px) ** 2 + (Z - pz) ** 2 > (r + 30) ** 2
# 산이 시작하는 가장자리 150 m 도 뺀다
pure &= (X > bx0 + 150) & (X < bx1 - 150) & (Z > bz0 + 150) & (Z < bz1 - 150)
print("순수 들판 (장소·물·가장자리 150 m 제외) 넓이 %.2f km²" % (pure.sum() / 1e6))
hp = h[pure]
print("  높이: 최소 %.1f, 5%% %.1f, 50%% %.1f, 95%% %.1f, 최대 %.1f m" % (hp.min(), *np.percentile(hp, [5, 50, 95]), hp.max()))
# 남→북 기울기 제거 후의 구릉
for R in (50, 100, 200):
    hb = box_blur(h, R)
    dv = (h - hb)[pure]
    print("  반지름 %3d m 평균에서 벗어남 (구릉 진폭): 표준편차 %.2f m, 5~95%% %.1f ~ %.1f m" % (R, dv.std(), *np.percentile(dv, [5, 95])))
# 200 m 창의 높낮이 (최대 − 최소)
step = 50
rel = []
for zi in range(bz0 + 150, bz1 - 150 - 200, step):
    for xi in range(bx0 + 150, bx1 - 150 - 200, step):
        m = pure[zi:zi + 200, xi:xi + 200]
        if m.mean() < 0.8:
            continue
        sub = h[zi:zi + 200, xi:xi + 200][m]
        rel.append((sub.max() - sub.min(), xi + 100, zi + 100))
rel.sort()
rv = np.array([r for r, _, _ in rel])
print("  200 × 200 m 창 %d 개의 높낮이 (최대−최소): 5%% %.1f, 50%% %.1f, 95%% %.1f m" % (len(rv), *np.percentile(rv, [5, 50, 95])))
print("  가장 밋밋한 창 5:", ", ".join("(%d,%d) %.1f m" % (x, z, r) for r, x, z in rel[:5]))
print("  경사 분포 (순수 들판): < 0.05 %.0f %%, 0.05~0.15 %.0f %%, 0.15~0.3 %.0f %%, 0.3~0.58 %.0f %%" % tuple(
    100 * np.mean((sl[pure] >= a) & (sl[pure] < b)) for a, b in ((0, 0.05), (0.05, 0.15), (0.15, 0.3), (0.3, 0.58))))

print("\n장소마다 지형 성격 (안 = 반지름 안 평균 높이, 둘레 = 반지름+40~+140 m 고리 평균; 차이 < 0 분지, > 0 고원)")
for pid, nm, px, pz, r in C.poi_list():
    d = np.sqrt((X - px) ** 2 + (Z - pz) ** 2)
    inn = (d <= r) & ~C.water_mask()
    ring = (d > r + 40) & (d < r + 140) & wk
    hi, hr = h[inn].mean(), h[ring].mean()
    relief = np.percentile(h[inn], 95) - np.percentile(h[inn], 5)
    print("  %-10s 안 %5.1f  둘레 %5.1f  차이 %+6.1f m  안쪽 높낮이(5~95%%) %5.1f m  안쪽 평균 경사 %.2f" % (
        pid, hi, hr, hi - hr, relief, sl[inn].mean()))

# 산: 능선 모양 (가장자리 산의 가장 높은 곳 기준)
mount = ~((X > bx0) & (X < bx1) & (Z > bz0) & (Z < bz1))
print("\n산 (bounds 밖): 높이 50%% %.0f, 90%% %.0f, 최대 %.0f m. 경사 > 1.5 (56°) 인 비율 %.0f %%, > 2.5 (68°) %.0f %%" % (
    np.percentile(h[mount], 50), np.percentile(h[mount], 90), h[mount].max(), 100 * np.mean(sl[mount] > 1.5), 100 * np.mean(sl[mount] > 2.5)))


def skyline(ox, oz, name, eye=1.7, fov_v=60.0):
    oy = C.hsample(h, ox, oz) + eye
    angs = []
    dists = []
    for k in range(720):
        th = k / 720 * 2 * math.pi
        dd = np.arange(10, 2000, 3.0)
        xs, zs = ox + math.sin(th) * dd, oz + math.cos(th) * dd       # 0° = 북쪽, 시계 방향
        ok = (xs >= 0) & (xs < 2048) & (zs >= 0) & (zs < 2048)
        xs, zs, dd = xs[ok], zs[ok], dd[ok]
        a = np.degrees(np.arctan2(C.hsample(h, xs, zs) - oy, dd))
        i = int(np.argmax(a))
        angs.append(a[i])
        dists.append(dd[i])
    angs, dists = np.array(angs), np.array(dists)
    # 봉우리: 좌우 3° 안에서 가장 높고 양옆 골보다 0.8° 이상 솟은 것
    peaks = []
    for i in range(720):
        w = [(i + j) % 720 for j in range(-6, 7)]
        if angs[i] == angs[w].max():
            lo_l = angs[[(i - j) % 720 for j in range(6, 30)]].min()
            lo_r = angs[[(i + j) % 720 for j in range(6, 30)]].min()
            if angs[i] - max(lo_l, lo_r) > 0.8:
                peaks.append(i / 2.0)
    gaps = np.diff(sorted(peaks)) if len(peaks) > 1 else np.array([0])
    # 능선 거친 정도: 0.5° 마다 고도각 차이
    rough = np.abs(np.diff(np.concatenate([angs, angs[:1]])))
    print("  %-10s 능선 고도각 %.1f~%.1f° (중앙 %.1f°), 능선까지 거리 중앙 %.0f m (%.0f~%.0f), 봉우리 %d 개, 간격 중앙 %.0f° (표준편차 %.0f°), 0.5° 마다 고도각 변화 중앙 %.2f° 90%% %.2f°" % (
        name, angs.min(), angs.max(), np.median(angs), np.median(dists), dists.min(), dists.max(), len(peaks),
        np.median(gaps), gaps.std(), np.median(rough), np.percentile(rough, 90)))
    # 그림 (가로 = 방위 0~360, 세로 = 고도각 -5~25°)
    Wd, Hh = 1440, 240
    im = Image.new("RGB", (Wd, Hh), (40, 36, 70))
    dr = ImageDraw.Draw(im)
    for k in range(720):
        y = Hh - (angs[k] + 5) / 30 * Hh
        x = k * 2
        dr.line([(x, Hh), (x, y)], fill=(15, 12, 25), width=2)
    for p in peaks:
        dr.line([(p * 4, 0), (p * 4, 8)], fill=(255, 120, 120))
    for a in range(0, 360, 90):
        dr.text((a * 4 + 2, 2), "NESW"[a // 90], fill=(255, 255, 255))
    im.save(C.OUT + "/skyline_%s.png" % name)
    return angs, dists


print("\n눈높이에서 본 360° 지형 윤곽 (0.5° 마다)")
for nm, p in (("spawn", (1000, 492)), ("graveyard", (1000, 880)), ("field_mid", (1250, 1150)), ("swamp_w", (1290, 905))):
    skyline(p[0], p[1], nm)
print("그림:", C.OUT + "/skyline_*.png")
