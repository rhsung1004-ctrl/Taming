#!/usr/bin/env python3
# 먼 표지 검사: 장소마다 가장 높은 실루엣·가장 센 광원이 150~600 m 밖 걸을 수 있는 자리에서 보이는가
#   - 지형 가림 (눈높이 1.7 m 에서 꼭대기까지 시선이 지형 위로 지나는가, 보이는 높이 몇 m)
#   - 화면 크기 (세로 시야 60°, 1080 줄 → 18 px/도)
#   - Unity 안개 (NecroWorldBuilder: ExponentialSquared, world.json fog.density; 카메라 far = 2.6/density)
#   python3 art_landmarks.py [안개 세기 ...]   예: python3 art_landmarks.py 0.0048 0.003 0.0025
import sys, math
import numpy as np
import artcommon as C

h = C.height()
wk = C.walkable()
W = C.world()
dens_list = [float(a) for a in sys.argv[1:]] or [W["fog"]["density"], 0.0032, 0.0026]
EYE = 1.7
PXDEG = 1080 / 60.0
RINGS = (150, 300, 450, 600)
objs = C.objects()["objects"]
lights = C.all_lights()
props = C.all_props()

print("Unity 안개: ExponentialSquared. 남는 빛 = exp(-(d·density)²)")
for de in dens_list:
    far = min(max(2.6 / de, 800), 2500)
    print("  density %.4f: 150 m %.2f, 300 m %.2f, 450 m %.3f, 600 m %.4f, 800 m %.5f | far clip %.0f m" % (
        de, *(math.exp(-(d * de) ** 2) for d in (150, 300, 450, 600, 800)), far))
print("  (NecroWorldBuilder.cs: cam.farClipPlane = Clamp(2.6/density, 800, 2500))")


def top_of_poi(pid, px, pz, r):
    best = None
    for a, x, z, s in props:
        if (x - px) ** 2 + (z - pz) ** 2 > (r + 10) ** 2:
            continue
        ht = C.prop_height(a, s)
        if best is None or ht > best[1]:
            best = (a, ht, x, z)
    return best


def los(ox, oz, oy, tx, tz, ty_base, ty_top):
    """관찰자 (ox, oy, oz) → 목표 기둥 (tx, tz, ty_base~ty_top). 지형 위로 보이는 기둥 높이(m)와 각도(도)"""
    d = math.hypot(tx - ox, tz - oz)
    n = max(int(d / 3), 2)
    t = np.linspace(0.02, 0.98, n)
    xs, zs = ox + (tx - ox) * t, oz + (tz - oz) * t
    hs = C.hsample(h, xs, zs)
    # 지형이 가리는 각도 (관찰자 기준 최대 고도각)
    ang = np.max((hs - oy) / (t * d))
    y_block = oy + ang * d                # 목표 위치에서 가려지는 높이
    vis = max(0.0, ty_top - max(y_block, ty_base))
    a_top = math.degrees(math.atan2(ty_top - oy, d))
    a_low = math.degrees(math.atan2(max(y_block, ty_base) - oy, d))
    return vis, max(0.0, a_top - a_low), d


print("\n장소별 먼 표지 (링마다 36 방향 중 걸을 수 있는 자리에서: 보임 = 지형 위로 2 m 이상 드러남)")
print("%-10s %-16s %5s %6s | " % ("장소", "가장 높은 것", "키m", "꼭대기") + " | ".join("%4dm 보임/자리 화면px" % r for r in RINGS))
rows = []
for pid, name, px, pz, r in C.poi_list():
    tp = top_of_poi(pid, px, pz, r)
    a, ht, tx, tz = tp
    base = C.hsample(h, tx, tz)
    # 가장 센 광원 (장소 반지름 안)
    ls = [l for l in lights if (l[0] - px) ** 2 + (l[2] - pz) ** 2 <= (r + 10) ** 2]
    Lmax = max(ls, key=lambda l: l[4]) if ls else None
    res = []
    for R in RINGS:
        nv, nt, pxs = 0, 0, []
        for k in range(36):
            th = k / 36 * 2 * math.pi
            ox, oz = tx + math.cos(th) * R, tz + math.sin(th) * R
            if not (0 <= ox < 2048 and 0 <= oz < 2048) or not wk[int(oz), int(ox)]:
                continue
            nt += 1
            oy = C.hsample(h, ox, oz) + EYE
            vis, angv, d = los(ox, oz, oy, tx, tz, base, base + ht)
            if vis >= 2.0:
                nv += 1
                pxs.append(angv * PXDEG)
        res.append((nv, nt, float(np.median(pxs)) if pxs else 0.0))
    rows.append((pid, a, ht, base + ht, res, Lmax))
    print("%-10s %-16s %5.1f %6.1f | " % (pid, a, ht, base + ht) +
          " | ".join("%4d/%-4d %10.0f" % (nv, nt, px_) for nv, nt, px_ in res) +
          ("   광원 최대 %s 세기 %.0f 범위 %.0f" % (Lmax[6], Lmax[4], Lmax[5]) if Lmax else "   광원 없음"))

print("\n해석: 300 m 링에서 안개 뒤 남는 대비 = exp(-(300·d)²). 기본값이면 %.2f, 450 m 에서 %.3f." % (
    math.exp(-(300 * dens_list[0]) ** 2), math.exp(-(450 * dens_list[0]) ** 2)))

# 산 실루엣: 들판 가운데·시작점에서 본 산 능선까지 거리
print("\n산 능선까지 거리 (지형 고도각이 가장 큰 지점) — 시작점·묘지 가운데·늪 서쪽 가장자리에서 12 방향")
for nm, (ox, oz) in (("spawn", (1000, 492)), ("graveyard", (1000, 880)), ("cathedral", (1010, 1478))):
    oy = C.hsample(h, ox, oz) + EYE
    out = []
    for k in range(12):
        th = k / 12 * 2 * math.pi
        dmax, best = 0, (-9, 0, 0)
        for dd in np.arange(20, 1800, 4):
            x, z = ox + math.cos(th) * dd, oz + math.sin(th) * dd
            if not (0 <= x < 2048 and 0 <= z < 2048):
                break
            a = (C.hsample(h, x, z) - oy) / dd
            if a > best[0]:
                best = (a, dd, C.hsample(h, x, z))
        out.append((int(round(math.degrees(th))), best[1], best[2], math.degrees(math.atan(best[0]))))
    print("  %-10s " % nm + ", ".join("%3d°:%4.0fm(%3.0fm,%4.1f°)" % o for o in out))
