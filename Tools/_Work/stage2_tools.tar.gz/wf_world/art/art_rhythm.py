#!/usr/bin/env python3
# 들판의 리듬 검사: 채움 소품(고목·덤불·돌) 이 고르게 흩뿌려졌는가(소금·후추), 아니면 무리·빈터가 있는가
#   + 눈길을 끄는 '큰 것' (키 ≥ 2.5 m 구조물·석상·무덤 3기 이상 무리·세기 ≥ 5 광원) 까지의 거리로 다시 본 빈 구역
#   python3 art_rhythm.py
import math, collections
import numpy as np
import artcommon as C

props = C.all_props()
pois = C.poi_list()
W = C.world()
(bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]
import sys
sys.path.insert(0, C.WG)
import worldgen as WG


def in_poi(x, z, pad=20):
    for pid, nm, px, pz, r in pois:
        if (x - px) ** 2 + (z - pz) ** 2 < (r + pad) ** 2:
            return True
    for (c, R) in (WG.FOREST_SW, WG.FOREST_NE):
        if (x - c[0]) ** 2 + (z - c[1]) ** 2 < (R + 40) ** 2:
            return True
    return False


inner = lambda x, z: bx0 + 150 < x < bx1 - 150 and bz0 + 150 < z < bz1 - 150
groups = {"고목": {"dead_tree_a", "dead_tree_b", "dead_tree_c"}, "덤불": {"bush_dead", "bramble"}, "돌": {"rock_a", "rock_b", "rock_c", "rock_flat"}}
B = 64
nb = 2048 // B
# 순수 들판 칸 (장소·숲 밖, 가장자리 150 m 안쪽)
cellok = np.zeros((nb, nb), bool)
for i in range(nb):
    for j in range(nb):
        x, z = j * B + B / 2, i * B + B / 2
        cellok[i, j] = inner(x, z) and not in_poi(x, z, 40)
print("순수 들판 64 m 칸 %d 개" % cellok.sum())
for gname, names in groups.items():
    cnt = np.zeros((nb, nb))
    pts = []
    for a, x, z, s in props:
        if a in names and inner(x, z) and not in_poi(x, z):
            cnt[int(z // B), int(x // B)] += 1
            pts.append((x, z))
    v = cnt[cellok]
    mean = v.mean()
    cv = v.std() / max(mean, 1e-9)
    # Clark–Evans 최근접 이웃 비: 1 ≈ 무작위, < 1 뭉침, > 1 고름
    P = np.array(pts)
    if len(P) > 2:
        d = C.dist_to_points(P[:, 0], P[:, 1], P)  # 자기 자신 0 → 다시
        dd = np.full(len(P), np.inf)
        for k in range(0, len(P), 1024):
            q = P[k:k + 1024]
            d2 = ((q[:, None, :] - P[None, :, :]) ** 2).sum(-1)
            d2[np.arange(len(q)), np.arange(k, k + len(q))] = np.inf
            dd[k:k + 1024] = np.sqrt(d2.min(1))
        area = cellok.sum() * B * B
        dens = len(P) / area
        R = dd.mean() / (0.5 / math.sqrt(dens))
    else:
        R = float("nan")
    print("  %-4s %5d 개, 칸당 평균 %.1f, 변동계수 %.2f (무작위 포아송이면 %.2f), 빈 칸 %.0f %%, 최근접 이웃 비 R = %.2f" % (
        gname, len(pts), mean, cv, 1 / math.sqrt(max(mean, 1e-9)), 100 * np.mean(v == 0), R))

# 큰 것 (멀리서 눈에 띄는 것)
big = []
for a, x, z, s in props:
    ht = C.prop_height(a, s)
    if C.kind(a) == "landmark" or (a in C.FEATURE and ht >= 2.5 and not a.startswith("cliff")) or a in ("statue_angel", "statue_reaper", "lantern"):
        big.append((x, z, a))
# 무덤 무리 (반지름 8 m 안 3 기 이상)
graves = np.array([(x, z) for a, x, z, s in props if a.startswith("grave_")])
for x, z in graves[::3]:
    if ((graves - (x, z)) ** 2).sum(1).__lt__(64).sum() >= 3:
        big.append((x, z, "grave_cluster"))
for l in C.all_lights():
    if l[4] >= 5:
        big.append((l[0], l[2], "light"))
print("\n'큰 것' %d 개 (종류: %s)" % (len(big), dict(collections.Counter(b[2] for b in big).most_common(8))))
field = np.load(C.OUT + "/field.npy")
STEP = 8
n = field.shape[0]
gx = np.arange(n) * STEP + STEP / 2
GX, GZ = np.meshgrid(gx, gx)
q = np.stack([GX.ravel(), GZ.ravel()], -1)
P = np.array([(b[0], b[1]) for b in big])
d = C.dist_to_points(P[:, 0], P[:, 1], q).reshape(GX.shape)
print("들판에서 '큰 것' 까지: > 60 m %.0f %%, > 100 m %.0f %%, > 150 m %.0f %%" % tuple(100 * (field & (d > t)).sum() / field.sum() for t in (60, 100, 150)))
D = np.where(field, d, 0)
cand = []
r = 6
for i in range(r, n - r):
    for j in range(r, n - r):
        v = D[i, j]
        if v >= 90 and v == D[i - r:i + r + 1, j - r:j + r + 1].max():
            cand.append((v, GX[i, j], GZ[i, j]))
cand.sort(reverse=True)
holes = []
for v, x, z in cand:
    if all((x - a) ** 2 + (z - b) ** 2 > 180 ** 2 for _, a, b in holes):
        holes.append((v, x, z))
h = C.height()
print("'큰 것' 이 없는 빈 구역 (반지름 ≥ 90 m):")
for v, x, z in holes[:12]:
    near = min(pois, key=lambda p: (p[2] - x) ** 2 + (p[3] - z) ** 2)
    print("  (%4d, %4d) 반지름 %4.0f m (지름 %4.0f m), 높이 %.0f m — 가까운 장소 %s %.0f m" % (
        x, z, v, 2 * v, C.hsample(h, x, z), near[0], math.hypot(near[2] - x, near[3] - z)))
np.save(C.OUT + "/d_big.npy", d)
