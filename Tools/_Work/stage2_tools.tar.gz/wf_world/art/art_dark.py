#!/usr/bin/env python3
# 빛이 하나도 안 보이는 구역: 가장 가까운 광원(소품 발광 포함)까지 > 120 m 인 들판 덩어리 (art_gaps.py 먼저)
import numpy as np, artcommon as C
dl = np.load(C.OUT + "/d_light.npy"); field = np.load(C.OUT + "/field.npy")
STEP = 8; n = dl.shape[0]
W = C.world(); (bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]
for TH in (120,):
    dark = field & (dl > TH)
    lab = np.zeros(dark.shape, int); comps = []; k = 0
    for i in range(n):
        for j in range(n):
            if dark[i, j] and not lab[i, j]:
                k += 1; st = [(i, j)]; lab[i, j] = k; cells = []
                while st:
                    a, b = st.pop(); cells.append((a, b))
                    for da, db in ((1,0),(-1,0),(0,1),(0,-1)):
                        aa, bb = a+da, b+db
                        if 0 <= aa < n and 0 <= bb < n and dark[aa, bb] and not lab[aa, bb]:
                            lab[aa, bb] = k; st.append((aa, bb))
                c = np.array(cells) * STEP + STEP / 2
                mi = np.argmax(dl[tuple(np.array(cells).T)])
                comps.append((len(cells) * STEP * STEP, c[:, 1].mean(), c[:, 0].mean(), dl[tuple(np.array(cells).T)].max(), c[mi, 1], c[mi, 0]))
    comps.sort(reverse=True)
    print("광원까지 > %d m 인 들판 덩어리 (넓은 순):" % TH)
    for a, cx, cz, dm, mx, mz in comps[:10]:
        edge = min(mx - bx0, bx1 - mx, mz - bz0, bz1 - mz)
        print("  %.3f km²  가운데 (%4.0f,%4.0f)  가장 어두운 자리 (%4.0f,%4.0f) 광원까지 %3.0f m, bounds 가장자리까지 %3.0f m" % (a / 1e6, cx, cz, mx, mz, dm, edge))
