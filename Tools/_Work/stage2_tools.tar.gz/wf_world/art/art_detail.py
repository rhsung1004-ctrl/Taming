#!/usr/bin/env python3
# 풀·덩굴(detail) 검사: 종류별 밀도, 장소별 차이, 작은 소품을 가리는 키 큰 풀
#   python3 art_detail.py → 표준 출력 + out/detail_mix.png (R = 키 큰 풀 grass_b+fern+reed, G = grass_a, B = grass_dead+weeds)
import math, collections
import numpy as np
from PIL import Image
import artcommon as C

W = C.world()
dets = W["details"]
names = [d["asset"] for d in dets]
maxpc = np.array([d["maxPerCell"] for d in dets], np.float32)
dt = C.detail()[..., :len(names)]                 # 0~1
man = C.manifest()
hgt = {nm: man[nm]["size"][2] * (d["minScale"] + d["maxScale"]) / 2 for nm, d in zip(names, dets)}
print("풀 종류별 평균 키 (m, 크기 범위 가운데):", {k: round(v, 2) for k, v in hgt.items()})
inst = dt * maxpc                                  # 칸(1 m²)당 포기 수
wk = C.walkable()[:2048, :2048]
sl = C.slope()[:2048, :2048]
field = wk & (sl < 0.58)
print("\n들판 전체: 종류별 포기/m² 평균, 풀이 1 포기 이상인 칸 비율")
tot = inst[field].sum(-1)
for k, nm in enumerate(names):
    print("  %-10s %.2f /m²  (칸 비율 %4.1f %%)" % (nm, inst[field][:, k].mean(), 100 * np.mean(inst[field][:, k] >= 1)))
print("  합계 %.2f /m², 맨땅(< 0.5 포기) 칸 %.1f %%, ≥ 4 포기 칸 %.1f %%" % (tot.mean(), 100 * np.mean(tot < 0.5), 100 * np.mean(tot >= 4)))
print("  풀 거리 110 m 원 (3.8 ha) 안 평균 포기 수 ≈ %.0f 만" % (tot.mean() * math.pi * 110 ** 2 / 1e4))

ax = np.arange(2048)
X, Z = np.meshgrid(ax, ax)
wm = C.water_mask()[:2048, :2048]
print("\n장소별 포기/m² (반지름 안, 물 아래 제외): " + " ".join("%9s" % n for n in names) + "   합계  키큰풀 비율")
tall_idx = [names.index(n) for n in names if hgt[n] >= 0.55]
for pid, nm, px, pz, r in C.poi_list() + [("들판", "", None, None, None)]:
    if px is None:
        m = field.copy()
        for p in C.poi_list():
            m &= (X - p[2]) ** 2 + (Z - p[3]) ** 2 > (p[4] + 20) ** 2
    else:
        m = ((X - px) ** 2 + (Z - pz) ** 2 <= r * r) & ~wm
    v = inst[m].mean(0)
    print("  %-10s " % pid + " ".join("%9.2f" % x for x in v) + "   %5.2f  %4.0f %%" % (v.sum(), 100 * v[tall_idx].sum() / max(v.sum(), 1e-6)))

# 작은 소품을 가리는 풀: 소품 둘레 0.8~2.5 m 고리 안에서 소품보다 키 큰 풀의 포기/m²
print("\n작은 소품 둘레 (0.8~2.5 m) 의 '소품보다 키 큰 풀' 포기/m² — 1 이상이면 낮은 눈높이에서 가려지기 쉽다")
smalls = collections.defaultdict(list)
for o in C.objects()["objects"]:
    a = o["a"]
    ph = C.prop_height(a, o["s"])
    if ph <= 0 or ph > 1.3:
        continue
    x, z = o["p"][0], o["p"][2]
    i0, i1 = int(z - 3), int(z + 4)
    j0, j1 = int(x - 3), int(x + 4)
    if i0 < 0 or j0 < 0 or i1 > 2048 or j1 > 2048:
        continue
    zz, xx = np.mgrid[i0:i1, j0:j1]
    d = np.sqrt((xx + 0.5 - x) ** 2 + (zz + 0.5 - z) ** 2)
    ring = (d >= 0.8) & (d <= 2.5)
    taller = [k for k, n in enumerate(names) if hgt[n] >= ph * 0.9]
    if not taller:
        smalls[a].append(0.0)
        continue
    v = inst[i0:i1, j0:j1][ring][:, taller].sum(-1).mean()
    smalls[a].append(v)
for a, v in sorted(smalls.items(), key=lambda kv: -np.mean(kv[1])):
    v = np.array(v)
    print("  %-15s 키 %.2f m  %4d 개: 평균 %.2f /m², 1 이상 %4.0f %%" % (a, C.prop_height(a, 1.0), len(v), v.mean(), 100 * np.mean(v >= 1)))

# 그림
tall = inst[..., [names.index(n) for n in ("grass_b", "fern_a", "reed")]].sum(-1)
low = inst[..., names.index("grass_a")]
dead = inst[..., [names.index(n) for n in ("grass_dead", "weeds")]].sum(-1)
rgb = np.stack([np.clip(tall / 3, 0, 1), np.clip(low / 3, 0, 1), np.clip(dead / 3, 0, 1)], -1)
Image.fromarray((np.flipud(rgb) * 255).astype(np.uint8)).resize((1024, 1024), Image.BILINEAR).save(C.OUT + "/detail_mix.png")
print("\n그림:", C.OUT + "/detail_mix.png")
