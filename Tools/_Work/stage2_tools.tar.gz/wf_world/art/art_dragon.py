#!/usr/bin/env python3
# 용의 무덤: 새로 들어온 뼈 소품(manifest_bones) 키로, 분지 밖 300~600 m 에서 갈비뼈가 보일지 (크기별)
import math, numpy as np, artcommon as C
h = C.height(); wk = C.walkable(); man = C.manifest()
a = np.array([0.78, -0.62]); a /= np.linalg.norm(a)
head = np.array([470 + 26.0, 1060 - 20.0])
rib = head - a * 19.5 + np.array([-a[1], a[0]]) * -0.5
base = C.hsample(h, *rib)
print("갈비뼈 자리 (%.0f, %.0f) 바닥 %.1f m, 분지 둘레(반지름 230~330 m 고리) 평균 %.1f m" % (rib[0], rib[1], base,
      np.mean([C.hsample(h, 470 + math.cos(t) * r, 1060 + math.sin(t) * r) for t in np.linspace(0, 6.28, 72) for r in (230, 280, 330)])))
H = man["dragon_ribs"]["size"][2]
print("dragon_ribs 키 %.1f m, bone_spike %.1f m, dragon_claw %.1f m" % (H, man["bone_spike"]["size"][2], man["dragon_claw"]["size"][2]))
def vis(R, top):
    nv = nt = 0
    for k in range(36):
        th = k / 36 * 2 * math.pi
        ox, oz = rib[0] + math.cos(th) * R, rib[1] + math.sin(th) * R
        if not (0 <= ox < 2048 and 0 <= oz < 2048) or not wk[int(oz), int(ox)]: continue
        nt += 1
        oy = C.hsample(h, ox, oz) + 1.7
        d = math.hypot(rib[0] - ox, rib[1] - oz)
        t = np.linspace(0.02, 0.98, int(d / 3))
        hs = C.hsample(h, ox + (rib[0] - ox) * t, oz + (rib[1] - oz) * t)
        yb = oy + np.max((hs - oy) / (t * d)) * d
        if top - max(yb, base) >= 2: nv += 1
    return nv, nt
for s in (1.0, 1.5, 2.0, 2.5):
    top = base + H * s
    print("  크기 %.1f (꼭대기 %.1f m): " % (s, top) + ", ".join("%d m %d/%d" % ((R,) + vis(R, top)) for R in (150, 300, 450, 600)))
