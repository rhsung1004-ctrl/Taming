#!/usr/bin/env python3
# 빛 검사: 광원(소품 META.light + objects.json lights) 의 분포, 색, 장소별 몰림, 어두운 구역,
#         LightCuller (주인공 80 m 안, 가까운 48 개만 켬) 에 걸리는 곳, 효과(fx) 분포
#   python3 art_lights.py  (art_gaps.py 를 먼저 돌려 out/d_light.npy, field.npy 가 있어야 한다)
import math, collections
import numpy as np
from PIL import Image, ImageDraw
import artcommon as C

L = C.all_lights()
fxs = C.objects()["fx"]
pois = C.poi_list()
STEP = 8


def col_class(c):
    r, g, b = c
    if g > 0.9 and b < 0.5:
        return "독(초록)"
    if g > 0.7 and b > 0.7:
        return "청록"
    return "보라"


print("광원 %d 개" % len(L))
bysrc = collections.Counter(l[6] for l in L)
print("  출처별:", ", ".join("%s %d" % kv for kv in bysrc.most_common()))
bycol = collections.Counter(col_class(l[3]) for l in L)
print("  색별:", dict(bycol))
print("  세기 합 (색별):", {k: round(sum(l[4] for l in L if col_class(l[3]) == k)) for k in bycol})
strong = [l for l in L if l[4] >= 5]
print("  세기 ≥ 5 (멀리서도 빛 웅덩이가 보이는 것): %d 개 — %s" % (len(strong), dict(collections.Counter(l[6] for l in strong))))


def poi_of(x, z):
    best = None
    for pid, nm, px, pz, r in pois:
        d = math.hypot(x - px, z - pz)
        if d <= r + 15 and (best is None or d - r < best[1]):
            best = (pid, d - r)
    return best[0] if best else "들판"


print("\n장소별 광원 (장소 반지름 + 15 m 안; 넓이당 개수)")
cnt = collections.defaultdict(list)
for l in L:
    cnt[poi_of(l[0], l[2])].append(l)
field = np.load(C.OUT + "/field.npy")
field_area = field.sum() * STEP * STEP
for pid, nm, px, pz, r in pois + [("들판", "", 0, 0, 0)]:
    ls = cnt.get(pid, [])
    area = math.pi * (r + 15) ** 2 if pid != "들판" else field_area - sum(math.pi * (p[4] + 15) ** 2 for p in pois)
    cc = collections.Counter(col_class(l[3]) for l in ls)
    src = collections.Counter(l[6] for l in ls)
    print("  %-10s %4d 개 (%5.1f /ha)  세기 합 %6.0f  색 %s  주로 %s" % (pid, len(ls), len(ls) / area * 1e4, sum(l[4] for l in ls),
                                                          dict(cc), ", ".join("%s %d" % kv for kv in src.most_common(3))))

# 어두운 구역 (광원까지 거리) — art_gaps 의 d_light
dl = np.load(C.OUT + "/d_light.npy")
print("\n들판에서 가장 가까운 광원까지:")
for th in (40, 80, 120, 160):
    print("  > %3d m: %5.1f %% (%.2f km²)" % (th, 100 * (field & (dl > th)).sum() / field.sum(), (field & (dl > th)).sum() * STEP * STEP / 1e6))
# 빛 없는 넓은 구역 (LightCuller 반지름 80 m 안에 광원이 하나도 없는 자리 = 화면에 점광원이 0 개)
dark = field & (dl > 80)
n = dark.shape[0]
gx = np.arange(n) * STEP + STEP / 2
# 연결 요소 (4-이웃)
lab = np.zeros(dark.shape, int)
comps = []
k = 0
for i in range(n):
    for j in range(n):
        if dark[i, j] and lab[i, j] == 0:
            k += 1
            st = [(i, j)]
            lab[i, j] = k
            cells = []
            while st:
                a, b = st.pop()
                cells.append((a, b))
                for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    aa, bb = a + da, b + db
                    if 0 <= aa < n and 0 <= bb < n and dark[aa, bb] and lab[aa, bb] == 0:
                        lab[aa, bb] = k
                        st.append((aa, bb))
            cc = np.array(cells)
            comps.append((len(cells) * STEP * STEP, gx[cc[:, 1]].mean(), gx[cc[:, 0]].mean(), gx[cc[:, 1]].min(), gx[cc[:, 1]].max(), gx[cc[:, 0]].min(), gx[cc[:, 0]].max()))
comps.sort(reverse=True)
print("\n광원 0 개 구역 (주인공 80 m 안에 켤 광원이 없는 곳), 넓은 순:")
for a, cx, cz, x0, x1, z0, z1 in comps[:10]:
    print("  %.3f km²  가운데 (%4.0f, %4.0f)  x %4.0f~%4.0f, z %4.0f~%4.0f" % (a / 1e6, cx, cz, x0, x1, z0, z1))

# LightCuller: 반지름 80 m 안 광원이 48 개를 넘는 곳 (먼 것부터 꺼져 걸을 때 켜졌다 꺼졌다)
P = np.array([[l[0], l[2]] for l in L])
q = np.stack(np.meshgrid(gx, gx), -1).reshape(-1, 2)
cntv = np.zeros(len(q), int)
for i in range(0, len(q), 4096):
    d2 = ((q[i:i + 4096, None, :] - P[None, :, :]) ** 2).sum(-1)
    cntv[i:i + 4096] = (d2 <= 80 * 80).sum(1)
cntv = cntv.reshape(n, n)
over = cntv > 48
print("\n80 m 안 광원 수: 최대 %d (자리 (%d, %d)), 48 개 초과 넓이 %.3f km²" % (
    cntv.max(), gx[np.unravel_index(cntv.argmax(), cntv.shape)[1]], gx[np.unravel_index(cntv.argmax(), cntv.shape)[0]], over.sum() * STEP * STEP / 1e6))
for pid, nm, px, pz, r in pois:
    i, j = int(pz // STEP), int(px // STEP)
    print("  %-10s 가운데에서 80 m 안 광원 %3d 개" % (pid, cntv[i, j]))

# 효과
print("\n효과 %d 개: %s" % (len(fxs), dict(collections.Counter(f["type"] for f in fxs))))
cfx = collections.defaultdict(collections.Counter)
area_fx = collections.Counter()
for f in fxs:
    cfx[poi_of(f["p"][0], f["p"][2])][f["type"]] += 1
    area_fx[f["type"]] += math.pi * f["r"] ** 2
for k, v in cfx.items():
    print("  %-10s %s" % (k, dict(v)))
print("  덮는 넓이 합 (겹침 포함): " + ", ".join("%s %.3f km² (%.1f %% of 들판)" % (k, a / 1e6, 100 * a / field_area) for k, a in area_fx.items()))
# 효과가 없는 장소
for pid, nm, px, pz, r in pois:
    if not cfx.get(pid):
        print("  효과 없음:", pid, nm)

# 그림: 광원 점 (색), 효과 원
im = Image.new("RGB", (1024, 1024), (10, 10, 20))
dr = ImageDraw.Draw(im)
sc = 1024 / 2048
fl = np.flipud(field)
fim = Image.fromarray((fl * 40).astype(np.uint8)).resize((1024, 1024))
im.paste(Image.merge("RGB", (fim, fim, fim)))
dr = ImageDraw.Draw(im)
for f in fxs:
    x, z, r = f["p"][0] * sc, 1024 - f["p"][2] * sc, f["r"] * sc
    c = {"mist": (90, 90, 140), "wisps": (200, 120, 255), "soulfire": (255, 80, 255), "fireflies": (80, 255, 180)}[f["type"]]
    dr.ellipse([x - r, z - r, x + r, z + r], outline=c)
for l in L:
    x, z = l[0] * sc, 1024 - l[2] * sc
    c = tuple(int(255 * min(1, v)) for v in l[3])
    rr = max(1, l[5] * sc)
    dr.ellipse([x - rr, z - rr, x + rr, z + rr], fill=c)
for pid, nm, px, pz, r in pois:
    dr.text((px * sc + 4, 1024 - pz * sc), pid, fill=(255, 255, 255))
im.save(C.OUT + "/lights.png")
print("\n그림:", C.OUT + "/lights.png")

# ── 빛 웅덩이 넓이 (광원 범위 원의 합집합) 와 길가 몰림
import sys
sys.path.insert(0, C.WG)
import worldgen as WGM
from terrain import catmull
G = 2
ng = 2048 // G
lit = np.zeros((ng, ng), bool)
for l in L:
    r = l[5]
    i0, i1 = max(0, int((l[2] - r) / G)), min(ng, int((l[2] + r) / G) + 1)
    j0, j1 = max(0, int((l[0] - r) / G)), min(ng, int((l[0] + r) / G) + 1)
    zz, xx = np.mgrid[i0:i1, j0:j1]
    lit[i0:i1, j0:j1] |= ((xx * G + G / 2 - l[0]) ** 2 + (zz * G + G / 2 - l[2]) ** 2) <= r * r
fd = field.repeat(STEP // G, 0).repeat(STEP // G, 1)[:ng, :ng]
print("\n광원 범위 안 (빛 웅덩이) 넓이: 들판의 %.2f %%" % (100 * (lit & fd).sum() / fd.sum()))
roads = [catmull(p, 2.0) for p, hw in WGM.ROADS]
RP = np.concatenate(roads)
lan = np.array([[l[0], l[2]] for l in L if l[6] == "lantern"])
dr_ = C.dist_to_points(RP[:, 0], RP[:, 1], lan)
print("등불 %d 개 중 길에서 8 m 안: %d 개 (%.0f %%)" % (len(lan), (dr_ < 8).sum(), 100 * np.mean(dr_ < 8)))
allp = np.array([[l[0], l[2]] for l in L if l[4] >= 5])
dr2 = C.dist_to_points(RP[:, 0], RP[:, 1], allp)
print("세기 ≥ 5 광원 %d 개 중 길에서 8 m 안: %.0f %%" % (len(allp), 100 * np.mean(dr2 < 8)))
