#!/usr/bin/env python3
# 빈 들판 검사: "볼 것" (무덤·폐허·석상·등불·발광 소품·큰 구조물) 까지의 거리 지도, 큰 빈 구역, 길·장소 사이 지루한 구간
#   python3 art_gaps.py            → 표준 출력 + out/gaps.png (밝을수록 볼 것에서 멀다, 점 = 장소)
import math
import numpy as np
from PIL import Image, ImageDraw
import artcommon as C

STEP = 8                    # 격자 (m)
SEE = 50.0                  # 밤·안개에서 작은 소품이 눈에 들어오는 거리 (m)

props = C.all_props()
man = C.manifest()
feat = [(a, x, z) for a, x, z, s in props if a in C.FEATURE or a in C.GLOW or C.kind(a) == "landmark"]
anyp = [(a, x, z) for a, x, z, s in props]
lights = C.all_lights()
print("볼 것 소품", len(feat), "/ 전체 소품·나무", len(anyp), "/ 광원", len(lights))

h = C.height()
wk = C.walkable()
n = h.shape[0]
gx = np.arange(0, n - 1, STEP) + STEP / 2
GX, GZ = np.meshgrid(gx, gx)
q = np.stack([GX.ravel(), GZ.ravel()], -1)
wk_c = wk[GZ.astype(int), GX.astype(int)]
# 걸을 수 있는 들판: 산비탈(경사 > 0.58 이 넓게 이어진 곳) 은 빼고 bounds 안
sl = C.slope()
field = wk_c & (sl[GZ.astype(int), GX.astype(int)] < 0.58)

fx = np.array([[x, z] for _, x, z in feat])
d_feat = C.dist_to_points(fx[:, 0], fx[:, 1], q).reshape(GX.shape)
ax_ = np.array([[x, z] for _, x, z in anyp])
d_any = C.dist_to_points(ax_[:, 0], ax_[:, 1], q).reshape(GX.shape)
lx = np.array([[l[0], l[2]] for l in lights])
d_light = C.dist_to_points(lx[:, 0], lx[:, 1], q).reshape(GX.shape)

A = field.sum() * STEP * STEP
print("\n걸을 수 있는 들판 넓이 %.2f km²" % (A / 1e6))
for th in (30, 50, 80, 100, 150):
    print("  볼 것까지 > %3d m 인 넓이: %5.1f %%   (아무 소품까지 > %3d m: %5.1f %%)   (광원까지 > %3d m: %5.1f %%)" % (
        th, 100 * (field & (d_feat > th)).sum() / field.sum(), th, 100 * (field & (d_any > th)).sum() / field.sum(),
        th, 100 * (field & (d_light > th)).sum() / field.sum()))

# 큰 빈 구역: 볼 것까지 거리의 국소 최대 (반지름 ≥ 70 m), 서로 150 m 이상 떨어진 것
D = np.where(field, d_feat, 0)
cand = []
r = 6
for i in range(r, D.shape[0] - r):
    for j in range(r, D.shape[1] - r):
        v = D[i, j]
        if v >= 70 and v == D[i - r:i + r + 1, j - r:j + r + 1].max():
            cand.append((v, GX[i, j], GZ[i, j]))
cand.sort(reverse=True)
holes = []
for v, x, z in cand:
    if all((x - a) ** 2 + (z - b) ** 2 > 150 ** 2 for _, a, b in holes):
        holes.append((v, x, z))
pois = C.poi_list()
print("\n큰 빈 구역 (가운데에서 가장 가까운 '볼 것' 까지 반지름; 지름 = 아무것도 없이 걷는 거리)")
for v, x, z in holes[:14]:
    near = min(pois, key=lambda p: (p[2] - x) ** 2 + (p[3] - z) ** 2)
    i, j = int(z // STEP), int(x // STEP)
    na = d_any[min(i, D.shape[0] - 1), min(j, D.shape[1] - 1)]
    nl = d_light[min(i, D.shape[0] - 1), min(j, D.shape[1] - 1)]
    print("  (%4d, %4d)  반지름 %4.0f m (지름 %4.0f m)  가장 가까운 광원 %4.0f m, 아무 소품 %3.0f m, 높이 %.1f m  — 가까운 장소 %s %.0f m" % (
        x, z, v, 2 * v, nl, na, C.hsample(h, x, z), near[1], math.hypot(near[2] - x, near[3] - z)))

# 장소 사이 직선·길 위의 지루한 구간 (볼 것까지 > SEE 가 이어지는 길이)
def boring_runs(path, th=SEE):
    seg = np.linalg.norm(np.diff(path, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    d = C.dist_to_points(fx[:, 0], fx[:, 1], path)
    runs, start = [], None
    for k in range(len(path)):
        if d[k] > th:
            if start is None:
                start = k
        else:
            if start is not None:
                runs.append((s[k - 1] - s[start], path[start], path[k - 1]))
                start = None
    if start is not None:
        runs.append((s[-1] - s[start], path[start], path[-1]))
    return s[-1], runs


import sys
sys.path.insert(0, C.WG)
import worldgen as WGM
from terrain import catmull
print("\n길 위의 지루한 구간 (볼 것까지 > %d m 가 150 m 이상 이어짐)" % SEE)
tot_len, tot_boring = 0, 0
for k, (pts, hw) in enumerate(WGM.ROADS):
    c = catmull(pts, 2.0)
    L, runs = boring_runs(c)
    tot_len += L
    for ln, a, b in runs:
        if ln >= 150:
            tot_boring += ln
            print("  길 %2d (%4d,%4d)→(%4d,%4d) 길이 %4.0f: %4.0f m 구간 (%4.0f,%4.0f) → (%4.0f,%4.0f)" % (
                k, pts[0][0], pts[0][1], pts[-1][0], pts[-1][1], L, ln, a[0], a[1], b[0], b[1]))
print("  길 전체 %.0f m 중 지루한 구간 %.0f m (%.0f %%)" % (tot_len, tot_boring, 100 * tot_boring / tot_len))

# 이웃 장소 사이 거리
print("\n장소마다 가장 가까운 이웃 장소 거리 (경계 사이 = 중심 거리 − 두 반지름)")
for p in pois:
    others = [(math.hypot(p[2] - o[2], p[3] - o[3]), o) for o in pois if o[0] != p[0]]
    d, o = min(others, key=lambda t: t[0] - t[1][4])
    print("  %-10s → %-10s 중심 %4.0f m, 경계 사이 %4.0f m" % (p[0], o[0], d, d - p[4] - o[4]))

# 그림
img = np.clip(np.where(field, d_feat, -1) / 200.0, 0, 1)
rgb = np.stack([img, img * 0.85, img * 0.6], -1)
rgb[~field] = (0.08, 0.1, 0.18)
im = Image.fromarray((np.flipud(rgb) * 255).astype(np.uint8)).resize((768, 768), Image.NEAREST)
dr = ImageDraw.Draw(im)
sc = 768 / (D.shape[0] * STEP)
for p in pois:
    x, z = p[2] * sc, 768 - p[3] * sc
    rr = p[4] * sc
    dr.ellipse([x - rr, z - rr, x + rr, z + rr], outline=(120, 200, 255))
    dr.text((x + 3, z - 6), p[0], fill=(120, 200, 255))
for v, x, z in holes[:14]:
    X_, Z_ = x * sc, 768 - z * sc
    dr.ellipse([X_ - v * sc, Z_ - v * sc, X_ + v * sc, Z_ + v * sc], outline=(255, 80, 80))
    dr.text((X_ - 10, Z_ - 5), "%.0f" % v, fill=(255, 80, 80))
for l in lights:
    dr.point((l[0] * sc, 768 - l[2] * sc), fill=(200, 120, 255))
im.save(C.OUT + "/gaps.png")
print("\n그림:", C.OUT + "/gaps.png")
np.save(C.OUT + "/d_feat.npy", d_feat)
np.save(C.OUT + "/d_light.npy", d_light)
np.save(C.OUT + "/field.npy", field)
