import sys, math, json, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import artcommon as C
h = C.height(); wk = C.walkable(); man = C.manifest()
DEN = C.world()["fog"]["density"]
objs = C.objects()["objects"]
bones = [o for o in objs if o["a"].startswith("dragon")]
for o in bones: print(o["a"], [round(v,1) for v in o["p"]], o["s"])
# 목표: 갈비뼈 꼭대기 (manifest), 해골 꼭대기
rib = np.array([480.4, 1052.4]); rib_base = C.hsample(h, *rib); rib_top = rib_base - 0.2 + 6.315
sk = [o for o in objs if o["a"]=="dragon_skull"][0]
skx, skz = sk["p"][0], sk["p"][2]; sk_base = C.hsample(h, skx, skz); sk_top = sk["p"][1] + 2.584*sk["s"]
print("rib top %.1f, skull top %.1f (base %.1f)" % (rib_top, sk_top, sk_base))
def los(ox, oz, tx, tz, tb, tt, eye=1.7):
    oy = C.hsample(h, ox, oz) + eye
    d = math.hypot(tx-ox, tz-oz)
    t = np.linspace(0.02, 0.98, max(int(d/1.5), 2))
    hs = C.hsample(h, ox+(tx-ox)*t, oz+(tz-oz)*t)
    yb = oy + np.max((hs-oy)/(t*d))*d
    vis = tt - max(yb, tb)
    # 보이는 세로 화면 px (60° / 1080)
    px = (math.degrees(math.atan2(tt-oy, d)) - math.degrees(math.atan2(max(yb, tb)-oy, d)))*18 if vis>0 else 0
    # 분지 바닥 (기준점 둘레 바닥) 보이는가: 바닥 높이 + 0.5
    return vis, px, d, oy
def walk(pts, step=10):
    out = []
    for (x0,z0),(x1,z1) in zip(pts[:-1], pts[1:]):
        L = math.hypot(x1-x0, z1-z0)
        for s in np.arange(0, L, step):
            out.append((x0+(x1-x0)*s/L, z0+(z1-z0)*s/L))
    out.append(pts[-1]); return out
routes = {
 "다리→용의무덤 (다리 서쪽끝→진입로)": [(722,1010),(640,1040),(565,1055),(500,1052)],
 "망루 길 (망루→용의 무덤, 북쪽에서 들어옴)": [(630,1540),(600,1450),(545,1300),(500,1140)],
 "묘지 서쪽→다리 동쪽": [(812,884),(770,950),(735,1000)],
}
for nm, pts in routes.items():
    print("\n==", nm)
    print("  지점           높이  갈비뼈까지  갈비뼈 보임m px  안개대비 | 해골 보임m px")
    for (x,z) in walk(pts, 15):
        v, px, d, oy = los(x, z, rib[0], rib[1], rib_base, rib_top)
        v2, px2, d2, _ = los(x, z, skx, skz, sk_base, sk_top)
        print("  (%4.0f,%4.0f) %5.1f  %5.0f m   %5.1f %4.0f   %.2f   | %5.1f %4.0f" % (x, z, oy-1.7, d, max(v,0), px, math.exp(-(d*DEN)**2), max(v2,0), px2))
