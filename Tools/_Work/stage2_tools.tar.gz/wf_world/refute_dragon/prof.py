import sys, math, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import artcommon as C
h = C.height(); wk = C.walkable()
cx, cz = 470, 1060
rib = np.array([480.4, 1052.4])
print("ribs base", C.hsample(h, *rib))
# 방향별 테두리: 중심에서 바깥으로 최대 높이 지점 (0~320 m)
print("방위  테두리거리(갈비뼈기준)  테두리높이  바닥->테두리 차  300m지점높이  300m 걷기")
for k in range(36):
    th = k/36*2*math.pi
    ds = np.arange(5, 400, 1.0)
    xs, zs = rib[0]+np.cos(th)*ds, rib[1]+np.sin(th)*ds
    hs = C.hsample(h, xs, zs)
    i = int(np.argmax(hs[:300]))
    o300 = (rib[0]+math.cos(th)*300, rib[1]+math.sin(th)*300)
    w = wk[int(o300[1]), int(o300[0])] if 0<=o300[0]<2048 and 0<=o300[1]<2048 else False
    print("%4d° %6.0f m %7.1f m %6.1f m  %6.1f m  %s  (h@150 %.1f, h@200 %.1f, h@250 %.1f)" % (k*10, ds[i], hs[i], hs[i]-hs[0], C.hsample(h,*o300), w, hs[145], hs[195], hs[245]))
