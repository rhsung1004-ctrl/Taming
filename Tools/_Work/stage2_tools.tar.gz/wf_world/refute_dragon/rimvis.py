import sys, math, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import artcommon as C
h = C.height(); wk = C.walkable()
DEN = C.world()["fog"]["density"]
rib = np.array([480.4, 1052.4]); base = C.hsample(h, *rib); top = base - 0.2 + 6.315
def vis(ox, oz):
    oy = C.hsample(h, ox, oz) + 1.7
    d = math.hypot(rib[0]-ox, rib[1]-oz)
    t = np.linspace(0.02, 0.98, max(int(d/1.5), 2))
    hs = C.hsample(h, ox+(rib[0]-ox)*t, oz+(rib[1]-oz)*t)
    yb = oy + np.max((hs-oy)/(t*d))*d
    return top - max(yb, base), d
nv = nt = 0; ds = []
for k in range(36):
    th = k/36*2*math.pi
    dd = np.arange(5, 300, 1.0)
    xs, zs = rib[0]+np.cos(th)*dd, rib[1]+np.sin(th)*dd
    hs = C.hsample(h, xs, zs)
    i = int(np.argmax(hs[:260]))   # 테두리 꼭대기 (260 m 안)
    ox, oz = xs[i], zs[i]
    if not wk[int(oz), int(ox)]: continue
    nt += 1
    v, d = vis(ox, oz)
    if v >= 2: nv += 1; ds.append(d)
print("테두리 꼭대기에 선 관찰자: 갈비뼈 2 m 이상 보임 %d/%d, 거리 중앙값 %.0f m, 안개 대비 %.2f" % (nv, nt, np.median(ds), math.exp(-(np.median(ds)*DEN)**2)))
# 가림 없는 평지라도 300 m 에서 갈비뼈가 얼마나 보이나
for d in (216, 300, 450):
    a = math.degrees(math.atan2(6.3, d))
    print("가림 없을 때 %d m: 키 6.3 m → %.2f° = %.0f px (1080p, 세로 60°), 안개 대비 %.3f" % (d, a, a*18, math.exp(-(d*DEN)**2)))
# 제안 기준 '300 m 에서 10/36': 방위 -20°~+40° 부채꼴은 36 방향 중 몇 개
print("부채꼴 -20°~+40° 안 방향 수:", sum(1 for k in range(36) if (k*10+20) % 360 <= 60))
