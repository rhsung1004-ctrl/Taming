import sys, math, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import artcommon as C
h = C.height(); wk = C.walkable()
DEN = C.world()["fog"]["density"]
cx, cz, R = 470, 1060, 215
rib = np.array([480.4, 1052.4])
props = [(a,x,z,s) for a,x,z,s in C.all_props() if (x-cx)**2+(z-cz)**2 <= (R+10)**2 and C.prop_height(a,s) >= 3.0]
from collections import Counter
print("분지 안·테두리 3 m 이상 소품:", Counter(p[0] for p in props))
def vis(ox, oz, oy, tx, tz, tb, tt):
    d = math.hypot(tx-ox, tz-oz)
    t = np.linspace(0.02, 0.98, max(int(d/3), 2))
    hs = C.hsample(h, ox+(tx-ox)*t, oz+(tz-oz)*t)
    yb = oy + np.max((hs-oy)/(t*d))*d
    return tt - max(yb, tb), d
for Rr in (250, 300):
    nany = ncl = nt = 0; rows=[]
    for k in range(36):
        th = k/36*2*math.pi
        ox, oz = rib[0]+math.cos(th)*Rr, rib[1]+math.sin(th)*Rr
        if not wk[int(oz), int(ox)]: continue
        nt += 1
        oy = C.hsample(h, ox, oz) + 1.7
        best = None
        for a,x,z,s in props:
            b = C.hsample(h, x, z); v, d = vis(ox, oz, oy, x, z, b, b + C.prop_height(a, s))
            if v >= 2 and (best is None or d < best[2]): best = (a, v, d)
        if best: nany += 1
        rows.append("%3d°:%s" % (k*10, ("%s %.0fm" % (best[0], best[2])) if best else "-"))
    print("갈비뼈에서 %d m 고리: 분지 소품 하나라도 2 m 이상 보임 %d/%d" % (Rr, nany, nt))
    print("   " + ", ".join(rows))
