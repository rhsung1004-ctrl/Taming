# 점광원 예산과 LightCuller(반지름 80, 여유 10, 최대 48, 0.5초) 깜박임 위험
#   python3 perf_lights.py [격자 간격 m=4]
# 1) 출처별 광원 수, 256 m 칸별 광원 수, 32 m 칸 최대 몰림
# 2) 주인공 자리마다 80 m 안 광원 수, 48번째로 가까운 광원 거리 (48 이 넘는 곳 = 최대 개수로 잘리는 곳)
# 3) 한 점을 비추는 광원 수 최대 (Forward+ 픽셀당 광원 비용)
# 4) 길을 따라 걸으며 LightCuller 를 그대로 흉내 내어 "가까운(30 m 안) 광원이 개수 제한 때문에 꺼졌다 켜지는" 횟수를 센다
import sys, collections, json
import numpy as np
from perf_common import *

step = float(sys.argv[1]) if len(sys.argv) > 1 else 4.0
A = assets()
L = load_lights(A)
P = np.array([[l[0], l[1], l[2]] for l in L], np.float64)
Rg = np.array([l[3] for l in L]); It = np.array([l[4] for l in L])
src = np.array([l[5] for l in L])
print("점광원 합 %d (소품 광원 %d + 따로 놓은 광원 %d)" % (len(L), (src != '(lights)').sum(), (src == '(lights)').sum()))
for n, c in collections.Counter(src.tolist()).most_common():
    m = src == n
    print("   %-15s %4d  (range %.1f~%.1f m, 세기 %.1f~%.1f)" % (n, c, Rg[m].min(), Rg[m].max(), It[m].min(), It[m].max()))

print("\n256 m 칸별 광원 수 (행 = 북→남, 열 = 서→동, 칸 번호 = Cell_x_z):")
cx_ = (P[:, 0] // 256).astype(int); cz_ = (P[:, 2] // 256).astype(int)
tab = np.zeros((8, 8), int)
np.add.at(tab, (cz_, cx_), 1)
print("      " + "".join("  x%d " % i for i in range(8)))
for z in range(7, -1, -1):
    print("  z%d " % z + "".join("%5d" % v for v in tab[z]))
k = np.unravel_index(np.argmax(tab), tab.shape)
m = (cz_ == k[0]) & (cx_ == k[1])
print("  최대 칸 Cell_%d_%d (x %d~%d, z %d~%d): %d 개 = %s" % (k[1], k[0], k[1] * 256, k[1] * 256 + 256, k[0] * 256, k[0] * 256 + 256, tab[k], dict(collections.Counter(src[m].tolist()).most_common())))

# 32 m 칸 몰림
c32 = collections.Counter(zip((P[:, 0] // 32).astype(int), (P[:, 2] // 32).astype(int)))
print("\n32 m 칸 광원 몰림 상위:")
for (ix, iz), c in c32.most_common(6):
    m = ((P[:, 0] // 32).astype(int) == ix) & ((P[:, 2] // 32).astype(int) == iz)
    print("   (%4d~%4d, %4d~%4d) %-22s %3d 개  %s" % (ix * 32, ix * 32 + 32, iz * 32, iz * 32 + 32, nearest_poi(ix * 32 + 16, iz * 32 + 16), c, dict(collections.Counter(src[m].tolist()).most_common(4))))

# 2) 자리마다 80 m 안 개수, 48번째 거리
cx, cz, ng = walk_grid(step)
n80 = np.zeros(len(cx), int); n90 = np.zeros(len(cx), int); d48 = np.zeros(len(cx)); d49 = np.zeros(len(cx))
for c0 in range(0, len(cx), 4000):
    dd = np.hypot(P[None, :, 0] - cx[c0:c0 + 4000, None], P[None, :, 2] - cz[c0:c0 + 4000, None])
    n80[c0:c0 + 4000] = (dd < CULLER_RADIUS).sum(1)
    n90[c0:c0 + 4000] = (dd < CULLER_RADIUS + CULLER_HYST).sum(1)
    part = np.partition(dd, 48, axis=1)
    d48[c0:c0 + 4000] = part[:, 47]; d49[c0:c0 + 4000] = part[:, 48]
print("\n주인공 자리 (간격 %.0f m, %d 곳) 80 m 안 광원 수: 중앙값 %d, 99%% %d, 최대 %d. 48 개 넘는 자리 %d 곳 (%.2f%%), 90 m 안 48 넘는 자리 %d 곳"
      % (step, len(cx), np.median(n80), np.percentile(n80, 99), n80.max(), (n80 > 48).sum(), (n80 > 48).mean() * 100, (n90 > 48).sum()))
order = np.argsort(-n80)
got = []
for i in order:
    if n80[i] <= 30:
        break
    if all(np.hypot(cx[i] - cx[j], cz[i] - cz[j]) > 60 for j in got):
        got.append(i)
    if len(got) >= 8:
        break
for i in got:
    dd = np.hypot(P[:, 0] - cx[i], P[:, 2] - cz[i])
    near = dd < CULLER_RADIUS
    print("   (%5.0f, %5.0f) %-24s 80 m 안 %3d 개, 48번째 %.1f m, 49번째 %.1f m  출처 %s" % (cx[i], cz[i], nearest_poi(cx[i], cz[i]), n80[i], d48[i], d49[i],
          dict(collections.Counter(src[near].tolist()).most_common(5))))
np.savez_compressed(os.path.join(OUT, 'lights_grid.npz'), cx=cx, cz=cz, n80=n80, n90=n90, d48=d48)

# 3) 한 점을 비추는 광원 수 (땅 높이 1 m 칸, 수평 거리 < range 로 어림)
cov = np.zeros((2048, 2048), np.int16)
for (x, y, z), r in zip(P, Rg):
    x0, x1 = int(max(0, x - r)), int(min(2047, x + r)); z0, z1 = int(max(0, z - r)), int(min(2047, z + r))
    yy, xx = np.mgrid[z0:z1 + 1, x0:x1 + 1]
    cov[z0:z1 + 1, x0:x1 + 1] += (np.hypot(xx + 0.5 - x, yy + 0.5 - z) < r).astype(np.int16)
k = np.unravel_index(np.argmax(cov), cov.shape)
print("\n한 점(1 m 칸)을 비추는 광원 수: 최대 %d 개 at (%d, %d) %s; 8 개 이상 비추는 땅 %d m², 4 개 이상 %d m²"
      % (cov.max(), k[1], k[0], nearest_poi(k[1], k[0]), (cov >= 8).sum(), (cov >= 4).sum()))
dd = np.hypot(P[:, 0] - k[1] - 0.5, P[:, 2] - k[0] - 0.5)
m = dd < Rg
print("   그 점의 광원: %s" % dict(collections.Counter(src[m].tolist())))

# 4) LightCuller 흉내 (0.5 초마다, 달리기 6 m/s → 3 m 간격)
def walk(path, speed=6.0, interval=0.5, near=30.0):
    path = np.array(path, float)
    seg = np.linalg.norm(np.diff(path, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    ts = np.arange(0, s[-1], speed * interval)
    xs = np.interp(ts, s, path[:, 0]); zs = np.interp(ts, s, path[:, 1])
    on = np.ones(len(P), bool)          # 시작: 모두 켜짐 (Refresh 직후 Cull)
    first = True
    pops = 0; pop_d = []; max_cand = 0; cap_hits = 0; capoff = collections.Counter(); capd = []
    for x, z in zip(xs, zs):
        dd = np.hypot(P[:, 0] - x, P[:, 2] - z)
        lim = np.where(on, (CULLER_RADIUS + CULLER_HYST) ** 2, CULLER_RADIUS ** 2)
        cand = np.nonzero(dd * dd <= lim)[0]
        max_cand = max(max_cand, len(cand))
        full = cand
        if len(cand) > CULLER_MAX:
            cap_hits += 1
            cand = cand[np.argsort(dd[cand])[:CULLER_MAX]]
        new = np.zeros(len(P), bool); new[cand] = True
        if not first:
            for i in full:
                if on[i] and not new[i]:          # 반지름 안인데 개수 제한으로 꺼짐
                    capoff[str(src[i])] += 1; capd.append(dd[i])
        if not first:
            ch = np.nonzero(new != on)[0]
            for i in ch:
                if dd[i] < near:
                    pops += 1; pop_d.append(dd[i])
        on = new; first = False
    return len(xs), max_cand, cap_hits, pops, (min(pop_d) if pop_d else None), capoff, capd

paths = {
    "시작→제단→묘지 가운데 길→납골당": [(1000, 492), (1000, 540), (1000, 700), (1000, 880), (1000, 990)],
    "묘지 동서 길": [(800, 884), (1000, 884), (1200, 884)],
    "제단 둘레 한 바퀴 (반지름 12 m)": [(1000 + 12 * np.cos(a), 520 + 12 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 40)],
    "늪 가로지르기 (z 935)": [(1260, 935), (1545, 935), (1830, 935)],
    "늪 세로 (x 1545)": [(1545, 650), (1545, 935), (1545, 1220)],
    "검은 숲 가로 (z 640)": [(220, 640), (430, 640), (660, 640)],
    "영혼의 고목 둘레": [(1470 + 20 * np.cos(a), 1420 + 20 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 40)],
    "호수 둘레": [(720 + 110 * np.cos(a), 330 + 110 * np.sin(a)) for a in np.linspace(0, 2 * np.pi, 60)],
    "용의 무덤 가로": [(270, 1060), (470, 1060), (670, 1060)],
    "버려진 마을": [(1300, 430), (1390, 430), (1480, 430)],
}
print("\nLightCuller 흉내 (달리기 6 m/s, 0.5 초마다, 30 m 안 광원이 켜짐↔꺼짐 바뀐 횟수):")
for name, pth in paths.items():
    steps, mc, caps, pops, md, capoff, capd = walk(pth)
    print("   %-34s 판단 %3d 번, 후보 최대 %3d, 48 제한 걸린 판단 %3d 번, 30 m 안 깜박임 %3d 번%s" % (name, steps, mc, caps, pops, (", 가장 가까운 %.1f m" % md) if md is not None else ""))
    if capoff:
        print("      개수 제한으로 반지름 안에서 꺼진 광원 %d 번 (거리 %.1f~%.1f m): %s" % (sum(capoff.values()), min(capd), max(capd), dict(capoff.most_common())))
