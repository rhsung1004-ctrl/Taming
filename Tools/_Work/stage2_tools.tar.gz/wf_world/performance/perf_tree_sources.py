# 지형 나무(죽은 나무·덤불·바위)를 생성기 지역별로 나눠 센다 → 어느 함수의 개수를 줄이면 먼 나무 LOD1 비용이 주는지
#   python3 perf_tree_sources.py
import collections
import numpy as np
from perf_common import *
A = assets()
I = load_instances(A)
reg = np.full(len(I.x), '들판·작은 숲(lay_fields·lay_groves)·개울·호수', dtype=object)
def disk(c, r): return np.hypot(I.x - c[0], I.z - c[1]) < r
reg[np.hypot((I.x - 1000) / 204, (I.z - 880) / 172) < 1] = '묘지 (lay_graveyard)'
reg[disk((1545, 935), 300)] = '늪 (lay_swamp)'
reg[disk((1470, 1420), 220)] = '북동 숲 (lay_forest NE 1/85, lay_tree)'
reg[disk((430, 640), 280)] = '검은 숲 (lay_forest SW 1/70)'
reg[disk((470, 1060), 215)] = '용의 무덤 (lay_dragon)'
edge = np.minimum.reduce([I.x - 170, 1878 - I.x, I.z - 170, 1878 - I.z])
reg[(edge < 40) & (reg == '들판·작은 숲(lay_fields·lay_groves)·개울·호수')] = '산기슭 (lay_mountain_foot)'
for kind in (['dead_tree_a', 'dead_tree_b', 'dead_tree_c'], ['bramble', 'bush_dead'], ['rock_a', 'rock_c']):
    m = I.tree & np.isin(I.name, kind)
    print("%s: %d 그루, LOD1 합 %.2fM" % ("+".join(kind), m.sum(), I.tris[m, 1].sum() / 1e6))
    for r, c in collections.Counter(reg[m]).most_common():
        mm = m & (reg == r)
        print("   %-40s %5d  (LOD1 합 %.2fM)" % (r, c, I.tris[mm, 1].sum() / 1e6))
