# 장소별: 가장 높은 것이 무엇이고 어디 있나 (장소 고유 소품인가, 들판 흩뿌림인가), 고목 밀도 장소 vs 들판
import sys, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np, artcommon as C
props = C.all_props()
TREES = {"dead_tree_a", "dead_tree_b", "dead_tree_c"}
P = np.array([(x, z) for a, x, z, s in props])
isT = np.array([a in TREES for a, x, z, s in props])
H = np.array([C.prop_height(a, s) for a, x, z, s in props])
names = [a for a, x, z, s in props]
wk = C.walkable()
field_area = wk.sum()
print("전체 고목 %d, 걸을 수 있는 넓이 %.2f km2 → %.1f 그루/ha" % (isT.sum(), field_area / 1e6, isT.sum() / (field_area / 1e4)))
print("고목 키 분포: 50%% %.1f, 90%% %.1f, 99%% %.1f, 최대 %.1f" % tuple(np.percentile(H[isT], [50, 90, 99, 100])))
for pid, name, px, pz, r in C.poi_list():
    d = np.hypot(P[:, 0] - px, P[:, 1] - pz)
    m = d <= r + 10
    nt = (m & isT).sum()
    area = math.pi * (r + 10) ** 2 / 1e4
    # 장소 고유 (고목·덤불·바위 제외) 중 가장 높은 것
    nonfill = m & ~isT & ~np.isin(names, ["bush_dead", "bramble", "rock_a", "rock_c", "rock_b", "cliff_a", "cliff_b", "cliff_c"])
    j = np.argmax(np.where(nonfill, H, -1)) if nonfill.any() else None
    k = np.argmax(np.where(m, H, -1))
    print("%-9s r%3d 고목 %3d (%.1f/ha)  최고 %s %.1f m (중심에서 %.0f m)  | 고유 최고 %s %.1f m (중심에서 %.0f m)" % (
        pid, r, nt, nt / area, names[k], H[k], d[k], names[j] if j is not None else "-", H[j] if j is not None else 0, d[j] if j is not None else 0))
