# 고목이 아닌 장소 고유 구조물(제단·기둥·벽·우물·다리 등)이 100~250 m 에서 지형 위로 드러나는가
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np, artcommon as C
h = C.height(); wk = C.walkable()
EYE = 1.7; FOG = 0.0048
SIG = {"altar": {"altar", "pillar_a", "pillar_b", "lantern"},
       "village": {"wall_ruin_a", "wall_ruin_b", "well", "pillar_b", "lantern", "fence"},
       "bridge": {"bridge_ruin", "lantern"},
       "graveyard": {"statue_angel", "grave_obelisk", "grave_tomb", "lantern", "crypt"}}
objs = C.objects()["objects"]
def exposed(ox, oz, oy, tx, tz, base, top):
    d = math.hypot(tx - ox, tz - oz)
    n = max(int(d / 3), 2)
    t = np.linspace(0.02, 0.97, n)
    hs = C.hsample(h, ox + (tx - ox) * t, oz + (tz - oz) * t)
    yb = oy + np.max((hs - oy) / (t * d)) * d
    return top - max(yb, base)
for pid, name, px, pz, r in C.poi_list():
    if pid not in SIG: continue
    rr = r if pid != "graveyard" else 30
    sel = [o for o in objs if o["a"] in SIG[pid] and (o["p"][0] - px) ** 2 + (o["p"][2] - pz) ** 2 <= (r + 10) ** 2]
    if pid == "graveyard":
        sel = [o for o in sel if (o["p"][0] - px) ** 2 + (o["p"][2] - pz) ** 2 <= 30 ** 2]
    tg = [(o["p"][0], o["p"][2], C.hsample(h, o["p"][0], o["p"][2]), C.hsample(h, o["p"][0], o["p"][2]) + C.prop_height(o["a"], o["s"])) for o in sel]
    print("%s: 고유 구조물 %d 개 (키 최대 %.1f m, 개수 %s)" % (pid, len(tg), max(t[3] - t[2] for t in tg),
          {a: sum(1 for o in sel if o["a"] == a) for a in SIG[pid]}))
    for R in (100, 150, 200, 250):
        nv = nt = 0; cnt = []
        for k in range(36):
            th = k / 36 * 2 * math.pi
            ox, oz = px + math.cos(th) * R, pz + math.sin(th) * R
            if not (0 <= ox < 2048 and 0 <= oz < 2048) or not wk[int(oz), int(ox)]: continue
            nt += 1
            oy = C.hsample(h, ox, oz) + EYE
            c = sum(1 for x, z, b, tp in tg if exposed(ox, oz, oy, x, z, b, tp) >= 1.5)
            cnt.append(c)
            if c >= 3: nv += 1
        print("   %3d m (대비 %.2f): 구조물 3 개 이상이 1.5 m 넘게 드러나는 자리 %2d/%2d, 드러나는 개수 중앙 %d" % (
            R, math.exp(-(R * FOG) ** 2), nv, nt, int(np.median(cnt)) if cnt else 0))
