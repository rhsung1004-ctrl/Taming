# 분지형 장소(호수·늪·용의 무덤): 다가가는 길·둘레에서 바닥(물 면·뼈 자리)이 내려다보이는가
# 실루엣이 지형 위로 솟는가(art_landmarks)가 아니라, 눈높이에서 장소 바닥이 시선에 들어오는가를 잰다
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np, artcommon as C
h = C.height(); wk = C.walkable(); W = C.world(); wm = C.water_mask()
EYE = 1.7
rng = np.random.default_rng(1)

def visible(ox, oz, oy, tx, tz, ty):
    d = math.hypot(tx - ox, tz - oz)
    n = max(int(d / 2), 3)
    t = np.linspace(0.01, 0.97, n)
    hs = C.hsample(h, ox + (tx - ox) * t, oz + (tz - oz) * t)
    ray = oy + (ty - oy) * t
    return bool(np.all(hs < ray - 0.05))

def targets_water(cx, cz, R, lev, n=150):
    ax = np.arange(h.shape[0])
    ys, xs = np.nonzero(wm[int(cz - R):int(cz + R), int(cx - R):int(cx + R)])
    xs = xs + int(cx - R); ys = ys + int(cz - R)
    sel = rng.choice(len(xs), min(n, len(xs)), replace=False)
    return [(float(xs[i]), float(ys[i]), lev) for i in sel]

def ring_report(name, cx, cz, tg, rings, fog=0.0048):
    print("%s: 목표 점 %d 개" % (name, len(tg)))
    for R in rings:
        rows = []
        for k in range(36):
            th = k / 36 * 2 * math.pi
            ox, oz = cx + math.cos(th) * R, cz + math.sin(th) * R
            if not (0 <= ox < 2048 and 0 <= oz < 2048) or not wk[int(oz), int(ox)]:
                continue
            oy = C.hsample(h, ox, oz) + EYE
            f = np.mean([visible(ox, oz, oy, x, z, y) for x, z, y in tg])
            rows.append(f)
        rows = np.array(rows)
        print("  %4d m (안개 남는 대비 %.2f): 자리 %2d, 바닥이 10%% 넘게 보이는 자리 %2d, 보이는 비율 중앙 %.0f%%" % (
            R, math.exp(-(R * fog) ** 2), len(rows), (rows > 0.10).sum(), 100 * np.median(rows) if len(rows) else 0))

lev = W["levels"]
# 호수: 중심에서 재는 거리 = 물가까지 + 여유
ring_report("호수 물 면", 720, 330, targets_water(720, 330, 140, lev["lake"]), (130, 170, 220, 270))
ring_report("늪 물 면", 1545, 935, targets_water(1545, 935, 300, lev["swamp"], 200), (280, 330, 380, 430))
# 용 무덤: 갈비뼈 자리 바닥 + 1 m (뼈 아랫부분)
a = np.array([0.78, -0.62]); a /= np.linalg.norm(a)
head = np.array([496.0, 1040.0])
pts = []
for t in np.linspace(0, 41, 12):
    p = head - a * t
    pts.append((float(p[0]), float(p[1]), float(C.hsample(h, p[0], p[1])) + 1.0))
ring_report("용 뼈 줄 (바닥+1 m)", 480, 1052, pts, (150, 200, 250, 300))
