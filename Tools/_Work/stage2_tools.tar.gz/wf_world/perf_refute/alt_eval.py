# 대안 비교: 숲 자리 3곳(방향마다 최대)에서 모델 A/C/D 그림자 + 종류별 내역. 환경 변수: PERF_DROP, PERF_OVERRIDE, SHADOW_D (그림자 거리)
import sys, os, collections
sys.path.insert(0, '/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/performance')
import numpy as np
import perf_common as pc
SD = float(os.environ.get('SHADOW_D', 150))
pc.CASCADE_SPLITS = tuple(SD * r for r in (0.067, 0.2, 0.467, 1.0))
pc.SHADOW_DISTANCE = SD
sys.argv = [sys.argv[0], '0', '0,0']
import shadow_cull as SC
import shadow_scan as S
S.splits = (0.2,) + pc.CASCADE_SPLITS
S.SHADOW_DISTANCE = SD
S.yaws = np.arange(0, 360, 15.0)
spots = [(446, 574), (430, 640), (446, 638), (346, 506), (274, 434), (1106, 930), (1044, 872)]
tot = {m: [0, 0] for m in 'ACD'}
for x, z in spots:
    res = S.spot(x, z)
    line = "(%4.0f,%4.0f)" % (x, z)
    for m in 'ACD':
        k = int(np.argmax([r[m][1] for r in res]))
        line += " | %s %4d번 %.2fM" % (m, res[k][m][0], res[k][m][1] / 1e6)
    print(line)
