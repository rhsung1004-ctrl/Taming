# total_base.npz 의 자리·방향(화면 안 소품+나무+풀 최대 방향)마다 그림자 패스를 더해 한 프레임 삼각형 합. 모델 A / C / D
import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/performance')
import numpy as np, json, os
from perf_common import *
import shadow_scan as S

d = np.load(os.path.join(OUT, 'total_base.npz'))
cx, cz, best, byaw = d['cx'], d['cz'], d['best'], d['byaw']
S.yaws = None
rows = []
for x, z, b, yw in zip(cx, cz, best, byaw):
    S.yaws = np.array([yw])
    r = S.spot(float(x), float(z))[0]
    rows.append([x, z, b] + [r[m][1] for m in 'ACD'] + [r[m][0] for m in 'ACD'])
R = np.array(rows)
np.save('/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/perf_refute/frame_scan.npy', R)
forest = (R[:, 0] >= 150) & (R[:, 0] < 710) & (R[:, 1] >= 360) & (R[:, 1] < 920)
pois = json.load(open(os.path.join(DATA, 'world.json')))['pois']
fp = [p for p in pois if p['name'] == '검은 숲'][0]
inF = np.hypot(R[:, 0] - fp['p'][0], R[:, 1] - fp['p'][2]) < fp['r']
print("검은 숲 POI", fp['p'], fp['r'], "자리", inF.sum(), "/ 숲 상자 자리", forest.sum(), "/ 전체", len(R))
for j, m in enumerate('ACD'):
    sh = R[:, 3 + j]; cnt = R[:, 6 + j]; tot = R[:, 2] + sh
    print("\n[모델 %s] 그림자 삼각형 (화면 최대 방향에서)" % m)
    for lab, mask in (('전체', np.ones(len(R), bool)), ('숲 상자', forest), ('숲 POI 안', inF), ('숲 밖', ~forest)):
        print("  %-8s 그림자 50/90/99/최대 %.2f/%.2f/%.2f/%.2fM, 개수 최대 %d | 화면+그림자 50/90/99/최대 %.2f/%.2f/%.2f/%.2fM" % (
            lab, *np.percentile(sh[mask], [50, 90, 99, 100]) / 1e6, cnt[mask].max(), *np.percentile(tot[mask], [50, 90, 99, 100]) / 1e6))
    o = np.argsort(-tot)[:6]
    print("  화면+그림자 최악:")
    for i in o:
        print("   (%4.0f,%4.0f) %-24s 화면 %.2fM + 그림자 %.2fM (%d번) = %.2fM %s" % (R[i, 0], R[i, 1], nearest_poi(R[i, 0], R[i, 1]), R[i, 2]/1e6, sh[i]/1e6, cnt[i], tot[i]/1e6, '숲' if forest[i] else ''))
