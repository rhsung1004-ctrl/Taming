# 그림자 캐스터 수를 Unity 컬링에 더 가깝게: 
#  A) perf_view 그대로 (캐스케이드 구 안 + 물체 반지름 = 최대 변 /2)
#  B) A ∧ 카메라 절두체(0.3~150 m)를 달빛 반대 방향(달 쪽)으로 늘인 볼륨 (그림자가 화면 안에 떨어질 수 있는 캐스터만)
#  C) 캐스케이드 직교 상자(구를 감싼 정사각 기둥, 달 쪽으로 무한) ∧ B 의 볼륨
#  D) C + 앞 캐스케이드 구 안에 완전히 들어가는 캐스터는 다음 캐스케이드에서 뺌 (cascadeBlendCullingFactor=1)
# 물체 경계: 반지름 = 반대각선 (보수적)
import sys, os
sys.path.insert(0, '/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/performance')
import numpy as np
from perf_common import *

def euler_fwd(px, py):
    px, py = np.radians(px), np.radians(py)
    v = np.array([0, -np.sin(px), np.cos(px)])
    return np.array([v[0]*np.cos(py) + v[2]*np.sin(py), v[1], -v[0]*np.sin(py) + v[2]*np.cos(py)])

A = assets(1.0)
h = load_height()
I = load_instances(A, h)
size3 = np.array([A[n].size3 for n in I.name])
rad_maxedge = size3.max(1) * I.s * 0.5
rad_diag = np.linalg.norm(size3, axis=1) * I.s * 0.5

def run(x0, z0, yaw, moon=(38, -150), far=150.0, label=''):
    L = euler_fwd(*moon)
    y0 = float(height_at(h, x0, z0)) + CAM_HEIGHT
    dx, dz, dy = I.x - x0, I.z - z0, I.cy - y0
    d = np.sqrt(dx*dx + dz*dz + dy*dy)
    lvl = np.where(d < I.dend[:, 0], 0, np.where(d < I.dend[:, 1], 1, np.where(d < I.dend[:, 2], 2, 3)))
    t = np.where(lvl < 3, I.tris[np.arange(len(d)), np.minimum(lvl, 2)], 0)
    pitch = np.radians(-10)
    fwd = np.array([np.sin(np.radians(yaw))*np.cos(pitch), np.sin(pitch), np.cos(np.radians(yaw))*np.cos(pitch)])
    right = np.array([np.cos(np.radians(yaw)), 0, -np.sin(np.radians(yaw))])
    up = np.cross(right, fwd)
    th = np.tan(np.radians(FOV_V/2)); tw = th*ASPECT
    cam = np.array([x0, y0, z0])
    P = np.stack([I.x, I.cy, I.z], 1)
    # 카메라 절두체 평면 (안쪽 법선 n, n·p + o >= 0)
    planes = []
    for sx in (-1, 1):   # 좌우: 방향 (fwd + sx*tw*right) 를 담는 평면
        n = np.cross(up, fwd + sx*tw*right) * (-sx)
        n /= np.linalg.norm(n); planes.append(n)
    for sy in (-1, 1):
        n = np.cross(fwd + sy*th*up, right) * (-sy)
        n /= np.linalg.norm(n); planes.append(n)
    # 부호 확인: fwd 가 안쪽이어야
    planes = [n if n @ fwd > 0 else -n for n in planes]
    Pl = [(n, -n @ cam) for n in planes]
    Pl.append((fwd, -(fwd @ cam) - 0.3))
    Pl.append((-fwd, (fwd @ cam) + far))
    def hull_test(rad):
        lo = np.zeros(len(P)); hi = np.full(len(P), np.inf); ok = np.ones(len(P), bool)
        for n, o in Pl:
            a = P @ n + o + rad
            b = L @ n
            if abs(b) < 1e-9:
                ok &= a >= 0
            elif b > 0:
                lo = np.maximum(lo, -a / b)
            else:
                hi = np.minimum(hi, -a / b)
        return ok & (lo <= hi)
    lr = np.cross([0, 1, 0], L); lr /= np.linalg.norm(lr); lu = np.cross(L, lr)
    splits = (0.2,) + CASCADE_SPLITS
    res = {}
    spheres = []
    for k in range(4):
        n_, f_ = splits[k], splits[k+1]
        corners = np.array([cam + fwd*dd + right*sx*tw*dd + up*sy*th*dd for dd in (n_, f_) for sx in (-1, 1) for sy in (-1, 1)])
        c = corners.mean(0); R = np.max(np.linalg.norm(corners - c, axis=1))
        spheres.append((c, R))
    hullD = hull_test(rad_diag)
    base = I.shadow & (t > 0)
    out = {}
    for mode in 'ABCD':
        cnt = []; tri = []; trees = []
        for k in range(4):
            c, R = spheres[k]
            if mode == 'A':
                m = (np.linalg.norm(P - c, axis=1) < R + rad_maxedge)
            else:
                rr = rad_diag
                if mode == 'B':
                    m = (np.linalg.norm(P - c, axis=1) < R + rr) & hullD
                else:
                    q = P - c
                    m = (np.abs(q @ lr) <= R + rr) & (np.abs(q @ lu) <= R + rr) & (q @ L <= R + rr) & hullD
                    if mode == 'D' and k > 0:
                        cp, Rp = spheres[k-1]
                        m &= ~(np.linalg.norm(P - cp, axis=1) + rr <= Rp)
            m &= base
            cnt.append(int(m.sum())); tri.append(float(t[m].sum())); trees.append(int((m & I.tree).sum()))
        out[mode] = (cnt, tri, trees)
    print("자리 (%.0f,%.0f) 방향 %.0f, 달 %s %s" % (x0, z0, yaw, moon, label))
    names = {'A': 'perf_view 구 모델', 'B': '구 ∧ 절두체-달쪽 볼륨', 'C': '직교 상자 ∧ 절두체-달쪽', 'D': 'C + 앞 캐스케이드 구 안 제외'}
    for mode in 'ABCD':
        cnt, tri, trees = out[mode]
        print("  %s %-24s 캐스케이드별 %s 개 (지형나무 %s) → 합 %d 번, %.2fM" % (mode, names[mode], cnt, trees, sum(cnt), sum(tri)/1e6))
    return out

if __name__ == '__main__':
    args = sys.argv[1:]
    if args:
        run(float(args[0]), float(args[1]), float(args[2]))
    else:
        for (x, z, yw) in [(446, 574, 40), (430, 640, 5)]:
            for moon in [(38, -150), (14, -160), (24, -140), (55, -120)]:
                run(x, z, yw, moon)
