# 자리마다 방향 12개(30도) 중 그림자 최대: 모델 A (perf_view 구) vs C (직교 상자 ∧ 절두체-달쪽) vs D (C + 앞 캐스케이드 구 제외)
import sys
sys.path.insert(0, '/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/performance')
import numpy as np
from perf_common import *
from shadow_cull import euler_fwd, A, h, I, size3, rad_maxedge, rad_diag

step = float(sys.argv[1]) if len(sys.argv) > 1 else 32
yaws = np.arange(0, 360, 30.0)
spots = [tuple(map(float, s.split(','))) for s in sys.argv[2:]] if len(sys.argv) > 2 else None
L = euler_fwd(38, -150)
lr = np.cross([0, 1, 0], L); lr /= np.linalg.norm(lr); lu = np.cross(L, lr)
th = np.tan(np.radians(FOV_V/2)); tw = th*ASPECT
splits = (0.2,) + CASCADE_SPLITS
Pall = np.stack([I.x, I.cy, I.z], 1)

def spot(x0, z0):
    y0 = float(height_at(h, x0, z0)) + CAM_HEIGHT
    sel = np.nonzero((np.abs(I.x - x0) < 420) & (np.abs(I.z - z0) < 420) & I.shadow)[0]
    P = Pall[sel]; rD = rad_diag[sel]; rM = rad_maxedge[sel]; tr = I.tree[sel]
    d = np.linalg.norm(P - [x0, y0, z0], axis=1)
    de = I.dend[sel]
    lvl = np.where(d < de[:, 0], 0, np.where(d < de[:, 1], 1, np.where(d < de[:, 2], 2, 3)))
    t = np.where(lvl < 3, I.tris[sel][np.arange(len(sel)), np.minimum(lvl, 2)], 0)
    live = t > 0
    cam = np.array([x0, y0, z0])
    res = []
    for yaw in yaws:
        pitch = np.radians(-10)
        fwd = np.array([np.sin(np.radians(yaw))*np.cos(pitch), np.sin(pitch), np.cos(np.radians(yaw))*np.cos(pitch)])
        right = np.array([np.cos(np.radians(yaw)), 0, -np.sin(np.radians(yaw))])
        up = np.cross(right, fwd)
        planes = []
        for sx in (-1, 1):
            n = np.cross(up, fwd + sx*tw*right); n /= np.linalg.norm(n); planes.append(n if n @ fwd > 0 else -n)
        for sy in (-1, 1):
            n = np.cross(fwd + sy*th*up, right); n /= np.linalg.norm(n); planes.append(n if n @ fwd > 0 else -n)
        Pl = [(n, -n @ cam) for n in planes] + [(fwd, -(fwd @ cam) - 0.3), (-fwd, (fwd @ cam) + SHADOW_DISTANCE)]
        lo = np.zeros(len(P)); hi = np.full(len(P), np.inf); ok = np.ones(len(P), bool)
        for n, o in Pl:
            a = P @ n + o + rD; b = L @ n
            if abs(b) < 1e-9: ok &= a >= 0
            elif b > 0: lo = np.maximum(lo, -a / b)
            else: hi = np.minimum(hi, -a / b)
        hull = ok & (lo <= hi)
        sph = []
        for k in range(4):
            n_, f_ = splits[k], splits[k+1]
            corners = np.array([cam + fwd*dd + right*sx*tw*dd + up*sy*th*dd for dd in (n_, f_) for sx in (-1, 1) for sy in (-1, 1)])
            c = corners.mean(0); R = np.max(np.linalg.norm(corners - c, axis=1)); sph.append((c, R))
        r = {}
        for mode in 'ACD':
            cnt = 0; tri = 0.0; ctree = 0
            for k in range(4):
                c, R = sph[k]
                if mode == 'A':
                    m = np.linalg.norm(P - c, axis=1) < R + rM
                else:
                    q = P - c
                    m = (np.abs(q @ lr) <= R + rD) & (np.abs(q @ lu) <= R + rD) & (q @ L <= R + rD) & hull
                    if mode == 'D' and k > 0:
                        cp, Rp = sph[k-1]
                        m &= ~(np.linalg.norm(P - cp, axis=1) + rD <= Rp)
                m &= live
                cnt += m.sum(); tri += t[m].sum(); ctree += (m & tr).sum()
            r[mode] = (cnt, tri, ctree)
        res.append(r)
    return res

if spots:
    for x, z in spots:
        res = spot(x, z)
        line = "(%4.0f,%4.0f) %-22s" % (x, z, nearest_poi(x, z))
        for mode in 'ACD':
            k = int(np.argmax([r[mode][1] for r in res]))
            line += " | %s 최대 %4d번 %.2fM (나무 %4d) yaw %3.0f" % (mode, res[k][mode][0], res[k][mode][1]/1e6, res[k][mode][2], yaws[k])
        print(line)
else:
    X, Z, n = walk_grid(step)
    rows = []
    for x, z in zip(X, Z):
        res = spot(float(x), float(z))
        rows.append([x, z] + [max(r[m][1] for r in res) for m in 'ACD'] + [max(r[m][0] for r in res) for m in 'ACD'])
    rows = np.array(rows)
    np.save('/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/perf_refute/shadow_scan_%d.npy' % step, rows)
    for j, m in enumerate('ACD'):
        o = np.argsort(-rows[:, 2 + j])[:8]
        print("[모델 %s] 그림자 삼각형 최악 (자리마다 방향 최대). 99%% %.2fM, 90%% %.2fM, 50%% %.2fM" % (m, *np.percentile(rows[:, 2+j], [99, 90, 50]) / 1e6))
        for i in o:
            print("   (%4.0f,%4.0f) %-24s %.2fM %4d번" % (rows[i, 0], rows[i, 1], nearest_poi(rows[i, 0], rows[i, 1]), rows[i, 2+j]/1e6, rows[i, 5+j]))
