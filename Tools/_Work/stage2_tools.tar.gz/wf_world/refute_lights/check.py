#!/usr/bin/env python3
# 반박 검사: '들판 27 % 광원 0 개' 를 실제 LightCuller 규칙(끄는 거리 = range x 12, 30~200 m)과
# 멀리서 보이는 발광 메쉬(LOD 사라지는 거리, 안개, 지형 가림)로 다시 센다. 읽기 전용.
import sys, os, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C

STEP = 8
field = np.load(C.OUT + "/field.npy")
dl = np.load(C.OUT + "/d_light.npy")
n = field.shape[0]
gx = np.arange(n) * STEP + STEP / 2
GX, GZ = np.meshgrid(gx, gx)
FA = field.sum()
man = C.manifest()
objs = C.objects()["objects"]
h = C.height()
W = C.world()
fogd = W["fog"]["density"]

# ── 광원 목록 (Unity Light.range 는 transform 크기에 영향 받지 않는다 → META range 그대로)
L = []
for o in objs:
    m = man.get(o["a"], {}).get("meta", {})
    li = m.get("light")
    if li:
        off = li.get("offset", [0, 0, 0])
        L.append((o["p"][0] + off[0] * o["s"], o["p"][1] + off[2] * o["s"], o["p"][2] + off[1] * o["s"], tuple(li["color"]), float(li["intensity"]), float(li["range"]), o["a"]))
for l in C.objects()["lights"]:
    L.append((l["p"][0], l["p"][1], l["p"][2], tuple(l["c"]), float(l["i"]), float(l["r"]), "free"))
P = np.array([[l[0], l[2]] for l in L])
R = np.array([l[5] for l in L])
cullR = np.clip(R * 12, 30, 200)
fullR = cullR * 0.7     # fadeFraction 0.3: 70 % 안쪽은 세기 100 %

q = np.stack([GX.ravel(), GZ.ravel()], -1)
on = np.zeros(len(q), int)
onfull = np.zeros(len(q), int)
for i in range(0, len(q), 4096):
    d = np.sqrt(((q[i:i + 4096, None, :] - P[None, :, :]) ** 2).sum(-1))
    on[i:i + 4096] = (d <= cullR[None, :]).sum(1)
    onfull[i:i + 4096] = (d <= fullR[None, :]).sum(1)
on = on.reshape(n, n)
onfull = onfull.reshape(n, n)
print("[A] 실제 LightCuller 규칙 (끄는 거리 = range x 12, 30~200 m)")
print("  보고서 모형 (80 m 안 광원 0 개): %.1f %%" % (100 * (field & (dl > 80)).sum() / FA))
print("  실제로 켜진 광원 0 개인 들판: %.1f %%  (세기 100 %% 로 켜진 것 0 개: %.1f %%)" % (100 * (field & (on == 0)).sum() / FA, 100 * (field & (onfull == 0)).sum() / FA))
print("  켜진 광원 수 분위 (들판): 50%% %d, 75%% %d, 90%% %d, 최대 %d; 48 초과 %.2f %%" % (
    np.percentile(on[field], 50), np.percentile(on[field], 75), np.percentile(on[field], 90), on[field].max(), 100 * (field & (on > 48)).sum() / FA))
# 지목된 가장 어두운 두 곳
for (x, z) in ((838, 1514), (634, 856), (660, 852)):
    d = np.hypot(P[:, 0] - x, P[:, 1] - z)
    k = np.where(d <= cullR)[0]
    print("  (%d,%d): 켜진 광원 %d 개 %s" % (x, z, len(k), sorted(((round(d[j]), L[j][6], round(cullR[j])) for j in k))[:6]))

# ── [B] 멀리서 보이는 발광 메쉬 (Glow_* HDR 발광 + Bloom). LOD 사라지는 거리 = size / (1.04 x cull) (lodBias 1)
#        광원 품은 소품은 최소 50 m. 안개 남는 빛 exp(-(density d)^2). 지형 가림 검사 (눈높이 1.7 m)
def lod_dist(a, s):
    v = man.get(a)
    if not v:
        return 0
    size = max(v["size"]) * s
    cull = float(v["meta"].get("cull") or 0.01)
    mind = 50 if v["meta"].get("light") else 30
    cull = min(cull, size / (1.04 * mind))
    return size / (1.04 * cull)

GLOWMESH = {"lantern", "grave_tomb", "statue_reaper", "altar", "crypt", "cathedral_ruin", "gate_great", "tree_giant", "dragon_skull"}
B = []
for o in objs:
    if o["a"] in GLOWMESH:
        v = man[o["a"]]
        li = v["meta"]["light"]
        off = li.get("offset", [0, 0, 0])
        B.append((o["p"][0] + off[0] * o["s"], o["p"][1] + off[2] * o["s"], o["p"][2] + off[1] * o["s"], lod_dist(o["a"], o["s"]), o["a"]))
B = np.array([(b[0], b[1], b[2], b[3]) for b in B])
print("\n[B] 멀리서 보이는 발광 메쉬 %d 개 (등불 LOD 사라지는 거리 %.0f m)" % (len(B), lod_dist("lantern", 1.0)))


def los(x0, z0, y0, x1, z1, y1, ns=48):
    t = np.linspace(0.05, 0.95, ns)
    xs, zs = x0 + (x1 - x0) * t, z0 + (z1 - z0) * t
    ys = y0 + (y1 - y0) * t
    return np.all(C.hsample(h, xs, zs) < ys - 0.3)


for FOGMIN in (0.5, 0.3):
    dmax_fog = math.sqrt(-math.log(FOGMIN)) / fogd
    seen = np.zeros((n, n), bool)
    seen_nolos = np.zeros((n, n), bool)
    idx = np.argwhere(field)
    for (i, j) in idx:
        x, z = gx[j], gx[i]
        d = np.hypot(B[:, 0] - x, B[:, 2] - z)
        ok = np.where((d <= np.minimum(B[:, 3], dmax_fog)))[0]
        if len(ok):
            seen_nolos[i, j] = True
        ey = C.hsample(h, x, z) + 1.7
        for k in ok[np.argsort(d[ok])][:12]:
            if los(x, z, ey, B[k, 0], B[k, 2], B[k, 1]):
                seen[i, j] = True
                break
    print("  안개 뒤 남는 빛 >= %.0f %% (<= %.0f m): 발광 메쉬가 하나라도 보이는 들판 %.1f %% (지형 가림 무시 %.1f %%)" % (
        100 * FOGMIN, dmax_fog, 100 * seen.sum() / FA, 100 * seen_nolos.sum() / FA))
    if FOGMIN == 0.5:
        seen50 = seen
dark80 = field & (dl > 80)
print("  보고서의 '광원 0 개' 구역 중 발광 메쉬가 보이는 곳 (안개 50 %%): %.1f %%" % (100 * (dark80 & seen50).sum() / dark80.sum()))

# ── [C] 어두운 들판이 어디에 있나: bounds 가장자리(산기슭)까지 거리
(bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]
edge = np.minimum.reduce([GX - bx0, bx1 - GX, GZ - bz0, bz1 - GZ])
print("\n[C] 보고서 '광원 0 개' 들판 (%.2f km²) 이 bounds 가장자리에서 얼마나 떨어져 있나" % (dark80.sum() * 64 / 1e6))
for th in (100, 150, 200):
    print("  가장자리 %d m 안: %.0f %%" % (th, 100 * (dark80 & (edge < th)).sum() / dark80.sum()))
dark120 = field & (dl > 120)
print("  120 m 넘는 곳 중 가장자리 150 m 안: %.0f %%" % (100 * (dark120 & (edge < 150)).sum() / dark120.sum()))
# 가장자리 200 m 를 뺀 안쪽 들판
inner = field & (edge >= 200)
print("  가장자리 200 m 밖(안쪽) 들판에서 80 m 안 광원 0 개: %.1f %%, 120 m: %.1f %%" % (100 * (inner & (dl > 80)).sum() / inner.sum(), 100 * (inner & (dl > 120)).sum() / inner.sum()))

# ── [D] 색: 개수 / 세기 합 / 빛 웅덩이 넓이(pi r^2) / 세기 x 넓이
def col_class(c):
    r, g, b = c
    if g > 0.9 and b < 0.5:
        return "독(초록)"
    if g > 0.7 and b > 0.7:
        return "청록"
    return "보라"


print("\n[D] 색별 광원")
agg = collections.defaultdict(lambda: [0, 0.0, 0.0, 0.0])
for l in L:
    a = agg[col_class(l[3])]
    a[0] += 1
    a[1] += l[4]
    a[2] += math.pi * l[5] ** 2
    a[3] += l[4] * math.pi * l[5] ** 2
tot = [sum(v[k] for v in agg.values()) for k in range(4)]
for k, v in agg.items():
    print("  %-6s 개수 %4d (%4.1f %%)  세기 합 %6.0f (%4.1f %%)  웅덩이 넓이 %7.0f m² (%4.1f %%)  세기x넓이 %4.1f %%" % (
        k, v[0], 100 * v[0] / tot[0], v[1], 100 * v[1] / tot[1], v[2], 100 * v[2] / tot[2], 100 * v[3] / tot[3]))
cnt = collections.Counter(o["a"] for o in objs)
print("  광원 없는 청록 발광 메쉬 (Glow_Spirit): flower_lily %d 개 (꽃술), + 주인공을 따라다니는 '창백한 청록 반딧불' 입자 (어디서나)" % cnt["flower_lily"])
print("  배치 fireflies 효과 (청록) %d 개" % sum(1 for f in C.objects()["fx"] if f["type"] == "fireflies"))

# ── [E] 제안 검토: 길가 등불을 near < 140 m 로 줄이면
import importlib
sys.path.insert(0, C.WG)
import worldgen as WGM
pois = [(pp[0], pp[1]) for (_, _, pp, _) in WGM.POIS if pp]
lan = [o for o in objs if o["a"] == "lantern"]
from terrain import catmull
RP = np.concatenate([catmull(p, 2.0) for p, hw in WGM.ROADS])
rm = []
for o in lan:
    x, z = o["p"][0], o["p"][2]
    dr = np.min(np.hypot(RP[:, 0] - x, RP[:, 1] - z))
    near = min((x - px) ** 2 + (z - pz) ** 2 for px, pz in pois)
    if dr < 8 and 140 ** 2 <= near:
        rm.append((x, z))
print("\n[E] 길가 등불 near<140 m 제안: 길 8 m 안이면서 장소에서 140 m 넘는 등불 %d 개가 빠진다" % len(rm))
keep = [l for l in L if not (l[6] == "lantern" and any(abs(l[0] - x) < 1.5 and abs(l[2] - z) < 1.5 for x, z in rm))]
P2 = np.array([[l[0], l[2]] for l in keep])
d2 = C.dist_to_points(P2[:, 0], P2[:, 1], q).reshape(n, n)
print("  그러면 80 m 안 광원 0 개 들판 %.1f %% → %.1f %%" % (100 * dark80.sum() / FA, 100 * (field & (d2 > 80)).sum() / FA))
# 길 위 걷는 사람 기준: 길 점에서 가장 가까운 등불·발광 메쉬까지
RPs = RP[::10]
lanP = np.array([[o["p"][0], o["p"][2]] for o in lan])
dd = C.dist_to_points(lanP[:, 0], lanP[:, 1], RPs)
lanP2 = np.array([[o["p"][0], o["p"][2]] for o in lan if not any(abs(o["p"][0] - x) < 1.5 and abs(o["p"][2] - z) < 1.5 for x, z in rm)])
dd2 = C.dist_to_points(lanP2[:, 0], lanP2[:, 1], RPs)
print("  길 위에서 등불까지 > 150 m 인 길 비율: %.0f %% → %.0f %%" % (100 * np.mean(dd > 150), 100 * np.mean(dd2 > 150)))
