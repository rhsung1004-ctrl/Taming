#!/usr/bin/env python3
# 제안 비교: 들판의 기존 무덤 무리·폐허 무더기에 등불을 하나씩 (장소 밖), 마을·망루 보강 → 80 m 안 광원 0 개 들판이 얼마나 줄어드나
import sys, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C

STEP = 8
field = np.load(C.OUT + "/field.npy")
dl = np.load(C.OUT + "/d_light.npy")
n = field.shape[0]
gx = np.arange(n) * STEP + STEP / 2
GX, GZ = np.meshgrid(gx, gx)
q = np.stack([GX.ravel(), GZ.ravel()], -1)
FA = field.sum()
W = C.world()
(bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]
edge = np.minimum.reduce([GX - bx0, bx1 - GX, GZ - bz0, bz1 - GZ])
print("들판 중 bounds 가장자리 200 m 띠의 비율: %.0f %%" % (100 * (field & (edge < 200)).sum() / FA))
pois = C.poi_list()
objs = C.objects()["objects"]
L = C.all_lights()
LP = np.array([[l[0], l[2]] for l in L])


def in_poi(x, z, pad=15):
    return any(math.hypot(x - px, z - pz) <= r + pad for _, _, px, pz, r in pois)


GR = {"grave_slab_a", "grave_slab_b", "grave_slab_c", "grave_cross", "grave_sunken"}
RU = {"wall_ruin_a", "wall_ruin_b", "pillar_a", "pillar_b", "arch_ruin"}


def clusters(names, link=14, minn=2):
    pts = [(o["p"][0], o["p"][2]) for o in objs if o["a"] in names and not in_poi(o["p"][0], o["p"][2], 40)]
    pts = np.array(pts)
    lab = -np.ones(len(pts), int)
    k = 0
    for i in range(len(pts)):
        if lab[i] >= 0:
            continue
        st = [i]
        lab[i] = k
        while st:
            a = st.pop()
            d = np.hypot(pts[:, 0] - pts[a, 0], pts[:, 1] - pts[a, 1])
            for b in np.where((d < link) & (lab < 0))[0]:
                lab[b] = k
                st.append(b)
        k += 1
    out = []
    for c in range(k):
        m = pts[lab == c]
        if len(m) >= minn:
            out.append(m.mean(0))
    return np.array(out)


gc = clusters(GR)
rc = clusters(RU)
print("들판 무덤 무리 %d 개, 폐허 무더기 %d 개 (장소 반지름+40 m 밖)" % (len(gc), len(rc)))
for nm, cc in (("무덤 무리", gc), ("폐허 무더기", rc)):
    d = C.dist_to_points(LP[:, 0], LP[:, 1], cc)
    print("  %s 가운데에서 가장 가까운 광원 > 15 m (불 없는 무리): %d / %d, 중앙값 %.0f m" % (nm, (d > 15).sum(), len(cc), np.median(d)))


def dark_after(extra):
    P2 = np.concatenate([LP, np.array(extra).reshape(-1, 2)]) if len(extra) else LP
    d2 = C.dist_to_points(P2[:, 0], P2[:, 1], q).reshape(n, n)
    return 100 * (field & (d2 > 80)).sum() / FA, 100 * (field & (d2 > 120)).sum() / FA, len(extra)


base = dark_after([])
print("\n지금: 80 m 넘는 들판 %.1f %%, 120 m 넘는 %.1f %%" % base[:2])
unl_g = [c for c, d in zip(gc, C.dist_to_points(LP[:, 0], LP[:, 1], gc)) if d > 15]
unl_r = [c for c, d in zip(rc, C.dist_to_points(LP[:, 0], LP[:, 1], rc)) if d > 15]
r = dark_after(unl_g + unl_r)
print("불 없는 무덤 무리·폐허 무더기에 등불 하나씩 (+%d 개): 80 m %.1f %%, 120 m %.1f %%" % (r[2], r[0], r[1]))

# 어두운 구역에 best-candidate 로 등불 무리 N 개 더 (기존 광원 거리 최대화, 들판 안)
def best_candidate(k, base_pts):
    pts = list(base_pts)
    add = []
    fq = q[field.ravel()]
    for _ in range(k):
        P2 = np.array(pts)
        d = C.dist_to_points(P2[:, 0], P2[:, 1], fq)
        i = np.argmax(np.where(np.minimum.reduce([fq[:, 0] - bx0, bx1 - fq[:, 0], fq[:, 1] - bz0, bz1 - fq[:, 1]]) > 60, d, 0))
        add.append(fq[i])
        pts.append(fq[i])
    return add


for k in (10, 20):
    add = best_candidate(k, list(LP) + unl_g + unl_r)
    r = dark_after(unl_g + unl_r + add)
    print("  + 어두운 자리 best-candidate 무더기 %d 개 더 (총 +%d): 80 m %.1f %%, 120 m %.1f %%" % (k, r[2], r[0], r[1]))
