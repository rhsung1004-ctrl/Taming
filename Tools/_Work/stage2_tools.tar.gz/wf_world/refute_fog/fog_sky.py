# 반박 검사: Unity 실제 설정(far clip = max(2000, size*1.42), Necro/Sky 하늘 그라데이션)에서
#   (1) 산 능선이 안개색 윤곽으로 하늘과 구별되는가
#   (2) 큰 표지 꼭대기가 하늘을 배경으로 서는가, 지형을 배경으로 서는가
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C

h = C.height(); W = C.world(); wk = C.walkable()
RHO = float(sys.argv[1]) if len(sys.argv) > 1 else W["fog"]["density"]
FAR = max(2000.0, W["size"] * 1.42)
EYE = 2.5   # 궤도 카메라: pivot 1.45 m + 5 m * sin 12°

def lin(c):
    c = np.asarray(c, float)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)
def lum(c):
    return float(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2])
FOG = lin(W["fog"]["color"]); TOP = lin([0.02, 0.02, 0.07])
LF, LT = lum(FOG), lum(TOP)
def sky_lum(e_deg):           # Necro/Sky: lerp(H, T, pow(sat(h), 0.55)), h = sin(고도)
    hh = max(math.sin(math.radians(e_deg)), 0.0)
    t = hh ** 0.55
    return LF * (1 - t) + LT * t
def fogf(d):
    return math.exp(-(d * RHO) ** 2)

print("density %.4f  far clip %.0f m  안개색 휘도(선형) %.4f, 하늘 꼭대기 %.4f" % (RHO, FAR, LF, LT))
print("하늘 휘도 / 안개색: " + ", ".join("%g°:%.2f" % (e, sky_lum(e) / LF) for e in (0.5, 1, 2, 4, 6, 8, 10, 15)))

def ridge(ox, oz, oy, az, dmin=0.0, dmax=3000.0, step=4.0):
    best = (-1e9, 0.0, 0.0)
    th = math.radians(az)
    ds = np.arange(max(dmin, 8.0), dmax, step)
    xs = ox + np.cos(th) * ds; zs = oz + np.sin(th) * ds
    m = (xs >= 0) & (xs < 2048) & (zs >= 0) & (zs < 2048) & (ds <= FAR)
    ds, xs, zs = ds[m], xs[m], zs[m]
    if len(ds) == 0:
        return None
    hs = C.hsample(h, xs, zs)
    a = (hs - oy) / ds
    i = int(np.argmax(a))
    return math.degrees(math.atan(a[i])), ds[i], hs[i]

print("\n(1) 산 능선 (방위 1° 간격, 능선 = 고도각 최대 지점). 능선 화소 = 안개색 (far clip 안이라 그려짐)")
print("    대비 = (능선 - 바로 위 하늘)/하늘, 휘도 선형. 30% 이상이면 뚜렷, 10% 미만이면 약함")
for nm, (ox, oz) in (("spawn", (1000, 492)), ("graveyard", (1000, 880)), ("field_mid", (1000, 1150)),
                     ("cathedral", (1010, 1478)), ("swamp_w", (1330, 935)), ("village", (1390, 430))):
    oy = C.hsample(h, ox, oz) + EYE
    con, els, dists = [], [], []
    for az in range(0, 360):
        r = ridge(ox, oz, oy, az)
        if r is None: continue
        e, d, _ = r
        f = fogf(d)
        # 능선 지형색은 어둡다고 보고(안개색의 0.5배) 안개와 섞는다
        Lr = LF * (1 - f) + 0.5 * LF * f
        Ls = sky_lum(e + 0.3)
        con.append((Lr - Ls) / Ls); els.append(e); dists.append(d)
    con = np.array(con); els = np.array(els); dists = np.array(dists)
    print("  %-10s 능선 고도각 중앙 %4.1f° (%.1f~%.1f), 거리 중앙 %4.0f m, far 밖 0개 | 대비 중앙 %+.0f%%, 10%% 미만 %d/360, 30%% 이상 %d/360" % (
        nm, np.median(els), els.min(), els.max(), np.median(dists), 100 * np.median(con), int((con < 0.10).sum()), int((con >= 0.30).sum())))

print("\n(2) 표지 꼭대기 배경: 링마다 36방향(걸을 수 있는 자리), 지형 위로 2 m 이상 보이는 자리 중")
print("    하늘 배경 = 표지 꼭대기 고도각 > 표지 뒤 지형 능선 고도각. 대비는 표지(그늘면, 안개색의 0.4배)를 안개와 섞어 배경과 비교")
LM = {"cathedral": ("cathedral_ruin",), "tower": ("watchtower_ruin",), "tree": ("tree_giant",), "gate": ("gate_great",),
      "graveyard": ("crypt",)}
props = C.all_props()
for pid, name, px, pz, r in C.poi_list():
    if pid not in LM: continue
    cand = [(a, x, z, s) for a, x, z, s in props if a in LM[pid] and (x - px) ** 2 + (z - pz) ** 2 <= (r + 10) ** 2]
    a, tx, tz, s = max(cand, key=lambda t: C.prop_height(t[0], t[3]))
    ht = C.prop_height(a, s); base = C.hsample(h, tx, tz); top = base + ht
    line = []
    for R in (150, 300, 450, 600, 800):
        nvis = nsky = 0; cons = []
        for k in range(36):
            th = k / 36 * 2 * math.pi
            ox, oz = tx + math.cos(th) * R, tz + math.sin(th) * R
            if not (0 <= ox < 2048 and 0 <= oz < 2048) or not wk[int(oz), int(ox)]: continue
            oy = C.hsample(h, ox, oz) + EYE
            d = math.hypot(tx - ox, tz - oz)
            n = max(int(d / 3), 2); t = np.linspace(0.02, 0.98, n)
            hs = C.hsample(h, ox + (tx - ox) * t, oz + (tz - oz) * t)
            y_block = oy + np.max((hs - oy) / (t * d)) * d
            if top - max(y_block, base) < 2.0: continue
            nvis += 1
            e_top = math.degrees(math.atan2(top - oy, d))
            az = math.degrees(math.atan2(tz - oz, tx - ox))
            rb = ridge(ox, oz, oy, az, dmin=d + 15)
            f = fogf(d)
            Lobj = LF * (1 - f) + 0.4 * LF * f
            if rb is None or rb[0] < e_top - 0.2:
                nsky += 1
                Lb = sky_lum(e_top - 0.2)
            else:
                fb = fogf(rb[1]); Lb = LF * (1 - fb) + 0.5 * LF * fb
            cons.append(abs(Lobj - Lb) / Lb)
        line.append("%4dm 보임 %2d 하늘배경 %2d 대비중앙 %3.0f%%" % (R, nvis, nsky, 100 * np.median(cons) if cons else 0))
    print("  %-9s %-15s 키 %4.1f m | " % (pid, a, ht) + " | ".join(line))

# 시작점에서 대성당
ox, oz = 1000, 492; oy = C.hsample(h, ox, oz) + EYE
cand = [(a, x, z, s) for a, x, z, s in props if a == "cathedral_ruin"]
a, tx, tz, s = cand[0]; top = C.hsample(h, tx, tz) + C.prop_height(a, s); d = math.hypot(tx - ox, tz - oz)
e_top = math.degrees(math.atan2(top - oy, d)); az = math.degrees(math.atan2(tz - oz, tx - ox))
rb = ridge(ox, oz, oy, az, dmin=d + 15)
print("\n시작점 → 대성당: 거리 %.0f m, 꼭대기 고도각 %.2f°, 뒤 능선 %.2f° (%.0f m) → %s" % (
    d, e_top, rb[0], rb[1], "하늘 배경" if rb[0] < e_top else "산 배경 (안개색끼리 겹침)"))
