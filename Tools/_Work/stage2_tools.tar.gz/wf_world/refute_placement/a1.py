# 독립 검산: 산기슭 rock_a/rock_c 뜸, 붙어 있는지(일부 묻힘), 걷는 땅과의 거리·높이
import sys, os, math, csv
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement")
import numpy as np
import common as C
H = C.load_height()
gz, gx = np.gradient(H)
SL = np.hypot(gx, gz)
man = C.load_manifest()
T = C.load_trees()
P, I = T["prototypes"], T["instances"]
walk = np.load("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement/_walk_component.npy")
print("walk comp", walk.shape, walk.dtype, walk.sum())
cols = {a: C.mesh_columns(a) for a in ("rock_a", "rock_c")}
def gaps(i):
    pi, x, z, yaw, s = I[i]
    a = P[pi]
    c = cols[a]
    sink = man[a]["meta"]["sink"]
    y = C.hsample(H, x, z) - sink * s
    R = C.yaw_mat(yaw)
    w = C.transform(c["low"], (x, y, z), R, s)
    g = w[:, 1] - C.hsample(H, w[:, 0], w[:, 2])     # 모든 칸의 바닥 (접촉 칸만이 아니라)
    m = c["ymin"] * s <= 0.10
    return a, x, z, s, g, m
for i in (3712, 3769, 3853, 3539, 4375, 3844):
    a, x, z, s, g, m = gaps(i)
    print("#%d %s (%.0f,%.0f) s %.2f slope %.2f  접촉칸 최대뜸 %.2f  모든칸 최대뜸 %.2f  가장 묻힘 %.2f  뜬 접촉칸 %.0f%%" % (
        i, a, x, z, s, C.hsample(SL, x, z), g[m].max(), g.max(), -g.min(), (g[m] > 0.25).mean() * 100))
