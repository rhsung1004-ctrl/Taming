# 산기슭 rock_a/rock_c: 걷는 땅(출발점과 이어진 영역, 기울기 ≤0.58)과의 거리·높이, 뜸 크기별 분포
import sys, math, csv
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement")
import numpy as np
import common as C
H = C.load_height()
gz, gx = np.gradient(H)
SL = np.hypot(gx, gz)
walk = np.load("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement/_walk_component.npy")
comfy = walk & (SL <= 0.58)

def near(xi, zi, R=80):
    z0, z1, x0, x1 = max(zi - R, 0), min(zi + R + 1, comfy.shape[0]), max(xi - R, 0), min(xi + R + 1, comfy.shape[1])
    ys, xs = np.nonzero(comfy[z0:z1, x0:x1])
    if len(ys) == 0:
        return 999.0, 0.0
    dd = np.hypot(xs + x0 - xi, ys + z0 - zi)
    k = int(np.argmin(dd))
    return float(dd[k]), float(H[zi, xi] - H[ys[k] + z0, xs[k] + x0])
rows = list(csv.DictReader(open("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement/ground_trees.csv")))
def grp(i):
    i = int(i)
    return "foot" if 3467 <= i <= 4566 else "fields" if 6875 <= i <= 7944 else "other"
out = []
for r in rows:
    if r["a"] not in ("rock_a", "rock_c"):
        continue
    x, z, f = float(r["x"]), float(r["z"]), float(r["fmax"])
    xi, zi = int(round(x)), int(round(z))
    dd, dh = near(xi, zi) if float(r["fmax"]) > 0.5 else (999.0, 0.0)
    out.append((r["a"], grp(r["i"]), int(r["i"]), x, z, f, float(r["slope"]), dd, dh, float(r["bmax"])))
for a in ("rock_a", "rock_c"):
    for g in ("foot", "fields", "other"):
        L = [o for o in out if o[0] == a and o[1] == g]
        for thr in (0.5, 1.0):
            F = [o for o in L if o[5] > thr]
            near = [o for o in F if o[7] <= 30]
            near60 = [o for o in F if o[7] <= 60]
            print("%s %-6s 뜸>%.1f: %4d개 | 걷기좋은 땅 30m 안 %3d (그중 높이차 <10m %3d) | 60m 안 %3d" % (
                a, g, thr, len(F), len(near), sum(1 for o in near if o[8] < 10), len(near60)))
print("\n걷기 좋은 땅 15 m 안, 뜸>0.5 m (산기슭):")
L = sorted([o for o in out if o[1] == "foot" and o[5] > 0.5 and o[7] <= 15], key=lambda o: -o[5])
for o in L[:40]:
    print("  %s #%d (%.0f, %.0f) 뜸 %.2f 경사 %.2f 거리 %.0f m 높이차 %.1f m 가장묻힘 %.2f" % (o[0], o[2], o[3], o[4], o[5], o[6], o[7], o[8], o[9]))
print("합계", len(L))
