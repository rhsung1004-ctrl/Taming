import sys, os, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import artcommon as C
from terrain import fbm, ss
from PIL import Image
W = C.world()
names = [l["name"] for l in W["layers"]]
sp = C.splat()[..., :len(names)].astype(np.float32)
TER = os.path.join(os.path.dirname(C.DATA), "Terrain")
alb = []
for nm in names:
    im = Image.open(os.path.join(TER, "ground_%s_albedo.jpg" % nm)).convert("RGB")
    alb.append(np.asarray(im.resize((64,64))).reshape(-1,3).mean(0)/255)
alb = np.array(alb)
print("층 사이 sRGB 거리 (grass 기준):", {n: round(float(np.linalg.norm((alb[k]-alb[0])*255)),1) for k,n in enumerate(names)})
wm = C.water_mask()[:2048,:2048]
wk = C.walkable()[:2048,:2048]; sl = C.slope()[:2048,:2048]
field = wk & (sl<0.58)
ax = np.arange(2048, dtype=np.float32)
X, Z = np.meshgrid(ax, ax)
pois = C.poi_list()
m = field.copy()
for pid, nm, px, pz, r in pois:
    m &= (X-px)**2+(Z-pz)**2 > (r+20)**2
fcol = sp[m].mean(0) @ alb
def pc(s, px, pz, r):
    mm = ((X-px)**2+(Z-pz)**2 <= r*r) & ~wm
    v = s[mm].mean(0)
    return v, np.linalg.norm((v@alb - fcol)*255)
# 현재: 핵심 반경
print("\n현재, 핵심 반경 안 (장소 반지름 대신 작게)")
for pid,(px,pz),r in [("village",(1390,430),45),("cathedral",(1010,1478),40),("gate",(1010,1822),30),("tower",(640,1572),25),("graveyard",(1000,880),120)]:
    v,d = pc(sp,px,pz,r)
    print("  %-10s r%3d  grass %.0f%% dirt %.0f%% path %.0f%% moss %.0f%% rock %.0f%%  diff %.1f" % (pid, r, 100*v[0],100*v[2],100*v[5],100*v[1],100*v[4],d))
# 제안의 장소 칠을 마지막에 덧칠 (상한 추정)
def over(s, k, a):
    a = np.clip(a,0,1)[...,None].astype(np.float32)
    s = s*(1-a)
    s[...,k] += a[...,0]
    return s
n2 = fbm(X, Z, 1/35, 3, 1002)
s2 = sp.copy()
ex = ((X-1000)/(W.get("grave_rx",150)))**2  # placeholder
k = {n:i for i,n in enumerate(names)}
n3 = fbm(X, Z, 1/14, 2, 1003)
ex = ((X-1000)/(190+20))**2 + ((Z-880)/(158+20))**2
grave = ss(-ex, -1.0, -0.7)
s2 = over(s2, k["dirt"], grave*0.5*ss(n2,-0.25,0.35))
s2 = over(s2, k["moss"], grave*0.3*ss(-n2,-0.1,0.3))
vil = np.sqrt((X-1390)**2+(Z-430)**2)
s2 = over(s2, k["dirt"], ss(-vil,-95,-45)*0.6)
s2 = over(s2, k["path"], ss(-vil,-14,-8)*0.6)
cd = np.sqrt((X-1010)**2+(Z-1478)**2)
s2 = over(s2, k["path"], ss(-cd,-50,-28)*0.7)
s2 = over(s2, k["ash"], ss(-cd,-80,-50)*0.4)
gd = np.sqrt((X-1010)**2+(Z-(1822-20))**2)
s2 = over(s2, k["path"], ss(-gd,-40,-25)*0.6)
s2 = over(s2, k["rock"], ss(-gd,-40,-25)*0.3)
td = np.sqrt((X-640)**2+(Z-1572)**2)
s2 = over(s2, k["rock"], ss(-td,-30,-15)*0.5)
print("\n제안의 장소 칠을 맨 뒤에 덧칠했을 때 (상한 추정), 장소 반지름 기준 diff")
for pid, nm, px, pz, r in pois:
    if pid in ("graveyard","village","cathedral","gate","tower","crypt"):
        v0,d0 = pc(sp,px,pz,r); v1,d1 = pc(s2,px,pz,r)
        print("  %-10s r%3d  현재 %.1f → 제안 %.1f   (grass %.0f%%→%.0f%%)" % (pid, r, d0, d1, 100*v0[0], 100*v1[0]))
# W.dry 바꿨을 때 풀(detail) 쪽 부작용: 마른 풀 면적
m2 = fbm(X[::2,::2], Z[::2,::2], 1/260, 3, 1005)
for lab,(a,b) in (("현재 ss(m2,.12,.45)",(0.12,0.45)),("제안 ss(m2,-.05,.22)",(-0.05,0.22))):
    d = ss(m2,a,b)
    print("  %s  W.dry>0.5: %.1f%%  평균 %.3f  → grass_dead 에 +0.6*dry, grass_a 에 ×(1-0.45*dry)" % (lab, 100*np.mean(d>0.5), d.mean()))
