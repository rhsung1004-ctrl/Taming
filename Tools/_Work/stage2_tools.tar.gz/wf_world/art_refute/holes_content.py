import sys, math, collections
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import numpy as np
import artcommon as C
props = C.all_props()
P = np.array([(x, z) for a, x, z, s in props])
names = np.array([a for a, x, z, s in props])
sizes = np.array([s for a, x, z, s in props])
hts = np.array([C.prop_height(a, s) for a, x, z, s in props])
holes = [(476,276,158),(1660,1636,155),(716,1692,138),(700,804,128),(940,308,125),(820,1516,123),(1540,364,120),(1284,316,119),(1748,612,119),(1236,572,104),
         (796,1236,216),(1628,1572,214),(452,836,201)]
trees_mask = np.isin(names, ["dead_tree_a","dead_tree_b","dead_tree_c"])
for x, z, r in holes:
    d = np.hypot(P[:,0]-x, P[:,1]-z)
    inr = d < r
    c = collections.Counter(names[inr])
    tall = (hts >= 4.0) & inr
    # nearest tree cluster: count trees within 30 m of each tree
    print("(%d,%d) r=%d: 소품 %d개, 키 4m+ %d개 (가장 가까운 %0.f m), 고목 %d, 종류 %s" % (x, z, r, inr.sum(), tall.sum(), d[hts>=4].min(), (trees_mask&inr).sum(), dict(c.most_common(8))))
