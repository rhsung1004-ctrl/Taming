import sys, math, collections
ART = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art"
sys.path.insert(0, ART)
import numpy as np
import artcommon as C
props = C.all_props()
feat = np.array([(x, z) for a, x, z, s in props if a in C.FEATURE or a in C.GLOW or C.kind(a) == "landmark"])
TR = {"dead_tree_a", "dead_tree_b", "dead_tree_c"}
T = np.array([(x, z) for a, x, z, s in props if a in TR])
# 나무 무리: 반지름 20 m 안 나무 ≥ 6 (자기 포함)
from collections import defaultdict
cell = 20
g = defaultdict(list)
for k, (x, z) in enumerate(T):
    g[(int(x // cell), int(z // cell))].append(k)
cnt = np.zeros(len(T), int)
for k, (x, z) in enumerate(T):
    i, j = int(x // cell), int(z // cell)
    for di in (-1, 0, 1):
        for dj in (-1, 0, 1):
            for m in g.get((i + di, j + dj), ()):
                if (T[m, 0] - x) ** 2 + (T[m, 1] - z) ** 2 < 400:
                    cnt[k] += 1
stand = T[cnt >= 6]
print("고목", len(T), "개 중 무리(20 m 안 6그루 이상)에 든 것", len(stand))
field = np.load(ART + "/out/field.npy")
d_feat = np.load(ART + "/out/d_feat.npy")
STEP = 8
n = field.shape[0]
gx = np.arange(n) * STEP + STEP / 2
GX, GZ = np.meshgrid(gx, gx)
q = np.stack([GX.ravel(), GZ.ravel()], -1)
d_stand = C.dist_to_points(stand[:, 0], stand[:, 1], q).reshape(GX.shape)
d2 = np.minimum(d_feat, d_stand)
F = field.sum()
for th in (50, 80, 100, 150):
    print("  > %3d m: 원래 볼 것 %5.1f %%  | 나무 무리 포함 %5.1f %%" % (th, 100 * (field & (d_feat > th)).sum() / F, 100 * (field & (d2 > th)).sum() / F))
# 구멍 다시 찾기
D = np.where(field, d2, 0)
cand = []
r = 6
for i in range(r, n - r):
    for j in range(r, n - r):
        v = D[i, j]
        if v >= 70 and v == D[i - r:i + r + 1, j - r:j + r + 1].max():
            cand.append((v, GX[i, j], GZ[i, j]))
cand.sort(reverse=True)
holes = []
for v, x, z in cand:
    if all((x - a) ** 2 + (z - b) ** 2 > 150 ** 2 for _, a, b in holes):
        holes.append((v, x, z))
print("나무 무리 포함 빈 구역:")
for v, x, z in holes[:14]:
    print("  (%4d, %4d) 반지름 %4.0f m" % (x, z, v))
# 원래 구멍 가운데에서 나무 무리까지
for x, z in [(476,276),(1660,1636),(716,1692),(700,804),(940,308),(820,1516),(1540,364),(1284,316),(1748,612),(1236,572)]:
    i, j = int(z // STEP), int(x // STEP)
    print("  원래 구멍 (%d,%d): 볼 것 %.0f m, 나무 무리 %.0f m" % (x, z, d_feat[i, j], d_stand[i, j]))
np.save("d_stand.npy", d_stand)
