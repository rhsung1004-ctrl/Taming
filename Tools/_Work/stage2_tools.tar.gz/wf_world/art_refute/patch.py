import re
src = open("wg/worldgen.py").read()
start = src.index("    # 외딴 무덤 무리 (울타리 일부와 함께)")
end = src.index("    # 길가 등불 (갈림길과 장소 가까이)")
new = r'''    MODE = os.environ.get("FIELD_MODE", "base")
    FEAT = {"grave_slab_a", "grave_slab_b", "grave_slab_c", "grave_cross", "grave_sunken", "grave_obelisk", "coffin", "grave_tomb",
            "wall_ruin_a", "wall_ruin_b", "arch_ruin", "pillar_a", "pillar_b", "stair_ruin", "statue_angel", "statue_reaper",
            "lantern", "fence_gate", "well", "bone_pile", "candles", "cliff_a", "cliff_b", "cliff_c",
            "mushroom_glow", "mushroom_toxic", "lotus_glow", "grave_tomb"}
    def featpts():
        out = [(o["p"][0], o["p"][2]) for o in P.objects if o["a"] in FEAT or P.meta.get(o["a"], {}).get("kind") == "landmark"]
        return np.array(out, np.float64)
    W.cluster_log = []
    def grave_cluster(x, z, extra):
        yaw = rng.uniform(0, 360)
        got = 0
        for j in range(rng.integers(3, 9)):
            gx, gz = x + rng.normal(0, 4), z + rng.normal(0, 4)
            got += P.put(["grave_slab_a", "grave_slab_b", "grave_cross", "grave_sunken", "grave_slab_c"][j % 5], gx, gz, yaw=yaw + rng.normal(0, 12),
                  stamp=("dirt", 1.5))
        if rng.random() < 0.6:
            P.put("fence", x + rng.uniform(-6, 6), z + rng.uniform(-6, 6), tilt=9)
        if rng.random() < 0.3:
            P.put("statue_angel", x + rng.uniform(-5, 5), z + rng.uniform(-5, 5), yaw=yaw)
        if extra and rng.random() < 0.4:
            P.put("lantern", x + rng.uniform(-5, 5), z + rng.uniform(-5, 5))
        return got
    def ruin_pile(x, z, extra):
        yaw = rng.uniform(0, 360)
        got = 0
        for j in range(rng.integers(2, 6)):
            nm = ["wall_ruin_a", "pillar_b", "rubble", "wall_ruin_b", "pillar_a", "arch_ruin", "rubble"][int(rng.integers(0, 7))]
            got += (nm != "rubble") * P.put(nm, x + rng.normal(0, 6), z + rng.normal(0, 6), yaw=yaw + rng.choice([0, 90, 180, 270]) + rng.normal(0, 8),
                  stamp=("dirt", 1.2))
        if rng.random() < 0.35:
            P.put("lantern", x + rng.uniform(-6, 6), z + rng.uniform(-6, 6))
        if extra and rng.random() < 0.4:
            P.put("candles", x + rng.uniform(-3, 3), z + rng.uniform(-3, 3))
        return got
    if MODE in ("base", "prop"):
        ng, nr = (26, 34) if MODE == "base" else (40, 45)
        poic = [(pp[0], pp[1]) for (_, _, pp, _) in POIS if pp]
        def pick():
            if MODE == "base":
                return a(rng)
            F = featpts()
            F = np.concatenate([F, np.array(poic, np.float64)]) if len(F) else np.array(poic, np.float64)
            best, bd = None, -1
            for c in range(24):
                p = a(rng)
                if p is None:
                    continue
                d = float(np.min((F[:, 0] - p[0]) ** 2 + (F[:, 1] - p[1]) ** 2))
                if d > bd:
                    best, bd = p, d
            return best
        for k in range(ng):
            p = pick()
            if p is None:
                continue
            x, z = p
            if any((x - px) ** 2 + (z - pz) ** 2 < 220 ** 2 for (px, pz) in (GRAVE_C, VILLAGE, CATH)):
                W.cluster_log.append(("grave", float(x), float(z), -1))
                continue
            W.cluster_log.append(("grave", float(x), float(z), int(grave_cluster(x, z, MODE == "prop"))))
        for k in range(nr):
            p = pick()
            if p is None:
                continue
            x, z = p
            W.cluster_log.append(("ruin", float(x), float(z), int(ruin_pile(x, z, MODE == "prop"))))
    else:
        # 걸을 수 있는 들판에서 '볼 것' 까지 가장 먼 자리부터 채운다 (farthest-point)
        TARGET = float(os.environ.get("FIELD_TARGET", "65"))
        ST = 8
        gx_ = np.arange(0, SIZE, ST) + ST / 2
        GX, GZ = np.meshgrid(gx_, gx_)
        (bx0, bz0), (bx1, bz1) = BOUNDS
        fm = (GX > bx0 + 12) & (GX < bx1 - 12) & (GZ > bz0 + 12) & (GZ < bz1 - 12)
        fm &= W.slope[GZ.astype(int), GX.astype(int)] < 0.45
        fm &= W.mount[GZ.astype(int), GX.astype(int)] < 0.15
        rd = W.road_dist[GZ.astype(int), GX.astype(int)] > 8
        fm &= rd
        for i_ in range(fm.shape[0]):
            for j_ in range(fm.shape[1]):
                if fm[i_, j_] and P.under_water(GX[i_, j_], GZ[i_, j_], 0.3):
                    fm[i_, j_] = False
        F = featpts()
        D = np.full(GX.shape, 1e9)
        for k0 in range(0, len(F), 512):
            f = F[k0:k0 + 512]
            D = np.minimum(D, np.sqrt(((GX[..., None] - f[:, 0]) ** 2 + (GZ[..., None] - f[:, 1]) ** 2).min(-1)))
        kinds = ["grave", "ruin", "grave", "shrine", "ruin", "tree"]
        n = 0
        for it in range(200):
            Dm = np.where(fm, D, -1)
            i_, j_ = np.unravel_index(np.argmax(Dm), Dm.shape)
            if Dm[i_, j_] < TARGET:
                break
            x, z = GX[i_, j_] + rng.uniform(-3, 3), GZ[i_, j_] + rng.uniform(-3, 3)
            kd = kinds[n % len(kinds)]
            if kd == "grave":
                got = grave_cluster(x, z, True)
            elif kd == "ruin":
                got = ruin_pile(x, z, True)
            elif kd == "shrine":
                got = P.put("statue_angel", x, z) + P.put("candles", x + 1.6, z + 0.8) + P.put("candles", x - 1.4, z + 1.1)
            else:
                got = P.put("dead_tree_a", x, z, s=1.8) + P.put("skull", x + 2.5, z + 1) + P.put("bone_pile", x - 2, z - 2)
            W.cluster_log.append((kd, float(x), float(z), int(got)))
            n += 1
            # 놓지 못했어도 그 칸은 다시 고르지 않는다
            if got:
                D = np.minimum(D, np.hypot(GX - x, GZ - z))
            else:
                fm[i_, j_] = False
        log("들판 farthest-point 무리", n, "목표", TARGET)
'''
src = src[:start] + new + src[end:]
# 채움 소품 무리·빈터 (prop 모드만)
src = src.replace('''    a = in_mask(W, open_)
    P.scatter("dead_tree_a", 260, a)''', '''    a = in_mask(W, open_)
    af = a
    if os.environ.get("FIELD_MODE", "base") in ("prop", "fps") and os.environ.get("FIELD_CLUMP", "1") == "1":
        af = in_mask(W, open_ * (0.2 + 1.6 * ss(fbm(W.X, W.Z, 1 / 170, 3, 1401), -0.05, 0.25)))
    P.scatter("dead_tree_a", 260, af)''')
body_start = src.index('    P.scatter("dead_tree_b", 200, a)')
body_end = src.index('    P.scatter("bone_pile", 30, a)') + len('    P.scatter("bone_pile", 30, a)')
src = src[:body_start] + src[body_start:body_end].replace(", a)", ", af)") + src[body_end:]
# 무리 기록 저장
src = src.replace('    save_map(W, P, out)\n', '    save_map(W, P, out)\n    json.dump(W.cluster_log, open(os.path.join(out, "clusters.json"), "w"))\n', 1)
open("wg/worldgen.py", "w").write(src)
