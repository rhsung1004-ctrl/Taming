import json, math, sys, collections
d = sys.argv[1]
cl = json.load(open(d + "/clusters.json"))
w = json.load(open(d + "/Data~/world.json"))
pois = [(p["id"], p["p"][0], p["p"][2], p["r"]) for p in w["pois"]]
(bx0, bz0), (bx1, bz1) = w["bounds"]["min"], w["bounds"]["max"]
FOR = [((430, 640), 235), ((1470, 1420), 175)]
cnt = collections.Counter()
for kd, x, z, got in cl:
    where = "들판"
    if not (bx0 < x < bx1 and bz0 < z < bz1):
        where = "bounds 밖"
    else:
        for pid, px, pz, r in pois:
            if math.hypot(x - px, z - pz) < r + 20:
                where = "장소:" + pid
                break
        else:
            for (c, R) in FOR:
                if math.hypot(x - c[0], z - c[1]) < R:
                    where = "숲"
    st = "건너뜀(220m)" if got < 0 else ("0개" if got == 0 else "놓음")
    cnt[(kd, where.split(":")[0], st)] += 1
for k, v in sorted(cnt.items()):
    print(k, v)
eff = [c for c in cl if c[3] > 0]
print("실제로 들판에 하나 이상 놓인 무리:", sum(1 for kd, x, z, g in cl if g > 0 and bx0 < x < bx1 and bz0 < z < bz1 and all(math.hypot(x - px, z - pz) >= r + 20 for _, px, pz, r in pois) and all(math.hypot(x-c[0],z-c[1])>=R for c,R in FOR)), "/", len(cl))
