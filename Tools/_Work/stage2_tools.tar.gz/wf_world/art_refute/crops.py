import sys, os, numpy as np
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/art")
import artcommon as C
from PIL import Image
W = C.world()
names = [l["name"] for l in W["layers"]]
sp = C.splat()[..., :len(names)]
TER = os.path.join(os.path.dirname(C.DATA), "Terrain")
alb = []
for nm in names:
    im = Image.open(os.path.join(TER, "ground_%s_albedo.jpg" % nm)).convert("RGB")
    alb.append(np.asarray(im.resize((64,64))).reshape(-1,3).mean(0)/255)
alb = np.array(alb)
img = np.einsum("zxk,kc->zxc", sp, alb)
dpal = np.array([[60,140,60],[30,90,70],[150,110,70],[70,50,40],[130,130,140],[220,200,160],[170,70,40],[200,200,220]],np.uint8)
dom = np.argmax(sp,-1)
out = []
for pid, x, z, r in [("graveyard",1000,880,200),("village",1390,430,100),("cathedral",1010,1478,90),("gate",1010,1822,70),("tower",640,1572,70)]:
    z0,z1,x0,x1 = z-r, z+r, x-r, x+r
    a = np.flipud(np.clip(img[z0:z1,x0:x1]*2.0,0,1))
    b = np.flipud(dpal[dom[z0:z1,x0:x1]])
    A = Image.fromarray((a*255).astype(np.uint8)).resize((400,400), Image.NEAREST)
    B = Image.fromarray(b).resize((400,400), Image.NEAREST)
    cv = Image.new("RGB",(800,400)); cv.paste(A,(0,0)); cv.paste(B,(400,0))
    cv.save("crop_%s.png"%pid)
    print(pid, "saved")
