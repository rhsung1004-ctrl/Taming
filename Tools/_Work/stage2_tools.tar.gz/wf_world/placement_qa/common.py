# 배치 검사 공통: 데이터 읽기, 높이 샘플, 쿼터니언, 소품 메쉬 기둥(칸별 최저점), 길·개울 곡선 재계산
# 환경 변수 WORLD_DATA (Data~ 폴더), KIT_OUT (소품 폴더) 로 다른 결과도 검사할 수 있다
import os, sys, json, math, glob
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.abspath(os.path.join(HERE, "..", ".."))
DATA = os.environ.get("WORLD_DATA", os.path.join(SCR, "world_out3", "Data~"))
KIT = os.environ.get("KIT_OUT", os.path.join(SCR, "kit_out"))
WG = os.environ.get("WORLDGEN", "/home/user/Taming/Tools/WorldGen")
CACHE = os.path.join(HERE, "_cache")
sys.path.insert(0, HERE)
import fbxmesh  # noqa: E402

_wg = None


def worldgen():
    """worldgen.py 의 상수·함수 (배치도, 곡선). 실행은 하지 않는다"""
    global _wg
    if _wg is None:
        sys.path.insert(0, WG)
        import worldgen as m
        _wg = m
    return _wg


def load_world():
    return json.load(open(os.path.join(DATA, "world.json")))


def load_height():
    w = load_world()
    n = w["heightRes"]
    h = np.fromfile(os.path.join(DATA, "height.r16"), "<u2").reshape(n, n).astype(np.float64) / 65535.0 * w["height"]
    return h


def load_objects():
    return json.load(open(os.path.join(DATA, "objects.json")))


def load_trees():
    return json.load(open(os.path.join(DATA, "trees.json")))


def load_manifest():
    man = {}
    for f in sorted(glob.glob(os.path.join(KIT, "manifest_*.json"))):
        for k, v in json.load(open(f)).items():
            man[k] = v
    return man


def hsample(h, x, z):
    """쌍선형 높이 (배열 [z, x], 1 m 칸). x, z 는 배열 가능"""
    x = np.asarray(x, np.float64)
    z = np.asarray(z, np.float64)
    n = h.shape[0] - 1
    xc = np.clip(x, 0, n - 1e-6)
    zc = np.clip(z, 0, n - 1e-6)
    i = zc.astype(np.int64)
    j = xc.astype(np.int64)
    fz, fx = zc - i, xc - j
    a = h[i, j] * (1 - fx) + h[i, j + 1] * fx
    b = h[i + 1, j] * (1 - fx) + h[i + 1, j + 1] * fx
    return a * (1 - fz) + b * fz


def hslope(h, x, z):
    gz, gx = np.gradient(h)
    return np.sqrt(hsample(gx, x, z) ** 2 + hsample(gz, x, z) ** 2)


def qmat(q):
    """Unity 쿼터니언 (x, y, z, w) → 3×3 회전 행렬 (열 벡터에 곱한다)"""
    x, y, z, w = q
    n = math.sqrt(x * x + y * y + z * z + w * w) or 1.0
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])


def yaw_mat(deg):
    t = math.radians(deg)
    return qmat((0, math.sin(t / 2), 0, math.cos(t / 2)))


def mesh_columns(name):
    """소품 LOD0 를 로컬 XZ 칸으로 나눈 기둥: 칸 중심 (x, z), 칸 최저 y, 최고 y, 최저점 (x, y, z).
    정점 + 삼각형 무게중심 + 변 중점으로 촘촘히 본다. 결과는 _cache 에 저장"""
    os.makedirs(CACHE, exist_ok=True)
    fbx = os.path.join(KIT, name + ".fbx")
    cp = os.path.join(CACHE, name + ".npz")
    if os.path.exists(cp) and os.path.getmtime(cp) > os.path.getmtime(fbx):
        d = np.load(cp)
        return {k: d[k] for k in d.files}
    U, T, _ = fbxmesh.lod0_vertices(fbx)
    pts = [U]
    if len(T):
        A, B, C = U[T[:, 0]], U[T[:, 1]], U[T[:, 2]]
        pts += [(A + B + C) / 3, (A + B) / 2, (B + C) / 2, (C + A) / 2]
        # 큰 삼각형은 안쪽도 더 찍는다
        for (wa, wb, wc) in ((0.6, 0.2, 0.2), (0.2, 0.6, 0.2), (0.2, 0.2, 0.6)):
            pts.append(A * wa + B * wb + C * wc)
    P = np.concatenate(pts)
    sx, sz = np.ptp(U[:, 0]), np.ptp(U[:, 2])
    c = float(np.clip(max(sx, sz) / 48.0, 0.04, 0.5))
    ix = np.floor((P[:, 0] - U[:, 0].min()) / c).astype(np.int64)
    iz = np.floor((P[:, 2] - U[:, 2].min()) / c).astype(np.int64)
    nx = ix.max() + 1
    key = iz * nx + ix
    order = np.lexsort((P[:, 1], key))
    ks = key[order]
    first = np.ones(len(ks), bool)
    first[1:] = ks[1:] != ks[:-1]
    lo = order[first]                       # 칸마다 가장 낮은 점
    last = np.ones(len(ks), bool)
    last[:-1] = ks[1:] != ks[:-1]
    hi = order[last]
    cx = U[:, 0].min() + (ix[lo] + 0.5) * c
    cz = U[:, 2].min() + (iz[lo] + 0.5) * c
    out = {"cell": np.array(c), "cx": cx, "cz": cz, "ymin": P[lo, 1], "ymax": P[hi, 1], "low": P[lo],
           "bmin": U.min(0), "bmax": U.max(0)}
    np.savez_compressed(cp, **out)
    return out


def transform(cols_pts, p, R, s):
    """로컬 점들 (N,3) → 월드"""
    return cols_pts * s @ R.T + np.asarray(p, float)


def road_curves():
    """worldgen.lay_roads 와 같은 계산으로 길 중심선 (곡선, 반폭) 목록과 다리 자리"""
    wg = worldgen()
    from terrain import wobble, catmull
    c = wobble(catmull(wg.CREEK, 2.0), 4.0, 1 / 55.0, 701)
    ib = int(np.argmin(np.linalg.norm(c - np.array(wg.BRIDGE_AT), axis=1)))
    bx, bz = c[ib]
    dvec = c[min(ib + 3, len(c) - 1)] - c[max(ib - 3, 0)]
    dvec = dvec / np.linalg.norm(dvec)
    r = np.array([dvec[1], -dvec[0]])
    if r[0] < 0:
        r = -r
    east_end = (bx + r[0] * 7.6, bz + r[1] * 7.6)
    west_end = (bx - r[0] * 7.6, bz - r[1] * 7.6)
    roads = list(wg.ROADS)
    roads.append((wg.ROAD_TO_BRIDGE_E + [(bx + r[0] * 20, bz + r[1] * 20), east_end], 1.9))
    roads.append(([west_end, (bx - r[0] * 20, bz - r[1] * 20)] + wg.ROAD_FROM_BRIDGE_W, 1.9))
    out = []
    for i, (pts, hw) in enumerate(roads):
        cc = wobble(catmull(pts, 2.0), 3.2, 1 / 70.0, 900 + i)
        out.append((cc, hw))
    creek = {"curve": c, "bridge": (float(bx), float(bz)), "dir": dvec, "axis": r}
    return out, creek


def seg_dist(px, pz, curve):
    """점들 (N) 에서 꺾은선까지 거리, 가장 가까운 선분 번호와 선분 방향"""
    px = np.asarray(px, float)[:, None]
    pz = np.asarray(pz, float)[:, None]
    a = curve[:-1][None]
    b = curve[1:][None]
    d = b - a
    L2 = (d ** 2).sum(-1) + 1e-12
    t = np.clip(((px - a[..., 0]) * d[..., 0] + (pz - a[..., 1]) * d[..., 1]) / L2, 0, 1)
    qx = a[..., 0] + t * d[..., 0]
    qz = a[..., 1] + t * d[..., 1]
    dist = np.sqrt((px - qx) ** 2 + (pz - qz) ** 2)
    k = np.argmin(dist, 1)
    dd = dist[np.arange(len(k)), k]
    dirs = d[0, k] / np.sqrt(L2[0, k])[:, None]
    return dd, k, dirs


class Roads:
    """모든 길에 대해 가장 가까운 길 거리·반폭·방향"""

    def __init__(self):
        self.curves, self.creek = road_curves()

    def nearest(self, x, z):
        x = np.atleast_1d(np.asarray(x, float))
        z = np.atleast_1d(np.asarray(z, float))
        best = np.full(len(x), 1e9)
        hw = np.zeros(len(x))
        rid = np.full(len(x), -1)
        dirs = np.zeros((len(x), 2))
        for i, (c, w) in enumerate(self.curves):
            # 상자로 먼저 거른다
            m = (x > c[:, 0].min() - 60) & (x < c[:, 0].max() + 60) & (z > c[:, 1].min() - 60) & (z < c[:, 1].max() + 60)
            if not m.any():
                continue
            idx = np.nonzero(m)[0]
            for s0 in range(0, len(idx), 4000):
                ii = idx[s0:s0 + 4000]
                d, k, dv = seg_dist(x[ii], z[ii], c)
                better = d < best[ii]
                jj = ii[better]
                best[jj] = d[better]
                hw[jj] = w
                rid[jj] = i
                dirs[jj] = dv[better]
        return best, hw, rid, dirs


def water_at(planes, x, z):
    """물 평면 (objects.json water) 안이면 수면 높이, 아니면 nan. 평면: 중심, 크기 (로컬 x 폭, 로컬 z 길이), yaw"""
    x = np.atleast_1d(np.asarray(x, float))
    z = np.atleast_1d(np.asarray(z, float))
    lev = np.full(len(x), np.nan)
    which = np.full(len(x), -1)
    for i, w in enumerate(planes):
        px, py, pz = w["p"]
        sx, sz = w["size"]
        t = math.radians(w.get("yaw", 0))
        # Unity Y 회전 t: 로컬 +Z → (sin t, cos t), 로컬 +X → (cos t, −sin t)
        dx, dz = x - px, z - pz
        u = dx * math.cos(t) - dz * math.sin(t)     # 로컬 X
        v = dx * math.sin(t) + dz * math.cos(t)     # 로컬 Z
        m = (np.abs(u) <= sx / 2) & (np.abs(v) <= sz / 2)
        m &= np.isnan(lev) | (py > lev)
        lev[m] = py
        which[m] = i
    return lev, which


def fmt(v, n=2):
    return ("%%.%df" % n) % v
