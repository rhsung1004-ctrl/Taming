# 방향 검사
#   python3 check_orient.py
# 앞면 = 로컬 +Z 를 쿼터니언으로 돌린 방향 (SPEC: Blender -Y 앞면 → Unity +Z), 긴 축 = 로컬 +X
import math, collections
import numpy as np
import common as C

H = C.load_height()
O = C.load_objects()["objects"]
roads = C.Roads()
wg = C.worldgen()
GC, GR = wg.GRAVE_C, wg.GRAVE_R


def fwd(o):
    v = C.qmat(o["q"]) @ [0, 0, 1]
    v = np.array([v[0], v[2]])
    return v / (np.linalg.norm(v) + 1e-12)


def xax(o):
    v = C.qmat(o["q"]) @ [1, 0, 0]
    v = np.array([v[0], v[2]])
    return v / (np.linalg.norm(v) + 1e-12)


def ang(a, b):
    return math.degrees(math.acos(max(-1, min(1, float(a @ b)))))


def axis_ang(a, b):
    """축끼리 (방향 무시) 0~90°"""
    return math.degrees(math.acos(min(1, abs(float(a @ b)))))


def road_dir_from(x, z):
    """(x, z) 에서 가장 가까운 길 중심선 점으로 가는 방향, 거리, 길 번호"""
    best = (1e9, None, -1)
    for i, (c, hw) in enumerate(roads.curves):
        d, k, dv = C.seg_dist([x], [z], c)
        if d[0] < best[0]:
            a, b = c[k[0]], c[k[0] + 1]
            t = np.clip(((x - a[0]) * (b - a)[0] + (z - a[1]) * (b - a)[1]) / (np.sum((b - a) ** 2) + 1e-12), 0, 1)
            q = a + t * (b - a)
            best = (d[0], q, i)
    d, q, i = best
    v = q - np.array([x, z])
    return v / (np.linalg.norm(v) + 1e-12), d, i


def region(x, z):
    e = ((x - GC[0]) / GR[0]) ** 2 + ((z - GC[1]) / GR[1]) ** 2
    if e < 1.0:
        return "큰 묘지"
    if (x - wg.VILLAGE[0] - 55) ** 2 + (z - wg.VILLAGE[1] - 55) ** 2 < 20 ** 2:
        return "마을 묘지"
    if (x - wg.CATH[0]) ** 2 + (z - wg.CATH[1]) ** 2 < 75 ** 2:
        return "대성당"
    if (x - wg.SWAMP[0]) ** 2 + (z - wg.SWAMP[1]) ** 2 < wg.SWAMP_R ** 2:
        return "늪"
    return "들판 무덤 무리"


print("== 1) 묘비 앞면 방향 (길까지 거리 < 40 m 인 것만 '길을 봄' 판정: 앞면과 길 쪽 방향 사이 < 90°)")
graves = [o for o in O if o["a"].startswith("grave_") and o["a"] not in ("grave_tomb",)]
stat = collections.defaultdict(lambda: [0, 0, 0, 0, 0])   # 개수, 남쪽 봄, 길 40m 안, 그중 길 봄, 그중 길 등짐(>135°)
for o in graves:
    x, z = o["p"][0], o["p"][2]
    f = fwd(o)
    rg = region(x, z)
    st = stat[rg]
    st[0] += 1
    if f[1] < -0.7:
        st[1] += 1
    rd, d, ri = road_dir_from(x, z)
    if d < 40:
        st[2] += 1
        a = ang(f, rd)
        if a < 90:
            st[3] += 1
        if a > 135:
            st[4] += 1
for rg, (n, south, near, face, back) in stat.items():
    print("  %-12s 묘비 %4d: 남쪽(−Z)을 봄 %4d (%.0f%%) | 길 40 m 안 %4d 중 길 쪽을 봄 %4d (%.0f%%), 길에 등을 짐 %4d (%.0f%%)" % (
        rg, n, south, 100 * south / max(n, 1), near, face, 100 * face / max(near, 1), back, 100 * back / max(near, 1)))
# 큰 묘지: 동서 길 북쪽 / 남쪽 반
for half, cond in (("동서 길 북쪽 반", lambda z: z > GC[1] + 6), ("동서 길 남쪽 반", lambda z: z < GC[1] - 6)):
    L = [o for o in graves if region(o["p"][0], o["p"][2]) == "큰 묘지" and cond(o["p"][2])]
    sf = sum(1 for o in L if fwd(o)[1] < -0.7)
    print("    큰 묘지 %s: %d 기, 남쪽을 봄 %d" % (half, len(L), sf))
# 들판 무덤 무리: 무리마다 앞면이 무작위 → 가장 가까운 길과의 각
fl = [o for o in graves if region(o["p"][0], o["p"][2]) == "들판 무덤 무리"]
angs = []
for o in fl:
    rd, d, ri = road_dir_from(o["p"][0], o["p"][2])
    if d < 60:
        angs.append(ang(fwd(o), rd))
if angs:
    a = np.array(angs)
    print("  들판 무덤 (길 60 m 안 %d 기): 길 쪽과의 각 분위 25/50/75 = %.0f/%.0f/%.0f°, 길에 등짐(>135°) %d" % (len(a), *np.percentile(a, [25, 50, 75]), (a > 135).sum()))

print("\n== 2) 울타리 긴 축(로컬 X)과 따라가야 할 선의 각 (0° = 나란함, 90° = 직각으로 꽂힘)")
fences = [(i, o) for i, o in enumerate(O) if o["a"] == "fence"]
groups = collections.defaultdict(list)
for i, o in fences:
    x, z = o["p"][0], o["p"][2]
    X = xax(o)
    e = math.sqrt(((x - GC[0]) / (GR[0] + 8)) ** 2 + ((z - GC[1]) / (GR[1] + 8)) ** 2)
    dv = (x - wg.VILLAGE[0], z - wg.VILLAGE[1])
    ev = math.sqrt((dv[0] / 60) ** 2 + (dv[1] / 50) ** 2)
    rd, d, ri = road_dir_from(x, z)
    if abs(e - 1) < 0.02:
        t = math.atan2((z - GC[1]) / (GR[1] + 8), (x - GC[0]) / (GR[0] + 8))
        tan = np.array([-math.sin(t) * (GR[0] + 8), math.cos(t) * (GR[1] + 8)])
        groups["큰 묘지 둘레"].append((i, o, axis_ang(X, tan / np.linalg.norm(tan))))
    elif abs(ev - 1) < 0.03:
        t = math.atan2(dv[1] / 50, dv[0] / 60)
        tan = np.array([-math.sin(t) * 60, math.cos(t) * 50])
        groups["마을 둘레"].append((i, o, axis_ang(X, tan / np.linalg.norm(tan))))
    elif d < 6:
        # 길 방향
        _, k, dirs = C.seg_dist([x], [z], roads.curves[ri][0])
        groups["길가"].append((i, o, axis_ang(X, dirs[0])))
    else:
        groups["그 밖 (무덤 무리 등, 방향 무작위)"].append((i, o, float("nan")))
for g, L in groups.items():
    a = np.array([t[2] for t in L])
    if np.isnan(a).all():
        print("  %-24s %3d 개" % (g, len(L)))
        continue
    print("  %-24s %3d 개: 각 분위 50/90 = %.1f/%.1f°, 45° 넘음 %d" % (g, len(L), np.nanpercentile(a, 50), np.nanpercentile(a, 90), (a > 45).sum()))
    if g == "마을 둘레":
        for i, o, a_ in L:
            print("      fence #%d (%.1f, %.1f) 각 %.0f°" % (i, o["p"][0], o["p"][2], a_))

print("\n== 3) 석상 앞면이 길·다가오는 쪽을 보는지")
for i, o in enumerate(O):
    if o["a"] in ("statue_angel", "statue_reaper", "crypt", "cathedral_ruin", "gate_great", "altar", "watchtower_ruin", "fence_gate", "well"):
        x, z = o["p"][0], o["p"][2]
        f = fwd(o)
        rd, d, ri = road_dir_from(x, z)
        print("  %-15s #%-5d (%7.1f, %7.1f) 앞면 (%.2f, %.2f)  가장 가까운 길 %d 까지 %.1f m, 길 쪽과의 각 %.0f°" % (o["a"], i, x, z, f[0], f[1], ri, d, ang(f, rd) if d > 0.5 else float("nan")))

print("\n== 4) 둘레 폐허 벽: 긴 축(로컬 X)과 둘레(원) 접선 사이 각 (0° = 둘레를 따라 늘어섬, 90° = 바큇살처럼 중심을 향함)")
for nm, c, r0, r1 in (("대성당", wg.CATH, 26, 52), ("망루", wg.TOWER, 8, 23)):
    L = []
    for i, o in enumerate(O):
        if o["a"] in ("wall_ruin_a", "wall_ruin_b", "arch_ruin"):
            x, z = o["p"][0], o["p"][2]
            d = math.hypot(x - c[0], z - c[1])
            if r0 <= d <= r1:
                rad = np.array([x - c[0], z - c[1]]) / d
                tan = np.array([-rad[1], rad[0]])
                L.append((o["a"], i, x, z, axis_ang(xax(o), tan)))
    a = np.array([t[4] for t in L])
    print("  %s 둘레 벽·아치 %d 개: 접선과의 각 %s" % (nm, len(L), " ".join("%.0f" % v for v in a)))

print("\n== 5) 다리: check_bridge.py 참고")
