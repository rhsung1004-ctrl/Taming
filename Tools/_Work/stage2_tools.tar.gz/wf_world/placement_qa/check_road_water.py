# 길 중심선이 물(늪·호수·웅덩이 평면 아래 지형)로 들어가는 곳, 길 위 기울기
#   python3 check_road_water.py
import numpy as np
import common as C
from check_roads import ROAD_NAMES

H = C.load_height()
gz, gx = np.gradient(H)
SL = np.sqrt(gx * gx + gz * gz)
planes = C.load_objects()["water"]
roads = C.Roads()
for ri, (c, hw) in enumerate(roads.curves):
    s = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(c, axis=0), axis=1))])
    ss_ = np.arange(0, s[-1], 0.5)
    x = np.interp(ss_, s, c[:, 0]); z = np.interp(ss_, s, c[:, 1])
    h = C.hsample(H, x, z)
    lev, wh = C.water_at(planes, x, z)
    wet = ~np.isnan(lev) & (h < lev)
    sl = C.hsample(SL, x, z)
    msg = "물에 잠긴 길 %.1f m" % (wet.sum() * 0.5)
    if wet.any():
        k = np.nonzero(wet)[0]
        msg += " (s %.0f~%.0f m, (%.1f, %.1f)~(%.1f, %.1f), 최대 깊이 %.2f m)" % (ss_[k[0]], ss_[k[-1]], x[k[0]], z[k[0]], x[k[-1]], z[k[-1]], (lev - h)[k].max())
    print("길 %2d %-14s 기울기 최대 %.2f (30°=0.58 넘는 길이 %.0f m, 45°=1.0 넘는 길이 %.0f m)  %s" % (
        ri, ROAD_NAMES[ri], sl.max(), (sl > 0.58).sum() * 0.5, (sl > 1.0).sum() * 0.5, msg))
