# 데이터 이상: NaN·무한대, 크기 0 이하, 쿼터니언 길이, 지형 밖, 걸을 수 있는 범위 밖, 겹친 중복, 광원·효과 높이, 시작 자리
#   python3 check_data.py
import math, collections
import numpy as np
import common as C

H = C.load_height()
W = C.load_world()
O = C.load_objects()
T = C.load_trees()
man = C.load_manifest()
size = W["size"]
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]


def finite(v):
    return all(isinstance(t, (int, float)) and math.isfinite(t) for t in v)


bad = collections.Counter()
ex = collections.defaultdict(list)
for i, o in enumerate(O["objects"]):
    if not finite(o["p"]) or not finite(o["q"]) or not finite([o["s"]]):
        bad["NaN/무한"] += 1; ex["NaN/무한"].append(i)
    if o["s"] <= 0.01:
        bad["크기 0 이하"] += 1; ex["크기 0 이하"].append(i)
    qn = math.sqrt(sum(t * t for t in o["q"]))
    if abs(qn - 1) > 1e-3:
        bad["쿼터니언 길이 ≠ 1"] += 1; ex["쿼터니언 길이 ≠ 1"].append((i, qn))
    if o["a"] not in man:
        bad["manifest 에 없음"] += 1; ex["manifest 에 없음"].append((i, o["a"]))
    x, y, z = o["p"]
    if not (0 <= x <= size and 0 <= z <= size):
        bad["지형 밖"] += 1; ex["지형 밖"].append((i, o["a"], x, z))
    hh = float(C.hsample(H, x, z))
    if abs(y - hh) > 3.0 and o["a"] not in ("cliff_a", "cliff_b", "cliff_c", "lotus_glow"):
        bad["중심 높이가 지형과 3 m 넘게 다름"] += 1; ex["중심 높이가 지형과 3 m 넘게 다름"].append((i, o["a"], round(y - hh, 2)))
print("== objects.json 소품 %d" % len(O["objects"]))
for k, v in bad.items():
    print("  %s: %d  예 %s" % (k, v, ex[k][:5]))
if not bad:
    print("  NaN·크기·쿼터니언·지형 밖·manifest: 문제 없음")
# 중복 (같은 종류, 0.05 m 안)
seen = {}
dup = []
for i, o in enumerate(O["objects"]):
    key = (o["a"], round(o["p"][0] / 0.05), round(o["p"][2] / 0.05))
    if key in seen:
        dup.append((seen[key], i, o["a"]))
    seen[key] = i
print("  같은 종류가 같은 자리(5 cm 안)에 둘: %d %s" % (len(dup), dup[:5]))
# 걸을 수 있는 범위 밖 소품 (종류별)
out = collections.Counter()
for o in O["objects"]:
    x, z = o["p"][0], o["p"][2]
    if not (b0x <= x <= b1x and b0z <= z <= b1z):
        out[o["a"]] += 1
print("  걸을 수 있는 범위(%s~%s) 밖 소품 종류별: %s" % (W["bounds"]["min"], W["bounds"]["max"], dict(out.most_common())))

print("\n== trees.json 나무 %d, 프로토타입 %s" % (len(T["instances"]), T["prototypes"]))
tb = collections.Counter()
for i, t in enumerate(T["instances"]):
    pi, x, z, yaw, s = t
    if not finite(t):
        tb["NaN"] += 1
    if not (0 <= pi < len(T["prototypes"])):
        tb["프로토타입 번호 밖"] += 1
    if s <= 0.01:
        tb["크기 0 이하"] += 1
    if not (0 <= x <= size and 0 <= z <= size):
        tb["지형 밖"] += 1
    if not (0 <= yaw < 360):
        tb["yaw 범위 밖"] += 1
print("  ", dict(tb) if tb else "NaN·번호·크기·지형 밖·yaw: 문제 없음")
for p in T["prototypes"]:
    if man.get(p, {}).get("meta", {}).get("kind") != "tree":
        print("  프로토타입 %s 의 META.kind 가 tree 가 아님: %s" % (p, man.get(p, {}).get("meta", {}).get("kind")))
outt = collections.Counter()
for (pi, x, z, yaw, s) in T["instances"]:
    if not (b0x <= x <= b1x and b0z <= z <= b1z):
        outt[T["prototypes"][pi]] += 1
print("  걸을 수 있는 범위 밖 나무: %s" % dict(outt.most_common()))
dupt = collections.Counter((pi, round(x, 1), round(z, 1)) for (pi, x, z, yaw, s) in T["instances"])
print("  같은 자리 중복 나무: %d" % sum(v - 1 for v in dupt.values() if v > 1))

print("\n== 광원 %d, 효과 %d" % (len(O["lights"]), len(O["fx"])))
for nm, L in (("lights", O["lights"]), ("fx", O["fx"])):
    nb = 0
    for i, l in enumerate(L):
        x, y, z = l["p"]
        if not finite(l["p"]):
            print("   %s[%d] NaN" % (nm, i)); continue
        hh = float(C.hsample(H, x, z))
        lev, _ = C.water_at(O["water"], [x], [z])
        if y < hh + 0.2:
            nb += 1
            print("   %s[%d] %s (%.1f, %.1f) 높이 %.2f 가 지형 %.2f 보다 %.2f m 낮거나 땅에 붙음" % (nm, i, l.get("type", "light"), x, z, y, hh, hh - y))
        elif not np.isnan(lev[0]) and y < lev[0]:
            print("   %s[%d] (%.1f, %.1f) 높이 %.2f 가 수면 %.2f 아래" % (nm, i, x, z, y, lev[0]))
    print("  %s: 땅속·땅에 붙은 것 %d" % (nm, nb))
# 소품 META.light 와 lights 중복 (같은 자리 2 m 안)
lp = np.array([l["p"] for l in O["lights"]])
lit = [o for o in O["objects"] if man.get(o["a"], {}).get("meta", {}).get("light")]
near = 0
for o in lit:
    d = np.linalg.norm(lp[:, [0, 2]] - np.array([o["p"][0], o["p"][2]]), axis=1)
    if (d < 1.0).any():
        near += 1
print("  META.light 소품 %d 중 lights 와 1 m 안에 겹친 것 %d" % (len(lit), near))

print("\n== 시작 자리·장소")
sp = W["spawn"]["p"]
hh = float(C.hsample(H, sp[0], sp[2]))
print("  spawn (%.1f, %.2f, %.1f): 지형 %.2f (발 높이 − 지형 %+.2f), 범위 안 %s" % (sp[0], sp[1], sp[2], hh, sp[1] - hh, b0x <= sp[0] <= b1x and b0z <= sp[2] <= b1z))
near = []
for i, o in enumerate(O["objects"]):
    d = math.hypot(o["p"][0] - sp[0], o["p"][2] - sp[2])
    if d < 25:
        near.append((round(d, 1), o["a"], i, round(o["p"][0], 1), round(o["p"][2], 1)))
for (pi, x, z, yaw, s) in T["instances"]:
    d = math.hypot(x - sp[0], z - sp[2])
    if d < 25:
        near.append((round(d, 1), T["prototypes"][pi], "tree", round(x, 1), round(z, 1)))
print("  시작 자리 25 m 안:", sorted(near))
for p in W["pois"]:
    x, y, z = p["p"]
    print("  POI %-10s (%.1f, %.1f) 범위 안 %s, y − 지형 %+.2f" % (p["id"], x, z, b0x <= x <= b1x and b0z <= z <= b1z, y - float(C.hsample(H, x, z))))
