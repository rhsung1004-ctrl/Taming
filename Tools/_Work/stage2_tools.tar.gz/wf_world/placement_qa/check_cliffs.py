# 절벽·큰 바위가 뜬 곳이 플레이어에게 보이는지: 가장 가까운 걷기 좋은 땅(기울기 ≤ 0.58, 범위 안)까지 거리
#   python3 check_cliffs.py
import csv, math
import numpy as np
import common as C

H = C.load_height()
gz, gx = np.gradient(H)
SL = np.sqrt(gx * gx + gz * gz)
W = C.load_world()
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]
wg = C.worldgen()
walk = SL <= 0.58
walk[:, :b0x] = False; walk[:, b1x + 1:] = False; walk[:b0z, :] = False; walk[b1z + 1:, :] = False
# 걷기 좋은 땅이 30 m × 30 m 에 절반 넘는 곳만 (산속의 작은 평지 제외)
cs = np.cumsum(np.cumsum(walk.astype(np.int32), 0), 1)
def boxsum(r):
    p = np.pad(cs, ((r + 1, r), (r + 1, r)), mode="edge")
    return p[2 * r + 1:, 2 * r + 1:] - p[:-2 * r - 1, 2 * r + 1:] - p[2 * r + 1:, :-2 * r - 1] + p[:-2 * r - 1, :-2 * r - 1]
open_ = walk & (boxsum(15) > 0.5 * 31 * 31)
ys, xs = np.nonzero(open_)
rows = list(csv.DictReader(open(C.HERE + "/ground_objects.csv"))) + [dict(r, src="tree") for r in csv.DictReader(open(C.HERE + "/ground_trees.csv"))]
print("== 크게 뜬 것 (뜸 > 1.0 m, 절벽·바위) 과 가장 가까운 넓은 평지까지 거리")
hist = {}
for r in rows:
    a = r["a"]
    if not (a.startswith("cliff") or a.startswith("rock")):
        continue
    f = float(r["fmax"])
    if f <= 1.0:
        continue
    x, z = float(r["x"]), float(r["z"])
    # 가까운 평지 (창 400 m)
    m = (np.abs(xs - x) < 400) & (np.abs(ys - z) < 400)
    d = np.min(np.hypot(xs[m] - x, ys[m] - z)) if m.any() else 999
    dh = float(C.hsample(H, x, z)) - (float(H[ys[m][np.argmin(np.hypot(xs[m] - x, ys[m] - z))], xs[m][np.argmin(np.hypot(xs[m] - x, ys[m] - z))]]) if m.any() else 0)
    b = "<=30" if d <= 30 else "30~80" if d <= 80 else "80~150" if d <= 150 else ">150"
    hist.setdefault(a, {}).setdefault(b, []).append((f, x, z, d, dh, r["i"], float(r["slope"]), float(r["s"])))
for a, hb in sorted(hist.items()):
    print("  %-10s %s" % (a, "  ".join("평지까지 %s m: %d" % (k, len(v)) for k, v in sorted(hb.items()))))
    for k in ("<=30", "30~80"):
        for (f, x, z, d, dh, i, sl, s) in sorted(hb.get(k, []), key=lambda t: -t[0])[:5]:
            print("      #%s (%.0f, %.0f) 크기 %.2f 경사 %.2f 뜸 %.2f m, 평지까지 %.0f m (평지보다 %.0f m 높음)" % (i, x, z, s, sl, f, d, dh))
print("\n== 용의 무덤 테두리 절벽 (22개) 하나씩")
for r in rows:
    if r["a"].startswith("cliff") and math.hypot(float(r["x"]) - wg.DRAGON[0], float(r["z"]) - wg.DRAGON[1]) < wg.DRAGON_R + 30:
        print("  %-8s #%-5s (%.0f, %.0f) 크기 %.2f 경사 %.2f 뜸 %.2f m (뜬 칸 %.0f%%) 가장 묻힘 %.2f m 가운데 묻힘 %.0f%%" % (
            r["a"], r["i"], float(r["x"]), float(r["z"]), float(r["s"]), float(r["slope"]), float(r["fmax"]), float(r["ffrac"]) * 100, float(r["bmax"]), float(r["bmedfrac"]) * 100))
