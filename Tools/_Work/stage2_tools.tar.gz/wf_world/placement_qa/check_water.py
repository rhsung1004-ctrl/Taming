# 물 검사: 늪·호수·개울 웅덩이 물 평면 안에서 수면 아래로 잠긴 소품·나무
#   python3 check_water.py
# 물 평면 = objects.json water (사각형, yaw). 그 자리 지형이 수면보다 낮으면 물이 보인다.
#   깊이 = 수면 − 소품 중심 지형 높이,  잠김 비율 = (수면 − 소품 바닥) / 소품 높이
#   소품 바닥 칸(땅에 닿는 칸) 가운데 물에 잠긴 칸 비율도 센다 (물가에 걸친 것)
import numpy as np
import common as C

ROOT_H = 0.4      # dead_tree_b 뿌리 부풀음 높이 (로컬 m, check_water 위 측정: 반경 90백분위가 0.4 m 위에서 줄기 굵기로 줄어든다)


def main():
    H = C.load_height()
    W = C.load_world()
    O = C.load_objects()
    planes = O["water"]
    man = C.load_manifest()
    T = C.load_trees()
    print("물 평면:", [(round(w["p"][1], 3), w["size"]) for w in planes])
    print("levels:", W["levels"])
    names = {0: "늪", 1: "호수"}
    items = []
    for i, o in enumerate(O["objects"]):
        items.append(("obj", i, o["a"], o["p"], C.qmat(o["q"]), o["s"]))
    for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
        a = T["prototypes"][pi]
        y = float(C.hsample(H, x, z)) - man[a]["meta"].get("sink", 0) * s
        items.append(("tree", i, a, (x, y, z), C.yaw_mat(yaw), s))
    xs = np.array([it[3][0] for it in items])
    zs = np.array([it[3][2] for it in items])
    lev, which = C.water_at(planes, xs, zs)
    hc = C.hsample(H, xs, zs)
    # 바닥 칸 하나라도 물 평면 안 + 지형 < 수면 인 것까지 본다
    cache = {}
    res = []
    for k, (src, i, a, p, R, s) in enumerate(items):
        if a not in cache:
            cache[a] = C.mesh_columns(a)
        m = cache[a]
        sel = m["ymin"] * s <= 0.10
        low = C.transform(m["low"][sel], p, R, s)
        lv, wh = C.water_at(planes, low[:, 0], low[:, 2])
        hl = C.hsample(H, low[:, 0], low[:, 2])
        wet = (~np.isnan(lv)) & (hl < lv)
        if not wet.any() and not (not np.isnan(lev[k]) and hc[k] < lev[k]):
            continue
        L = np.nanmax(lv) if wet.any() else lev[k]
        top = p[1] + m["bmax"][1] * s
        base = p[1] + m["bmin"][1] * s
        height = top - base
        res.append({"src": src, "i": i, "a": a, "x": p[0], "z": p[2], "y": p[1], "s": s, "lev": L,
                    "plane": int(np.nanmax(wh)) if wet.any() else int(which[k]),
                    "depth": L - hc[k], "wetfrac": float(wet.mean()), "sub": (L - base) / height, "top_under": top < L,
                    "height": height})
    by = {}
    for r in res:
        by.setdefault(r["a"], []).append(r)
    print("\n== 물 평면 안에서 바닥이 물에 닿는 것: 종류별")
    print("%-15s %5s %10s %10s %10s %12s %10s" % ("종류", "개수", "중심이물속", "깊이>0.3", "깊이>1.0", "통째로잠김", "최대깊이m"))
    for a in sorted(by, key=lambda k: -len(by[k])):
        L = by[a]
        d = np.array([r["depth"] for r in L])
        print("%-15s %5d %10d %10d %10d %12d %10.2f" % (a, len(L), (d > 0).sum(), (d > 0.3).sum(), (d > 1.0).sum(),
                                                       sum(r["top_under"] for r in L), d.max()))
    print("\n== lotus_glow (수면에 떠야 한다): 지형이 수면보다 높은 곳 / 수면과 높이 차")
    lot = [r for r in res if r["a"] == "lotus_glow"]
    allot = [(i, o) for i, o in enumerate(O["objects"]) if o["a"] == "lotus_glow"]
    lx = np.array([o["p"][0] for _, o in allot]); lz = np.array([o["p"][2] for _, o in allot]); ly = np.array([o["p"][1] for _, o in allot])
    llev, lw = C.water_at(planes, lx, lz)
    lh = C.hsample(H, lx, lz)
    print("  전체 %d, 물 평면 밖 %d, 지형이 수면 위 %d, 지형이 수면 −0.05 위 %d, y − 수면: 최소 %.3f 최대 %.3f" % (
        len(allot), np.isnan(llev).sum(), (lh >= llev).sum(), (lh > llev - 0.05).sum(), np.nanmin(ly - llev), np.nanmax(ly - llev)))
    # 연꽃 둘레 (반경 0.3 m) 지형이 수면 위로 나온 것
    bad = 0
    for k in range(len(allot)):
        ang = np.linspace(0, 2 * np.pi, 8, endpoint=False)
        hh = C.hsample(H, lx[k] + 0.3 * np.cos(ang), lz[k] + 0.3 * np.sin(ang))
        if (hh > llev[k]).any():
            bad += 1
    print("  잎 둘레 0.3 m 안에 땅이 수면 위로 나온 연꽃 %d" % bad)
    print("\n== dead_tree_b 가 물에 선 것: 깊이 = 수면 − 지형 (뿌리 높이 %.1f m × 크기 넘으면 줄기가 잠긴다)" % ROOT_H)
    tb = [r for r in res if r["a"] == "dead_tree_b" and r["depth"] > 0]
    d = np.array([r["depth"] for r in tb])
    rootlim = np.array([ROOT_H * r["s"] + 0.05 * r["s"] for r in tb])
    print("  물속 중심 %d 그루: 깊이 분위 10/50/90 %% = %.2f / %.2f / %.2f m, 최대 %.2f m. 뿌리 높이를 넘어 줄기까지 잠긴 것 %d 그루 (그중 0.2 m 넘게 넘은 것 %d)" % (
        len(tb), *np.percentile(d, [10, 50, 90]), d.max(), (d > rootlim).sum(), (d > rootlim + 0.2).sum()))
    for r in sorted(tb, key=lambda r: -r["depth"])[:6]:
        print("    #%d (%.1f, %.1f) 크기 %.2f 깊이 %.2f m (뿌리 높이 %.2f) %s" % (r["i"], r["x"], r["z"], r["s"], r["depth"], ROOT_H * r["s"], names.get(r["plane"], "웅덩이")))
    print("\n== 의도하지 않은 잠김 (lotus_glow·dead_tree_b 제외): 중심이 물속(깊이 > 0.05) 이거나 바닥 칸 30%% 넘게 잠긴 것")
    others = [r for r in res if r["a"] not in ("lotus_glow", "dead_tree_b") and (r["depth"] > 0.05 or r["wetfrac"] > 0.3)]
    by2 = {}
    for r in others:
        by2.setdefault(r["a"], []).append(r)
    for a in sorted(by2, key=lambda k: -len(by2[k])):
        L = sorted(by2[a], key=lambda r: -r["depth"])
        print("  %-14s %3d개  예: %s" % (a, len(L), "; ".join("#%d(%.1f,%.1f) 깊이 %.2f 잠김 %.0f%% %s%s" % (
            r["i"], r["x"], r["z"], r["depth"], max(0, r["sub"]) * 100, names.get(r["plane"], "웅덩이"), " 통째로" if r["top_under"] else "") for r in L[:4])))
    # 개울 웅덩이 둘레
    print("\n== 개울 웅덩이 평면 안 (plane ≥ 2) 의 모든 것")
    for r in res:
        if r["plane"] >= 2:
            print("  %s #%d %-12s (%.1f, %.1f) y %.2f 수면 %.2f 깊이 %.2f 바닥칸잠김 %.0f%% 잠김 %.0f%%" % (r["src"], r["i"], r["a"], r["x"], r["z"], r["y"], r["lev"], r["depth"], r["wetfrac"] * 100, max(0, r["sub"]) * 100))


if __name__ == "__main__":
    main()
