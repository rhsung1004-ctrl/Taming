# 용의 무덤: 새 manifest(뼈 소품)로 worldgen.lay_dragon 이 놓을 자리를 미리 검사 (기울기 tilt 0, 두개골 크기 1.0 으로 근사)
#   python3 check_dragon_plan.py
# worldgen.Placer.put 를 그대로 써서 y·쿼터니언을 만들고, check_ground 와 같은 방식으로 뜸·묻힘을 잰다
import math, types
import numpy as np
import common as C
from check_ground import analyse

wg = C.worldgen()
H = C.load_height()
man = C.load_manifest()
meta = {k: v.get("meta", {}) for k, v in man.items()}
W = types.SimpleNamespace()
W.h = H.astype(np.float32)
W.gz, W.gx = np.gradient(W.h)
W.slope = np.sqrt(W.gx ** 2 + W.gz ** 2)
W.lights, W.fx = [], []


class R0:
    """tilt·잡음 0 으로 고정한 rng"""
    def uniform(self, a, b=None):
        return (a + b) / 2 if b is not None else a
    def normal(self, m=0, s=1):
        return m
    def random(self):
        return 0.5


P = wg.Placer(W, meta, R0())
for nm in ("dragon_skull", "dragon_spine", "dragon_ribs", "dragon_claw"):
    meta[nm] = dict(meta[nm], tilt=0)
cx, cz = wg.DRAGON
a = np.array([0.78, -0.62]); a /= np.linalg.norm(a)
side = np.array([-a[1], a[0]])
head = np.array([cx + 26.0, cz - 20.0])
fy = wg.yaw_to(a[0], a[1])
along = math.degrees(math.atan2(-a[1], a[0]))
at = lambda t, off=0.0: tuple(map(float, head - a * t + side * off))
plan = [("dragon_skull", at(0), fy + 12, None), ("dragon_spine", at(9.5, 0.8), along + 8, 0.7), ("dragon_ribs", at(19.5, -0.5), along + 180, 1.0),
        ("dragon_spine", at(31.5, 1.5), along - 6, 1.0), ("dragon_spine", at(41.0, -1.5), along + 15, 0.75)]
for t, sd, sc_ in ((15.5, 1, 1.0), (17.0, -1, 0.9), (27.0, 1, 0.85), (28.5, -1, 0.8)):
    plan.append(("dragon_claw", at(t, sd * 8.5), fy + sd * 70, sc_))
print("부분            자리              크기  경사  fmax  뜬칸%  bmax  묻힘/높이  땅이 뚫음")
for nm, (x, z), yaw, s in plan:
    n0 = len(P.objects)
    P.put(nm, x, z, yaw=yaw, s=s if s is not None else 1.0, check=False)
    o = P.objects[-1]
    cols = C.mesh_columns(nm)
    r = analyse(nm, cols, o["p"], C.qmat(o["q"]), o["s"], H)
    print("%-14s (%7.1f, %7.1f) %4.2f %5.2f %5.2f %5.0f%% %5.2f %6.0f%%   %.2f m (%.0f%%)" % (
        nm, x, z, o["s"], float(C.hsample(W.slope, x, z)), r["fmax"], r["ffrac"] * 100, r["bmax"], r["bfrac"] * 100, r["poke"], r["pokefrac"] * 100))
# 부분끼리 겹침 (XZ 발자국, 지형 위 0.05~2.5 m)
from check_overlap import cells_of
cache = {}
fps = [cells_of(o["a"], o["p"], C.qmat(o["q"]), o["s"], H, cache, False) for o in P.objects]
for i in range(len(fps)):
    for j in range(i + 1, len(fps)):
        n = len(np.intersect1d(fps[i], fps[j]))
        if n:
            print("  겹침: %s #%d × %s #%d  %.2f m²" % (P.objects[i]["a"], i, P.objects[j]["a"], j, n * 0.0625))
