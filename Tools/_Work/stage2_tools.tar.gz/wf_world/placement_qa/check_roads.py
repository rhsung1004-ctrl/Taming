# 길 검사
#   python3 check_roads.py
# 1) 길 위(중심선에서 반폭 안)로 들어온 충돌체 (걸음 높이에 걸치는 부분) — 종류·자리·파고든 깊이
# 2) 충돌 없는 잡동사니(해골·양초·꽃·덤불 …) 가 길 위에 놓인 수
# 3) 길마다 0.25 m 칸으로 띠(반폭 + 6 m)를 깔고, 장애물(캐릭터 반지름 0.4 m 만큼 부풀림)과
#    가파른 땅(기울기 > 1.0 = 45°)을 막힌 칸으로 해서 길 시작 → 끝이 이어지는지(BFS), 가장 좁은 곳 폭
import math, collections
import numpy as np
import common as C
import obstacles as OB

RAD = 0.4
SLOPE_MAX = 1.0
ROAD_NAMES = list(getattr(C.worldgen(), "ROAD_NAMES", [])) or ["제단→묘지→납골당", "납골당→대성당", "대성당→북쪽 봉인문", "묘지 동서",
              "묘지→늪", "제단→마을", "제단→호수", "용의 무덤→망루", "늪→고목", "고목→북쪽 길", "제단 북쪽→검은 숲", "묘지 서쪽→다리 동쪽",
              "다리 서쪽→용의 무덤"]
ROAD_NAMES += ["길 %d" % i for i in range(len(ROAD_NAMES), 40)]


def main():
    H = C.load_height()
    gz, gx = np.gradient(H)
    SL = np.sqrt(gx * gx + gz * gz)
    man = C.load_manifest()
    roads = C.Roads()
    W = C.load_world()
    O = C.load_objects()["objects"]
    T = C.load_trees()

    # 길 근처 거르기 (중심이 길에서 반폭 + 20 m 안)
    def near_fn(x, z):
        d, hw, _, _ = roads.nearest([x], [z])
        return d[0] < hw[0] + 20
    obs = OB.all_obstacles(man, H, near_fn)
    print("길 20 m 안 충돌체 %d" % len(obs))

    # 1) 파고든 깊이
    print("\n== 1) 길 위로 들어온 충돌체 (파고듦 = 반폭 − 충돌체 가장 가까운 점까지 거리, 0.3 m 넘는 것)")
    hits = []
    for (a, src, i, c, pts, rad) in obs:
        d, hw, rid, _ = roads.nearest(pts[:, 0], pts[:, 1])
        intr = hw - (d - rad)
        k = int(np.argmax(intr))
        if intr[k] > 0.3:
            # 길 폭 가운데 얼마를 덮는지: 길 직각 방향으로 점들을 투영
            hits.append((a, src, i, c, float(intr[k]), int(rid[k]), float(hw[k]), float(d[k] - rad[k])))
    by = collections.Counter(h[0] for h in hits)
    print("  종류별:", dict(by.most_common()))
    for h in sorted(hits, key=lambda h: (h[0], -h[4])):
        a, src, i, c, intr, rid, hw, dmin = h
        print("  %-15s %s#%-5d (%7.1f, %7.1f) 길 %-2d %-12s 반폭 %.1f  중심선까지 %.2f m  파고듦 %.2f m%s" % (
            a, src, i, c[0], c[1], rid, ROAD_NAMES[rid], hw, max(dmin, 0), intr, "  ← 중심선 위" if dmin <= 0.2 else ""))

    # 2) 충돌 없는 것
    print("\n== 2) 충돌 없는 잡동사니 중 중심이 길 반폭 안인 것 (종류별 수)")
    xs, zs, names = [], [], []
    for o in O:
        if man[o["a"]]["meta"].get("collider", "mesh") == "none":
            xs.append(o["p"][0]); zs.append(o["p"][2]); names.append(o["a"])
    for (pi, x, z, yaw, s) in T["instances"]:
        a = T["prototypes"][pi]
        if man[a]["meta"].get("collider") == "none":
            xs.append(x); zs.append(z); names.append(a)
    d, hw, rid, _ = roads.nearest(xs, zs)
    on = d < hw
    cnt = collections.Counter(n for n, f in zip(names, on) if f)
    print("  ", dict(cnt.most_common()))
    for n in cnt:
        ex = [(xs[k], zs[k], d[k], rid[k]) for k in range(len(xs)) if on[k] and names[k] == n][:3]
        print("   %-14s 예: %s" % (n, "; ".join("(%.1f, %.1f) 중심선 %.2f m 길 %d" % e for e in ex)))

    # 3) 이어짐
    print("\n== 3) 길마다 이어짐 (띠 = 반폭 + 6 m, 0.25 m 칸, 캐릭터 반지름 %.1f, 기울기 > %.1f 막힘)" % (RAD, SLOPE_MAX))
    # 장애물 점을 0.25 m 전역 칸 사전에 찍는다
    cell = 0.25
    keys = []
    for (a, src, i, c, pts, rad) in obs:
        R_ = rad + RAD
        k = int(math.ceil(R_.max() / cell))
        off = np.arange(-k, k + 1)
        DX, DZ = np.meshgrid(off, off)
        DX, DZ = DX.ravel(), DZ.ravel()
        dd = np.hypot(DX, DZ) * cell
        ix = np.round(pts[:, 0] / cell).astype(np.int64)
        iz = np.round(pts[:, 1] / cell).astype(np.int64)
        m = dd[None, :] <= R_[:, None]
        KX = (ix[:, None] + DX[None, :])[m]
        KZ = (iz[:, None] + DZ[None, :])[m]
        keys.append(np.unique(KX * 100000 + KZ))
    occ = np.unique(np.concatenate(keys)) if keys else np.zeros(0, np.int64)
    for ri, (curve, hw) in enumerate(roads.curves):
        seg = np.linalg.norm(np.diff(curve, axis=0), axis=1)
        s = np.concatenate([[0], np.cumsum(seg)])
        L = s[-1]
        ss_ = np.arange(0, L, cell)
        cx = np.interp(ss_, s, curve[:, 0]); cz = np.interp(ss_, s, curve[:, 1])
        dx = np.gradient(cx); dz = np.gradient(cz)
        nl = np.hypot(dx, dz) + 1e-9
        nx, nz = -dz / nl, dx / nl
        band = hw + 6.0
        ts = np.arange(-band, band + 1e-6, cell)
        X = cx[:, None] + nx[:, None] * ts[None]
        Z = cz[:, None] + nz[:, None] * ts[None]
        blocked = C.hsample(SL, X.ravel(), Z.ravel()).reshape(X.shape) > SLOPE_MAX
        IX = np.round(X / cell).astype(np.int64); IZ = np.round(Z / cell).astype(np.int64)
        ob = np.isin(IX * 100000 + IZ, occ)
        free = ~(blocked | ob)
        # BFS: 시작 줄(처음 1 m)의 길 위 빈 칸에서
        n0, n1 = X.shape
        seen = np.zeros(X.shape, bool)
        q = collections.deque()
        onroad = np.abs(ts) <= hw
        for a in range(0, min(4, n0)):
            for b in np.nonzero(free[a] & onroad)[0]:
                seen[a, b] = True
                q.append((a, b))
        while q:
            a, b = q.popleft()
            for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                aa, bb = a + da, b + db
                if 0 <= aa < n0 and 0 <= bb < n1 and free[aa, bb] and not seen[aa, bb]:
                    seen[aa, bb] = True
                    q.append((aa, bb))
        reach = seen[-4:].any()
        # 가장 좁은 곳: 길 반폭 안 빈 칸 수 (가로줄마다)
        w_on = (free & onroad[None]).sum(1) * cell
        w_band = free.sum(1) * cell
        # 처음으로 못 간 줄
        far = np.nonzero(seen.any(1))[0].max()
        k_on = int(np.argmin(w_on[4:-4])) + 4
        narrow = np.nonzero(w_on[4:-4] < 0.5)[0] + 4
        runs = []
        if len(narrow):
            start = narrow[0]; prev = narrow[0]
            for k in narrow[1:]:
                if k != prev + 1:
                    runs.append((start, prev)); start = k
                prev = k
            runs.append((start, prev))
        print("  길 %2d %-14s 길이 %5.0f m 반폭 %.1f: 끝까지 %s (도달 %.0f m)  길 안 최소 빈 폭 %.2f m @ (%.1f, %.1f)  길 안 빈 폭 < 0.5 m 구간 %d 곳" % (
            ri, ROAD_NAMES[ri], L, hw, "이어짐" if reach else "막힘", ss_[far], w_on[k_on], cx[k_on], cz[k_on], len(runs)))
        for (a0, a1) in runs[:12]:
            k = (a0 + a1) // 2
            print("        막힌 구간 s %.1f~%.1f m 중심 (%.1f, %.1f) 길 안 빈 폭 %.2f, 띠 전체 빈 폭 %.2f m" % (ss_[a0], ss_[a1], cx[k], cz[k], w_on[a0:a1 + 1].min(), w_band[a0:a1 + 1].min()))
    # 시작 자리
    sp = W["spawn"]["p"]
    print("\n== 시작 자리 (%.1f, %.1f) 둘레 충돌체" % (sp[0], sp[2]))
    for (a, src, i, c, pts, rad) in obs:
        dd = np.hypot(pts[:, 0] - sp[0], pts[:, 1] - sp[2]) - rad
        if dd.min() < 3.0:
            print("   %s #%d %s 가장 가까운 면까지 %.2f m" % (src, i, a, dd.min()))


if __name__ == "__main__":
    main()
