# 대성당 안 소품: 소품 둘레 (가로 0.35 m) 의 대성당 정점 가운데 소품 높이(바닥 +0.05 ~ +1.2 m)에 있는 것 = 벽·기둥에 파고듦
# 또 소품 바로 아래 대성당 바닥(소품 바닥 ±0.6 m 안 가장 높은 정점)과 소품 바닥의 차
#   python3 check_cathedral_inside.py
import numpy as np
import common as C, fbxmesh

H = C.load_height()
man = C.load_manifest()
O = C.load_objects()["objects"]
T = C.load_trees()
cat = [o for o in O if o["a"] == "cathedral_ruin"][0]
U, Tr, _ = fbxmesh.lod0_vertices(C.KIT + "/cathedral_ruin.fbx")
A, B, Cc = U[Tr[:, 0]], U[Tr[:, 1]], U[Tr[:, 2]]
P = np.concatenate([U, (A + B + Cc) / 3, (A + B) / 2, (B + Cc) / 2, (Cc + A) / 2])
Wv = C.transform(P, cat["p"], C.qmat(cat["q"]), cat["s"])
items = [(o["a"], "obj", i, o["p"][0], o["p"][1], o["p"][2], o["s"]) for i, o in enumerate(O) if o["a"] != "cathedral_ruin"]
for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
    a = T["prototypes"][pi]
    items.append((a, "tree", i, x, float(C.hsample(H, x, z)) - man[a]["meta"].get("sink", 0) * s, z, s))
for (a, src, i, x, y, z, s) in items:
    if (x - cat["p"][0]) ** 2 + (z - cat["p"][2]) ** 2 > 24 ** 2:
        continue
    d = np.hypot(Wv[:, 0] - x, Wv[:, 2] - z)
    near = d < 0.35 + man[a]["meta"].get("footprint", 0.3) * s * 0.5
    if not near.any():
        print("  %-10s %s#%d (%.1f, %.1f): 둘레에 대성당 메쉬 없음 (지붕 없는 빈 바닥 = 지형 위)" % (a, src, i, x, z))
        continue
    vy = Wv[near, 1]
    wall = ((vy > y + 0.05) & (vy < y + 1.2)).sum()
    floor = vy[(vy > y - 0.6) & (vy < y + 0.6)]
    ftop = floor.max() if len(floor) else np.nan
    print("  %-10s %s#%d (%.1f, %.1f) 소품 바닥 %.2f, 지형 %.2f, 둘레 대성당 정점 %d 중 소품 높이(0.05~1.2 m)에 %d, 바로 아래 바닥 윗면 %.2f (소품 바닥 − 바닥 윗면 %+.2f)" % (
        a, src, i, x, z, y, C.hsample(H, x, z), near.sum(), wall, ftop, y - ftop))
