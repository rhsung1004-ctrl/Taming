# 지도 밖으로 걸어 나갈 수 있는지: 1 m 칸, 기울기 ≤ 한계 인 칸을 걸을 수 있다고 보고
# 시작 자리에서 이어진 땅(4-이웃)이 걸을 수 있는 범위(bounds) 밖·지형 가장자리까지 가는지 본다
#   python3 check_escape.py [기울기 한계=1.0]
# (소품 충돌은 넣지 않는다 → 실제보다 잘 이어진다고 본다. 봉인문은 아래에서 따로 본다)
import sys
import numpy as np
import common as C

lim = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
H = C.load_height()
W = C.load_world()
n = H.shape[0]
gz, gx = np.gradient(H)
walk = np.sqrt(gx * gx + gz * gz) <= lim
# 행마다 구간 → 합집합 찾기
parent = []


def find(a):
    while parent[a] != a:
        parent[a] = parent[parent[a]]
        a = parent[a]
    return a


def union(a, b):
    a, b = find(a), find(b)
    if a != b:
        parent[max(a, b)] = min(a, b)


runs = []        # (행, 시작, 끝(포함))
prev = []
for zi in range(n):
    row = walk[zi]
    d = np.diff(np.concatenate([[0], row.astype(np.int8), [0]]))
    st = np.nonzero(d == 1)[0]
    en = np.nonzero(d == -1)[0] - 1
    cur = []
    j = 0
    for a, b in zip(st, en):
        k = len(runs)
        runs.append((zi, a, b))
        parent.append(k)
        # 이전 행과 겹치는 구간
        while j < len(prev) and runs[prev[j]][2] < a:
            j += 1
        jj = j
        while jj < len(prev) and runs[prev[jj]][1] <= b:
            union(k, prev[jj])
            jj += 1
        cur.append(k)
    prev = cur
sp = W["spawn"]["p"]
sx, sz = int(round(sp[0])), int(round(sp[2]))
root = None
for k, (zi, a, b) in enumerate(runs):
    if zi == sz and a <= sx <= b:
        root = find(k)
mask = np.zeros(H.shape, bool)
for k, (zi, a, b) in enumerate(runs):
    if find(k) == root:
        mask[zi, a:b + 1] = True
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]
zz, xx = np.nonzero(mask)
print("기울기 한계 %.2f: 시작 자리에서 이어진 땅 %d m²" % (lim, mask.sum()))
print("  x %d~%d, z %d~%d (bounds %s~%s)" % (xx.min(), xx.max(), zz.min(), zz.max(), W["bounds"]["min"], W["bounds"]["max"]))
edge = (xx <= 2) | (xx >= n - 3) | (zz <= 2) | (zz >= n - 3)
print("  지형 가장자리(2 m 안)까지 닿는 칸 %d" % edge.sum())
if edge.any():
    e = np.nonzero(edge)[0]
    print("   예: %s" % ", ".join("(%d, %d)" % (xx[k], zz[k]) for k in e[:: max(1, len(e) // 8)][:8]))
out = (xx < b0x) | (xx > b1x) | (zz < b0z) | (zz > b1z)
print("  bounds 밖 칸 %d" % out.sum())
for nm, sel in (("북", zz > b1z), ("남", zz < b0z), ("동", xx > b1x), ("서", xx < b0x)):
    if sel.any():
        far = np.max(np.where(nm == "북", zz[sel] - b1z, np.where(nm == "남", b0z - zz[sel], np.where(nm == "동", xx[sel] - b1x, b0x - xx[sel]))))
        print("   %s쪽으로 bounds 밖 칸 %d, 가장 멀리 %d m (예 %s)" % (nm, sel.sum(), far, ", ".join("(%d, %d)" % (xx[k], zz[k]) for k in np.nonzero(sel)[0][:3])))
# 봉인문 고갯길: 문 x 둘레, 문 줄 북쪽의 지형 (문 자리는 worldgen.GATE)
GX_, GZ_ = C.worldgen().GATE
print("\n봉인문 북쪽 고갯길 (x %d~%d 에서 가장 완만한 칸의 기울기·높이)" % (GX_ - 30, GX_ + 30))
for z in range(GZ_ - 22, 2049, 16):
    row = np.sqrt(gx[z, GX_ - 30:GX_ + 31] ** 2 + gz[z, GX_ - 30:GX_ + 31] ** 2)
    k = int(np.argmin(row))
    print("  z %4d: 최소 기울기 %.2f @ x %d, 높이 %.1f, 이어진 땅에 듦 %s" % (z, row[k], GX_ - 30 + k, H[z, GX_ - 30 + k], mask[z, GX_ - 30:GX_ + 31].any()))
np.save(C.HERE + "/_walk_component.npy", mask)
