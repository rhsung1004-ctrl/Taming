#!/bin/bash
# 배치 검사 전체 실행 (결과: out_*.txt, ground_*.csv). 다른 결과를 보려면:
#   WORLD_DATA=<Data~ 폴더> KIT_OUT=<소품 폴더> ./run_all.sh
cd "$(dirname "$0")"
set -e
run() { echo "▶ $1"; nice python3 "$@" > "out_${1%.py}.txt" 2>&1 || echo "  실패: $1 (out_${1%.py}.txt 참고)"; }
run check_data.py
run check_ground.py
run summarize_ground.py
run check_cliffs.py
run check_bridge.py
run check_water.py
run check_pool.py
run check_roads.py
run check_road_water.py
run check_gate_pass.py
run check_escape.py
run check_overlap.py
run check_inside.py
run check_cathedral_inside.py
run check_orient.py
echo "끝: $(ls out_*.txt | wc -l) 개 결과"
