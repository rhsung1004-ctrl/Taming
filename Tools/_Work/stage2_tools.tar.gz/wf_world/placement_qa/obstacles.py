# 충돌체 발자국 (Unity 도구 NecroWorldImport.AddCollider 와 같은 규칙으로 근사)
#   mesh    : LOD 메쉬 기둥 가운데 걸음 높이(지형 위 0.35~1.8 m)에 걸치는 칸
#   box     : 로컬 메쉬 경계 상자
#   capsule : 지형 나무 = 줄기 반지름(지형 위 0.4~1.8 m 정점의 70번째 백분위 거리), 원점 축
#             그 밖 = rock/cliff/ruin 태그면 min(x, z) × 0.45, 아니면 줄기 반지름, 경계 중심
#   none    : 없음
# 결과: 장애물마다 XZ 점들과 반지름 (점 둘레 원의 합)
import numpy as np
import common as C
import fbxmesh

STEP = 0.35       # 캐릭터 stepOffset (NecroSetupTools: 0.35)
HEAD = 1.8        # 키

_trunk = {}


def trunk_radius(name, man):
    if name in _trunk:
        return _trunk[name]
    U, T, _ = fbxmesh.lod0_vertices(C.KIT + "/" + name + ".fbx")
    y = U[:, 1] - U[:, 1].min()
    sel = (y >= 0.4) & (y <= 1.8)
    sx, sz = np.ptp(U[:, 0]), np.ptp(U[:, 2])
    fallback = float(np.clip(min(sx, sz) * 0.12, 0.2, 1.0))
    if sel.sum() < 8:
        r = fallback
    else:
        d = np.sort(np.hypot(U[sel, 0], U[sel, 2]))
        r = float(np.clip(d[int(len(d) * 0.7)], 0.12, max(0.2, min(sx, sz) * 0.4)))
    _trunk[name] = r
    return r


def footprint(a, p, R, s, man, H, is_tree=False):
    """(점 (N,2), 반지름 (N,)) 또는 None"""
    meta = man[a]["meta"]
    kind = meta.get("collider", "capsule" if is_tree else "mesh")
    if meta.get("kind") == "tree" and kind != "none":
        kind = "capsule"
    if kind == "none":
        return None
    m = C.mesh_columns(a)
    tags = meta.get("tags", [])
    if kind == "mesh":
        lo = C.transform(m["low"], p, R, s)
        top = C.transform(np.stack([m["cx"], m["ymax"], m["cz"]], 1), p, R, s)
        hh = C.hsample(H, lo[:, 0], lo[:, 2])
        solid = (lo[:, 1] < hh + HEAD) & (top[:, 1] > hh + STEP)
        if not solid.any():
            return None
        cc = C.transform(np.stack([m["cx"], m["ymin"], m["cz"]], 1)[solid], p, R, s)
        return cc[:, [0, 2]], np.full(solid.sum(), float(m["cell"]) * s * 0.71)
    if kind == "box":
        b0, b1 = m["bmin"], m["bmax"]
        if (b1[1] - b0[1]) * s < STEP:
            return None
        xs = np.linspace(b0[0], b1[0], max(2, int((b1[0] - b0[0]) * s / 0.2) + 1))
        zs = np.linspace(b0[2], b1[2], max(2, int((b1[2] - b0[2]) * s / 0.2) + 1))
        X, Z = np.meshgrid(xs, zs)
        pts = np.stack([X.ravel(), np.full(X.size, (b0[1] + b1[1]) / 2), Z.ravel()], 1)
        w = C.transform(pts, p, R, s)
        return w[:, [0, 2]], np.full(len(w), 0.1 * 1.0)
    if kind == "capsule":
        b0, b1 = m["bmin"], m["bmax"]
        if any(t in tags for t in ("rock", "cliff", "ruin")):
            r = min(b1[0] - b0[0], b1[2] - b0[2]) * 0.45
        else:
            r = trunk_radius(a, man)
        r = max(0.1, r)
        if meta.get("kind") == "tree":
            c = np.array([0.0, 0.0, 0.0])
        else:
            c = np.array([(b0[0] + b1[0]) / 2, 0.0, (b0[2] + b1[2]) / 2])
        w = C.transform(c[None], p, R, s)
        return w[:, [0, 2]], np.array([r * s])
    return None


def all_obstacles(man, H, near=None):
    """[(종류, 출처, 번호, 중심 xz, 점, 반지름)]. near(x, z) → bool 로 거를 수 있다"""
    out = []
    O = C.load_objects()["objects"]
    for i, o in enumerate(O):
        x, y, z = o["p"]
        if near is not None and not near(x, z):
            continue
        fp = footprint(o["a"], o["p"], C.qmat(o["q"]), o["s"], man, H)
        if fp is not None:
            out.append((o["a"], "obj", i, (x, z), fp[0], fp[1]))
    T = C.load_trees()
    for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
        a = T["prototypes"][pi]
        if near is not None and not near(x, z):
            continue
        y = float(C.hsample(H, x, z)) - man[a]["meta"].get("sink", 0) * s
        fp = footprint(a, (x, y, z), C.yaw_mat(yaw), s, man, H, is_tree=True)
        if fp is not None:
            out.append((a, "tree", i, (x, z), fp[0], fp[1]))
    return out
