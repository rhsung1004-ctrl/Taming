# 겹침 검사: 서로 파고드는 소품, 랜드마크 발자국 안의 잡동사니
#   python3 check_overlap.py
# 소품마다 메쉬 기둥 가운데 "지형 위 0.05 ~ 2.5 m 에 몸이 있는 칸"을 0.25 m 칸으로 찍어 발자국을 만들고
# (나무는 줄기·뿌리·낮은 가지만), 두 발자국이 겹치는 넓이를 잰다.
import collections, math
import numpy as np
import common as C

CELL = 0.25
LANDMARKS = {"altar", "crypt", "cathedral_ruin", "gate_great", "watchtower_ruin", "tree_giant", "bridge_ruin", "well", "fence_gate",
             "dragon_skull", "stair_ruin"}
BIGISH = {"wall_ruin_a", "wall_ruin_b", "arch_ruin", "pillar_a", "pillar_b", "cliff_a", "cliff_b", "cliff_c", "rock_b", "rock_flat",
          "log_fallen", "grave_tomb", "coffin", "statue_angel", "statue_reaper", "lantern", "fence", "stump", "grave_obelisk",
          "dead_tree_a", "dead_tree_b", "dead_tree_c", "rock_a"} | LANDMARKS


def cells_of(a, p, R, s, H, cache, low_only):
    if a not in cache:
        cache[a] = C.mesh_columns(a)
    m = cache[a]
    lo = C.transform(m["low"], p, R, s)
    top = C.transform(np.stack([m["cx"], m["ymax"], m["cz"]], 1), p, R, s)
    hh = C.hsample(H, lo[:, 0], lo[:, 2])
    sel = (top[:, 1] > hh + 0.05) & (lo[:, 1] < hh + (2.5 if low_only else 99))
    if not sel.any():
        return np.zeros(0, np.int64)
    c = C.transform(np.stack([m["cx"], m["ymin"], m["cz"]], 1)[sel], p, R, s)
    # 칸 크기가 0.25 보다 크면 둘레도 찍는다
    r = float(m["cell"]) * s / 2
    pts = [c[:, [0, 2]]]
    if r > CELL * 0.6:
        for dx in (-r * 0.6, r * 0.6):
            for dz in (-r * 0.6, r * 0.6):
                pts.append(c[:, [0, 2]] + [dx, dz])
    P = np.concatenate(pts)
    ix = np.floor(P[:, 0] / CELL).astype(np.int64)
    iz = np.floor(P[:, 1] / CELL).astype(np.int64)
    return np.unique(ix * 100000 + iz)


def main():
    H = C.load_height()
    man = C.load_manifest()
    O = C.load_objects()["objects"]
    T = C.load_trees()
    cache = {}
    items = []
    for i, o in enumerate(O):
        if o["a"] == "lotus_glow":
            continue
        items.append(("obj", i, o["a"], o["p"], C.qmat(o["q"]), o["s"]))
    for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
        a = T["prototypes"][pi]
        y = float(C.hsample(H, x, z)) - man[a]["meta"].get("sink", 0) * s
        items.append(("tree", i, a, (x, y, z), C.yaw_mat(yaw), s))
    fps, rads = [], []
    for (src, i, a, p, R, s) in items:
        low_only = man[a]["meta"].get("kind") == "tree" and a.startswith("dead_tree")
        k = cells_of(a, p, R, s, H, cache, low_only)
        fps.append(k)
        m = cache[a]
        rads.append(float(np.max(np.hypot(m["cx"], m["cz"]))) * s + 0.5)
    xs = np.array([it[3][0] for it in items]); zs = np.array([it[3][2] for it in items])
    rads = np.array(rads)
    # 공간 해시
    G = 16.0
    grid = collections.defaultdict(list)
    for k in range(len(items)):
        grid[(int(xs[k] // G), int(zs[k] // G))].append(k)
    pairs = []
    for k in range(len(items)):
        gx, gz = int(xs[k] // G), int(zs[k] // G)
        rr = int(math.ceil((rads[k] + 25) / G))
        for ix in range(gx - rr, gx + rr + 1):
            for iz in range(gz - rr, gz + rr + 1):
                for j in grid.get((ix, iz), ()):
                    if j <= k:
                        continue
                    if (xs[j] - xs[k]) ** 2 + (zs[j] - zs[k]) ** 2 > (rads[j] + rads[k]) ** 2:
                        continue
                    if len(fps[k]) == 0 or len(fps[j]) == 0:
                        continue
                    n = len(np.intersect1d(fps[k], fps[j], assume_unique=True))
                    if n:
                        area = n * CELL * CELL
                        small = min(len(fps[k]), len(fps[j])) * CELL * CELL
                        pairs.append((k, j, area, area / small))
    print("겹치는 쌍 (발자국 칸이 하나라도 겹침) %d" % len(pairs))

    def name(k):
        src, i, a, p, R, s = items[k]
        return "%s %s#%d (%.1f, %.1f)" % (a, src, i, p[0], p[2])

    print("\n== 랜드마크 발자국과 겹치는 것 (넓이 > 0.1 m²)")
    for (k, j, area, frac) in sorted(pairs, key=lambda t: -t[2]):
        a, b = items[k][2], items[j][2]
        if (a in LANDMARKS or b in LANDMARKS) and area > 0.1:
            print("  %-45s × %-45s 겹침 %.2f m² (작은 쪽의 %.0f%%)" % (name(k), name(j), area, frac * 100))
    print("\n== 큰 소품끼리 파고듦 (둘 다 벽·기둥·아치·절벽·큰 바위·석관·석상·등불·울타리·통나무·나무 줄기 중, 넓이 > 0.3 m² 그리고 작은 쪽의 15% 넘게)")
    cnt = collections.Counter()
    shown = collections.Counter()
    for (k, j, area, frac) in sorted(pairs, key=lambda t: -t[2]):
        a, b = items[k][2], items[j][2]
        if a in LANDMARKS or b in LANDMARKS:
            continue
        if a in BIGISH and b in BIGISH and area > 0.3 and frac > 0.15:
            key = tuple(sorted((a, b)))
            cnt[key] += 1
            if shown[key] < 3:
                shown[key] += 1
                print("  %-45s × %-45s 겹침 %.2f m² (%.0f%%)" % (name(k), name(j), area, frac * 100))
    print("\n  종류 쌍별 수:", ", ".join("%s×%s %d" % (k[0], k[1], v) for k, v in cnt.most_common()))
    print("\n== 전체: 종류 쌍별 겹침 (넓이 > 0.15 m², 작은 쪽의 25% 넘게) 상위 25")
    c2 = collections.Counter()
    for (k, j, area, frac) in pairs:
        if area > 0.15 and frac > 0.25:
            c2[tuple(sorted((items[k][2], items[j][2])))] += 1
    for k, v in c2.most_common(25):
        print("  %-16s × %-16s %d" % (k[0], k[1], v))


if __name__ == "__main__":
    main()
