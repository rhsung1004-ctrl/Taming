# 다리 검사: 경간 방향, 양 끝 둑 높이와 상판 높이, 교각·둑 바닥의 뜸, 다리 위 길 연결
#   python3 check_bridge.py
import numpy as np, math
import common as C

H = C.load_height()
W = C.load_world()
ob = [x for x in C.load_objects()["objects"] if x["a"] == "bridge_ruin"][0]
m = C.mesh_columns("bridge_ruin")
R = C.qmat(ob["q"]); s = ob["s"]; p = np.array(ob["p"])
roads = C.Roads()
ax = R @ [1, 0, 0]
print("다리 위치", ob["p"], "로컬 X(경간) 방향 (%.3f, %.3f)" % (ax[0], ax[2]), "개울 직각 축", roads.creek["axis"].round(3), "개울 방향", roads.creek["dir"].round(3))
print("경간과 개울 흐름 사이 각 %.1f° (90° 이면 개울을 똑바로 건넌다)" % math.degrees(math.acos(abs(ax[0] * roads.creek["dir"][0] + ax[2] * roads.creek["dir"][1]))))
# 길 곡선 두 개 (다리 동쪽 / 서쪽) 끝 방향
for k in (11, 12):
    c, hw = roads.curves[k]
    end = c[-1] if k == 11 else c[0]
    nxt = c[-6] if k == 11 else c[5]
    d = (end - nxt) / np.linalg.norm(end - nxt)
    ang = math.degrees(math.acos(abs(d[0] * ax[0] + d[1] * ax[2])))
    loc = R.T @ (np.array([end[0], 0, end[1]]) - p)
    print("길 %d 끝점 (%.1f, %.1f) 다리 로컬 (x %.2f, z %.2f), 마지막 10 m 방향과 경간 사이 %.1f°" % (k, end[0], end[1], loc[0], loc[2], ang))
    # 길 중심선이 다리 로컬 z 로 얼마나 벗어나는지 (끝에서 20 m 까지)
    seg = c[-12:] if k == 11 else c[:12]
    lz = [(R.T @ (np.array([q[0], 0, q[1]]) - p))[2] for q in seg]
    lx = [(R.T @ (np.array([q[0], 0, q[1]]) - p))[0] for q in seg]
    print("   길 중심선의 다리 로컬 (x, z):", " ".join("(%.1f,%.2f)" % (a, b) for a, b in zip(lx, lz)))
# 상판 윗면 (가운데 띠 |z|<1.0) 과 지형
print("\n로컬 x   상판 윗면 y   지형 y   (윗면 − 지형)   바닥 최저 y  바닥 − 지형")
band = np.abs(m["cz"]) < 1.0
for x0 in np.arange(-8, 8.5, 1.0):
    sel = band & (np.abs(m["cx"] - x0) < 0.3)
    wpt = p + R @ (np.array([x0, 0, 0]) * s)
    hh = C.hsample(H, wpt[0], wpt[2])
    if sel.any():
        top = p[1] + m["ymax"][sel].max() * s
        lo = p[1] + m["ymin"][sel].min() * s
        print("%5.1f   %8.2f   %8.2f   %+6.2f   %8.2f   %+6.2f" % (x0, top, hh, top - hh, lo, lo - hh))
    else:
        print("%5.1f   (메쉬 없음)   %8.2f" % (x0, hh))
# 다리 끝 너머 길 위 지형 (x = ±7.6 ~ ±12)
print("\n둑 높이 (다리 축을 따라, 다리 원점 y = %.2f, world.levels.creekPool = %.3f)" % (p[1], W["levels"]["creekPool"]))
for x0 in (-12, -10, -8.5, -7.6, -7.0, 7.0, 7.6, 8.5, 10, 12):
    for z0 in (-1.5, 0, 1.5):
        wpt = p + R @ (np.array([x0, 0, z0]) * s)
        print("  로컬 (%5.1f, %4.1f) → 지형 %.2f (원점 대비 %+.2f)" % (x0, z0, C.hsample(H, wpt[0], wpt[2]), C.hsample(H, wpt[0], wpt[2]) - p[1]))
# 교각·물가름 바닥 (로컬 |x| 4~6) 과 개울 바닥
sel = (np.abs(np.abs(m["cx"]) - 5.0) < 1.0) & (m["ymin"] < -1.5)
low = C.transform(m["low"][sel], p, R, s)
g = low[:, 1] - C.hsample(H, low[:, 0], low[:, 2])
print("\n교각·물가름 바닥 칸 %d: 바닥 − 지형 최소 %.2f, 중앙 %.2f, 최대 %.2f (양수 = 떠 있음)" % (sel.sum(), g.min(), np.median(g), g.max()))
# 아치 아래 수면과 아치 아랫면
lev = W["levels"]["creekPool"]
sel = (np.abs(m["cx"]) < 3.5) & (np.abs(m["cz"]) < 1.5)
print("아치 아랫면 최저 y (|x|<3.5): %.2f, 수면 %.2f → 수면 위 %.2f m" % (p[1] + m["ymin"][sel].min() * s, lev, p[1] + m["ymin"][sel].min() * s - lev))
# 다리 끝 턱: 상판 끝 윗면 (로컬 |z|<1.2, 끝에서 0.3 m 안 정점 최고 y) 과 바로 밖(끝 + 0.1 m) 지형의 차
import fbxmesh
U, Tr, _ = fbxmesh.lod0_vertices(C.KIT + "/bridge_ruin.fbx")
band = np.abs(U[:, 2]) < 1.2
print("\n다리 끝 턱 (캐릭터 stepOffset 0.35 m 보다 높으면 올라설 수 없다)")
for sgn in (-1, 1):
    xe = U[:, 0].max() if sgn > 0 else U[:, 0].min()
    sel = band & (np.abs(U[:, 0] - xe) < 0.3)
    top = p[1] + U[sel, 1].max() * s
    wpt = p + R @ (np.array([xe + sgn * 0.1, 0, 0]) * s)
    hh = C.hsample(H, wpt[0], wpt[2])
    print("  %s 끝 (로컬 x %.2f): 상판 윗면 %.2f, 바로 밖 지형 %.2f → 턱 %.2f m" % ("동" if sgn > 0 else "서", xe, top, hh, top - hh))
