# 랜드마크 안(발자국 위)에 놓인 소품·나무: 그 자리 랜드마크 메쉬 윗면(바닥)과 소품 바닥 높이를 비교
#   python3 check_inside.py
# 또 Placer.free() 가 보는 창(반지름 r + 8 m)보다 큰 발자국(META.footprint × 크기)을 가진 소품 둘레에서
# 간격 규칙 (거리² < (r1 + r2)² × 0.85) 을 어긴 것을 센다
import numpy as np
import common as C

H = C.load_height()
man = C.load_manifest()
O = C.load_objects()["objects"]
T = C.load_trees()
LM = ["cathedral_ruin", "crypt", "altar", "gate_great", "watchtower_ruin", "tree_giant", "bridge_ruin", "well", "stair_ruin", "dragon_skull"]
items = [(o["a"], "obj", i, o["p"][0], o["p"][1], o["p"][2], o["s"]) for i, o in enumerate(O)]
for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
    a = T["prototypes"][pi]
    items.append((a, "tree", i, x, float(C.hsample(H, x, z)) - man[a]["meta"].get("sink", 0) * s, z, s))
X = np.array([it[3] for it in items]); Z = np.array([it[5] for it in items])
for lm in LM:
    for o in [o for o in O if o["a"] == lm]:
        m = C.mesh_columns(lm)
        R = C.qmat(o["q"]); s = o["s"]; p = np.array(o["p"])
        inv = R.T
        rel = np.stack([X - p[0], np.zeros_like(X), Z - p[2]], 1) @ inv.T / s      # 로컬
        c = float(m["cell"])
        inside = (rel[:, 0] > m["bmin"][0]) & (rel[:, 0] < m["bmax"][0]) & (rel[:, 2] > m["bmin"][2]) & (rel[:, 2] < m["bmax"][2])
        print("== %s (%.1f, %.1f): 로컬 경계 상자 안 소품·나무 %d" % (lm, p[0], p[2], inside.sum() - 1))
        for k in np.nonzero(inside)[0]:
            a, src, i, x, y, z, ss = items[k]
            if a == lm:
                continue
            # 그 자리 메쉬 기둥 (가장 가까운 칸)
            d = np.hypot(m["cx"] - rel[k, 0], m["cz"] - rel[k, 2])
            j = int(np.argmin(d))
            if d[j] > c * 1.5:
                where = "메쉬 없는 빈 곳 (바닥 없음)"
                top = None
            else:
                top = p[1] + m["ymax"][j] * s
                bot = p[1] + m["ymin"][j] * s
                where = "기둥 바닥 %.2f 윗면 %.2f" % (bot, top)
            hh = C.hsample(H, x, z)
            note = ""
            if top is not None:
                if top - y > 0.6:
                    note = "← 벽·기둥 속 (소품 바닥보다 메쉬 윗면이 %.2f m 높음)" % (top - y)
                elif top - y > 0.05:
                    note = "← 바닥에 %.2f m 묻힘" % (top - y)
                elif y - top > 0.1:
                    note = "← 바닥 위 %.2f m 떠 있음" % (y - top)
            print("   %-14s %s#%-5d (%.1f, %.1f) 소품 y %.2f 지형 %.2f | %s %s" % (a, src, i, x, z, y, hh, where, note))
# free() 창 문제
print("\n== 큰 발자국 둘레 간격 규칙 위반 (Placer.free 는 반지름 r + 8 m 안의 칸만 본다)")
fp = np.array([man[it[0]]["meta"].get("footprint", 0.5) * it[6] for it in items])
big = np.nonzero(fp > 7.0)[0]
for k in big:
    a, src, i, x, y, z, s = items[k]
    d2 = (X - x) ** 2 + (Z - z) ** 2
    viol = np.nonzero((d2 < (fp + fp[k]) ** 2 * 0.85) & (np.arange(len(items)) != k))[0]
    if len(viol):
        kinds = {}
        for j in viol:
            kinds[items[j][0]] = kinds.get(items[j][0], 0) + 1
        print("  %-14s %s#%d (%.1f, %.1f) 발자국 %.1f m: 간격 규칙 안쪽 %d개 %s" % (a, src, i, x, z, fp[k], len(viol), kinds))
