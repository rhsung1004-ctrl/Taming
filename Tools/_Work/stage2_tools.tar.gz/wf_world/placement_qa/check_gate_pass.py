# 문 통과 검사: 묘지 정문(fence_gate) 과 북쪽 봉인문(gate_great)
#   python3 check_gate_pass.py
# 1) 문 폭 안(로컬 |x| < 한계)으로만 앞 → 뒤로 캐릭터(반지름 0.4 m, 걸음 높이 0.35~1.8 m)가 지나갈 수 있는지 (0.05 m 격자 BFS)
#    LOD0 정점 + 삼각형 안쪽 점을 쓴다 (Unity 충돌은 LOD1 이라 조금 다를 수 있다)
# 2) 문 옆으로 돌아갈 수 있는지: 문 줄(월드 z)에서 걸을 수 있는 땅(기울기 ≤ 1.0)이 문보다 얼마나 넓은지
import math, collections
import numpy as np
import common as C, fbxmesh

H = C.load_height()
gzr, gxr = np.gradient(H)
SL = np.sqrt(gxr * gxr + gzr * gzr)
O = C.load_objects()["objects"]
for name, lim in (("fence_gate", 1.6), ("gate_great", 7.9)):
    o = [x for x in O if x["a"] == name][0]
    U, T, _ = fbxmesh.lod0_vertices(C.KIT + "/%s.fbx" % name)
    A, B, Cc = U[T[:, 0]], U[T[:, 1]], U[T[:, 2]]
    P = np.concatenate([U, (A + B + Cc) / 3, (A + B) / 2, (B + Cc) / 2, (Cc + A) / 2,
                        A * 0.6 + B * 0.2 + Cc * 0.2, A * 0.2 + B * 0.6 + Cc * 0.2, A * 0.2 + B * 0.2 + Cc * 0.6])
    base = float(C.hsample(H, o["p"][0], o["p"][2])) - o["p"][1]          # 지형 높이 (로컬, 문 자리는 평평)
    S = P[(P[:, 1] > base + 0.35) & (P[:, 1] < base + 1.8)]
    g = 0.05
    gx = np.arange(-lim - 1, lim + 1, g)
    gz = np.arange(U[:, 2].min() - 1.5, U[:, 2].max() + 1.5, g)
    occ = np.zeros((len(gz), len(gx)), bool)
    ix = np.round((S[:, 0] - gx[0]) / g).astype(int)
    iz = np.round((S[:, 2] - gz[0]) / g).astype(int)
    k = int(math.ceil(0.4 / g))
    for dx in range(-k, k + 1):
        for dz in range(-k, k + 1):
            if (dx * g) ** 2 + (dz * g) ** 2 <= 0.16:
                a = iz + dz; b = ix + dx
                m = (a >= 0) & (a < len(gz)) & (b >= 0) & (b < len(gx))
                occ[a[m], b[m]] = True
    occ[:, np.abs(gx) > lim] = True
    prev = {}
    q = collections.deque()
    for j in range(len(gx)):
        if not occ[0, j]:
            q.append((0, j)); prev[(0, j)] = None
    end = None
    while q:
        a, b = q.popleft()
        if a == len(gz) - 1:
            end = (a, b); break
        for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            aa, bb = a + da, b + db
            if 0 <= aa < len(gz) and 0 <= bb < len(gx) and not occ[aa, bb] and (aa, bb) not in prev:
                prev[(aa, bb)] = (a, b); q.append((aa, bb))
    print("== %s (%.1f, %.1f) 로컬 X %.2f~%.2f" % (name, o["p"][0], o["p"][2], U[:, 0].min(), U[:, 0].max()))
    print("   문 폭 안(로컬 |x| < %.1f)으로 앞 → 뒤 지나감: %s" % (lim, "예" if end else "아니오 (막힘)"))
    if end:
        path = []
        c = end
        while c:
            path.append(c); c = prev[c]
        path = path[::-1]
        print("   경로 (로컬 x, z):", [(round(gx[b], 2), round(gz[a], 2)) for a, b in path[::10]])
    # 문 옆 땅
    R = C.qmat(o["q"])
    wx0 = o["p"][0] + (R @ [U[:, 0].min(), 0, 0])[0]
    wx1 = o["p"][0] + (R @ [U[:, 0].max(), 0, 0])[0]
    z = int(round(o["p"][2]))
    xs = np.arange(int(o["p"][0]) - 150, int(o["p"][0]) + 151)
    okw = SL[z, xs] <= 1.0
    # 문 양쪽 이어진 걸을 수 있는 폭
    left = 0
    x = int(min(wx0, wx1)) - 1
    while x > xs[0] and SL[z, x] <= 1.0:
        left += 1; x -= 1
    right = 0
    x = int(max(wx0, wx1)) + 1
    while x < xs[-1] and SL[z, x] <= 1.0:
        right += 1; x += 1
    print("   문 줄 z=%d: 문 월드 x %.1f~%.1f, 문 왼쪽(서) 걸을 수 있는 땅 %d m%s, 오른쪽(동) %d m%s" % (
        z, min(wx0, wx1), max(wx0, wx1), left, "+" if left >= 149 - (o["p"][0] - min(wx0, wx1)) else "", right, "+" if right >= 149 - (max(wx0, wx1) - o["p"][0]) else ""))
fg = [x for x in O if x["a"] == "fence_gate"][0]
fs = [x for x in O if x["a"] == "fence" and math.hypot(x["p"][0] - fg["p"][0], x["p"][2] - fg["p"][2]) < 20]
print("\n정문 20 m 안 울타리:", [(round(x["p"][0], 1), round(x["p"][2], 1)) for x in fs])
