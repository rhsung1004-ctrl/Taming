# 최소 FBX 바이너리 읽기: LOD0 메쉬 정점을 Unity 로컬 좌표(x 오른쪽, y 위, z 앞)로 돌려준다
#   python3 fbxmesh.py <fbx> [manifest size x,y,z]  → 정점 범위 출력 (검증용)
# FBX 정점은 Blender 내보내기(bake_space_transform, -Z forward, Y up)로 (bx, bz, -by) 이고,
# Unity 는 FBX 를 들여올 때 X 를 뒤집어 Unity 로컬 = (-bx, bz, -by) (SPEC.md 의 C_o 와 같다)
import struct, zlib, sys
import numpy as np


def _read_prop(b, o):
    t = chr(b[o]); o += 1
    if t == 'Y':
        return struct.unpack_from('<h', b, o)[0], o + 2
    if t == 'C':
        return b[o] != 0, o + 1
    if t == 'I':
        return struct.unpack_from('<i', b, o)[0], o + 4
    if t == 'F':
        return struct.unpack_from('<f', b, o)[0], o + 4
    if t == 'D':
        return struct.unpack_from('<d', b, o)[0], o + 8
    if t == 'L':
        return struct.unpack_from('<q', b, o)[0], o + 8
    if t in 'fdlib':
        n, enc, cl = struct.unpack_from('<III', b, o); o += 12
        raw = b[o:o + cl]; o += cl
        if enc == 1:
            raw = zlib.decompress(raw)
        dt = {'f': '<f4', 'd': '<f8', 'l': '<i8', 'i': '<i4', 'b': 'u1'}[t]
        return np.frombuffer(raw, dt, n), o
    if t in 'SR':
        n = struct.unpack_from('<I', b, o)[0]; o += 4
        v = b[o:o + n]; o += n
        return (v.decode('utf8', 'replace') if t == 'S' else v), o
    raise ValueError("알 수 없는 속성 형식 %r" % t)


def _read_node(b, o, v64):
    if v64:
        end, nprop, plen = struct.unpack_from('<QQQ', b, o); o += 24
    else:
        end, nprop, plen = struct.unpack_from('<III', b, o); o += 12
    nl = b[o]; o += 1
    if end == 0:
        return None, o
    name = b[o:o + nl].decode('ascii', 'replace'); o += nl
    props = []
    for _ in range(nprop):
        p, o = _read_prop(b, o)
        props.append(p)
    kids = []
    null = 25 if v64 else 13
    while o < end - null + 0 and o < end:
        if end - o == null:
            break
        k, o2 = _read_node(b, o, v64)
        if k is None:
            o = o2
            break
        kids.append(k)
        o = o2
    return (name, props, kids), end


def parse(path):
    b = open(path, 'rb').read()
    assert b[:18] == b'Kaydara FBX Binary', "바이너리 FBX 아님"
    ver = struct.unpack_from('<I', b, 23)[0]
    v64 = ver >= 7500
    o = 27
    top = []
    while o < len(b):
        n, o = _read_node(b, o, v64)
        if n is None:
            break
        top.append(n)
    return top


def find(nodes, name):
    return [n for n in nodes if n[0] == name]


def lod0_vertices(path):
    """LOD0 메쉬 정점 (Unity 로컬, m) 과 삼각형 인덱스 (폴리곤 부채꼴)"""
    top = parse(path)
    objs = find(top, 'Objects')[0][2]
    conns = find(top, 'Connections')[0][2]
    geoms = {g[1][0]: g for g in find(objs, 'Geometry')}
    models = {m[1][0]: m for m in find(objs, 'Model')}
    # Model 이름 'xxx_LOD0\x00\x01Model'
    lod0 = [mid for mid, m in models.items() if m[1][1].split('\x00')[0].endswith('_LOD0')]
    gid = None
    for c in conns:
        p = c[1]
        if p[0] == 'OO' and p[2] in lod0 and p[1] in geoms:
            gid = p[1]
    if gid is None:      # LOD 이름이 없으면 정점이 가장 많은 것
        gid = max(geoms, key=lambda k: len(find(geoms[k][2], 'Vertices')[0][1][0]))
    g = geoms[gid]
    V = find(g[2], 'Vertices')[0][1][0].reshape(-1, 3).astype(np.float64)
    idx = find(g[2], 'PolygonVertexIndex')[0][1][0].astype(np.int64)
    # 모델 변환 (bake_space_transform 이면 단위 행렬이어야 한다)
    m = models[[c[1][2] for c in conns if c[1][0] == 'OO' and c[1][1] == gid][0]]
    xf = {}
    for p70 in find(m[2], 'Properties70'):
        for P in p70[2]:
            xf[P[1][0]] = P[1][4:]
    # 단위: GlobalSettings UnitScaleFactor (cm 단위 100 이면 m 로)
    usf = 1.0
    for gs in find(top, 'GlobalSettings'):
        for p70 in find(gs[2], 'Properties70'):
            for P in p70[2]:
                if P[1][0] == 'UnitScaleFactor':
                    usf = float(P[1][4])
    sc = xf.get('Lcl Scaling', [1, 1, 1])
    V = V * np.array(sc, float) * usf / 100.0
    tr = np.array(xf.get('Lcl Translation', [0, 0, 0]), float) * usf / 100.0
    V = V + tr
    # 삼각형 (음수 = 폴리곤 끝, ~i)
    tris = []
    poly = []
    for i in idx:
        if i < 0:
            poly.append(~i)
            for k in range(1, len(poly) - 1):
                tris.append((poly[0], poly[k], poly[k + 1]))
            poly = []
        else:
            poly.append(i)
    U = np.stack([-V[:, 0], V[:, 1], V[:, 2]], 1)     # Unity 로컬 (X 뒤집기)
    return U, np.array(tris, np.int64), {'xf': xf, 'usf': usf}


if __name__ == "__main__":
    U, T, info = lod0_vertices(sys.argv[1])
    print("정점", len(U), "삼각형", len(T), "단위", info['usf'], {k: v for k, v in info['xf'].items() if k.startswith('Lcl')})
    print("Unity 로컬 범위 x %.2f~%.2f  y %.2f~%.2f  z %.2f~%.2f" % (U[:, 0].min(), U[:, 0].max(), U[:, 1].min(), U[:, 1].max(), U[:, 2].min(), U[:, 2].max()))
    print("크기 (Blender x,y,z 순서로) %.2f %.2f %.2f" % (np.ptp(U[:, 0]), np.ptp(U[:, 2]), np.ptp(U[:, 1])))
