# 들어갈 수 있게 만든 건물(대성당·납골당·망루) 입구: 앞면(로컬 +Z) 중심선을 따라 바닥 윗면 − 지형 (턱 높이)
#   python3 check_entrances.py
# 칸마다 "걸음 높이 아래 가장 높은 면" = 로컬 정점 가운데 (지형 + 1.0 m) 아래에서 가장 높은 y
import numpy as np
import common as C, fbxmesh

H = C.load_height()
O = C.load_objects()["objects"]
for name in ("cathedral_ruin", "crypt", "watchtower_ruin"):
    o = [x for x in O if x["a"] == name][0]
    R = C.qmat(o["q"]); p = np.array(o["p"]); s = o["s"]
    U, T, _ = fbxmesh.lod0_vertices(C.KIT + "/%s.fbx" % name)
    A, B, Cc = U[T[:, 0]], U[T[:, 1]], U[T[:, 2]]
    P = np.concatenate([U, (A + B + Cc) / 3, (A + B) / 2, (B + Cc) / 2, (Cc + A) / 2])
    print("== %s (%.1f, %.1f) 로컬 z %.2f~%.2f (앞면 +z)" % (name, p[0], p[2], U[:, 2].min(), U[:, 2].max()))
    for xoff in (0.0, -1.0, 1.0):
        line = []
        for z0 in np.arange(U[:, 2].max() + 1.0, U[:, 2].max() - 8.0, -0.5):
            w = p + R @ (np.array([xoff, 0, z0]) * s)
            hh = C.hsample(H, w[0], w[2])
            sel = (np.abs(P[:, 0] - xoff) < 0.3) & (np.abs(P[:, 2] - z0) < 0.3)
            ys = p[1] + P[sel, 1] * s
            low = ys[ys < hh + 1.0]
            top = low.max() if len(low) else np.nan
            line.append("%.1f:%s" % (z0, "%+.2f" % (top - hh) if not np.isnan(top) else " 땅"))
        print("  로컬 x %+.1f 앞→안: %s" % (xoff, " ".join(line)))
