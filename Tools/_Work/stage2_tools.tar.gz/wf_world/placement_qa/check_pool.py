# 개울 웅덩이: 개울 중심선을 따라 지형과 수면, 물 평면 끝에서 물이 끊겨 보이는지
#   python3 check_pool.py
import numpy as np
import common as C

H = C.load_height()
W = C.load_world()
O = C.load_objects()
planes = O["water"]
roads = C.Roads()
c = roads.creek["curve"]
s = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(c, axis=0), axis=1))])
bx, bz = roads.creek["bridge"]
ib = int(np.argmin(np.hypot(c[:, 0] - bx, c[:, 1] - bz)))
sb = s[ib]
lev = W["levels"]["creekPool"]
print("다리 s = %.1f m, 웅덩이 수면 %.3f, 물 평면 범위 s %.1f ~ %.1f" % (sb, lev, sb - 36, sb + 36))
print("  s−sb    x       z     지형(중심)  수면−지형  물평면안")
for k in range(len(c)):
    d = s[k] - sb
    if -60 <= d <= 60 and k % 2 == 0:
        h = C.hsample(H, c[k, 0], c[k, 1])
        lv, wh = C.water_at(planes, [c[k, 0]], [c[k, 1]])
        print("  %+5.1f  %6.1f  %7.1f   %7.2f   %+6.2f    %s" % (d, c[k, 0], c[k, 1], h, lev - h, "예" if not np.isnan(lv[0]) else "-"))
# 물 평면 사각형 가장자리 둘레에서 지형이 수면보다 낮은 점 (물 평면이 끊겨 보이는 곳)
print("\n물 평면 바깥 1 m 안쪽 띠에서 지형 < 수면 인 점 (평면이 끝나는 자리에 물이 '잘려' 보임)")
import math
for i, w in enumerate(planes[2:], 2):
    px, py, pz = w["p"]; sx, sz = w["size"]; t = math.radians(w["yaw"])
    ux = np.array([math.cos(t), -math.sin(t)]); vz = np.array([math.sin(t), math.cos(t)])
    pts = []
    for u in np.linspace(-sx / 2, sx / 2, 31):
        for v in (-sz / 2 - 0.5, sz / 2 + 0.5):
            pts.append(np.array([px, pz]) + ux * u + vz * v)
    for v in np.linspace(-sz / 2, sz / 2, 31):
        for u in (-sx / 2 - 0.5, sx / 2 + 0.5):
            pts.append(np.array([px, pz]) + ux * u + vz * v)
    pts = np.array(pts)
    lv, _ = C.water_at(planes, pts[:, 0], pts[:, 1])
    h = C.hsample(H, pts[:, 0], pts[:, 1])
    out = np.isnan(lv) & (h < py)
    print("  평면 %d: 가장자리 바깥 점 %d 중 지형이 수면보다 낮은 점 %d (최대 %.2f m 낮음)%s" % (
        i, len(pts), out.sum(), (py - h[out]).max() if out.any() else 0, "  예: " + ", ".join("(%.1f, %.1f)" % tuple(q) for q in pts[out][:4]) if out.any() else ""))
