# check_ground.py 결과(csv)를 걸을 수 있는 범위 안/밖, 경사로 나눠 본다
#   python3 summarize_ground.py
import csv, collections, math
import numpy as np
import common as C

W = C.load_world()
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]
wg = C.worldgen()


def dout(x, z):
    return max(b0x - x, x - b1x, b0z - z, z - b1z, 0.0)


def src(a, x, z):
    if a.startswith("cliff"):
        if math.hypot(x - wg.DRAGON[0], z - wg.DRAGON[1]) < wg.DRAGON_R + 30:
            return "용의 무덤 테두리"
        return "산기슭/언덕 꼭대기"
    return ""


for fn in ("ground_objects.csv", "ground_trees.csv"):
    rows = list(csv.DictReader(open(C.HERE + "/" + fn)))
    print("== %s" % fn)
    by = collections.defaultdict(list)
    for r in rows:
        by[r["a"]].append(r)
    print("%-14s %6s | %-42s | %-42s" % ("종류", "개수", "범위 안: 개수 / 뜸>0.25 / 뜸>0.5 / 가운데묻힘≥30%", "범위 밖 0~60 m: 개수 / 뜸>0.25 / 뜸>0.5 / 가운데묻힘"))
    for a, L in sorted(by.items(), key=lambda kv: -len(kv[1])):
        def st(sel):
            f = np.array([float(r["fmax"]) for r in sel]) if sel else np.zeros(0)
            bm = np.array([float(r["bmedfrac"]) for r in sel]) if sel else np.zeros(0)
            return "%5d / %5d / %5d / %5d" % (len(sel), (f > 0.25).sum(), (f > 0.5).sum(), (bm >= 0.3).sum())
        ins = [r for r in L if dout(float(r["x"]), float(r["z"])) == 0]
        near = [r for r in L if 0 < dout(float(r["x"]), float(r["z"])) <= 60]
        if any(float(r["fmax"]) > 0.25 or float(r["bmedfrac"]) >= 0.3 for r in L):
            print("%-14s %6d | %-42s | %-42s" % (a, len(L), st(ins), st(near)))
    # 범위 안 뜬 것 목록 (큰 것)
    for a in ("cliff_a", "cliff_b", "cliff_c", "rock_b", "rock_flat", "rock_a", "log_fallen", "wall_ruin_a", "pillar_b", "fence", "dead_tree_b", "dead_tree_c", "dead_tree_a"):
        L = [r for r in by.get(a, []) if dout(float(r["x"]), float(r["z"])) == 0 and float(r["fmax"]) > 0.5]
        if L:
            L.sort(key=lambda r: -float(r["fmax"]))
            print("  범위 안 %s 뜸>0.5 m: %d 개, 예: %s" % (a, len(L), "; ".join("#%s (%.0f, %.0f) 경사 %.2f 뜸 %.2f m%s" % (
                r["i"], float(r["x"]), float(r["z"]), float(r["slope"]), float(r["fmax"]), (" " + src(a, float(r["x"]), float(r["z"]))) if src(a, float(r["x"]), float(r["z"])) else "") for r in L[:6])))
    # 경사별 (범위 안 + 밖 60 m)
    print()
