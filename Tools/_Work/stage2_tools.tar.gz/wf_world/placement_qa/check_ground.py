# 떠 있음 / 묻힘 검사
#   python3 check_ground.py [--all]      (--all: 큰 소품 말고도 모든 소품 한 줄씩)
# 소품 LOD0 메쉬를 칸(기둥)으로 나눠, 땅에 닿도록 만든 칸(로컬 최저 y × 크기 ≤ 0.10 m)의 최저점을
# 실제 회전·크기·위치로 옮긴 뒤 그 자리 지형 높이와 비교한다.
#   gap > 0  : 그 칸의 바닥이 땅 위에 떠 있다 (m)
#   gap < 0  : 땅속에 묻혔다 (m)
# 결과: ground_objects.csv, ground_trees.csv (같은 폴더)
import sys, os, math, csv
import numpy as np
import common as C

FLOAT = 0.25          # 이보다 많이 뜨면 문제
BURY_FRAC = 0.30      # 높이의 이 비율 이상 묻히면 문제
CONTACT = 0.10        # 로컬 최저 y × 크기 가 이 값 이하인 칸 = 땅에 닿게 만든 칸 (평평한 땅에서 뜸 0.10 − sink 이하)
BIG = {"crypt", "cathedral_ruin", "gate_great", "bridge_ruin", "watchtower_ruin", "dragon_skull", "dragon_spine",
       "dragon_ribs", "dragon_claw", "altar", "tree_giant", "cliff_a", "cliff_b", "cliff_c", "wall_ruin_a", "wall_ruin_b",
       "arch_ruin", "stair_ruin", "well", "statue_angel", "statue_reaper", "fence_gate"}


def analyse(name, cols, p, R, s, H):
    m = cols["ymin"] * s <= CONTACT
    if m.sum() < 3:
        m = cols["ymin"] <= np.percentile(cols["ymin"], 10)
    low = cols["low"][m]
    w = C.transform(low, p, R, s)
    g = w[:, 1] - C.hsample(H, w[:, 0], w[:, 2])
    height = (cols["bmax"][1] - cols["bmin"][1]) * s
    # 땅이 기둥 꼭대기보다 높은 칸 (바닥·낮은 판을 땅이 뚫고 올라옴)
    top = np.stack([cols["cx"], cols["ymax"], cols["cz"]], 1)
    wt = C.transform(top, p, R, s)
    poke = C.hsample(H, wt[:, 0], wt[:, 2]) - wt[:, 1]
    # 밖 둘레 칸만 따로 (가장자리가 뜨는 것이 눈에 띈다): 중심에서 먼 30%
    r = np.hypot(low[:, 0], low[:, 2])
    edge = r >= np.percentile(r, 70)
    return {
        "fmax": float(g.max()), "ffrac": float((g > FLOAT).mean()), "fedge": float((g[edge] > FLOAT).mean()),
        "bmax": float(-g.min()), "bmed": float(-np.median(g)), "height": height,
        "bfrac": float(-g.min() / max(height, 1e-6)), "bmedfrac": float(-np.median(g) / max(height, 1e-6)),
        "worst": w[int(np.argmax(g))], "ncont": int(m.sum()),
        "poke": float(poke.max()), "pokefrac": float((poke > 0.05).mean()), "pokeat": wt[int(np.argmax(poke))],
    }


def main():
    show_all = "--all" in sys.argv
    H = C.load_height()
    gz, gx = np.gradient(H)
    SL = np.sqrt(gx * gx + gz * gz)
    man = C.load_manifest()
    objs = C.load_objects()["objects"]
    trees = C.load_trees()
    rows = []
    cache = {}
    for i, o in enumerate(objs):
        a = o["a"]
        if a not in cache:
            cache[a] = C.mesh_columns(a)
        R = C.qmat(o["q"])
        r = analyse(a, cache[a], o["p"], R, o["s"], H)
        x, y, z = o["p"]
        r.update({"i": i, "a": a, "x": x, "y": y, "z": z, "s": o["s"], "slope": float(C.hsample(SL, x, z)),
                  "tilt": math.degrees(math.acos(max(-1, min(1, (R @ [0, 1, 0])[1]))))})
        rows.append(r)
    trow = []
    for i, (pi, x, z, yaw, s) in enumerate(trees["instances"]):
        a = trees["prototypes"][pi]
        if a not in cache:
            cache[a] = C.mesh_columns(a)
        sink = man[a]["meta"].get("sink", 0.0)
        y = float(C.hsample(H, x, z)) - sink * s
        r = analyse(a, cache[a], (x, y, z), C.yaw_mat(yaw), s, H)
        r.update({"i": i, "a": a, "x": x, "y": y, "z": z, "s": s, "slope": float(C.hsample(SL, x, z)), "tilt": 0.0})
        trow.append(r)

    keys = ["i", "a", "x", "y", "z", "s", "slope", "tilt", "fmax", "ffrac", "fedge", "bmax", "bmed", "height", "bfrac", "bmedfrac", "ncont", "poke", "pokefrac"]
    for fn, rr in (("ground_objects.csv", rows), ("ground_trees.csv", trow)):
        with open(os.path.join(C.HERE, fn), "w", newline="") as f:
            wr = csv.writer(f)
            wr.writerow(keys + ["worst_x", "worst_z"])
            for r in rr:
                wr.writerow([("%.3f" % r[k]) if isinstance(r[k], float) else r[k] for k in keys] + ["%.1f" % r["worst"][0], "%.1f" % r["worst"][2]])

    def summary(title, rr):
        print("\n== %s: 종류별 (뜸 = 바닥 칸이 %.2f m 넘게 뜸, 묻힘 = 높이의 %d%% 이상)" % (title, FLOAT, BURY_FRAC * 100))
        print("%-16s %6s %8s %8s %8s %9s %9s %8s %9s" % ("종류", "개수", "뜸>0.25", "뜸>0.5", "뜸>1.0", "최대뜸m", "묻힘30%", "중앙묻30", "최대묻힘"))
        by = {}
        for r in rr:
            by.setdefault(r["a"], []).append(r)
        for a in sorted(by, key=lambda k: -len(by[k])):
            L = by[a]
            f = np.array([r["fmax"] for r in L])
            b = np.array([r["bfrac"] for r in L])
            bm = np.array([r["bmedfrac"] for r in L])
            print("%-16s %6d %8d %8d %8d %9.2f %9d %8d %8.0f%%" % (a, len(L), (f > FLOAT).sum(), (f > 0.5).sum(), (f > 1.0).sum(), f.max(),
                                                               (b >= BURY_FRAC).sum(), (bm >= BURY_FRAC).sum(), b.max() * 100))
        return by

    by = summary("소품 objects.json", rows)
    tby = summary("지형 나무 trees.json", trow)

    print("\n== 큰 소품 하나씩 (fmax = 가장 많이 뜬 바닥 칸, ffrac = 뜬 바닥 칸 비율, bmax = 가장 깊이 묻힌 칸, 경사 = 중심 기울기)")
    print("%-16s %5s %8s %8s %7s %5s %6s %6s %5s %6s %6s %6s %5s  %s" % ("종류", "번호", "x", "z", "y", "크기", "경사", "fmax", "ffrac", "bmax", "b/높이", "뚫림m", "뚫림%", "가장 뜬 곳 / 가장 뚫린 곳"))
    for a in sorted(by):
        if a not in BIG and not show_all:
            continue
        for r in sorted(by[a], key=lambda r: -r["fmax"]):
            flag = ""
            if r["fmax"] > FLOAT:
                flag += " 뜸"
            if r["bfrac"] >= BURY_FRAC:
                flag += " 묻힘"
            if r["poke"] > 0.05:
                flag += " 땅이뚫음"
            print("%-16s %5d %8.1f %8.1f %7.2f %5.2f %6.2f %6.2f %5.0f%% %6.2f %5.0f%% %6.2f %4.1f%%  (%.1f, %.1f) / (%.1f, %.1f)%s" % (
                a, r["i"], r["x"], r["z"], r["y"], r["s"], r["slope"], r["fmax"], r["ffrac"] * 100, r["bmax"], r["bfrac"] * 100,
                r["poke"], r["pokefrac"] * 100, r["worst"][0], r["worst"][2], r["pokeat"][0], r["pokeat"][2], flag))

    print("\n== 작은 소품: 가장 많이 뜬 20개")
    small = [r for r in rows if r["a"] not in BIG and r["a"] != "lotus_glow"]
    for r in sorted(small, key=lambda r: -r["fmax"])[:20]:
        print("  %-14s #%d (%.1f, %.1f) 크기 %.2f 경사 %.2f 기울기 %.1f° fmax %.2f m 뜬 칸 %.0f%%" % (
            r["a"], r["i"], r["x"], r["z"], r["s"], r["slope"], r["tilt"], r["fmax"], r["ffrac"] * 100))
    print("\n== 지형 나무: 가장 많이 뜬 20개")
    for r in sorted(trow, key=lambda r: -r["fmax"])[:20]:
        print("  %-12s #%d (%.1f, %.1f) 크기 %.2f 경사 %.2f fmax %.2f m 뜬 칸 %.0f%%" % (r["a"], r["i"], r["x"], r["z"], r["s"], r["slope"], r["fmax"], r["ffrac"] * 100))
    print("\n== 지형 나무: 경사별 뜸 (fmax > 0.25 비율)")
    for a in sorted(tby):
        L = tby[a]
        sl = np.array([r["slope"] for r in L])
        f = np.array([r["fmax"] for r in L])
        parts = []
        for lo, hi in ((0, 0.2), (0.2, 0.45), (0.45, 0.75), (0.75, 9)):
            mm = (sl >= lo) & (sl < hi)
            if mm.any():
                parts.append("경사 %.2f~%.2f: %d개 중 %d (평균 fmax %.2f)" % (lo, hi, mm.sum(), (f[mm] > FLOAT).sum(), f[mm].mean()))
        print("  %-12s %s" % (a, " | ".join(parts)))


if __name__ == "__main__":
    main()
