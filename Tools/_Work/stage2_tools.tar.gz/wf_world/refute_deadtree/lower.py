# 나무별 추가 묻기 (경사 낙차에 비례) 가정 시험: 남는 뜸, 묻힘, 옮길 그루 수
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement")
import numpy as np
import common as C
import check_ground as G
H = C.load_height()
man = C.load_manifest()
T = C.load_trees()
cols = {}
out = []
for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
    a = T["prototypes"][pi]
    if not a.startswith("dead_tree") or not (170 <= x <= 1878 and 170 <= z <= 1878):
        continue
    cols.setdefault(a, C.mesh_columns(a))
    fp, sink = man[a]["meta"]["footprint"], man[a]["meta"]["sink"]
    h0 = float(C.hsample(H, x, z))
    t = np.arange(8) / 8 * 2 * math.pi
    d10 = h0 - C.hsample(H, x + np.cos(t) * fp * s, z + np.sin(t) * fp * s).min()
    y = h0 - sink * s
    r0 = G.analyse(a, cols[a], (x, y, z), C.yaw_mat(yaw), s, H)
    for thr, cap in ((0.2, 0.6),):
        ex = float(np.clip(d10 - thr, 0, cap))
        r1 = G.analyse(a, cols[a], (x, y - ex, z), C.yaw_mat(yaw), s, H)
    out.append((i, a, x, z, s, d10, ex, r0["fmax"], r1["fmax"], r0["poke"], r1["poke"]))
A = np.array([o[4:] for o in out], float)
s, d10, ex, f0, f1, p0, p1 = A.T
rej = d10 > 0.8
print("추가 묻기 = clip(1.0·fp·s 8점 낙차 − 0.2, 0, 0.6), 낙차 > 0.8 m 는 버림")
print("  버림 %d 그루, 추가 묻기 > 0.05 m: %d 그루 (평균 %.2f m)" % (rej.sum(), ((ex > 0.05) & ~rej).sum(), ex[(ex > 0.05) & ~rej].mean()))
k = ~rej
print("  뜸>0.25: %d → %d, 뜸>0.35: %d → %d, 최대 %.2f → %.2f" % ((f0 > 0.25).sum(), (f1[k] > 0.25).sum(), (f0 > 0.35).sum(), (f1[k] > 0.35).sum(), f0.max(), f1[k].max()))
for o in out:
    if o[5] > 0.8 or o[8] > 0.25:
        print("   ", o[0], o[1], "(%.0f, %.0f)" % (o[2], o[3]), "낙차 %.2f 추가 %.2f 뜸 %.2f → %.2f" % (o[5], o[6], o[7], o[8]))
