# 죽은 나무 뿌리 뜸: 중심 기울기 한계 vs 둘레 고리 검사 vs (가정) 나무별 추가 묻기 비교
import sys, math
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/placement")
import numpy as np
import common as C
import check_ground as G

H = C.load_height()
gz, gx = np.gradient(H)
SL = np.sqrt(gx * gx + gz * gz)
man = C.load_manifest()
T = C.load_trees()
cols = {}
res = []
for i, (pi, x, z, yaw, s) in enumerate(T["instances"]):
    a = T["prototypes"][pi]
    if not a.startswith("dead_tree"):
        continue
    if not (170 <= x <= 1878 and 170 <= z <= 1878):
        continue
    if a not in cols:
        cols[a] = C.mesh_columns(a)
    m = man[a]["meta"]
    fp, sink = m["footprint"], m["sink"]
    h0 = float(C.hsample(H, x, z))
    sl = float(C.hsample(SL, x, z))
    def ring(r, n):
        t = np.arange(n) / n * 2 * math.pi
        return C.hsample(H, x + np.cos(t) * r, z + np.sin(t) * r)
    d08 = h0 - ring(0.8 * fp * s, 6).min()
    d10 = h0 - ring(1.0 * fp * s, 8).min()
    d12 = h0 - ring(1.2 * fp * s, 8).min()
    y = h0 - sink * s
    r0 = G.analyse(a, cols[a], (x, y, z), C.yaw_mat(yaw), s, H)
    # 가정: 나무별 추가 묻기 = 고리 최저 낙차 − 0.15, 0~0.6 m
    extra = float(np.clip(d10 - 0.15, 0, 0.6))
    r1 = G.analyse(a, cols[a], (x, y - extra, z), C.yaw_mat(yaw), s, H)
    res.append((i, a, x, z, s, sl, d08, d10, d12, r0["fmax"], r1["fmax"], extra, r0["bmax"], r1["bmax"], r1["height"]))

R = np.array([r[4:] for r in res], float)
names = np.array([r[1] for r in res])
s, sl, d08, d10, d12, f0, f1, ex, b0, b1, ht = R.T
bad = f0 > 0.25
print("범위 안 죽은 나무", len(res), "뜸>0.25", bad.sum(), "뜸>0.5", (f0 > 0.5).sum())
def rule(name, rej):
    print("%-44s 버림 %4d | 잡은 뜸 %3d/%d (>0.5: %d/%d) | 안 뜬 것 버림 %4d | 남은 뜸>0.25 %3d 남은 최대 %.2f" % (
        name, rej.sum(), (rej & bad).sum(), bad.sum(), (rej & (f0 > 0.5)).sum(), (f0 > 0.5).sum(), (rej & ~bad).sum(),
        (~rej & bad).sum(), f0[~rej].max()))
lim = np.where(names == "dead_tree_a", 0.30, 0.25)
rule("제안1: 중심 기울기 ≥0.25 (a 0.30)", sl > lim)
man_sink = {a: man[a]["meta"]["sink"] for a in set(names)}
sk = np.array([man_sink[a] for a in names])
rule("제안2: 0.8·fp 6점 낙차 > 0.2+sink·s", d08 > 0.2 + sk * s)
rule("고리 1.0·fp 8점 낙차 > 0.3+sink·s", d10 > 0.3 + sk * s)
rule("고리 1.0·fp 8점 낙차 > 0.35", d10 > 0.35)
rule("고리 1.0·fp 8점 낙차 > 0.40", d10 > 0.40)
rule("고리 1.2·fp 8점 낙차 > 0.40", d12 > 0.40)
rule("중심 0.25 + 고리1.0 > 0.4", (sl > lim) | (d10 > 0.4))
print()
print("가정 (trees.json 6번째 값 = 추가 묻기, Unity 한 줄 수정 필요): 추가 묻기 = clip(1.0·fp 낙차 − 0.15, 0, 0.6)")
print("  뜸>0.25: %d → %d, 뜸>0.4: %d → %d, 뜸>0.5: %d → %d, 최대 %.2f → %.2f" % (bad.sum(), (f1 > 0.25).sum(), (f0 > 0.4).sum(), (f1 > 0.4).sum(), (f0 > 0.5).sum(), (f1 > 0.5).sum(), f0.max(), f1.max()))
print("  추가 묻기 > 0: %d 그루, 평균 %.2f m, 최대 %.2f m; 묻힘 최대 %.2f → %.2f m (나무 높이 %.1f~%.1f m)" % ((ex > 0).sum(), ex[ex > 0].mean(), ex.max(), b0.max(), b1.max(), ht.min(), ht.max()))
for a in ["dead_tree_a", "dead_tree_b", "dead_tree_c"]:
    m = names == a
    print("  %s: 기울기>0.25 비율 %.0f%%" % (a, 100 * (sl[m] > 0.25).mean()))
# 기울기 분포: 걸을 수 있는 범위 안 땅 중 기울기 0.25~0.45 넓이
sub = SL[170:1879, 170:1879]
print("범위 안 땅: 기울기 <0.25 %.0f%%, 0.25~0.45 %.0f%%, 0.45~0.75 %.0f%%, >0.75 %.0f%%" % (
    100 * (sub < 0.25).mean(), 100 * ((sub >= 0.25) & (sub < 0.45)).mean(), 100 * ((sub >= 0.45) & (sub < 0.75)).mean(), 100 * (sub >= 0.75).mean()))
