import numpy as np, sys
from collections import deque
B=sys.argv[1]
h=np.fromfile(B+"/height.r16","<u2").reshape(2049,2049).astype(np.float32)*320/65535
# cell-center heights like navcommon (bilinear at cell centers) approx by averaging 4 vertices
hc=(h[:-1,:-1]+h[1:,:-1]+h[:-1,1:]+h[1:,1:])/4
N=hc.shape[0]
par=np.full(hc.shape,-1,np.int64); seen=np.zeros(hc.shape,bool)
s=(492,1000); seen[s]=True; q=deque([s])
while q:
    i,j=q.popleft()
    for a,b in ((i-1,j),(i+1,j),(i,j-1),(i,j+1)):
        if 0<=a<N and 0<=b<N and not seen[a,b] and abs(hc[a,b]-hc[i,j])<=1.0:
            seen[a,b]=True; par[a,b]=i*N+j; q.append((a,b))
X,Z=np.meshgrid(np.arange(N)+0.5,np.arange(N)+0.5)
dout=np.maximum.reduce([170-X,X-1878,170-Z,Z-1878])
print("reach", seen.sum(), "outside>10", (seen&(dout>10)).sum())
tgt=[(int(t[1]),int(t[0])) for t in [tuple(map(int,a.split(','))) for a in sys.argv[2:]]]
for (zi,xi) in tgt:
    if not seen[zi,xi]: print("not reached", xi, zi); continue
    path=[]; c=zi*N+xi
    while c>=0: path.append(divmod(c,N)); c=par[path[-1]]
    path=path[::-1]
    # print the part with dout in [-8, 32]
    seg=[(p[1],p[0],round(float(dout[p]),1),round(float(hc[p]),1)) for p in path if -8<dout[p]<32]
    print("target",xi,zi,"path len",len(path))
    for k in range(0,len(seg),max(1,len(seg)//40)): print("  ",seg[k])
