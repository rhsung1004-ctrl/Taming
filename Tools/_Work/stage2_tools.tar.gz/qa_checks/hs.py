import numpy as np, sys
from PIL import Image
D=sys.argv[1]; tag=sys.argv[2]
h=np.fromfile(D+"/height.r16","<u2").reshape(2049,2049).astype(np.float64)*320/65535
gz,gx=np.gradient(h)
sh=np.clip(0.6+(-gx*0.6+gz*0.6)*0.9,0,1.3)
hn=(h-h.min())/(h.max()-h.min())
col=np.stack([sh*(0.5+0.5*hn)]*3,-1)
sl=np.hypot(gx,gz)
col[...,0]=np.where(sl>1.0, np.minimum(col[...,0]+0.35,1), col[...,0])
img=(np.clip(np.flipud(col),0,1)*255).astype(np.uint8)
Image.fromarray(img).resize((1024,1024)).save("hs_%s.png"%tag)
c=img[2048-2000:2048-1700, 850:1170]
Image.fromarray(c).resize((640,600)).save("gate_%s.png"%tag)
print((h>=318.9).sum(), "clipped;", "max", h.max())
