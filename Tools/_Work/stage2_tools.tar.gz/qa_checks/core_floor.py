import numpy as np, json, sys
from PIL import Image
D=sys.argv[1]
w=json.load(open(D+"/world.json"))
L=[l["name"] for l in w["layers"]]
col={"grass":(57,69,62),"moss":(69,87,71),"dirt":(79,71,72),"mud":(61,57,58),"rock":(99,99,110),"path":(87,84,86),"leaves":(73,59,53),"ash":(122,118,125)}
sp=np.concatenate([np.flipud(np.asarray(Image.open(D+"/splat_%d.png"%k)).astype(np.float32)/255) for k in range(2)],-1)  # [z,x,8]
det=np.concatenate([np.flipud(np.asarray(Image.open(D+"/detail_%d.png"%k)).astype(np.float32)/255) for k in range(2)],-1)
mpc=[d["maxPerCell"] for d in w["details"]]
grass=sum(det[...,i]*mpc[i] for i in range(len(mpc)))
C=np.array([col[n] for n in L],np.float32)
alb=sp@C
X,Z=np.meshgrid(np.arange(2048),np.arange(2048))
field=np.ones((2048,2048),bool)
for p in w["pois"]:
    field&=np.hypot(X-p["p"][0],Z-p["p"][2])>p["r"]+40
field&=(X>250)&(X<1800)&(Z>250)&(Z<1800)
fc=alb[field].mean(0); fg=grass[field].mean()
print("들판 평균색", np.round(fc,1), "풀 %.2f/m²"%fg)
for nm,c,r in (("village",(1390,430),45),("cathedral",(1010,1478),40),("gate",(1010,1804),30),("tower",(640,1572),25),("graveyard",(1000,880),120)):
    m=np.hypot(X-c[0],Z-c[1])<r
    pc=alb[m].mean(0)
    print("%-10s 핵심 %d m: 색 차이 %.1f, 풀 %.2f/m² (들판의 %.0f%%)"%(nm,r,np.linalg.norm(pc-fc),grass[m].mean(),100*grass[m].mean()/fg))
