# 새 데이터 높이 그대로 (벽은 이미 들어 있다): 봉인문 실제 발자국(LOD1, gate_occ.npy)에 반지름 0.4 를 더해 막고
# 0.1 m 격자로 문 앞에서 플러드필 → 문 뒤 주머니(z > 1827, |x-1010| < 8) 와 문 뒤 넓은 영역(z >= 1832, |x-1010| <= 45) 에 닿는지
import numpy as np, sys
from collections import deque
D = sys.argv[1]
lim = float(sys.argv[2]) if len(sys.argv) > 2 else 1.19
h = np.fromfile(D + "/height.r16", "<u2").reshape(2049, 2049).astype(np.float64) * 320 / 65535
X0, X1, Z0, Z1 = 960, 1060, 1790, 1900
hh = h[Z0:Z1 + 1, X0:X1 + 1]
h00 = hh[:-1, :-1]; h10 = hh[:-1, 1:]; h01 = hh[1:, :-1]; h11 = hh[1:, 1:]
s = np.maximum.reduce([np.hypot(h10 - h00, h11 - h10), np.hypot(h11 - h01, h01 - h00), np.hypot(h10 - h00, h01 - h00), np.hypot(h11 - h01, h11 - h10)])
res = 0.1
fx = np.arange(X0, X1, res) + res / 2; fz = np.arange(Z0, Z1, res) + res / 2
FX, FZ = np.meshgrid(fx, fz)
walk = s[(FZ - Z0).astype(int), (FX - X0).astype(int)] <= lim
occ = np.load("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/gatecheck/gate_occ.npy")
big = np.zeros_like(walk)
oi = int(round((1810 - Z0) / res)); oj = int(round((995 - X0) / res))
big[oi:oi + occ.shape[0], oj:oj + occ.shape[1]] = occ
r = 4
dil = big.copy()
for dy in range(-r, r + 1):
    for dx in range(-r, r + 1):
        if dy * dy + dx * dx <= r * r:
            dil |= np.roll(np.roll(big, dy, 0), dx, 1)
walk &= ~dil
nz, nx = walk.shape
st = (int((1800 - Z0) / res), int((1010 - X0) / res))
R = np.zeros_like(walk); R[st] = True; q = deque([st])
while q:
    i, j = q.popleft()
    for a, b in ((i - 1, j), (i + 1, j), (i, j - 1), (i, j + 1)):
        if 0 <= a < nz and 0 <= b < nx and walk[a, b] and not R[a, b]:
            R[a, b] = True; q.append((a, b))
pocket = (FZ > 1827) & (np.abs(FX - 1010) < 8)
behind = (FZ >= 1832) & (np.abs(FX - 1010) <= 45)
print("기울기 한계 %.2f: 문 뒤 주머니 %.1f m², 문 뒤(z≥1832, |dx|≤45) %.1f m², 창 가장자리 닿음 %s, 닿은 최대 z %.1f" % (
    lim, (R & pocket).sum() * res * res, (R & behind).sum() * res * res,
    bool(R[0].any() or R[-1].any() or R[:, 0].any() or R[:, -1].any()), FZ[R].max()))
# 문 없이 (지형만) 주머니에 닿는지 = 문이 실제로 길을 막고 있는지
