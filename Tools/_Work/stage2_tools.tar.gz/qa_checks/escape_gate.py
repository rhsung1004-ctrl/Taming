# 전체 지도 1 m 칸 플러드필 (삼각형 기울기 ≤ 한계), 봉인문 실제 발자국(+0.4 m)은 막힘.
# 확인: 지형 끝 닿는 칸, bounds 밖 최대 거리, 문 뒤 주머니(z>1827,|dx|<8) 닿는 칸, 문 뒤 (z≥1832, |dx|≤60) 닿는 칸의 자리
import numpy as np, sys, json
sys.path.insert(0, "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/wf_world/navigation")
D = sys.argv[1]
lim = float(sys.argv[2]) if len(sys.argv) > 2 else 1.19
import os
os.environ["NAV_DATA"] = D
import navcommon as N
h = np.fromfile(D + "/height.r16", "<u2").reshape(2049, 2049).astype(np.float32) * 320 / 65535
W = json.load(open(D + "/world.json"))
# 봉인문 자리 (objects.json 의 gate_great). gate_occ.npy 는 문 (1010, 1822), yaw 180 기준 0.1 m 격자 (원점 = 문 − (15, 12))
_g = [o for o in json.load(open(D + "/objects.json"))["objects"] if o["a"] == "gate_great"][0]["p"]
GX, GZ = _g[0], _g[2]
sl = N.cell_slope(h)                     # (2048, 2048), 칸 [z, x]
walk = sl <= lim
occ = np.load("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/gatecheck/gate_occ.npy")
# 0.1 m → 1 m: 0.4 m 넓혀 칸에 조금이라도 들면 막힘 (보수적이지 않게: 칸의 30% 넘게 들면 막힘)
res = 0.1
r = 4
big = np.zeros((occ.shape[0] + 2 * r, occ.shape[1] + 2 * r), bool)
big[r:-r, r:-r] = occ
dil = big.copy()
for dy in range(-r, r + 1):
    for dx in range(-r, r + 1):
        if dy * dy + dx * dx <= r * r:
            dil |= np.roll(np.roll(big, dy, 0), dx, 1)
z0 = GZ - 12 - r * res; x0 = GX - 15 - r * res
gate = np.zeros_like(walk)
for i in range(int(z0), int(z0 + dil.shape[0] * res) + 1):
    for j in range(int(x0), int(x0 + dil.shape[1] * res) + 1):
        a0 = int(round((i - z0) / res)); b0 = int(round((j - x0) / res))
        blk = dil[max(a0, 0):max(a0 + 10, 0), max(b0, 0):max(b0 + 10, 0)]
        if blk.size and blk.mean() > 0.3:
            gate[i, j] = True
walk &= ~gate
lab, n = N.label4(walk)
sp = W["spawn"]["p"]
comp = lab == lab[int(sp[2]), int(sp[0])]
zz, xx = np.nonzero(comp)
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]
edge = (xx <= 2) | (xx >= 2045) | (zz <= 2) | (zz >= 2045)
cx, cz = xx + 0.5, zz + 0.5
dout = np.maximum.reduce([b0x - cx, cx - b1x, b0z - cz, cz - b1z, np.zeros_like(cx)])
pocket = (cz > GZ + 5) & (np.abs(cx - GX) < 8)
behind = (cz >= GZ + 10) & (np.abs(cx - GX) <= 60)
print("한계 %.2f: 이어진 땅 %.2f km², 지형 끝 닿는 칸 %d, bounds 밖 칸 %d (최대 %.1f m), 문 뒤 주머니 %d 칸, 문 뒤 z≥문+10·|dx|≤60 %d 칸" % (
    lim, comp.sum() / 1e6, edge.sum(), (dout > 0).sum(), dout.max(), pocket.sum(), behind.sum()))
if behind.any():
    k = np.nonzero(behind)[0]
    print("   문 뒤 닿는 칸 예:", [(int(xx[i]), int(zz[i])) for i in k[:: max(1, len(k) // 10)][:10]])
# 문 막힘을 빼면 주머니에 닿는가 (문이 실제로 길을 막는지)
walk2 = sl <= lim
lab2, _ = N.label4(walk2)
comp2 = lab2 == lab2[int(sp[2]), int(sp[0])]
print("   (문 충돌을 빼면 주머니 칸 %d — 문만 길을 막는다)" % (comp2 & ((np.arange(2048)[None, :] - GX + 0.5 < 8) & (np.arange(2048)[None, :] + 0.5 - GX > -8) & (np.arange(2048)[:, None] + 0.5 > GZ + 5))).sum())
np.save("comp_%.2f.npy" % lim, comp)
