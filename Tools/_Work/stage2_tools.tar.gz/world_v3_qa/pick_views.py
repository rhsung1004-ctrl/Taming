# 눈높이 확인 렌더 자리 고르기: 카메라 자리 후보에서 보이는 장면(지형 시선, 눈 1.7 m)이 많은 방향
import sys, json, math, numpy as np
OUT = sys.argv[1]
D = OUT + "/Data~"
W = json.load(open(D + "/world.json")); n = W["heightRes"]
h = np.fromfile(D + "/height.r16", "<u2").reshape(n, n).astype(np.float32) / 65535 * W["height"]
SC = json.load(open(OUT + "/_scenes.json"))
Z = json.load(open(OUT + "/_zones.json"))
RD = json.load(open(OUT + "/_roads.json"))
BR = next(p["p"] for p in W["pois"] if p["id"] == "bridge"); BR = (BR[0], BR[2])
def H(x, z):
    x = np.clip(x, 0, n - 1.001); z = np.clip(z, 0, n - 1.001); x0 = np.int32(x); z0 = np.int32(z); fx = x - x0; fz = z - z0
    return h[z0, x0] * (1 - fx) * (1 - fz) + h[z0, x0 + 1] * fx * (1 - fz) + h[z0 + 1, x0] * (1 - fx) * fz + h[z0 + 1, x0 + 1] * fx * fz
def vis(cx, cz, rmax=160):
    e = H(cx, cz) + 1.7
    out = []
    for i, s in enumerate(SC):
        tx, ty, tz = s["top"][0], s["top"][1], s["top"][2]
        d = math.hypot(tx - cx, tz - cz)
        if d > rmax or d < 8:
            continue
        t = np.linspace(0.03, 0.97, int(max(8, d / 2)))
        ok = (H(cx + (tx - cx) * t, cz + (tz - cz) * t) < e + (ty - e) * t - 0.1).all()
        if ok:
            out.append((i, d, math.degrees(math.atan2(tx - cx, tz - cz))))
    return out
def best_dir(v, fov=80):
    best = None
    for a in range(0, 360, 5):
        inv = [x for x in v if abs((x[2] - a + 180) % 360 - 180) < fov / 2]
        sc = sum(1.0 / (1 + x[1] / 60) for x in inv)
        if best is None or sc > best[0]:
            best = (sc, a, inv)
    return best
def report(name, cx, cz):
    v = vis(cx, cz)
    sc, a, inv = best_dir(v)
    lx, lz = cx + math.sin(math.radians(a)) * 80, cz + math.cos(math.radians(a)) * 80
    print("%-10s 카메라 (%d, %d) 보는 방향 %d° → (%d, %d) | 시야 안 장면 %d: %s" % (name, cx, cz, a, lx, lz, len(inv),
          ", ".join("%s %.0fm" % (SC[i]["type"], d) for i, d, _ in sorted(inv, key=lambda x: x[1]))))
    return (cx, cz, lx, lz)
# 1) 북동쪽 들판 (1395, 1440) 고정
report("ne_field", 1395, 1440)
# 2) 무리마다 길 위 자리: 무리 가운데에서 가장 가까운 길 점에서 30~60 m 떨어진 곳
for hm in Z["hamlets"]:
    hx, hz = hm["center"]
    best = None
    for r in RD:
        for p in r["pts"][::5]:
            if math.hypot(p[0] - BR[0], p[1] - BR[1]) < 30:      # 다리 위·둘레는 빼고 (카메라가 다리 상판에 묻힌다)
                continue
            d = math.hypot(p[0] - hx, p[1] - hz)
            if 45 < d < 90:
                v = vis(p[0], p[1])
                k = sum(1 for x in v if x[0] in hm["scenes"])
                if best is None or k > best[0] or (k == best[0] and len(v) > best[1]):
                    best = (k, len(v), p)
    if best:
        report(hm["id"] + "_" + hm["kind"], best[2][0], best[2][1])
# 3) 조용한 구역 가운데
for q in Z["quiet"][:4]:
    report(q["id"] + "_quiet", q["center"][0], q["center"][1])
# 4) 길 밖 들판: 길에서 45 m 넘게, 장소 밖, 기울기 < 0.3 인 24 m 격자 점 중 시야 안 장면이 많은 곳
import itertools
rd_pts = np.concatenate([np.array(r["pts"]) for r in RD])
best = []
for gx in range(400, 1660, 24):
    for gz in range(400, 1660, 24):
        if np.min(np.hypot(rd_pts[:, 0] - gx, rd_pts[:, 1] - gz)) < 45:
            continue
        if any(math.hypot(gx - p["p"][0], gz - p["p"][2]) < p["r"] + 20 for p in W["pois"]):
            continue
        gzz, gxx = np.gradient(h[gz - 2:gz + 3, gx - 2:gx + 3])
        if np.hypot(gxx, gzz).max() > 0.3:
            continue
        v = vis(gx, gz, 140)
        sc, a, inv = best_dir(v)
        best.append((sc, len(inv), gx, gz))
best.sort(reverse=True)
for sc, k, gx, gz in best[:5]:
    report("field_%d_%d" % (gx, gz), gx, gz)
