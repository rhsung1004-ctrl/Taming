#!/bin/bash
# 사용: render_pair.sh <월드 폴더> <접두어> <samples>
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
V=$(cat $S/world_v3_qa/eye/views.txt)
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $1 $S/kit_out $2 $V $3
