#!/bin/bash
# 재시작 뒤 이어 렌더: v2 남은 4곳 → 스냅숏 11 전 12곳
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
cd $S/world_v3_qa/eye
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $S/world_v2 $S/kit_out $S/world_v3_qa/eye/v2_ eye_1073.2_1414.9_174.2,eye_1249.0_1409.7_110.1,eye_1111.1_605.8_109.1,eye_842.4_918.4_338.8 24 > v2b.log 2>&1
echo "V2B_EXIT $?" >> v2b.log
./render_pair.sh $S/world_v3_snap11 $S/world_v3_qa/eye/s11_ 24 > s11.log 2>&1
echo "S11_EXIT $?" >> s11.log
