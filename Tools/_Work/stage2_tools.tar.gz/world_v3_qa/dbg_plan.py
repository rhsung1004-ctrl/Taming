# 장면 계획만 돌려 보는 디버그 (lay_vignettes 까지)
import sys, time, collections
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import worldgen as wg
import numpy as np
out, kit = sys.argv[1], sys.argv[2]
why = collections.Counter()
orig_ok = wg.scene_ok
def scene_ok(W, P, x, z, R):
    v = orig_ok(W, P, x, z, R)
    if not v: why["scene_ok"] += 1
    return v
wg.scene_ok = scene_ok
orig_ta = wg.type_allowed
meta = wg.load_manifest(kit)
W = wg.World(); W.lights, W.fx, W.scenes = [], [], []
wg.build_height(W)
W.forest = np.zeros(W.h.shape, np.float32)
rng = np.random.default_rng(7)
P = wg.Placer(W, meta, rng)
pads = wg.lay_landmarks(W, P)
wg.finish_height(W, pads)
water = wg.water_planes(W); wg.make_pool_mask(W); wg.bridge_ramps(W)
gz, gx = np.gradient(W.h); W.slope, W.gx, W.gz = np.sqrt(gx * gx + gz * gz), gx, gz
wg.place_landmarks(W, P); wg.lay_altar(W, P); wg.lay_graveyard(W, P); wg.lay_cathedral(W, P); wg.lay_village(W, P)
wg.lay_gate(W, P); wg.lay_tower(W, P); wg.lay_tree(W, P); wg.lay_swamp(W, P); wg.lay_dragon(W, P); wg.lay_bridge_creek(W, P); wg.lay_lake(W, P)
wg.forest_plan(W)
import pickle
wg.lay_vignettes(W, P, 7)
print("scene_ok 실패", why)
