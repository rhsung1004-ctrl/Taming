# 채움 지표 (지도 전체, 눈높이 합격 기준을 무작위 자리·방향으로 넓힌 것)
#   걸을 수 있는 땅(장소 원 밖, 길 가장자리 밖) 무작위 600 점 × 네 방향(북·동·남·서, 가로 ±45.7° = 세로 시야 60° 16:9)
#   (a) 그 방향 40 m 안 '중간 크기 볼거리'(eye_metrics.py 와 같은 규칙, 지형 시선) 3 개 이상인 비율, 볼거리 수 중앙값
#       + 지형 볼거리(v3 _fill.json: 도랑·턱·둔덕)를 더한 값
#   (b) 그 방향 80 m 밖에 보이는 빛(LightCuller 끄는 거리 안) 또는 키 4 m 넘는 실루엣(400 m 안)이 있는 비율
#   가장 가까운 볼거리(아무 방향, 보이는 것)까지 거리 중앙값·90%
#   python3 fill_metrics.py <월드 폴더> [<월드 폴더> ...]
import sys, os, json, math
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import eye_metrics as em

worlds = sys.argv[1:]
ref = em.load(worlds[0])
Wj, h = ref[0], ref[1]
n = h.shape[0]
gz, gx = np.gradient(h)
sl = np.hypot(gx, gz)
(bx0, bz0), (bx1, bz1) = Wj["bounds"]["min"], Wj["bounds"]["max"]
POIS = [((p["p"][0], p["p"][2]), p["r"]) for p in Wj["pois"]]
RD = json.load(open("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_struct/_roads.json"))
RP = np.concatenate([np.array(r["pts"]) for r in RD])
lev = Wj["levels"]
rng = np.random.default_rng(777)
pts = []
while len(pts) < 600:
    x, z = rng.uniform(bx0 + 5, bx1 - 5), rng.uniform(bz0 + 5, bz1 - 5)
    if sl[int(z), int(x)] > 0.8:
        continue
    hh = float(em.H(h, x, z))
    if math.hypot(x - 1430, z - 950) < 268 and hh < lev["swamp"] + 0.1 or math.hypot(x - 790, z - 495) < 114 and hh < lev["lake"] + 0.1:
        continue
    if any(math.hypot(x - c[0], z - c[1]) < r for c, r in POIS):
        continue
    if np.min(np.hypot(RP[:, 0] - x, RP[:, 1] - z)) < 5:
        continue
    pts.append((x, z))
print("표본 %d 점 (걸을 수 있는 땅, 장소 원·길 밖, 씨앗 777) × 방향 4" % len(pts))
for w in worlds:
    pk = em.load(w)
    _, hw, E, LT, fill, scenes = pk
    A, A2, B, near, cnt, cnt2 = [], [], [], [], [], []
    for (x, z) in pts:
        best = 1e9
        for yw in (0.0, 90.0, 180.0, 270.0):
            feats, terr, lights, tall, _ = em.analyse(pk, {"x": x, "z": z, "yaw": yw})
            A.append(len(feats) >= 3)
            A2.append(len(feats) + len(terr) >= 3)
            B.append(lights + tall >= 1)
            cnt.append(len(feats))
            cnt2.append(len(feats) + len(terr))
            if feats:
                best = min(best, feats[0][1])
        near.append(best)
    near = np.array(near)
    nf = np.isfinite(near) & (near < 1e8)
    print("[%s] (a) 방향의 %.1f%% 가 40 m 안 소품 볼거리 3 개 이상 (지형 더하면 %.1f%%), 볼거리 수 중앙값 %.1f (지형 더하면 %.1f) | "
          "(b) 80 m 밖 빛·실루엣 %.1f%% | 가장 가까운 볼거리(40 m 안, 네 방향) 없는 점 %.1f%%, 있으면 거리 중앙값 %.1f m" % (
              os.path.basename(w), 100 * np.mean(A), 100 * np.mean(A2), float(np.median(cnt)), float(np.median(cnt2)), 100 * np.mean(B),
              100 * (1 - nf.mean()), float(np.median(near[nf])) if nf.any() else -1))
