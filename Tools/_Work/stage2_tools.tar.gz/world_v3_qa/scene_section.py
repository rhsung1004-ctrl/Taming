# ─────────────────────────── 작은 장면 (v3: 길과 지형을 따라 구조) ───────────────────────────
# v2 는 '가장 먼 땅부터' 80 m 간격으로 고르게 뿌려 물방울 무늬가 됐다. v3 는 구조를 만든다:
#  - 들판 장면의 60% 넘게 길에서 40 m 안: 갈림길, 굽은 곳, 언덕 마루, 다리·개울가, 숲으로 들어가는 길목
#  - 나머지는 지형 특징 자리에만: 언덕 꼭대기, 능선, 개울가, 숲 가장자리, 움푹한 곳 (아무 특징 없는 평지에는 놓지 않는다)
#  - 조밀한 무리(장면 2~3 개 + 장소가 서로 보이는 '마을 같은 무리', HAMLETS)와 조용한 구역(_zones.json, 다음 단계가 채운다)
#  - 시선: 길을 10 m 마다 걸으며, 또 길 밖 땅에서 150 m 안에 장면·장소·등대 빛이 보이게 (지형 시선, 눈높이 1.7 m)
#  - 같은 틀 장면은 200 m 안에 둘 두지 않는다. 장면마다 키 3.5 m 넘는 세로 요소와 등대 빛(far 140 m) 하나 이상
# 장면 틀: (차지하는 반지름 m, 길가 선호, 들판(지형 특징) 선호)
SCENES = {
    "execution": (9.0, 1.0, 0.6),     # 처형터: 교수대·매달린 새장·해골·화로
    "chapel":    (10.0, 0.7, 1.0),    # 무너진 예배당: 아치·담·기둥·석관 제단·영혼 불꽃
    "shrine":    (5.5, 1.4, 0.15),    # 길가 사당: 작은 사당·선돌 이정표·양초·등불 (길가만)
    "barrow":    (11.0, 0.5, 1.2),    # 선돌이 둘러선 무덤 둔덕: 지형 둔덕 + 선돌 고리 + 입구 돌 + 영혼 불꽃
    "camp":      (8.5, 0.9, 0.9),     # 버려진 야영지: 모닥불·찢긴 천막·통나무 의자·부서진 수레·깃발
    "crystal":   (7.0, 0.35, 1.1),    # 영혼 수정 노두: 바위 기둥에서 솟은 수정
    "family":    (9.0, 0.9, 0.8),     # 가족 묘역: 작은 납골당·사슬 오벨리스크·쇠 울타리·묘비
    "battle":    (12.0, 0.6, 1.0),    # 전장의 흔적: 찢긴 깃발·해골 유해·뼈 무더기
    "outpost":   (8.0, 1.4, 0.2),     # 길목 초소: 낮은 돌담 ㄱ 자·화로·깃발·무너진 모서리 (길가만)
}
# 틀별로 어울리는 자리 특징 (무게에 1 + 값을 곱한다)
SCENE_FEAT = {
    "execution": {"crest": 1.2, "hilltop": 1.4, "junction": 0.8, "ridge": 0.6},
    "chapel":    {"hilltop": 0.8, "crest": 0.6, "bend": 0.5, "ridge": 0.5},
    "shrine":    {"junction": 1.2, "bend": 1.0, "bridge": 1.0, "forest_entry": 0.8},
    "barrow":    {"hilltop": 1.6, "ridge": 1.4, "crest": 0.4},
    "camp":      {"forest_edge": 1.4, "creek": 1.2, "hollow": 0.8, "forest_entry": 0.8},
    "crystal":   {"hollow": 1.2, "creek": 1.0, "forest_edge": 0.8, "ridge": 0.3},
    "family":    {"bend": 0.8, "crest": 0.5, "forest_edge": 0.5, "hilltop": 0.4},
    "battle":    {"ridge": 1.0, "hilltop": 0.6, "creek": 0.6, "hollow": 0.5},
    "outpost":   {"crest": 1.4, "bridge": 1.2, "junction": 0.8, "forest_entry": 1.0},
}
ROAD_FEATS = ("junction", "bend", "crest", "bridge", "forest_entry")
TERRAIN_FEATS = ("hilltop", "ridge", "creek", "forest_edge", "hollow")
SAME_TYPE_GAP = 200.0       # 같은 틀 장면 사이 최소 거리 (m)
SIGHT = 150.0               # 시선 지표 거리 (m)
EYE = 1.7                   # 눈높이 (m)
TALL = 3.5                  # 장면마다 이보다 키 큰 세로 요소 하나 이상 (100 m 밖 실루엣)
HAMLETS = 8                 # 조밀한 무리 수 (장면 2~3 개 + 장소)
ROADSIDE = 40.0             # '길가' = 장면 가운데가 길 중심선에서 이 거리 안
SCENE_GAP = 70.0            # 무리 밖 장면 사이 최소 거리
SCENE_TARGET = 104          # 들판 장면 목표 수 (갈림길·숲 빈터·용의 무덤 장면 빼고). 시선을 채운 뒤 남으면 길가 특징 자리에 더한다
COVER_ROAD, COVER_OFF = 0.985, 0.93   # 계획 단계 시선 목표 (검사 기준 95% / 85% 보다 여유)
SCENE_STATS = {}            # (틀, 요소) → [시도, 놓임, 필수, 실패한 장면 수, 대체 없음]
SCENE_COUNT = {}            # 틀 → 장면 수


class Scene:
    """장면 하나의 로컬 좌표: 가운데 (x, z), 앞(+lz)이 yaw 쪽 (보통 가장 가까운 길), 오른쪽 +lx"""

    def __init__(self, W, P, kind, x, z, fy):
        self.W, self.P, self.kind, self.x, self.z, self.fy = W, P, kind, x, z, fy
        t = math.radians(fy)
        self.f = (math.sin(t), math.cos(t))
        self.r = (math.cos(t), -math.sin(t))
        self.n = 0
        self.beacon = None                    # (x, y, z, far) 등대 빛
        self.top = (x, P.height(x, z), z, 0.0)   # 가장 키 큰 것 (x, 꼭대기 y, z, 땅 위 높이)
        self.tags = {}                        # 요소 → [시도, 놓임, 필수, 대체 없음]

    def at(self, lx, lz):
        return (self.x + self.r[0] * lx + self.f[0] * lz, self.z + self.r[1] * lx + self.f[1] * lz)

    def put(self, a, lx, lz, yaw=None, ayaw=None, loose=False, slope=None, must=False, req=False, tag=None, **kw):
        """yaw: 장면 앞 기준 회전(도), ayaw: 절대 회전. loose: 장면 안 다른 소품과의 겹침은 보지 않는다 (땅·길·물은 본다).
        must: 장면의 중심 소품 — 보통 검사로 안 되면 loose 로 한 번 더. must·req 는 필수 요소 (계획 vs 실제 집계에서
        틀 인스턴스의 20% 넘게 빠지면 생성 실패). slope: loose 로 놓을 때 기울기 한계 (v3: 0.6 → 0.35)"""
        tag = tag or a
        rec = self.tags.setdefault(tag, [0, 0, False, 0])
        rec[0] += 1
        rec[2] = rec[2] or must or req
        skip0 = self.P.sub_skip.get(a, 0)
        ok = self._put(a, lx, lz, yaw, ayaw, loose, slope, **kw)
        if not ok and must and not loose:
            ok = self._put(a, lx, lz, yaw, ayaw, True, slope, **kw)
        if ok:
            rec[1] += 1
        elif self.P.sub_skip.get(a, 0) > skip0:
            rec[3] += 1
        return ok

    def _put(self, a, lx, lz, yaw, ayaw, loose, slope, **kw):
        P, W = self.P, self.W
        x, z = self.at(lx, lz)
        kw = dict(kw)
        if a in BOX_GROUND:
            kw.setdefault("ground", "box")          # 길쭉하거나 큰 구조물: 바닥 상자 전체가 땅에 닿게 (비탈에서 한쪽이 뜨지 않게)
        if ayaw is None:
            ayaw = self.fy + yaw if yaw is not None else P.rng.uniform(0, 360)
        if loose:
            s0 = kw.get("s") or 1.0
            if not P.ok_ground(x, z, P.fp(a) * s0, kw.get("road", True), kw.get("water", True), 0.35 if slope is None else slope):
                return False
            kw["check"] = False
        else:
            kw.setdefault("slope", 0.6 if slope is None else slope)
        n0, t0, l0 = len(P.objects), len(P.trees), len(W.lights)
        if not P.put(a, x, z, yaw=ayaw, **kw):
            return False
        self.n += 1
        g = P.height(x, z)
        if len(P.objects) > n0:
            o = P.objects[-1]
            m = P.meta.get(o["a"], {})
            hz = (m.get("_size") or [0, 0, 0])[2] * o["s"]
            top = o["p"][1] + hz
            lt = m.get("light")
            if lt and lt.get("far"):
                self.beacon = (o["p"][0], o["p"][1] + lt["offset"][2] * o["s"], o["p"][2], float(lt["far"]))
            self._top(o["p"][0], top, o["p"][2], top - g)
        elif len(P.trees) > t0:
            tr = P.trees[-1]
            m = P.meta.get(P.protos[tr[0]], {})
            hz = ((m.get("_size") or [0, 0, 0])[2] - m.get("sink", 0.0)) * tr[4]
            self._top(tr[1], g + hz, tr[2], hz)
        for l in W.lights[l0:]:
            if l.get("far"):
                self.beacon = (l["p"][0], l["p"][1], l["p"][2], l["far"])
        return True

    def _top(self, x, y, z, hgt):
        if hgt > self.top[3]:
            self.top = (x, y, z, hgt)

    def light(self, c, i, r, lx=0.0, lz=0.0, up=2.0, far=None):
        x, z = self.at(lx, lz)
        l = {"p": [round(x, 2), round(self.P.height(x, z) + up, 2), round(z, 2)], "c": list(c), "i": float(i), "r": float(r), "flicker": True}
        if far:
            l["far"] = float(far)
            self.beacon = (l["p"][0], l["p"][1], l["p"][2], float(far))
        self.W.lights.append(l)

    def fx(self, t, r, lx=0.0, lz=0.0, up=1.0):
        x, z = self.at(lx, lz)
        self.W.fx.append({"type": t, "p": [x, self.P.height(x, z) + up, z], "r": r})

    def floor(self, kind, r, lx=0.0, lz=0.0):
        x, z = self.at(lx, lz)
        self.P.stamps.append((x, z, r, kind))

    def finish(self):
        """틀 요소 집계 (계획 vs 실제)"""
        SCENE_COUNT[self.kind] = SCENE_COUNT.get(self.kind, 0) + 1
        for tag, (n, ok, req, skip) in self.tags.items():
            st = SCENE_STATS.setdefault((self.kind, tag), [0, 0, False, 0, 0])
            st[0] += n
            st[1] += ok
            st[2] = st[2] or req
            st[3] += (req and ok == 0)
            st[4] += skip


BOX_GROUND = {"wall_ruin_a", "wall_ruin_b", "arch_ruin", "pillar_b", "mausoleum_small", "sarcophagus", "cart_broken", "tent_torn",
              "log_fallen", "gallows", "iron_fence", "stone_wall_low", "standing_stone", "cliff_b", "grave_tomb"}


def polar(rng, r0, r1):
    a = rng.uniform(0, 2 * math.pi)
    d = math.sqrt(rng.uniform((r0 / r1) ** 2, 1)) * r1
    return math.cos(a) * d, math.sin(a) * d


def sc_execution(S, rng):
    S.floor("dirt", 5.5)
    S.put("gallows", 0, 0, yaw=rng.normal(0, 5), must=True, stamp=("dirt", 1.6))
    for sd in (-1, 1):
        if rng.random() < 0.8:
            S.put("hanging_cage", sd * 5.0, -1.2, yaw=sd * 15 + rng.normal(0, 6))
    S.put("skeleton_remains", 0.4, 1.7, yaw=rng.uniform(-30, 30), loose=True)
    for k in range(int(rng.integers(4, 8))):
        S.put("skull", *polar(rng, 1.6, 5.5), loose=True)
    for k in range(3):
        S.put("candles", rng.uniform(-1.4, 1.4), rng.uniform(2.3, 3.1), loose=True)
    S.put("bone_pile", -3.4, -2.8)
    for (lx, lz) in ((-1.8, -5.2), (1.6, -5.6)):           # 처형된 이들의 이름 없는 무덤
        if rng.random() < 0.75:
            S.put("grave_sunken", lx, lz, yaw=rng.normal(0, 10), stamp=("mud", 1.2))
    S.put("brazier", 3.6, 2.6, yaw=0, req=True)
    if rng.random() < 0.6:
        sd = rng.choice([-1, 1])
        S.put("fence", sd * 5.6, 5.0, yaw=rng.normal(0, 8), tilt=8)


def sc_chapel(S, rng):
    hw, hd = 4.2, 6.0
    S.floor("path", 5.5)
    S.floor("rock", 3.0, 0, -1.0)
    S.put("arch_ruin", 0, hd, yaw=rng.normal(0, 3), must=True)
    for sd in (-1, 1):
        for lz, nm in ((2.6, "wall_ruin_a"), (-2.8, "wall_ruin_b")):
            if rng.random() < 0.8:
                S.put(nm, sd * hw, lz, yaw=90 * sd + rng.normal(0, 4), loose=True, stamp=("dirt", 1.1), tag="wall")
    if rng.random() < 0.6:
        S.put("wall_ruin_b", 0, -hd - 0.4, yaw=180 + rng.normal(0, 4), loose=True, tag="wall")
    for sd in (-1, 1):                       # 안쪽은 가는 기둥만 (담 안쪽 면 |lx| 2.7 까지), 부러진 큰 기둥은 담 밖에
        if rng.random() < 0.8:
            S.put("pillar_a", sd * 1.9, 0.9, yaw=rng.uniform(0, 360), loose=True)
        if rng.random() < 0.5:
            S.put("pillar_a", sd * 1.9, -1.6, yaw=rng.uniform(0, 360), loose=True)
    if rng.random() < 0.7:
        a_ = rng.uniform(0, 2 * math.pi)
        S.put("pillar_b", math.cos(a_) * 8.0, math.sin(a_) * 8.0, yaw=rng.uniform(0, 360))
    S.put("sarcophagus", 0, -3.7, yaw=90 + rng.normal(0, 3), loose=True, req=True)
    for (lx, lz) in ((-1.4, -2.0), (1.4, -2.1), (0.2, -1.6)):
        S.put("candles", lx + rng.normal(0, 0.15), lz + rng.normal(0, 0.15), loose=True)
    S.light(SOUL, 4.5, 8.0, 0, -3.0, up=1.8, far=FAR)            # 제단 위 영혼 불꽃 (등대 빛)
    S.fx("soulfire", 2.5, 0, -3.0, up=1.2)
    S.put("lantern", hw + 1.6, hd + 1.4, yaw=rng.normal(0, 10))
    for k in range(3):
        S.put("rubble", *polar(rng, 2.0, 8.0))
    for k in range(int(rng.integers(1, 4))):                # 예배당 마당의 오래된 무덤
        S.put(["grave_slab_c", "grave_cross", "grave_slab_a"][k], -hw - 2.2 - k * 0.4, hd - 1.0 - k * 2.0, yaw=rng.normal(0, 8))
    if rng.random() < 0.3:
        S.put("statue_angel", hw + 2.0, -hd + 1.0, yaw=rng.normal(0, 10))


def sc_shrine(S, rng):
    S.floor("path", 2.4)
    S.put("shrine_roadside", 0, 0, yaw=rng.normal(0, 4), must=True, stamp=("path", 1.4))
    S.put("standing_stone", -2.4, -1.2, yaw=rng.normal(0, 12), s=rng.uniform(1.2, 1.3), req=True, tag="waystone")   # 이정표 선돌
    for k in range(3):
        S.put("candles", rng.uniform(-0.9, 0.9), rng.uniform(1.3, 1.9), loose=True)
    S.put("lantern", 2.1, 0.7, yaw=-20 + rng.normal(0, 8))
    for k in range(4):
        S.put("flower_lily", *polar(rng, 1.5, 3.4), loose=True)
    if rng.random() < 0.5:
        S.put("skull", rng.uniform(-1.0, 1.0), rng.uniform(1.0, 1.3), loose=True)
    if rng.random() < 0.35:
        S.put("statue_angel", 2.5, -1.6, yaw=-15 + rng.normal(0, 6))


def sc_barrow(S, rng):
    """선돌이 둘러선 무덤 둔덕 (둔덕은 lay_scene 이 지형에 쌓는다). 입구는 앞(+lz, 길 쪽)"""
    S.floor("moss", 7.5)
    n = 10
    off = rng.uniform(-0.15, 0.15)
    for k in range(n):
        a = math.pi / 2 + (k + 0.5) / n * 2 * math.pi + off          # 입구(앞) 양옆은 비운다 (k = 9, 0 사이가 입구)
        if k in (n - 1, 0):
            continue
        if rng.random() < 0.12:
            continue                                                  # 쓰러져 사라진 돌
        lx, lz = math.cos(a) * 9.6, math.sin(a) * 9.6
        x, z = S.at(lx, lz)
        tl = 18 if rng.random() < 0.15 else None                     # 몇은 기울었다
        S.put("standing_stone", lx, lz, ayaw=yaw_to(S.x - x, S.z - z) + rng.normal(0, 8), s=rng.uniform(0.85, 1.1),
              tilt=tl, req=True, stamp=("dirt", 1.0))
    for sd in (-1, 1):                                                # 입구 돌: 키 큰 두 개가 길 쪽 입구를 지킨다
        S.put("standing_stone", sd * 1.9, 9.9, yaw=rng.normal(0, 5), s=rng.uniform(1.25, 1.3), req=True, tag="entrance_stone",
              stamp=("dirt", 1.0))
    S.put("grave_sunken", 0, 6.9, yaw=rng.normal(0, 5), stamp=("mud", 1.3), tag="entrance_pit")   # 둔덕 발치의 어두운 입구
    for k in range(3):
        S.put("candles", rng.uniform(-1.4, 1.4), rng.uniform(7.9, 8.8), loose=True)
    for k in range(4):
        S.put("skull", *polar(rng, 3.0, 8.5), loose=True)
    S.put("bones_scatter", rng.uniform(-2, 2), rng.uniform(7.5, 8.5), loose=True)
    S.fx("soulfire", 3, up=0.6)
    S.light(SOUL, 5.0, 10.0, up=2.6, far=FAR)


def sc_camp(S, rng):
    S.floor("dirt", 4.8)
    S.put("campfire", 0, 0, must=True, stamp=("ash", 1.3))
    for sd in (-1, 1):                                       # 통나무 의자 (모닥불을 보고)
        S.put("log_fallen", sd * 2.6, 0.6, yaw=sd * 80 + rng.normal(0, 6), s=0.75, tag="log_bench")
    S.put("tent_torn", -3.9, -3.2, yaw=25 + rng.normal(0, 8))
    if rng.random() < 0.5:
        S.put("tent_torn", 3.7, -3.6, yaw=-30 + rng.normal(0, 8))
    S.put("cart_broken", 6.0, 4.0, yaw=rng.uniform(60, 120))
    S.put("stump", -5.4, 3.4)
    S.put("banner_torn", -0.8, -5.8, yaw=rng.normal(0, 20), s=rng.uniform(1.2, 1.3), req=True)   # 야영지 깃발 (멀리서 실루엣)
    for k in range(3):
        a_ = rng.uniform(0, 2 * math.pi)
        S.put("rock_c", math.cos(a_) * 1.1, math.sin(a_) * 1.1, loose=True, s=rng.uniform(0.6, 0.8))
    S.put("skull", *polar(rng, 2.0, 4.0), loose=True)
    S.put("bones_scatter", *polar(rng, 3.0, 6.0), loose=True)
    S.put("skeleton_remains", *polar(rng, 3.0, 5.0), loose=True)      # 불가에서 잠든 채로
    S.fx("fireflies", 7, up=1.2)


def sc_crystal(S, rng):
    S.floor("moss", 4.2)
    S.put("soul_crystal", 0, 0, s=1.3, yaw=rng.uniform(0, 360), must=True, stamp=("rock", 1.4))
    S.put("cliff_b", rng.uniform(-0.6, 0.6), -3.4, yaw=rng.normal(0, 25), s=rng.uniform(0.36, 0.42), req=True, tag="rock_spire",
          stamp=("rock", 1.2))                                             # 수정이 솟은 바위 기둥 (세로 실루엣)
    for k in range(int(rng.integers(1, 3))):
        S.put("soul_crystal", *polar(rng, 2.4, 3.8), s=rng.uniform(0.7, 1.0), tag="soul_crystal_small")
    S.put("rock_b", *polar(rng, 3.5, 5.5))
    S.put("rock_flat", *polar(rng, 3.5, 5.5))
    for k in range(2):
        S.put("rock_a", *polar(rng, 3.0, 6.0))
    for k in range(4):
        S.put("mushroom_glow", *polar(rng, 1.5, 5.0), loose=True)
    S.fx("wisps", 8, up=1.0)


def sc_family(S, rng):
    S.floor("dirt", 5.2)
    S.put("mausoleum_small", 0, -3.6, yaw=rng.normal(0, 3), must=True, stamp=("dirt", 1.2))
    S.put("obelisk_chained", -3.6, -6.4, yaw=rng.uniform(0, 360), req=True, stamp=("dirt", 1.0))   # 가문 비석 (세로 실루엣)
    gn = ["grave_slab_a", "grave_slab_b", "grave_cross", "grave_slab_c"]
    for k, (lx, lz) in enumerate(((-2.6, 1.0), (-0.9, 1.0), (0.9, 1.0), (2.6, 1.0), (-1.8, 3.2), (0.0, 3.2), (1.8, 3.2))):
        if rng.random() < 0.8:
            S.put(gn[k % 4], lx + rng.normal(0, 0.15), lz + rng.normal(0, 0.15), yaw=rng.normal(0, 6), loose=True, stamp=("dirt", 1.4),
                  tag="grave")
    for sd in (-1, 1):
        S.put("iron_fence", sd * 3.1, 5.6, yaw=rng.normal(0, 3), loose=True, tilt=4)
        S.put("iron_fence", sd * 5.2, 2.2, yaw=90 + rng.normal(0, 3), loose=True, tilt=4)
        if rng.random() < 0.6:
            S.put("iron_fence", sd * 5.2, -1.4, yaw=90 + rng.normal(0, 3), loose=True, tilt=6)
    for sd in (-1, 1):
        S.put("candles", sd * 0.7, 4.4, loose=True)
    S.put("lantern", 1.2, 7.6, yaw=rng.normal(0, 10), req=True)     # v2: (1.5, 6.8) 은 앞 울타리와 겹쳐 한 번도 놓이지 않았다


def sc_battle(S, rng):
    S.floor("dirt", 7.0)
    for k in range(4):
        S.put("banner_torn", *polar(rng, 2.0, 10.0), s=rng.uniform(1.15, 1.3) if k < 2 else None, req=True)
    for k in range(5):
        S.put("skeleton_remains", *polar(rng, 1.0, 10.0), loose=True)
    for k in range(8):
        S.put("skull", *polar(rng, 0.5, 10.0), loose=True)
    for k in range(2):
        S.put("bone_pile", *polar(rng, 2.0, 8.0))
    for k in range(3):
        S.put("bones_scatter", *polar(rng, 1.0, 9.0), loose=True)
    S.put("rubble", *polar(rng, 3.0, 8.0))
    if rng.random() < 0.4:
        S.put("cart_broken", *polar(rng, 4.0, 9.0))
    for k in range(2):                       # 전장을 떠도는 영혼 빛 (하나는 등대 빛)
        lx, lz = polar(rng, 1.0, 7.0)
        S.light(SPIRIT, 3.5 if k else 4.5, 8.0, lx, lz, up=rng.uniform(1.8, 2.6), far=FAR if k == 0 else None)
    S.fx("wisps", 12, up=1.0)


def sc_outpost(S, rng):
    """길목 초소: 길 쪽(+lz)에 낮은 돌담 ㄱ 자, 화로, 깃발, 무너진 모서리, 쓰러진 보초"""
    S.floor("dirt", 5.0)
    S.put("stone_wall_low", -1.5, 3.2, yaw=rng.normal(0, 3), req=True, tag="stone_wall_low")
    S.put("stone_wall_low", 2.6, 3.0, yaw=rng.normal(0, 4), tag="stone_wall_low")
    S.put("stone_wall_low", -4.2, 0.6, yaw=90 + rng.normal(0, 4), tag="stone_wall_low")
    S.put("brazier", 1.4, -0.6, yaw=0, must=True)
    S.put("banner_torn", -3.0, -2.6, yaw=rng.normal(0, 15), s=rng.uniform(1.2, 1.3), req=True)
    S.put("wall_ruin_b", 3.6, -3.2, yaw=rng.uniform(-60, 60), tag="post_corner")
    for k in range(2):
        S.put("skeleton_remains", *polar(rng, 1.5, 5.0), loose=True)
    for k in range(3):
        S.put("skull", *polar(rng, 1.0, 5.5), loose=True)
    S.put("rubble", *polar(rng, 3.0, 6.5))
    S.put("bones_scatter", *polar(rng, 2.0, 6.0), loose=True)


SCENE_FN = {"execution": sc_execution, "chapel": sc_chapel, "shrine": sc_shrine, "barrow": sc_barrow, "camp": sc_camp,
            "crystal": sc_crystal, "family": sc_family, "battle": sc_battle, "outpost": sc_outpost}


def scene_ok(W, P, x, z, R):
    """장면 자리: 가운데가 고르고 길·물·다른 소품에서 떨어져 있고, 둘레 8 점도 걸을 수 있는 땅"""
    (bx0, bz0), (bx1, bz1) = BOUNDS
    if not (bx0 + 18 < x < bx1 - 18 and bz0 + 18 < z < bz1 - 18):
        return False
    if not P.ok_ground(x, z, R, road=True, water=True, slope=0.35):
        return False
    if not P.free(x, z, R * 0.75):
        return False
    for k in range(8):
        a = k / 8 * 2 * math.pi
        px, pz = x + math.cos(a) * R, z + math.sin(a) * R
        if sample(W.slope, px, pz) > 0.55 or sample(W.mount, px, pz) > 0.4 or P.under_water(px, pz, 0.2):
            return False
    return True


def type_allowed(W, kind, x, z):
    """같은 틀 장면이 SAME_TYPE_GAP 안에 없는가"""
    return all((x - s_["p"][0]) ** 2 + (z - s_["p"][1]) ** 2 >= SAME_TYPE_GAP ** 2 for s_ in W.scenes if s_["type"] == kind)


def face_road(W, x, z):
    """가장 가까운 길 쪽을 보는 yaw 와 길까지 거리"""
    best, bp = 1e18, None
    for c, hw in W.road_curves:
        d2 = (c[:, 0] - x) ** 2 + (c[:, 1] - z) ** 2
        k = int(np.argmin(d2))
        if d2[k] < best:
            best, bp = float(d2[k]), c[k]
    return yaw_to(bp[0] - x, bp[1] - z), math.sqrt(best)


def lay_scene(W, P, kind, x, z, yaw=None, feature=None, hamlet=-1):
    """장면 하나. 자리 검사 → 가운데 자리 고르기(지형) → 틀 → 등대 빛·세로 요소 보충 → 둘레. 성공하면 W.scenes 항목"""
    R = SCENES[kind][0]
    if not scene_ok(W, P, x, z, R) or not type_allowed(W, kind, x, z):
        return None
    rng = P.rng
    fy, droad = face_road(W, x, z)
    if yaw is not None:
        fy = yaw
    fy += rng.normal(0, 10)
    # v3: 장면 가운데를 부드럽게 고른다 (큰 소품이 비탈 오르막 쪽에 묻히지 않게. 길·물·개울은 건드리지 않는다)
    P.terraform(x, z, R * 0.55, R + 6.0, "flat", 0.8)
    if kind == "barrow":
        P.terraform(x, z, 0.0, 8.0, "mound", rng.uniform(1.6, 2.0), max_slope=0.62)
    S = Scene(W, P, kind, x, z, fy)
    SCENE_FN[kind](S, rng)
    if S.top[3] < TALL:                     # 키 큰 세로 요소가 없으면 (대체 소품이 낮거나 빠졌을 때) 깃발 하나
        for (lx, lz) in ((0.0, -R * 0.7), (R * 0.6, -R * 0.4), (-R * 0.6, -R * 0.4)):
            if S.put("banner_torn", lx, lz, s=1.3, tag="tall_fallback") and S.top[3] >= TALL:
                break
    if S.beacon is None:                    # 멀리서 보이는 등대 빛이 없으면 떠도는 영혼 빛 하나 (far)
        S.light(SPIRIT if rng.random() < 0.5 else SOUL, 4.0, 8.0, up=2.4, far=FAR)
    # 둘레: 덤불·가시덤불·바위·고목 몇 (빈 들판 한가운데 덩그러니 놓이지 않게 둘레를 감싼다)
    for k in range(int(rng.integers(3, 7))):
        a = rng.uniform(0, 2 * math.pi)
        d = R + rng.uniform(1.5, 7.0)
        nm = ["dead_tree_b", "bramble", "bush_dead", "bush_dead", "rock_c", "bramble"][k % 6] if k else \
            ("dead_tree_a" if rng.random() < 0.5 else "dead_tree_c")
        P.put(nm, x + math.cos(a) * d, z + math.sin(a) * d)
    # 길가 장면: 길에서 장면 앞까지 밟힌 오솔길 (바닥 칠·풀 걷기만)
    if droad < 50:
        t = math.radians(fy)
        fx_, fz_ = math.sin(t), math.cos(t)
        n = int((droad - R * 0.4) / 2.0)
        for k in range(max(0, n)):
            d = R * 0.4 + k * 2.0
            P.stamps.append((x + fx_ * d + rng.normal(0, 0.3), z + fz_ * d + rng.normal(0, 0.3), 0.95, "path"))
    P.reserve(x, z, R)
    S.finish()
    rec = {"type": kind, "p": [round(x, 1), round(z, 1)], "r": R, "yaw": round(fy % 360, 1), "props": S.n,
           "feature": feature or "", "road_d": round(droad, 1), "hamlet": hamlet,
           "top": [round(S.top[0], 2), round(S.top[1], 2), round(S.top[2], 2)], "tall": round(S.top[3], 2),
           "beacon": [round(v, 2) for v in S.beacon] if S.beacon else None}
    W.scenes.append(rec)
    return rec


def lay_crossroads(W, P):
    """길이 갈라지는 곳 (장소 밖): 모서리의 화로 둘과 이정표 기둥, 기둥 발치의 해골·초"""
    rng = P.rng
    pois = [(p if p else W.bridge_p, r) for (_, _, p, r) in POIS]
    curves = W.road_curves
    got = 0
    for i, (c, hw) in enumerate(curves):
        for end in (c[0], c[-1]):
            for j, (c2, hw2) in enumerate(curves):
                if j == i:
                    continue
                d2 = (c2[:, 0] - end[0]) ** 2 + (c2[:, 1] - end[1]) ** 2
                k = int(np.argmin(d2))
                if d2[k] > 10 ** 2:
                    continue
                jx, jz = float(c2[k, 0]), float(c2[k, 1])
                if any((jx - px) ** 2 + (jz - pz) ** 2 < (pr + 12) ** 2 for (px, pz), pr in pois):
                    continue
                if any((jx - s_["p"][0]) ** 2 + (jz - s_["p"][1]) ** 2 < 40 ** 2 for s_ in W.scenes):
                    continue
                if not type_allowed(W, "crossroad", jx, jz):
                    continue
                # 모서리 후보: 둘레 12 방향, 길 가장자리에서 2.2 m 넘게 떨어진 첫 자리
                spots = []
                for t in range(12):
                    a = t / 12 * 2 * math.pi
                    for rr in (hw2 + 4.5, hw2 + 6.0, hw2 + 7.5):
                        x, z = jx + math.cos(a) * rr, jz + math.sin(a) * rr
                        if sample(W.road_dist, x, z) > sample(W.road_hw, x, z) + 2.2 and P.ok_ground(x, z, 0.8, road=False, slope=0.45):
                            spots.append((a, x, z))
                            break
                S = Scene(W, P, "crossroad", jx, jz, 0.0)
                used = []
                for nm in ("brazier", "brazier", "pillar_a"):
                    for (a, x, z) in spots:
                        if any(abs((a - b + math.pi) % (2 * math.pi) - math.pi) < 1.3 for b in used):
                            continue
                        lx, lz = x - jx, z - jz                   # Scene 로컬 = 월드 (fy 0)
                        if S.put(nm, lx, lz, ayaw=yaw_to(jx - x, jz - z), road=False, slope=0.45, tag=nm,
                                 req=(nm == "pillar_a")):
                            used.append(a)
                            if nm == "pillar_a":                    # 이정표 기둥 발치
                                for q in range(3):
                                    P.put("skull", x + rng.normal(0, 0.8), z + rng.normal(0, 0.8), road=False)
                                P.put("candles", x + rng.uniform(-0.8, 0.8), z + rng.uniform(-0.8, 0.8), road=False)
                            break
                if not used:
                    continue
                if S.beacon is None:
                    S.light(SPIRIT, 4.0, 8.0, up=2.6, far=FAR)
                P.reserve(jx, jz, 8.0)
                S.finish()
                W.scenes.append({"type": "crossroad", "p": [round(jx, 1), round(jz, 1)], "r": 8.0, "yaw": 0.0, "props": len(used),
                                 "feature": "junction", "road_d": 0.0, "hamlet": -1,
                                 "top": [round(S.top[0], 2), round(S.top[1], 2), round(S.top[2], 2)], "tall": round(S.top[3], 2),
                                 "beacon": [round(v, 2) for v in S.beacon] if S.beacon else None})
                got += 1
    log("갈림길 화로", got)


# ───── 시선 (지형만 본다) ─────
def hs_arr(h, x, z):
    """높이 쌍선형 보간 (배열)"""
    x = np.clip(x, 0, RES - 1.001)
    z = np.clip(z, 0, RES - 1.001)
    x0 = x.astype(np.int32)
    z0 = z.astype(np.int32)
    fx, fz = x - x0, z - z0
    return (h[z0, x0] * (1 - fx) * (1 - fz) + h[z0, x0 + 1] * fx * (1 - fz) + h[z0 + 1, x0] * (1 - fx) * fz + h[z0 + 1, x0 + 1] * fx * fz)


def los_ok(h, ox, oz, oy, tx, tz, ty, clear=0.15):
    """관측점 배열 (ox, oz, 눈 높이 oy) 에서 표적 한 점 (tx, tz, ty) 이 지형에 가리지 않는가"""
    if len(ox) == 0:
        return np.zeros(0, bool)
    d = np.hypot(tx - ox, tz - oz)
    n = int(max(8, d.max() / 2.0))
    t = np.linspace(0.02, 0.97, n)[None, :]
    sx = ox[:, None] + (tx - ox)[:, None] * t
    sz = oz[:, None] + (tz - oz)[:, None] * t
    line = oy[:, None] + (ty - oy)[:, None] * t
    return (hs_arr(h, sx, sz) < line - clear).all(1)


def sight_samples(W, seed=4242, n_off=3200):
    """시선 표본: 길 중심선 10 m 마다 (RS), 길 밖 걸을 수 있는 땅 무작위 (OS)"""
    rs = []
    for c, hw in W.road_curves:
        seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
        s = np.concatenate([[0], np.cumsum(seg)])
        for t in np.arange(0, s[-1], 10.0):
            rs.append((float(np.interp(t, s, c[:, 0])), float(np.interp(t, s, c[:, 1]))))
    rs = np.array(rs)
    rng = np.random.default_rng(seed)
    (bx0, bz0), (bx1, bz1) = BOUNDS
    os_ = []
    tries = 0
    while len(os_) < n_off and tries < n_off * 20:
        tries += 1
        x, z = rng.uniform(bx0 + 2, bx1 - 2), rng.uniform(bz0 + 2, bz1 - 2)
        if sample(W.slope, x, z) > 0.9 or sample(W.road_dist, x, z) < sample(W.road_hw, x, z) + 3:
            continue
        hh = sample(W.h, x, z)
        if (x - SWAMP[0]) ** 2 + (z - SWAMP[1]) ** 2 < (SWAMP_R + 40) ** 2 and hh < W.swamp_level + 0.1:
            continue
        if (x - LAKE[0]) ** 2 + (z - LAKE[1]) ** 2 < (LAKE_R + 30) ** 2 and hh < W.lake_level + 0.1:
            continue
        os_.append((x, z))
    return rs, np.array(os_)


def poi_targets(W):
    """장소마다 표적 점: 가운데(땅 + 5 m)와 반지름 0.6 배 둘레 8 점(땅 + 3 m)"""
    T = []
    for pid, name, p, r in POIS:
        p = p if p else W.bridge_p
        T.append((p[0], p[1], sample(W.h, *p) + 5.0, pid, r))
        for k in range(8):
            a = k / 8 * 2 * math.pi
            x, z = p[0] + math.cos(a) * r * 0.6, p[1] + math.sin(a) * r * 0.6
            T.append((x, z, sample(W.h, x, z) + 3.0, pid, r))
    return T


def vis_set(W, px, pz, peye, tx, tz, ty, rad=SIGHT):
    """표본 배열 중 표적 (tx, tz, ty) 이 rad 안에서 보이는 번호"""
    d = np.hypot(px - tx, pz - tz)
    idx = np.nonzero(d < rad)[0]
    if len(idx) == 0:
        return idx
    return idx[los_ok(W.h, px[idx], pz[idx], peye[idx], tx, tz, ty)]


# ───── 자리 특징 ─────
def site_features(W):
    """지형 특징 지도 (0~1): 언덕 꼭대기, 능선, 개울가, 숲 가장자리, 움푹한 곳"""
    h = W.h
    F = {}
    F["hilltop"] = ss(h - box_blur(h, 40), 1.5, 5.0)
    rid = ss(h - box_blur(h, 12), 0.45, 1.5)
    F["ridge"] = rid * (1 - 0.5 * F["hilltop"])
    F["hollow"] = ss(-(h - box_blur(h, 60)), 2.0, 5.0)
    cr = np.zeros(h.shape, np.float32)
    (z0, z1), (x0, x1) = W.creek_win
    dd = W.creek_dist - W.creek_wt
    cr[z0:z1, x0:x1] = ss(dd, 5.0, 9.0) * (1 - ss(dd, 26.0, 40.0))
    F["creek"] = cr
    fp = W.forest_plan
    F["forest_edge"] = ss(fp, 0.04, 0.18) * (1 - ss(fp, 0.35, 0.55))
    return F


def road_features(W, F):
    """길 표본 10 m 마다의 특징 점수 (갈림길·굽은 곳·마루·다리/개울·숲 길목). [(x, z, 길 번호, 법선, 특징, 점수)]"""
    curves = W.road_curves
    ends = []
    for i, (c, hw) in enumerate(curves):
        for e in (c[0], c[-1]):
            for j, (c2, _) in enumerate(curves):
                if j != i and np.min((c2[:, 0] - e[0]) ** 2 + (c2[:, 1] - e[1]) ** 2) < 100:
                    ends.append(e)
    ends = np.array(ends) if ends else np.zeros((0, 2))
    cdf = np.full(W.h.shape, 1e9, np.float32)
    (z0, z1), (x0, x1) = W.creek_win
    cdf[z0:z1, x0:x1] = W.creek_dist
    out = []
    for i, (c, hw) in enumerate(curves):
        seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
        s = np.concatenate([[0], np.cumsum(seg)])
        L = s[-1]
        P_ = lambda t: np.array([np.interp(t, s, c[:, 0]), np.interp(t, s, c[:, 1])])
        for t in np.arange(5.0, L - 5.0, 10.0):
            p = P_(t)
            d = P_(min(t + 2, L)) - P_(max(t - 2, 0))
            d /= np.linalg.norm(d) + 1e-9
            nrm = np.array([d[1], -d[0]])
            f = {}
            if len(ends):
                dj = float(np.min(np.hypot(ends[:, 0] - p[0], ends[:, 1] - p[1])))
                f["junction"] = max(0.0, 1 - dj / 45.0)
            if 25 < t < L - 25:
                a = P_(t - 25) - P_(t - 20)
                b = P_(t + 25) - P_(t + 20)
                ang = math.degrees(math.acos(max(-1, min(1, float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))))))
                f["bend"] = float(ssf(ang, 12, 40))
                cross = a[0] * b[1] - a[1] * b[0]            # 굽은 바깥쪽 = 법선 부호
                bend_out = -1 if cross > 0 else 1
            else:
                bend_out = 0
            hc = sample(W.h, *p)
            hn = max(sample(W.h, *P_(max(t - 35, 0))), sample(W.h, *P_(min(t + 35, L))))
            f["crest"] = float(ssf(hc - hn, 0.3, 2.0))
            f["bridge"] = 1.0 if sample(cdf, *p) < 40 else 0.0
            fa, fb = sample(W.forest_plan, *P_(max(t - 25, 0))), sample(W.forest_plan, *P_(min(t + 25, L)))
            f["forest_entry"] = float(ssf(abs(fa - fb), 0.15, 0.4))
            k = max(f, key=f.get)
            out.append((float(p[0]), float(p[1]), i, nrm, k, f[k], bend_out))
    return out


def scene_candidates(W, P, F):
    """장면 후보 자리. 길가(길 특징 자리 옆, 또는 길 40 m 안의 지형 특징)와 들판(길 40 m 밖의 지형 특징 자리만)"""
    (bx0, bz0), (bx1, bz1) = BOUNDS
    pois = [(p if p else W.bridge_p, r) for (_, _, p, r) in POIS]
    cdf = np.full(W.h.shape, 1e9, np.float32)
    (z0, z1), (x0, x1) = W.creek_win
    cdf[z0:z1, x0:x1] = W.creek_dist

    def base_ok(x, z):
        if not (bx0 + 24 < x < bx1 - 24 and bz0 + 24 < z < bz1 - 24):
            return False
        if sample(W.slope, x, z) > 0.3 or sample(W.mount, x, z) > 0.25 or sample(cdf, x, z) < 14:
            return False
        if P.under_water(x, z, 0.4):
            return False
        return all((x - px) ** 2 + (z - pz) ** 2 > (pr + 25) ** 2 for (px, pz), pr in pois)

    cands = []          # (x, z, 특징, 점수, 길가)
    RF = road_features(W, F)
    W.road_feat = RF
    for (x, z, i, nrm, feat, sc, bend_out) in RF:
        if sc < 0.35:
            continue
        hw = W.road_curves[i][1]
        for side in (-1, 1):
            for off in (hw + 13.0, hw + 20.0, hw + 28.0):
                cx, cz = x + nrm[0] * side * off, z + nrm[1] * side * off
                if sample(W.road_dist, cx, cz) < off - 3 or not base_ok(cx, cz):
                    continue
                w = sc * (1.2 if feat == "bend" and side == bend_out else 1.0)
                cands.append((cx, cz, feat, w, True))
    g = np.arange(bx0 + 28, bx1 - 28, 10.0)
    for gz_ in g:
        for gx_ in g:
            x, z = gx_ + 2.5 * math.sin(gz_ * 0.37), gz_ + 2.5 * math.sin(gx_ * 0.29)
            iz, ix = int(round(z)), int(round(x))
            best, bk = 0.0, None
            for k in TERRAIN_FEATS:
                v = float(F[k][iz, ix])
                if v > best:
                    best, bk = v, k
            if best < 0.4 or not base_ok(x, z):
                continue
            rd = float(W.road_dist[iz, ix])
            cands.append((x, z, bk, best, rd <= ROADSIDE))
    return cands


def lay_vignettes(W, P, seed):
    """작은 장면 v3: 길과 지형 특징을 따라 구조를 만든다 (갈림길 → 무리 → 길 시선 → 들판 시선 → 길가 보충).
    장면은 따로 씨앗을 쓴다 (앞 단계의 개수를 바꿔도 장면 자리가 흔들리지 않게)"""
    main_rng = P.rng
    P.rng = rng = np.random.default_rng(seed + 9001)
    t0 = time.time()
    lay_crossroads(W, P)
    F = site_features(W)
    cands = scene_candidates(W, P, F)
    C = np.array([(c[0], c[1]) for c in cands])
    cfeat = [c[2] for c in cands]
    cscore = np.array([c[3] for c in cands])
    croad = np.array([c[4] for c in cands])
    # 시선 표본과 표적
    RS, OS = sight_samples(W)
    S_ = np.concatenate([RS, OS])
    nR = len(RS)
    seye = hs_arr(W.h, S_[:, 0], S_[:, 1]) + EYE
    cov = np.zeros(len(S_), bool)
    for pid, name, p, r in POIS:                       # 장소 원 안 = 장소가 보인다
        p = p if p else W.bridge_p
        cov |= np.hypot(S_[:, 0] - p[0], S_[:, 1] - p[1]) < r
    for (tx, tz, ty, pid, r) in poi_targets(W):
        cov[vis_set(W, S_[:, 0], S_[:, 1], seye, tx, tz, ty)] = True
    # 후보마다 보이는 표본 (장면 꼭대기 = 땅 + TALL)
    cvis = []
    for k in range(len(C)):
        ty = sample(W.h, C[k, 0], C[k, 1]) + TALL
        cvis.append(vis_set(W, S_[:, 0], S_[:, 1], seye, C[k, 0], C[k, 1], ty))
    alive = np.ones(len(C), bool)
    log("장면 후보 %d 곳 (길가 %d), 시선 표본 길 %d · 들판 %d, 준비 %.1f 초" % (len(C), int(croad.sum()), nR, len(OS), time.time() - t0))

    def mark(x, z, ty=None):
        if ty is None:
            ty = sample(W.h, x, z) + TALL
        cov[vis_set(W, S_[:, 0], S_[:, 1], seye, x, z, ty)] = True

    for s_ in W.scenes:
        mark(s_["p"][0], s_["p"][1], s_["top"][1])

    def near_scene(x, z, r):
        return any((x - s_["p"][0]) ** 2 + (z - s_["p"][1]) ** 2 < r * r for s_ in W.scenes)

    def type_order(x, z, feat, road, avoid=()):
        w = {}
        n_avg = (sum(SCENE_COUNT.get(t, 0) for t in SCENES) + 1) / len(SCENES)
        for t in SCENES:
            if t in avoid or not type_allowed(W, t, x, z):
                continue
            R, wr, wf = SCENES[t]
            v = wr if road else wf
            v *= 1 + SCENE_FEAT[t].get(feat, 0.0)
            if math.hypot(x - GRAVE_C[0], z - GRAVE_C[1]) < 260 or math.hypot(x - CATH[0], z - CATH[1]) < 200:
                v *= {"family": 1.5, "chapel": 1.3}.get(t, 1.0)
            if math.hypot(x - DRAGON[0], z - DRAGON[1]) < DRAGON_R + 90:
                v *= {"battle": 1.7, "execution": 1.3}.get(t, 1.0)
            if math.hypot(x - FOREST_SW[0][0], z - FOREST_SW[0][1]) < FOREST_SW[1] + 90 or \
                    math.hypot(x - FOREST_NE[0][0], z - FOREST_NE[0][1]) < FOREST_NE[1] + 70:
                v *= {"camp": 1.4, "crystal": 1.3}.get(t, 1.0)
            if math.hypot(x - SWAMP[0], z - SWAMP[1]) < SWAMP_R + 120:
                v *= {"crystal": 1.3, "shrine": 1.2}.get(t, 1.0)
            if math.hypot(x - VILLAGE[0], z - VILLAGE[1]) < 220:
                v *= {"camp": 1.3, "execution": 1.3, "outpost": 1.2}.get(t, 1.0)
            v *= ((1.0 + n_avg) / (1.0 + SCENE_COUNT.get(t, 0))) ** 0.7       # 적게 쓴 틀을 조금 더
            w[t] = v * rng.uniform(0.8, 1.2)
        return sorted(w, key=lambda k: -w[k])

    def try_at(k, hamlet=-1, avoid=()):
        x, z = float(C[k, 0]), float(C[k, 1])
        for t in type_order(x, z, cfeat[k], bool(croad[k]), avoid):
            rec = lay_scene(W, P, t, x, z, feature=cfeat[k], hamlet=hamlet)
            if rec:
                mark(x, z, rec["top"][1])
                alive[np.hypot(C[:, 0] - x, C[:, 1] - z) < 2 * SCENES[t][0] + 6] = False
                return rec
        alive[k] = False
        return None

    # 1) 무리: 장소에서 30~230 m 의 길 특징 자리, 그 장소가 보이는 곳. 장면 2~3 개가 서로 보이게
    ptg = poi_targets(W)
    hamlets = []
    order = np.argsort(-(cscore * rng.uniform(0.85, 1.0, len(C))))
    for k in order:
        if len(hamlets) >= HAMLETS:
            break
        if not alive[k] or not croad[k] or cfeat[k] not in ROAD_FEATS or cscore[k] < 0.5:
            continue
        x, z = float(C[k, 0]), float(C[k, 1])
        if any(math.hypot(x - hx, z - hz) < 280 for hx, hz, _, _ in hamlets):
            continue
        eye_ = sample(W.h, x, z) + EYE
        seen = []
        for (tx, tz, ty, pid, r) in ptg:
            dd = math.hypot(tx - x, tz - z)
            if pid in seen or dd > 260:
                continue
            if los_ok(W.h, np.array([x]), np.array([z]), np.array([eye_]), tx, tz, ty)[0]:
                seen.append(pid)
        dedge = min(math.hypot(x - (p if p else W.bridge_p)[0], z - (p if p else W.bridge_p)[1]) - r for (_, _, p, r) in POIS)
        if not seen or not (30 <= dedge <= 230):
            continue
        hid = len(hamlets)
        first = try_at(k, hid)
        if not first:
            continue
        mem = [first]
        near = np.nonzero(alive & (np.hypot(C[:, 0] - x, C[:, 1] - z) > 24) & (np.hypot(C[:, 0] - x, C[:, 1] - z) < 78))[0]
        near = near[np.argsort(-(cscore[near] + 0.4 * croad[near]) * rng.uniform(0.8, 1.0, len(near)))]
        for j in near:
            if len(mem) >= 3:
                break
            if not alive[j]:
                continue
            jx, jz = float(C[j, 0]), float(C[j, 1])
            ok = True
            for m in mem:      # 서로 보이는가 (눈높이 → 상대 꼭대기)
                if not los_ok(W.h, np.array([jx]), np.array([jz]), np.array([sample(W.h, jx, jz) + EYE]), m["top"][0], m["top"][2],
                              m["top"][1])[0]:
                    ok = False
                    break
            if not ok:
                continue
            rec = try_at(j, hid, avoid=[m["type"] for m in mem])
            if rec:
                mem.append(rec)
        if len(mem) < 2:
            first["hamlet"] = -1
            continue
        cxm = float(np.mean([m["p"][0] for m in mem]))
        czm = float(np.mean([m["p"][1] for m in mem]))
        hamlets.append((cxm, czm, [W.scenes.index(m) for m in mem], seen))
    W.hamlets = hamlets
    n_h = len(W.scenes)

    def greedy(mask_fn, goal_fn, w_road, w_off, label):
        added = 0
        while not goal_fn():
            best, bk = 0.0, -1
            unc = ~cov
            for k in np.nonzero(alive & mask_fn())[0]:
                v = cvis[k]
                gr = int(unc[v[v < nR]].sum())
                go = int(unc[v[v >= nR]].sum())
                g = (w_road * gr + w_off * go) * (0.6 + 0.4 * cscore[k])
                if g > best:
                    best, bk = g, k
            if bk < 0 or best < 1.0:
                break
            x, z = float(C[bk, 0]), float(C[bk, 1])
            if near_scene(x, z, SCENE_GAP):
                alive[bk] = False
                continue
            if try_at(bk):
                added += 1
        log("  %s: 장면 %d 곳 더함, 길 시선 %.1f%%, 들판 시선 %.1f%%" % (label, added, 100 * cov[:nR].mean(), 100 * cov[nR:].mean()))

    # 2) 길 시선: 길가 후보만으로 길 표본을 덮는다
    greedy(lambda: croad, lambda: cov[:nR].mean() >= COVER_ROAD, 1.0, 0.25, "길 시선")
    # 3) 들판 시선: 지형 특징 자리(길가 포함)로 들판 표본을 덮는다
    greedy(lambda: np.ones(len(C), bool), lambda: cov[nR:].mean() >= COVER_OFF, 0.3, 1.0, "들판 시선")

    # 4) 길가 보충: 목표 수까지 길 특징 자리에 (들판 깊은 곳은 조용히 둔다)
    def field_count():
        return sum(1 for s_ in W.scenes if s_["type"] in SCENES)
    order = np.argsort(-(cscore * rng.uniform(0.7, 1.0, len(C))))
    for k in order:
        if field_count() >= SCENE_TARGET:
            break
        if not alive[k] or not croad[k]:
            continue
        x, z = float(C[k, 0]), float(C[k, 1])
        if near_scene(x, z, SCENE_GAP + 15):
            continue
        try_at(k)
    P.rng = main_rng
    cnt = {}
    for s_ in W.scenes:
        cnt[s_["type"]] = cnt.get(s_["type"], 0) + 1
    fs = [s_ for s_ in W.scenes if s_["type"] in SCENES]
    near_road = sum(1 for s_ in fs if s_["road_d"] <= ROADSIDE)
    log("작은 장면 %d 곳 (들판 %d, 길 %d m 안 %d = %.0f%%, 무리 %d 개 %d 곳): %s | 시선 길 %.1f%% 들판 %.1f%% (계획 기준) %.1f 초" % (
        len(W.scenes), len(fs), int(ROADSIDE), near_road, 100.0 * near_road / max(1, len(fs)), len(hamlets),
        sum(len(hh[2]) for hh in hamlets), ", ".join("%s %d" % kv for kv in sorted(cnt.items())),
        100 * cov[:nR].mean(), 100 * cov[nR:].mean(), time.time() - t0))


def scene_report(W, P):
    """장면 틀 요소별 계획 vs 실제 놓임. 필수 요소가 틀 인스턴스의 20% 넘게 빠지면 생성 실패"""
    bad = []
    log("장면 요소 (틀 / 요소: 시도 → 놓임, 필수 요소는 빠진 장면 수 / 장면 수, 대체 없음):")
    for kind in sorted(SCENE_COUNT):
        n = SCENE_COUNT[kind]
        parts = []
        for (k2, tag), (tr, ok, req, fail, skip) in sorted(SCENE_STATS.items()):
            if k2 != kind:
                continue
            s_ = "%s %d→%d" % (tag, tr, ok)
            if req:
                s_ += " [필수 빠짐 %d/%d]" % (fail, n)
                if fail > 0.2 * n:
                    bad.append("%s/%s 빠짐 %d/%d" % (kind, tag, fail, n))
            if skip:
                s_ += " (대체 없음 %d)" % skip
            parts.append(s_)
        log("  %-10s %3d 곳: %s" % (kind, n, ", ".join(parts)))
    short = [s_ for s_ in W.scenes if s_.get("tall", 0) < TALL]
    nob = [s_ for s_ in W.scenes if not s_.get("beacon")]
    log("  세로 요소 %.1f m 미만 장면 %d 곳, 등대 빛 없는 장면 %d 곳" % (TALL, len(short), len(nob)))
    if short:
        log("    낮은 장면:", ", ".join("%s(%.0f, %.0f) %.1f m" % (s_["type"], s_["p"][0], s_["p"][1], s_["tall"]) for s_ in short[:12]))
    if bad:
        raise SystemExit("[실패] 장면 필수 요소가 틀 인스턴스의 20%% 넘게 빠졌다: %s" % "; ".join(bad))


def scene_zones(W):
    """구역 표시: 조밀한 무리(hamlets)와 조용한 구역(quiet: 장면·장소에서 70 m 넘게 떨어진 걸을 수 있는 땅 덩어리, 16 m 칸)"""
    (bx0, bz0), (bx1, bz1) = BOUNDS
    step = 16.0
    g = np.arange(bx0 + step / 2, bx1, step)
    GX, GZ = np.meshgrid(g, g)
    ix, iz = np.round(GX).astype(int), np.round(GZ).astype(int)
    ok = (W.slope[iz, ix] < 0.8) & (W.mount[iz, ix] < 0.3)
    hh = W.h[iz, ix]
    ok &= ~((np.hypot(GX - SWAMP[0], GZ - SWAMP[1]) < SWAMP_R + 40) & (hh < W.swamp_level + 0.1))
    ok &= ~((np.hypot(GX - LAKE[0], GZ - LAKE[1]) < LAKE_R + 30) & (hh < W.lake_level + 0.1))
    d = np.full(GX.shape, 1e9)
    for s_ in W.scenes:
        d = np.minimum(d, np.hypot(GX - s_["p"][0], GZ - s_["p"][1]) - s_["r"])
    dp = np.full(GX.shape, 1e9)
    for (_, _, p, r) in POIS:
        p = p if p else W.bridge_p
        dp = np.minimum(dp, np.maximum(np.hypot(GX - p[0], GZ - p[1]) - r, 0))
    quiet = ok & (np.minimum(d, dp) > 70)
    lab = np.zeros(quiet.shape, int)
    zones = []
    n = 0
    for (a, b) in zip(*np.nonzero(quiet)):
        if lab[a, b]:
            continue
        n += 1
        st = [(a, b)]
        lab[a, b] = n
        cells = []
        while st:
            i, j = st.pop()
            cells.append((i, j))
            for (u, v) in ((i + 1, j), (i - 1, j), (i, j + 1), (i, j - 1)):
                if 0 <= u < quiet.shape[0] and 0 <= v < quiet.shape[1] and quiet[u, v] and not lab[u, v]:
                    lab[u, v] = n
                    st.append((u, v))
        if len(cells) < 6:
            continue
        xs = np.array([GX[i, j] for i, j in cells])
        zs = np.array([GZ[i, j] for i, j in cells])
        cx, cz = float(xs.mean()), float(zs.mean())
        ns = min(W.scenes, key=lambda s_: (s_["p"][0] - cx) ** 2 + (s_["p"][1] - cz) ** 2)
        npoi = min(POIS, key=lambda q: math.hypot(cx - (q[2] or W.bridge_p)[0], cz - (q[2] or W.bridge_p)[1]) - q[3])
        rd = float(np.median([sample(W.road_dist, x_, z_) for x_, z_ in zip(xs, zs)]))
        zones.append({"id": "Q%d" % len(zones), "center": [round(cx, 1), round(cz, 1)], "area_ha": round(len(cells) * step * step / 1e4, 2),
                      "cells": [[round(float(x_), 1), round(float(z_), 1)] for x_, z_ in zip(xs, zs)], "cell": step,
                      "road_d_median": round(rd, 1),
                      "nearest_scene": {"type": ns["type"], "p": ns["p"], "d": round(math.hypot(ns["p"][0] - cx, ns["p"][1] - cz), 1)},
                      "nearest_poi": npoi[0],
                      "fill": "밭 경계 돌담(stone_wall_low)·나무 무리·바위 노두·무덤 둔덕·외딴 선돌 (다음 단계)"})
    zones.sort(key=lambda zz: -zz["area_ha"])
    for k, zz in enumerate(zones):
        zz["id"] = "Q%d" % k
    hl = []
    for k, (cx, cz, idx, seen) in enumerate(getattr(W, "hamlets", [])):
        r = max(math.hypot(W.scenes[i]["p"][0] - cx, W.scenes[i]["p"][1] - cz) + W.scenes[i]["r"] for i in idx)
        hl.append({"id": "H%d" % k, "center": [round(cx, 1), round(cz, 1)], "r": round(r + 15, 1), "scenes": idx,
                   "types": [W.scenes[i]["type"] for i in idx], "sees": seen})
    W.zones = {"hamlets": hl, "quiet": zones,
               "note": "hamlets = 장면 2~3 개 + 장소가 서로 보이는 조밀한 무리. quiet = 장면·장소에서 70 m 넘게 떨어진 땅 (16 m 칸). "
                       "조용한 구역도 비어 있지 않게 채우는 것은 다음 단계(채움)가 맡는다"}
    log("구역: 무리 %d 개, 조용한 구역 %d 개 (넓이 합 %.1f ha, 가장 큰 것 %.1f ha)" % (
        len(hl), len(zones), sum(zz["area_ha"] for zz in zones), zones[0]["area_ha"] if zones else 0))


