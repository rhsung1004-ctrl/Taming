# 장면 틀별 눈높이 렌더를 한 장으로: scene_sheet.py <접두사> → scene_sheet.png (밝게 = 분석용)
import os, sys, glob
import numpy as np
from PIL import Image, ImageDraw, ImageFont
E = os.path.dirname(os.path.abspath(__file__))
P = sys.argv[1] if len(sys.argv) > 1 else "w6s_"
fs = sorted(glob.glob(E + "/" + P + "scene_*.png"))
f1 = ImageFont.truetype("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc", 18)
tw, th, cols = 448, 252, 4
G = Image.new("RGB", (cols * (tw + 6), ((len(fs) + cols - 1) // cols) * (th + 26)), (18, 18, 26))
d = ImageDraw.Draw(G)
for i, f in enumerate(fs):
    im = Image.open(f).convert("RGB").resize((tw, th), Image.LANCZOS)
    a = np.asarray(im).astype(np.float32) / 255.0
    im = Image.fromarray((np.clip(a * 2.2, 0, 1) ** 0.85 * 255).astype(np.uint8))
    x, y = (i % cols) * (tw + 6), (i // cols) * (th + 26)
    G.paste(im, (x, y + 24))
    d.text((x + 4, y + 2), os.path.basename(f)[len(P):-4] + " (밝게)", fill=(230, 230, 230), font=f1)
G.save(E + "/scene_sheet.png")
print("끝", len(fs))
