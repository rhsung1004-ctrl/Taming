# w4 눈높이 비교: compare.py [w4 접두사=w4_] → cmp_<id>.png (왼쪽 v2, 가운데 w3, 오른쪽 w4. 위 = 그대로, 아래 = 밝게(분석용)), cmp_all.png
import json, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
E = os.path.dirname(os.path.abspath(__file__))
Q = os.path.dirname(E)
PFX = sys.argv[1] if len(sys.argv) > 1 else "w4_"
FONT = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
f1, f2 = ImageFont.truetype(FONT, 22), ImageFont.truetype(FONT, 17)
spots = json.load(open(E + "/spots_all.json"))
def bright(im):
    a = np.asarray(im).astype(np.float32) / 255.0
    return Image.fromarray((np.clip(a * 2.6, 0, 1) ** 0.8 * 255).astype(np.uint8))
thumbs = []
for s in spots:
    v = "eye_%.1f_%.1f_%.1f" % (s["x"], s["z"], s["yaw"])
    pa, pw3, pb = Q + "/eye_w3/v2_" + v + ".png", Q + "/eye_w3/w3_" + v + ".png", E + "/" + PFX + v + ".png"
    old = False
    if not os.path.exists(pa):
        pa = Q + "/eye/v2_" + v + ".png"; old = True
    if not all(os.path.exists(p) for p in (pa, pw3, pb)):
        print("없음", s["id"]); continue
    ims = [Image.open(p).convert("RGB") for p in (pa, pw3, pb)]
    w, h = ims[0].size
    W_, H_ = w // 2, h // 2
    ims = [im.resize((W_, H_), Image.LANCZOS) for im in ims]
    c = Image.new("RGB", (W_ * 3 + 16, H_ * 2 + 8 + 40), (18, 18, 26))
    for k, im in enumerate(ims):
        c.paste(im, (k * (W_ + 8), 40)); c.paste(bright(im), (k * (W_ + 8), 40 + H_ + 8))
    d = ImageDraw.Draw(c)
    kind = {"field": "들판", "forest_edge": "숲 가장자리", "mount_foot": "산 밑", "between": "장소 사이", "road": "길"}.get(s["kind"], s["kind"])
    d.text((8, 6), "%s %s (%.1f, %.1f) 방향 %.0f° — 왼쪽 v2 / 가운데 w3 / 오른쪽 w4 (새 소품). 아래 = 밝게(분석용)%s" % (
        s["id"], kind, s["x"], s["z"], s["yaw"], "  ※ v2 는 이전 렌더(점광원이 흰 공)" if old else ""), fill=(235, 235, 235), font=f1)
    c.save(E + "/cmp_%s.png" % s["id"])
    thumbs.append((s["id"], ims))
if thumbs:
    tw, th = 300, 169
    G = Image.new("RGB", ((tw * 3 + 16) * 2 + 12, (th + 24) * ((len(thumbs) + 1) // 2)), (18, 18, 26))
    d = ImageDraw.Draw(G)
    for i, (sid, ims) in enumerate(thumbs):
        x0, y0 = (i % 2) * (tw * 3 + 28), (i // 2) * (th + 24)
        for k, im in enumerate(ims):
            G.paste(bright(im.resize((tw, th))), (x0 + k * (tw + 4), y0 + 22))
        d.text((x0 + 4, y0 + 2), sid + "  v2 | w3 | w4 (밝게)", fill=(230, 230, 230), font=f2)
    G.save(E + "/cmp_all.png")
print("끝", len(thumbs))
