#!/bin/bash
# w4 눈높이 렌더: render.sh <월드 폴더> <접두사> <보기 목록 파일> [samples]   (광원 숨김, 소품 kit_world)
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
E=$S/world_v3_qa/eye_w4
V=$(cat $3)
SM=${4:-24}
cd $E
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $1 $S/kit_world $E/$2 $V $SM > $E/$2.log 2>&1
echo "$2 exit $?" >> $E/status.txt
