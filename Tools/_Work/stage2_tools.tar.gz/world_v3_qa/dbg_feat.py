import sys, pickle, collections
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import worldgen as wg
import numpy as np
from terrain import box_blur, ss
wg.log = lambda *a: None
meta = wg.load_manifest(sys.argv[2])
W = wg.World(); W.lights, W.fx, W.scenes = [], [], []
wg.build_height(W)
W.forest = np.zeros(W.h.shape, np.float32)
P = wg.Placer(W, meta, np.random.default_rng(7))
pads = wg.lay_landmarks(W, P); wg.finish_height(W, pads)
water = wg.water_planes(W); wg.make_pool_mask(W); wg.bridge_ramps(W)
gz, gx = np.gradient(W.h); W.slope, W.gx, W.gz = np.sqrt(gx * gx + gz * gz), gx, gz
wg.forest_plan(W)
np.save(sys.argv[1] + "/h.npy", W.h); np.save(sys.argv[1] + "/mount.npy", W.mount.astype(np.float32)); np.save(sys.argv[1] + "/fplan.npy", W.forest_plan)
pickle.dump({"roads": W.road_curves, "creek_win": W.creek_win, "creek_dist": W.creek_dist, "creek_wt": W.creek_wt,
             "road_dist": W.road_dist, "road_hw": W.road_hw}, open(sys.argv[1] + "/w.pkl", "wb"))
F = wg.site_features(W)
RF = wg.road_features(W, F)
for k in wg.ROAD_FEATS:
    pass
c = collections.Counter(r[4] for r in RF)
print("길 표본", len(RF), "최고 특징", c)
