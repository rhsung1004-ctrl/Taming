# 눈높이 합격 지표 (렌더와 같은 자리·방향): 화면 안(세로 시야 60°, 16:9 → 가로 ±45.7°), 지형 시선(눈 땅 + 1.7 m)
#   (a) 40 m 안 '중간 크기 볼거리' 수와 종류 수
#       소품을 4 m 이웃으로 묶은 무리 가운데: 요소 2 개 이상이거나, 긴 변·키 중 큰 값이 1.8 m 넘는 것(큰 덤불·큰 바위·고목·선돌·담 …)이
#       있으면 볼거리 하나. 요소 = 키 1.0 m 넘거나 (긴 변 3 m 넘고 키 0.5 m 넘는) 소품 — 눈높이에서 풀(0.4~0.8 m) 위로 드러나는 것.
#       (풀·꽃·해골·초·버섯·돌무더기·그루터기처럼 낮은 것은 고사리에 묻혀 요소가 아니다)
#       종류 = 무리 안 요소의 대표 분류 (담·울타리 / 무덤·석상·폐허 / 바위 노두 / 나무 무리 / 고목 하나 / 덤불 / 뼈 / 장면 소품)
#       + 지형 볼거리 (v3 _fill.json: 마른 도랑, 밭 턱, 작은 둔덕) — 따로 센다
#   (b) 80 m 밖: 보이는 빛 (LightCuller 끄는 거리 안: far 또는 range × 12) 과 키 4 m 넘는 실루엣 (400 m 안)
#   python3 eye_metrics.py <eye_spots.json> <월드 폴더> [<월드 폴더> ...]   (첫 줄: 판 이름 = 폴더 이름)
import sys, os, json, math, glob, collections
import numpy as np

KIT = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_out"
NEW_SUB = {"gallows": ("dead_tree_c", 1.0), "hanging_cage": ("dead_tree_c", 0.7), "brazier": ("lantern", 1.0), "banner_torn": ("bone_spike", 1.0),
           "sarcophagus": ("coffin", 1.0), "cart_broken": ("log_fallen", 1.0), "soul_crystal": ("rock_b", 0.6), "skeleton_remains": ("bones_scatter", 1.0),
           "iron_fence": ("fence", 1.0), "mausoleum_small": ("grave_tomb", 1.15), "shrine_roadside": ("grave_obelisk", 1.0),
           "obelisk_chained": ("grave_obelisk", 1.7), "campfire": ("rubble", 0.75), "stone_wall_low": ("wall_ruin_b", 0.5), "standing_stone": ("cliff_b", 0.34)}
MAN = {}
for f in glob.glob(KIT + "/manifest_*.json"):
    for k, v in json.load(open(f)).items():
        MAN[k] = (v.get("size") or [1, 1, 1], v.get("meta", {}))
SMALL = {"skull", "flower_lily", "mushroom_glow", "mushroom_toxic", "candles", "lotus_glow", "grass_a", "grass_b", "grass_dead", "fern_a", "weeds", "reed"}


def cat(a, hgt, L):
    if a.startswith("dead_tree") or a == "tree_giant":
        return "tree"
    if a in ("bramble", "bush_dead"):
        return "brush"
    if a.startswith("cliff_") or a in ("rock_b", "rock_flat", "rock_a", "rock_c"):
        return "rock"
    if a.startswith("wall_ruin") or a in ("fence", "fence_gate", "stair_ruin", "pillar_a", "pillar_b", "arch_ruin", "rubble"):
        return "wall"
    if a.startswith("grave_") or a in ("coffin", "statue_angel", "statue_reaper", "crypt", "altar", "lantern", "well"):
        return "grave"
    if a.startswith("dragon_") or a in ("bone_pile", "bone_spike", "bones_scatter"):
        return "bone"
    if a in ("log_fallen", "stump", "roots"):
        return "wood"
    return "other"


KIND_NAME = {"wall": "담·울타리", "grave": "무덤·석상·폐허", "rock": "바위", "tree": "나무 무리", "tree1": "고목 하나", "brush": "덤불",
             "bone": "뼈", "wood": "쓰러진 나무", "other": "기타", "stone": "선돌"}


def load(world):
    D = world + "/Data~"
    W = json.load(open(D + "/world.json"))
    n = W["heightRes"]
    h = np.fromfile(D + "/height.r16", "<u2").reshape(n, n).astype(np.float32) / 65535 * W["height"]
    O = json.load(open(D + "/objects.json"))
    T = json.load(open(D + "/trees.json"))
    E = []                    # x, z, 땅 높이 기준 꼭대기 높이, 긴 변, 분류, 이름
    for o in O["objects"]:
        a = o["a"]
        if a in SMALL:
            continue
        size, meta = MAN.get(a, (None, None))
        s = o["s"]
        if size is None:
            continue
        hgt = size[2] * s
        L = max(size[0], size[1]) * s
        E.append((o["p"][0], o["p"][2], o["p"][1], hgt, L, a))
    for t in T["instances"]:
        a = T["prototypes"][int(t[0])]
        if a in SMALL:
            continue
        size, meta = MAN.get(a, (None, None))
        if size is None:
            continue
        s = t[4]
        E.append((t[1], t[2], None, size[2] * s - meta.get("sink", 0) * s, max(size[0], size[1]) * s, a))
    LT = []
    for l in O.get("lights", []):
        LT.append((l["p"][0], l["p"][2], l["p"][1], l.get("far") or min(max(l["r"] * 12, 30), 200)))
    for o in O["objects"]:
        size, meta = MAN.get(o["a"], (None, {}))
        li = (meta or {}).get("light")
        if li and (meta or {}).get("kind") != "tree":
            LT.append((o["p"][0], o["p"][2], o["p"][1] + li["offset"][2] * o["s"], li.get("far") or min(max(li["range"] * 12, 30), 200)))
    fill = json.load(open(world + "/_fill.json")) if os.path.exists(world + "/_fill.json") else None
    scenes = json.load(open(world + "/_scenes.json")) if os.path.exists(world + "/_scenes.json") else []
    G = {}
    for e in E:
        G.setdefault((int(e[0] // 32), int(e[1] // 32)), []).append(e)
    TALLE = [e for e in E if e[3] >= 4.0]
    return W, h, (E, G, TALLE), LT, fill, scenes


def H(h, x, z):
    n = h.shape[0]
    x = np.clip(x, 0, n - 1.001); z = np.clip(z, 0, n - 1.001)
    x0 = np.int32(x); z0 = np.int32(z); fx = x - x0; fz = z - z0
    return h[z0, x0] * (1 - fx) * (1 - fz) + h[z0, x0 + 1] * fx * (1 - fz) + h[z0 + 1, x0] * (1 - fx) * fz + h[z0 + 1, x0 + 1] * fx * fz


def los(h, ox, oz, oy, tx, tz, ty):
    d = math.hypot(tx - ox, tz - oz)
    m = max(4, int(d / 1.5))
    t = np.linspace(0.03, 0.97, m)
    return bool(np.all(H(h, ox + (tx - ox) * t, oz + (tz - oz) * t) < oy + (ty - oy) * t - 0.1))


HALF = math.degrees(math.atan(math.tan(math.radians(30)) * 16 / 9))


def in_view(x, z, cx, cz, yw):
    a = math.degrees(math.atan2(x - cx, z - cz))
    return abs((a - yw + 180) % 360 - 180) <= HALF


def analyse(world_pack, sp):
    W, h, (E, G, TALLE), LT, fill, scenes = world_pack
    cx, cz, yw = sp["x"], sp["z"], sp["yaw"]
    ey = float(H(h, cx, cz)) + 1.7
    near = []
    cand = [e for i in range(int((cx - 46) // 32), int((cx + 46) // 32) + 1) for j in range(int((cz - 46) // 32), int((cz + 46) // 32) + 1)
            for e in G.get((i, j), ())]
    for (x, z, y, hgt, L, a) in cand:
        d = math.hypot(x - cx, z - cz)
        if d > 46 or d < 0.8:
            continue
        if hgt < 1.0 and not (L >= 3.0 and hgt >= 0.5):         # 풀(0.4~0.8 m) 위로 드러나는 것만
            continue
        near.append((x, z, y, hgt, L, a, d))
    # 6 m 이웃 무리
    n = len(near)
    par = list(range(n))

    def f(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i
    for i in range(n):
        for j in range(i + 1, n):
            if (near[i][0] - near[j][0]) ** 2 + (near[i][1] - near[j][1]) ** 2 < 16:
                par[f(i)] = f(j)
    groups = collections.defaultdict(list)
    for i in range(n):
        groups[f(i)].append(near[i])
    feats = []
    for g in groups.values():
        big = [e for e in g if max(e[3], e[4]) >= 1.8]
        if len(g) < 2 and not big:
            continue
        # 화면 안·40 m 안·보이는 요소가 하나라도 있어야
        seen = []
        for (x, z, y, hgt, L, a, d) in g:
            if d > 40 or not in_view(x, z, cx, cz, yw):
                continue
            gy = float(H(h, x, z))
            if los(h, cx, cz, ey, x, z, gy + max(0.5, 0.75 * hgt)):
                seen.append((x, z, y, hgt, L, a, d))
        if not seen:
            continue
        cats = collections.Counter(cat(e[5], e[3], e[4]) for e in g)
        if cats.get("wall"):
            k = "wall"
        elif cats.get("grave"):
            k = "grave"
        elif any(e[5] == "cliff_b" and e[3] > 2.0 and e[3] < 6 for e in g) and not cats.get("tree"):
            k = "stone"
        elif cats.get("tree", 0) >= 3:
            k = "tree"
        elif cats.get("rock", 0) >= 2 or any(e[5].startswith("cliff_") for e in g):
            k = "rock"
        elif cats.get("tree"):
            k = "tree1" if cats.get("tree") == 1 and len(g) < 4 else "tree"
        elif cats.get("bone"):
            k = "bone"
        else:
            k = cats.most_common(1)[0][0]
        dmin = min(e[6] for e in seen)
        feats.append((k, round(dmin, 1), len(g)))
    feats.sort(key=lambda t: t[1])
    # 지형 볼거리 (v3)
    terr = []
    if fill:
        for ln in fill["lines"]:
            if ln["t"] not in ("ditch", "scarp"):
                continue
            pts = np.array(ln["pts"])
            dd = np.hypot(pts[:, 0] - cx, pts[:, 1] - cz)
            ok = [i for i in range(len(pts)) if dd[i] < 40 and in_view(pts[i, 0], pts[i, 1], cx, cz, yw)]
            if ok:
                terr.append(("도랑" if ln["t"] == "ditch" else "턱", round(float(dd[ok].min()), 1)))
        for it in fill["items"]:
            if it["t"] == "barrow":
                d = math.hypot(it["p"][0] - cx, it["p"][1] - cz)
                if d < 40 and in_view(it["p"][0], it["p"][1], cx, cz, yw):
                    terr.append(("둔덕", round(d, 1)))
    # (b) 80 m 밖 빛·키 큰 실루엣
    lights = 0
    for (x, z, y, cull) in LT:
        d = math.hypot(x - cx, z - cz)
        if 80 < d <= cull and in_view(x, z, cx, cz, yw) and los(h, cx, cz, ey, x, z, y):
            lights += 1
    tall = 0
    tall_k = collections.Counter()
    for (x, z, y, hgt, L, a) in TALLE:
        if hgt < 4.0:
            continue
        d = math.hypot(x - cx, z - cz)
        if not (80 < d <= 400) or not in_view(x, z, cx, cz, yw):
            continue
        gy = float(H(h, x, z))
        if los(h, cx, cz, ey, x, z, gy + hgt * 0.85):
            tall += 1
            tall_k[cat(a, hgt, L)] += 1
    return feats, terr, lights, tall, tall_k


if __name__ == "__main__":
    spots = json.load(open(sys.argv[1]))
    worlds = sys.argv[2:]
    packs = [load(w) for w in worlds]
    res = {}
    for sp in spots:
        line = "%-3s %-5s (%6.1f, %6.1f) 방향 %5.1f°" % (sp["id"], "길" if sp["kind"] == "road" else "들판", sp["x"], sp["z"], sp["yaw"])
        print(line)
        res[sp["id"]] = {}
        for w, pk in zip(worlds, packs):
            feats, terr, lights, tall, tall_k = analyse(pk, sp)
            kinds = sorted(set(k for k, _, _ in feats))
            okA = len(feats) + len(terr) >= 3
            okB = lights + tall >= 1
            res[sp["id"]][os.path.basename(w)] = {"feats": feats, "kinds": kinds, "terrain": terr, "lights80": lights, "tall80": tall, "a": okA, "b": okB}
            print("   %-12s (a) 40 m 안 볼거리 %2d 개, 종류 %d [%s]%s | (b) 80 m 밖 빛 %d, 키 4 m 넘는 실루엣 %d (%s)  → a %s, b %s" % (
                os.path.basename(w), len(feats), len(kinds), ", ".join("%s %.0fm" % (KIND_NAME[k], d) for k, d, _ in feats[:8]),
                (" + 지형 " + ", ".join("%s %.0fm" % t for t in terr[:4])) if terr else "", lights, tall,
                ", ".join("%s %d" % kv for kv in tall_k.most_common(3)), "통과" if okA else "미달", "통과" if okB else "미달"))
    for w in worlds:
        b = os.path.basename(w)
        nt = [len(res[s][b]["feats"]) + len(res[s][b]["terrain"]) for s in res]
        na = sum(res[s][b]["a"] for s in res)
        nb = sum(res[s][b]["b"] for s in res)
        nf = [len(res[s][b]["feats"]) for s in res]
        nk = [len(res[s][b]["kinds"]) for s in res]
        print("[%s] (a) 통과 %d/%d, (b) 통과 %d/%d | 40 m 안 소품 볼거리 수 중앙값 %.1f (최소 %d), + 지형 중앙값 %.1f (최소 %d), 종류 수 중앙값 %.1f (최소 %d)" % (
            b, na, len(res), nb, len(res), float(np.median(nf)), min(nf), float(np.median(nt)), min(nt), float(np.median(nk)), min(nk)))
    json.dump(res, open(os.path.join(os.path.dirname(os.path.abspath(sys.argv[1])), "eye_metrics.json"), "w"), ensure_ascii=False, indent=1)
