import sys, math, json, numpy as np, collections
sys.argv = ["x", sys.argv[1]]
import eye_metrics as em
w = sys.argv[1]
pk = em.load(w)
exec(open("fill_metrics.py").read().split("print(\"표본")[0].replace("worlds = sys.argv[1:]", "worlds=[w]"))
cat = collections.Counter(); tot = collections.Counter()
fails = []
for (x, z) in pts:
    de = min(x - bx0, bx1 - x, z - bz0, bz1 - z)
    dfs = math.hypot(x - 562, z - 722) - 185
    dfn = math.hypot(x - 1372, z - 1335) - 140
    k = "edge<70" if de < 70 else ("forest" if min(dfs, dfn) < 20 else "field")
    for yw in (0, 90, 180, 270):
        f, t, l, ta, _ = em.analyse(pk, {"x": x, "z": z, "yaw": yw})
        ok = len(f) + len(t) >= 3
        tot[k] += 1
        if not ok:
            cat[k] += 1
            fails.append((round(x), round(z), yw, len(f)))
for k in tot:
    print(k, "실패 %d / %d (%.0f%%)" % (cat[k], tot[k], 100 * cat[k] / tot[k]))
print(fails[:40])
