# 시선 지표 (지형 시선, 눈높이 1.7 m): 150 m 안에 장면·장소·등대 빛이 하나 이상 보이는가
#   python3 sightline.py <월드 출력 폴더 (Data~, _scenes.json)> <소품 폴더(kit_out)> [--roads <_roads.json>] [--label 이름]
# - 길: 길 중심선을 10 m 마다 걷는다 (_roads.json. 없으면 --roads 로 다른 판의 것을 준다: v2 와 v3 는 길이 같다)
# - 길 밖: 걸을 수 있는 땅(칸 기울기 ≤ 1.0, 범위 안, 물 밖, 길 가장자리 3 m 밖) 무작위 4,000 점 (씨앗 고정)
# - 표적:
#     장면 = _scenes.json 의 가장 키 큰 세로 요소 꼭대기 (top). 없으면(v2) 땅 + 2.5 m
#     장소 = 장소 원 안이면 보임. 아니면 가운데(땅 + 5 m)와 반지름 0.6 배 둘레 8 점(땅 + 3 m) 중 하나가 보이면
#     등대 빛 = objects.json lights 의 far 가 있는 광원과 META.light.far 가 있는 소품 광원 (거리 ≤ min(150, far))
# - 보임 = 눈(땅 + 1.7 m)에서 표적까지 선분 아래로 지형이 0.1 m 넘게 올라오지 않는다 (2 m 마다 본다). 나무·소품 가림은 보지 않는다
import sys, os, json, glob, math, collections
import numpy as np

args = sys.argv[1:]
OUTDIR, KIT = args[0], args[1]
ROADS = os.path.join(OUTDIR, "_roads.json")
LABEL = os.path.basename(OUTDIR.rstrip("/"))
if "--roads" in args:
    ROADS = args[args.index("--roads") + 1]
if "--label" in args:
    LABEL = args[args.index("--label") + 1]
D = os.path.join(OUTDIR, "Data~")
SIGHT, EYE = 150.0, 1.7
W = json.load(open(D + "/world.json"))
n = W["heightRes"]
h = np.fromfile(D + "/height.r16", "<u2").reshape(n, n).astype(np.float32) / 65535 * W["height"]
O = json.load(open(D + "/objects.json"))
SC = json.load(open(os.path.join(OUTDIR, "_scenes.json")))
RD = json.load(open(ROADS))
man = {}
for f in glob.glob(KIT + "/manifest_*.json"):
    man.update(json.load(open(f)))
(b0x, b0z), (b1x, b1z) = W["bounds"]["min"], W["bounds"]["max"]


def H(x, z):
    x = np.clip(x, 0, n - 1.001); z = np.clip(z, 0, n - 1.001)
    x0 = x.astype(np.int32); z0 = z.astype(np.int32); fx = x - x0; fz = z - z0
    return h[z0, x0] * (1 - fx) * (1 - fz) + h[z0, x0 + 1] * fx * (1 - fz) + h[z0 + 1, x0] * (1 - fx) * fz + h[z0 + 1, x0 + 1] * fx * fz


def los(ox, oz, oy, tx, tz, ty):
    d = np.hypot(tx - ox, tz - oz)
    m = int(max(8, d.max() / 2.0))
    t = np.linspace(0.02, 0.97, m)[None, :]
    sx = ox[:, None] + (tx - ox)[:, None] * t
    sz = oz[:, None] + (tz - oz)[:, None] * t
    line = oy[:, None] + (ty - oy)[:, None] * t
    return (H(sx, sz) < line - 0.1).all(1)


# ── 표본 ──
road_pts = []
for r in RD:
    c = np.array(r["pts"], float)
    seg = np.linalg.norm(np.diff(c, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    for t in np.arange(0, s[-1], 10.0):
        road_pts.append((np.interp(t, s, c[:, 0]), np.interp(t, s, c[:, 1]), r["name"]))
RS = np.array([(a, b) for a, b, _ in road_pts])
RN = [c for _, _, c in road_pts]
allroad = np.concatenate([np.array(r["pts"], float) for r in RD])
allhw = np.concatenate([np.full(len(r["pts"]), r["hw"]) for r in RD])
gz_, gx_ = np.gradient(h)
h00 = h[:-1, :-1]; h10 = h[:-1, 1:]; h01 = h[1:, :-1]; h11 = h[1:, 1:]
cell_sl = np.maximum.reduce([np.hypot(h10 - h00, h11 - h10), np.hypot(h11 - h01, h01 - h00), np.hypot(h10 - h00, h01 - h00), np.hypot(h11 - h01, h11 - h10)])
lv = W.get("levels", {})
waters = [(w["p"][0], w["p"][2], w["size"][0] / 2, w["size"][1] / 2, w.get("yaw", 0), w["p"][1]) for w in O.get("water", [])]


def under_water(x, z):
    hh = H(np.array([x]), np.array([z]))[0]
    for (cx, cz, hx, hz, yaw, lev) in waters:
        a = math.radians(yaw)
        u = (x - cx) * math.cos(a) - (z - cz) * math.sin(a)
        v = (x - cx) * math.sin(a) + (z - cz) * math.cos(a)
        if abs(u) <= hx and abs(v) <= hz and hh < lev + 0.05:
            return True
    return False


rng = np.random.default_rng(20261124)
OS = []
while len(OS) < 4000:
    x, z = rng.uniform(b0x + 1, b1x - 1), rng.uniform(b0z + 1, b1z - 1)
    if cell_sl[int(z), int(x)] > 1.0:
        continue
    d = np.hypot(allroad[:, 0] - x, allroad[:, 1] - z)
    k = int(np.argmin(d))
    if d[k] < allhw[k] + 3:
        continue
    if under_water(x, z):
        continue
    OS.append((x, z))
OS = np.array(OS)
ALL = np.concatenate([RS, OS])
nR = len(RS)
eye = H(ALL[:, 0], ALL[:, 1]) + EYE

# ── 표적 ──
seen = {"scene": np.zeros(len(ALL), int), "place": np.zeros(len(ALL), bool), "beacon": np.zeros(len(ALL), bool)}
seen100 = np.zeros(len(ALL), bool)
same_type = [collections.Counter() for _ in range(len(ALL))]
nearest_seen = np.full(len(ALL), 1e9)
for s in SC:
    x, z = s["p"]
    ty = s["top"][1] if s.get("top") else float(H(np.array([x]), np.array([z]))[0]) + 2.5
    tx, tz = (s["top"][0], s["top"][2]) if s.get("top") else (x, z)
    d = np.hypot(ALL[:, 0] - tx, ALL[:, 1] - tz)
    idx = np.nonzero(d < SIGHT)[0]
    if not len(idx):
        continue
    v = idx[los(ALL[idx, 0], ALL[idx, 1], eye[idx], tx, tz, ty)]
    seen["scene"][v] += 1
    seen100[v[d[v] < 100]] = True
    nearest_seen[v] = np.minimum(nearest_seen[v], d[v])
    for i in v:
        same_type[i][s["type"]] += 1
for p in W["pois"]:
    cx, cz, r = p["p"][0], p["p"][2], p["r"]
    inside = np.hypot(ALL[:, 0] - cx, ALL[:, 1] - cz) < r
    seen["place"] |= inside
    seen100 |= inside
    pts = [(cx, cz, float(H(np.array([cx]), np.array([cz]))[0]) + 5.0)]
    for k in range(8):
        a = k / 8 * 2 * math.pi
        x, z = cx + math.cos(a) * r * 0.6, cz + math.sin(a) * r * 0.6
        pts.append((x, z, float(H(np.array([x]), np.array([z]))[0]) + 3.0))
    for (tx, tz, ty) in pts:
        d = np.hypot(ALL[:, 0] - tx, ALL[:, 1] - tz)
        idx = np.nonzero((d < SIGHT) & ~seen["place"])[0]
        if len(idx):
            v = idx[los(ALL[idx, 0], ALL[idx, 1], eye[idx], tx, tz, ty)]
            seen["place"][v] = True
            seen100[v[d[v] < 100]] = True
B = []
for l in O["lights"]:
    if l.get("far"):
        B.append((l["p"][0], l["p"][2], l["p"][1], l["far"]))
for o in O["objects"]:
    lt = man.get(o["a"], {}).get("meta", {}).get("light")
    if lt and lt.get("far"):
        B.append((o["p"][0], o["p"][2], o["p"][1] + lt["offset"][2] * o["s"], lt["far"]))
for (tx, tz, ty, far) in B:
    rad = min(SIGHT, far)
    d = np.hypot(ALL[:, 0] - tx, ALL[:, 1] - tz)
    idx = np.nonzero((d < rad) & ~seen["beacon"])[0]
    if len(idx):
        v = idx[los(ALL[idx, 0], ALL[idx, 1], eye[idx], tx, tz, ty)]
        seen["beacon"][v] = True
anyv = (seen["scene"] > 0) | seen["place"] | seen["beacon"]


def pct(m):
    return 100.0 * m.mean() if len(m) else 0.0


R_, O_ = slice(0, nR), slice(nR, None)
print("[%s] 시선 지표 (지형 시선, 눈 1.7 m, 150 m 안) — 장면 %d 곳, 장소 %d 곳, 등대 빛 %d 개" % (LABEL, len(SC), len(W["pois"]), len(B)))
print("  길 10 m 마다 %d 점: 장면·장소·등대 빛 하나 이상 보임 %.1f%% (기준 ≥ 95%%) | 장면 %.1f%%, 장소 %.1f%%, 등대 빛 %.1f%%, 등대 빛 빼고 %.1f%%" % (
    nR, pct(anyv[R_]), pct(seen["scene"][R_] > 0), pct(seen["place"][R_]), pct(seen["beacon"][R_]),
    pct((seen["scene"][R_] > 0) | seen["place"][R_])))
print("  길 밖 걸을 수 있는 땅 %d 점: 하나 이상 보임 %.1f%% (기준 ≥ 85%%) | 장면 %.1f%%, 장소 %.1f%%, 등대 빛 %.1f%%, 등대 빛 빼고 %.1f%%" % (
    len(OS), pct(anyv[O_]), pct(seen["scene"][O_] > 0), pct(seen["place"][O_]), pct(seen["beacon"][O_]),
    pct((seen["scene"][O_] > 0) | seen["place"][O_])))
print("  100 m 안 장면·장소가 보임: 길 %.1f%%, 길 밖 %.1f%%" % (pct(seen100[R_]), pct(seen100[O_])))
for nm, sl in (("길", R_), ("길 밖", O_)):
    sc = seen["scene"][sl]
    nd = nearest_seen[sl]
    print("  %s: 보이는 장면 수 중앙값 %d, 2 곳 이상 %.1f%%, 4 곳 이상 %.1f%%. 보이는 가장 가까운 장면 거리 중앙값 %.0f m" % (
        nm, np.median(sc), pct(sc >= 2), pct(sc >= 4), np.median(nd[nd < 1e8]) if (nd < 1e8).any() else -1))
dup = np.array([any(v >= 2 for v in c.values()) for c in same_type])
print("  150 m 안에 같은 틀 장면이 둘 이상 보이는 점: 길 %.1f%%, 길 밖 %.1f%%" % (pct(dup[R_]), pct(dup[O_])))
miss = np.nonzero(~anyv[R_])[0]
if len(miss):
    by = collections.Counter(RN[i] for i in miss)
    print("  길에서 아무것도 안 보이는 점 %d 개: %s" % (len(miss), dict(by.most_common())))
    print("    예:", [(int(RS[i, 0]), int(RS[i, 1])) for i in miss[:: max(1, len(miss) // 10)][:10]])
miss = np.nonzero(~anyv[O_])[0]
if len(miss):
    print("  길 밖에서 아무것도 안 보이는 점 %d 개, 예: %s" % (len(miss), [(int(OS[i, 0]), int(OS[i, 1])) for i in miss[:: max(1, len(miss) // 12)][:12]]))
np.savez(os.path.join(os.path.dirname(os.path.abspath(__file__)), "sightline_%s.npz" % LABEL), pts=ALL, nR=nR, scene=seen["scene"], place=seen["place"],
         beacon=seen["beacon"])
