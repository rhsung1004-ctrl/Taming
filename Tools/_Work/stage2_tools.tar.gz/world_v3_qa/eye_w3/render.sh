#!/bin/bash
# w3 눈높이 22곳 렌더 (검토자 10 + 작업자 12): w3 최종판과 v2 를 같은 설정(광원 숨김, samples 24)으로
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
V=$(cat /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/views.txt)
cd /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $S/world_v3 $S/kit_out /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/w3_ $V 24 > /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/w3.log 2>&1
echo w3 exit $? >> /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/status.txt
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $S/world_v2 $S/kit_out /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/v2_ $V 24 > /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/v2.log 2>&1
echo v2 exit $? >> /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/status.txt
