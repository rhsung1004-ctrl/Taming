# w3 눈높이 비교: compare.py  → cmp_<id>.png (왼쪽 v2, 오른쪽 w3 최종, 위 = 그대로, 아래 = 밝게(분석용)), cmp_all.png
# 두 판 모두 같은 render_world.py (점광원 카메라에 안 보임 = Unity 와 같음), samples 24
import json, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
E = os.path.dirname(os.path.abspath(__file__))
FONT = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
f1, f2 = ImageFont.truetype(FONT, 22), ImageFont.truetype(FONT, 17)
spots = json.load(open(E + "/spots_all.json"))
met = json.load(open(E + "/m/eye_metrics.json")) if os.path.exists(E + "/m/eye_metrics.json") else {}
def bright(im):
    a = np.asarray(im).astype(np.float32) / 255.0
    return Image.fromarray((np.clip(a * 2.6, 0, 1) ** 0.8 * 255).astype(np.uint8))
thumbs = []
for s in spots:
    v = "eye_%.1f_%.1f_%.1f" % (s["x"], s["z"], s["yaw"])
    pa, pb = E + "/v2_" + v + ".png", E + "/w3_" + v + ".png"
    old = False
    if not os.path.exists(pa):                      # 작업자 자리 v2 는 이전 렌더 (점광원이 흰 공으로 보이는 설정)를 쓴다
        pa = os.path.dirname(E) + "/eye/v2_" + v + ".png"
        old = True
    if not (os.path.exists(pa) and os.path.exists(pb)):
        print("없음", s["id"]); continue
    A, B = Image.open(pa).convert("RGB"), Image.open(pb).convert("RGB")
    w, h = A.size
    W_, H_ = w // 2, h // 2
    A, B = A.resize((W_, H_), Image.LANCZOS), B.resize((W_, H_), Image.LANCZOS)
    c = Image.new("RGB", (W_ * 2 + 8, H_ * 2 + 8 + 64), (18, 18, 26))
    for k, im in enumerate((A, B)):
        c.paste(im, (k * (W_ + 8), 64)); c.paste(bright(im), (k * (W_ + 8), 64 + H_ + 8))
    d = ImageDraw.Draw(c)
    kind = {"field": "들판", "forest_edge": "숲 가장자리", "mount_foot": "산 밑", "between": "장소 사이", "road": "길"}.get(s["kind"], s["kind"])
    d.text((8, 4), "%s %s (%.1f, %.1f) 방향 %.0f° — 왼쪽 v2 / 오른쪽 w3 최종 %s. 아래 = 밝게(분석용)" % (s["id"], kind, s["x"], s["z"], s["yaw"],
           "(v2 는 이전 렌더: 점광원이 흰 공으로 보여 실제보다 밝다)" if old else "(같은 설정: 점광원 숨김, samples 24)"), fill=(235, 235, 235), font=f1)
    m = met.get(s["id"], {})
    t = []
    for nm, lab in (("world_v2", "v2"), ("world_v3", "w3")):
        r = m.get(nm)
        if r:
            t.append("%s: (a) 40 m 안 볼거리 %d (%s) | (b) 80 m 밖 발광 빛 %d, 실루엣 %d" % (lab, len(r["feats"]) + len(r["terrain"]), "통과" if r["a"] else "미달", r["lights80"], r["tall80"]))
    d.text((8, 34), "   ".join(t), fill=(200, 200, 160), font=f2)
    c.save(E + "/cmp_%s.png" % s["id"])
    thumbs.append((s["id"], A, B))
if thumbs:
    tw, th = 320, 180
    G = Image.new("RGB", ((tw * 2 + 12) * 2, (th + 24) * ((len(thumbs) + 1) // 2)), (18, 18, 26))
    d = ImageDraw.Draw(G)
    for i, (sid, A, B) in enumerate(thumbs):
        x0, y0 = (i % 2) * (tw * 2 + 12), (i // 2) * (th + 24)
        G.paste(bright(A.resize((tw, th))), (x0, y0 + 22)); G.paste(bright(B.resize((tw, th))), (x0 + tw + 4, y0 + 22))
        d.text((x0 + 4, y0 + 2), sid + "  v2 | w3 (밝게)", fill=(230, 230, 230), font=f2)
    G.save(E + "/cmp_all.png")
print("끝", len(thumbs))
