#!/bin/bash
# w3 최종판 눈높이 22곳 렌더 (광원 숨김, samples 24)
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
V=$(cat /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/views.txt)
cd /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3
flock $S/blender.lock blender -b --python-exit-code 1 -P /home/user/Taming/Tools/WorldGen/render_world.py -- $S/world_v3 $S/kit_out /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/w3_ $V 24 > /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/w3.log 2>&1
echo w3final exit $? >> /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/eye_w3/status.txt
