#!/bin/bash
# w4: 새 소품(kit_world = kit_out + kit_scenes) 으로 만든 월드 검사 전부: run_qa_w4.sh <월드 폴더> <결과 폴더> [소품 폴더]
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
D=$1/Data~
Q=$2
K=${3:-$S/kit_world}
mkdir -p $Q/escape $Q/nav $Q/perf $Q/placement
cp $S/world_v3_qa/escape/*.py $Q/escape/ 2>/dev/null
( cd $Q/escape && python3 $S/qa_checks/escape_gate.py $D 1.19 > $Q/escape_119.txt 2>&1; python3 $S/qa_checks/escape_gate.py $D 1.0 > $Q/escape_100.txt 2>&1 ) &
( cd $S/wf_world/navigation && export NAV_KIT=$K && NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_flood.py 1.0 large 1 > $Q/nav_flood_100.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_flood.py 1.19 large 1 > $Q/nav_flood_119.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_roads.py > $Q/nav_roads.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_bridge.py > $Q/nav_bridge.txt 2>&1 ) &
( cd $S/wf_world/perf_qa && KIT_OUT=$K WORLD_DATA=$D PERF_OUT=$Q/perf ./run_v2.sh > $Q/perf.log 2>&1 ) &
wait
( cd $S/wf_world/placement_qa && WORLD_DATA=$D KIT_OUT=$K ./run_all.sh > $Q/placement.log 2>&1; cp out_*.txt ground_*.csv $Q/placement/ )
echo QA_DONE
