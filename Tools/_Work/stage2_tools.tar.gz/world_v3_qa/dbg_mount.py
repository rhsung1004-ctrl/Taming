import sys, numpy as np
sys.path.insert(0, "/home/user/Taming/Tools/WorldGen")
import worldgen as wg
W = wg.World(); W.lights, W.fx, W.scenes = [], [], []
wg.build_height(W)
gz, gx = np.gradient(W.h); sl = np.hypot(gx, gz)
(bx0, bz0), (bx1, bz1) = wg.BOUNDS
win = (slice(bz0, bz1), slice(bx0, bx1))
m = W.mount[win]; s = sl[win]
walk = s < 0.6
for t in (0.03, 0.08, 0.15, 0.3, 0.5):
    print("mount >= %.2f: walkable frac %.3f" % (t, ((m >= t) & walk).sum() / walk.sum()))
np.save("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/mount.npy", W.mount.astype(np.float16))
for (x, z) in ((404.9, 1025.3), (1642.2, 1420.2), (1101.3, 401.0), (529.6, 449.2)):
    print((x, z), "mount", round(float(W.mount[int(z), int(x)]), 3), "slope", round(float(sl[int(z), int(x)]), 3))
