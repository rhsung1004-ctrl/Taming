# 장면 구조 지표: 길가 비율, 특징, 이웃 거리, Clark-Evans R, 같은 틀 거리, 세로 요소, 등대 빛
import json, sys, math, collections, numpy as np
OUT = sys.argv[1]
sc = json.load(open(OUT + "/_scenes.json"))
W = json.load(open(OUT + "/Data~/world.json"))
PLACE = {"dragon_young", "bone_altar", "spike_ring"}
field = [s for s in sc if s["type"] not in PLACE | {"crossroad"} and s.get("feature") != "forest_clearing"]
print("장면 %d 곳: 들판 %d, 숲 빈터 %d, 갈림길 %d, 용의 무덤 %d" % (len(sc), len(field), sum(s.get("feature") == "forest_clearing" for s in sc),
      sum(s["type"] == "crossroad" for s in sc), sum(s["type"] in PLACE for s in sc)))
rd = np.array([s["road_d"] for s in field])
print("들판 장면 길 40 m 안: %d / %d = %.0f%% (기준 ≥ 60%%). 길까지 거리 중앙값 %.0f m, 90%% %.0f m, 최대 %.0f m" % (
    (rd <= 40).sum(), len(field), 100 * (rd <= 40).mean(), np.median(rd), np.percentile(rd, 90), rd.max()))
print("들판 장면 자리 특징:", dict(collections.Counter((s["feature"], "길가" if s["road_d"] <= 40 else "들판") for s in field)))
print("틀별 수:", dict(collections.Counter(s["type"] for s in sc)))
P = np.array([s["p"] for s in sc], float)
d = np.hypot(P[:, None, 0] - P[None, :, 0], P[:, None, 1] - P[None, :, 1]); np.fill_diagonal(d, 1e9)
nn = d.min(1)
(b0, _), (b1, _) = W["bounds"]["min"], W["bounds"]["max"]
A = (b1 - b0) ** 2
R = nn.mean() / (0.5 * math.sqrt(A / len(sc)))
print("가장 가까운 이웃 장면: 중앙값 %.0f m, 10%% %.0f, 90%% %.0f. Clark-Evans R = %.2f (1 = 무작위, 2.15 = 격자. v2 는 1.60)" % (
    np.median(nn), np.percentile(nn, 10), np.percentile(nn, 90), R))
T = [s["type"] for s in sc]
same = [d[i, j] for i in range(len(sc)) for j in range(i + 1, len(sc)) if T[i] == T[j]]
print("같은 틀 장면 사이 가장 가까운 거리: %.0f m (기준 200 m 넘게), 200 m 안 쌍 %d" % (min(same), sum(1 for v in same if v < 200)))
tall = np.array([s.get("tall", 0) for s in sc])
print("세로 요소 높이: 최소 %.2f m, 중앙값 %.2f m, 3.5 m 넘는 장면 %d / %d" % (tall.min(), np.median(tall), (tall > 3.5).sum(), len(sc)))
print("등대 빛 있는 장면 %d / %d (far %s)" % (sum(1 for s in sc if s.get("beacon")), len(sc),
      sorted(set(s["beacon"][3] for s in sc if s.get("beacon")))))
Z = json.load(open(OUT + "/_zones.json"))
print("무리 %d (장소 보임), 길목 짝 %d: %s" % (sum(h["kind"] == "hamlet" for h in Z["hamlets"]), sum(h["kind"] == "pair" for h in Z["hamlets"]),
      "; ".join("%s %s→%s" % (h["id"], "+".join(h["types"]), ",".join(h["sees"]) or "-") for h in Z["hamlets"])))
q = Z["quiet"]
print("조용한 구역 %d 곳, 넓이 합 %.1f ha, 큰 것: %s" % (len(q), sum(z["area_ha"] for z in q),
      ", ".join("%s %.1f ha (%d, %d)" % (z["id"], z["area_ha"], z["center"][0], z["center"][1]) for z in q[:6])))
