# 눈높이 합격 렌더 나란히 놓기: 왼쪽 v2, 오른쪽 v3 (채움). 자리마다 eye_compare_<id>.png, 전체 한 장 eye_compare_all.png
#   python3 eye_compare.py <eye_spots.json> <v2 접두어> <v3 접두어> <출력 폴더> [eye_metrics.json]
import sys, os, json
from PIL import Image, ImageDraw, ImageFont

spots = json.load(open(sys.argv[1]))
P2, P3, OUT = sys.argv[2], sys.argv[3], sys.argv[4]
MET = json.load(open(sys.argv[5])) if len(sys.argv) > 5 and os.path.exists(sys.argv[5]) else {}
FONT = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
f1 = ImageFont.truetype(FONT, 26)
f2 = ImageFont.truetype(FONT, 20)
KN = {"wall": "담·울타리", "grave": "무덤·폐허", "rock": "바위", "tree": "나무 무리", "tree1": "고목", "brush": "덤불", "bone": "뼈",
      "wood": "쓰러진 나무", "other": "기타", "stone": "선돌"}
tiles = []
for s in spots:
    name = "eye_%s_%s_%s.png" % (s["x"], s["z"], s["yaw"])
    a, b = P2 + name, P3 + name
    if not (os.path.exists(a) and os.path.exists(b)):
        print("없음", s["id"], a if not os.path.exists(a) else b)
        continue
    ia, ib = Image.open(a).convert("RGB"), Image.open(b).convert("RGB")
    w, h = ia.size
    im = Image.new("RGB", (w * 2 + 12, h + 96), (14, 12, 22))
    im.paste(ia, (0, 96))
    im.paste(ib, (w + 12, 96))
    d = ImageDraw.Draw(im)
    where = "길 위 (%s)" % s.get("road", "") if s["kind"] == "road" else "들판 (걸을 수 있는 땅 무작위)"
    d.text((16, 8), "%s  자리 (%.1f, %.1f)  방향 %.0f°  %s  — 눈높이 1.7 m, 세로 시야 60°, 밤" % (s["id"], s["x"], s["z"], s["yaw"], where),
           font=f1, fill=(235, 230, 245))
    for k, (lab, x0) in enumerate((("v2 (이전)", 16), ("v3 채움", w + 28))):
        m = MET.get(s["id"], {}).get(["world_v2", "world_v3"][k], {})
        txt = lab
        if m:
            fe = m["feats"]
            txt += "   40 m 안 볼거리 %d (%s)%s   80 m 밖 빛 %d · 키 큰 실루엣 %d" % (
                len(fe) + len(m.get("terrain", [])), ", ".join(KN.get(t[0], t[0]) for t in fe[:5]),
                (" + 지형 " + ", ".join(t[0] for t in m["terrain"][:3])) if m.get("terrain") else "", m["lights80"], m["tall80"])
        d.text((x0, 52), txt, font=f2, fill=(255, 214, 140) if k else (190, 190, 210))
    out = os.path.join(OUT, "eye_compare_%s.png" % s["id"])
    im.save(out)
    tiles.append(im)
    print(out)
if tiles:
    tw, th = tiles[0].size
    sc = 0.5
    W_, H_ = int(tw * sc), int(th * sc)
    allim = Image.new("RGB", (W_ * 2, H_ * ((len(tiles) + 1) // 2)), (0, 0, 0))
    for i, t in enumerate(tiles):
        allim.paste(t.resize((W_, H_), Image.LANCZOS), ((i % 2) * W_, (i // 2) * H_))
    allim.save(os.path.join(OUT, "eye_compare_all.png"))
