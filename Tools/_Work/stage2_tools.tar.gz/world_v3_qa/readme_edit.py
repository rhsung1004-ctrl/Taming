p = "README.md"
s = open(p, encoding="utf-8").read()
def rep(old, new):
    global s
    assert s.count(old) == 1, old[:70]
    s = s.replace(old, new)
rep('''- `worldgen.py` 배치도(장소·길·개울)와 지역별 배치 규칙. 장소 좌표는 파일 맨 위 `POIS`(발견·지도, 장면·등불 배치 참고)와 그 아래 상수(`ALTAR`, `GRAVE_C`, `CRYPT`, `CATH` … 실제 지형·배치)를 함께 고치고, 길은 `ROADS`(+ 이름 `ROAD_NAMES`), 개울은 `CREEK` 에서 고친다. 작은 장면은 `SCENES`·`sc_*` 함수, 새 소품 예상 META 는 `NEW_PROPS`
- `render_world.py` Blender 확인 렌더 (풀은 카메라 앞만 심는다). 보기: overview, spawn, graveyard, swamp, cathedral, dragon, tree, bridge, gate, village, fields (들판의 작은 장면)''',
'''- `worldgen.py` 배치도(장소·길·개울)와 지역별 배치 규칙. 장소 좌표는 파일 맨 위 `POIS`(발견·지도, 장면·등불 배치 참고)와 그 아래 상수(`ALTAR`, `GRAVE_C`, `CRYPT`, `CATH` … 실제 지형·배치)를 함께 고치고, 길은 `ROADS`(+ 이름 `ROAD_NAMES`), 개울은 `CREEK` 에서 고친다. 작은 장면은 `SCENES`·`SCENE_FEAT`·`sc_*` 함수와 `lay_vignettes`, 새 소품 예상 META 는 `NEW_PROPS`
- `render_world.py` Blender 확인 렌더 (풀은 카메라 앞만 심는다). 장소 보기: overview, spawn, graveyard, swamp, cathedral, dragon, tree, bridge, gate, village.
  v3 눈높이(1.7 m) 보기: fields, roadside, ne_field, hamlet, pair, quiet (장면이 지형에 가리지 않고 보이는 자리), `scene_<틀>` (그 틀의 첫 장면을 앞 24 m 에서. 예: scene_barrow)
- 출력 폴더의 확인용 파일 (Unity 는 읽지 않는다): `_overview.png` (화소 = m, 장면 틀별 색 고리, 무리 흰 점선, 조용한 구역 파랑), `_scenes.json`, `_zones.json`, `_roads.json`, `_boxground.json` (SPEC.md)''')
rep('''## 지도 (지형 2 km × 2 km, 걸어 다니는 범위 1.33 km, X 동쪽, Z 북쪽)''', '''## 지도 (지형 2 km × 2 km, 걸어 다니는 범위 1.33 km, X 동쪽, Z 북쪽)

게임 안 지도(`map.png`)는 걸어 다니는 범위 + 60 m (300 ~ 1750 m) 만 그린다 (world.json `map`, v3. 전에는 지형 2 km 전체라 걸어 다니는 범위가 지도의 65% 였다).''')
a = s.index("### 작은 장면 (`lay_vignettes`, v2)")
b = s.index("### 장면용 새 소품과 대체 규칙 (`NEW_PROPS`)")
new = open("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/readme_scenes.md", encoding="utf-8").read()
s = s[:a] + new + s[b:]
rep('''| 이름 | 크기 (m) | footprint | kind | collider | 광원 (색, 세기, range, 높이) | 대체 |
| --- | --- | --- | --- | --- | --- | --- |
| gallows 교수대 | 3.6 × 1.8 × 4.8 | 1.9 | prop | mesh | 없음 | dead_tree_c (교수목) |
| hanging_cage 매달린 새장 (기둥·팔·새장) | 2.0 × 1.0 × 3.6 | 0.9 | prop | capsule | 영혼 보라, 1.5, 3, 1.9 m | 없음 |
| brazier 화로 | 1.0 × 1.0 × 1.3 | 0.6 | prop | capsule | 영혼 청록, 7, 9, 1.25 m | lantern |''', '''| 이름 | 크기 (m) | footprint | kind | collider | 광원 (색, 세기, range, 높이, far) | 대체 |
| --- | --- | --- | --- | --- | --- | --- |
| gallows 교수대 | 3.6 × 1.8 × 4.8 | 1.9 | prop | mesh | 없음 | dead_tree_c (교수목) |
| hanging_cage 매달린 새장 (기둥·팔·새장) | 2.0 × 1.0 × 3.6 | 0.9 | prop | capsule | 영혼 보라, 1.5, 3, 1.9 m | dead_tree_c × 0.7 (교수 고목) |
| brazier 화로 | 1.0 × 1.0 × 1.3 | 0.6 | prop | capsule | 영혼 청록, 7, 9, 1.25 m, far 140 | lantern |''')
rep('''| soul_crystal 영혼 수정 | 1.4 × 1.3 × 2.4 | 0.9 | prop | mesh | 영혼 청록, 4, 7, 1.2 m | rock_b × 0.6 |''',
    '''| soul_crystal 영혼 수정 | 1.4 × 1.3 × 2.4 | 0.9 | prop | mesh | 영혼 청록, 4, 7, 1.2 m, far 140 | rock_b × 0.6 |''')
rep('''| mausoleum_small 작은 납골당 | 4.4 × 5.2 × 4.8 | 3.0 | landmark | mesh | 영혼 보라, 3, 5, 1.6 m (문 안) | crypt × 0.5 |
| shrine_roadside 길가 사당 | 1.3 × 1.0 × 2.2 | 0.8 | prop | box | 영혼 보라, 2.5, 5, 1.2 m (감실) | grave_obelisk |
| obelisk_chained 사슬 오벨리스크 | 1.5 × 1.5 × 4.6 | 1.0 | prop | box | 없음 | grave_obelisk × 1.6 |
| tent_torn 찢긴 천막 | 3.6 × 3.0 × 2.4 | 2.0 | prop | mesh | 없음 | 없음 |
| campfire 꺼져 가는 모닥불 | 1.4 × 1.4 × 0.5 | 0.8 | prop | none | 잉걸 주황 (1.0, 0.5, 0.28), 3.5, 7, 0.5 m | rubble × 0.75 |''',
'''| mausoleum_small 작은 납골당 | 4.4 × 5.2 × 4.8 | 3.0 | landmark | mesh | 영혼 보라, 3, 5, 1.6 m (문 안), far 140 | grave_tomb × 1.15 (v2 의 crypt × 0.5 는 이름 있는 장소의 축소판이라 바꿨다) |
| shrine_roadside 길가 사당 | 1.3 × 1.0 × 2.2 | 0.8 | prop | box | 영혼 보라, 2.5, 5, 1.2 m (감실), far 140 | grave_obelisk |
| obelisk_chained 사슬 오벨리스크 | 1.5 × 1.5 × 4.6 | 1.0 | prop | box | 없음 | grave_obelisk × 1.7 (3.5 m 넘게) |
| tent_torn 찢긴 천막 | 3.6 × 3.0 × 2.4 | 2.0 | prop | mesh | 없음 | 없음 (건너뜀, 필수 요소 아님) |
| campfire 꺼져 가는 모닥불 | 1.4 × 1.4 × 0.5 | 0.8 | prop | none | 잉걸 주황 (1.0, 0.5, 0.28), 3.5, 7, 0.5 m, far 140 | rubble × 0.75 |
| stone_wall_low 낮은 돌담 (마른 돌쌓기 밭 경계, 긴 축 = 로컬 X, 양 끝이 무너짐) | 4.0 × 0.8 × 1.2 | 2.0 | prop | box | 없음 | wall_ruin_b × 0.5 (높이 약 1.2 m, 땅 기울기를 따른다) |
| standing_stone 선돌 (키 큰 거친 돌, 희미한 새김) | 1.2 × 0.9 × 3.2 | 0.8 | prop | box | 없음 | cliff_b × 0.34 (바위 기둥, 높이 약 4 m) |''')
rep('''나머지 META (sink, tilt, align, scale) 는 `worldgen.py` 의 `NEW_PROPS` 표. 소품을 만들 때 크기가 표와 많이 다르면 표도 고친다 (장면 배치 간격이 이 값을 쓴다).''',
    '''나머지 META (sink, tilt, align, scale) 는 `worldgen.py` 의 `NEW_PROPS` 표. 소품을 만들 때 크기가 표와 많이 다르면 표도 고친다 (장면 배치 간격이 이 값을 쓴다).
멀리 보여야 하는 광원(화로·수정·모닥불·사당·납골당)은 META light 에 `"far": 140` 을 넣는다 (Unity 도구가 프리팹 광원에 LightCullDistance 를 붙인다).
대체 소품에 광원이 없어 따로 넣는 광원에도 far 가 같이 간다. 새 소품의 align 이 true 면 대체 소품도 땅 기울기를 따른다.''')
rep('''- 광원 예산: 걸을 수 있는 범위 4 m 격자 어디서도 80 m 안 점광원 44 개 이하 (`trim_lights` 가 넘는 곳의 초·버섯·연꽃부터 뺀다. LightCuller 한도 48)''',
    '''- 광원 예산: 걸을 수 있는 범위 4 m 격자 어디서도 LightCuller '켜 둘 후보'(광원별 끄는 거리 + 여유 10 m 안) 46 개 이하 (`trim_lights`. LightCuller 한도 48)
- 장면: 필수 요소가 틀 인스턴스의 20% 넘게 빠지면 생성 실패. 장면마다 3.5 m 넘는 세로 요소와 등대 빛. 같은 틀 200 m 안 둘 없음. 들판 장면 60% 넘게 길 40 m 안
- 시선 (scratchpad world_v3_qa/sightline.py): 길 10 m 마다 150 m 안에 장면·장소·등대 빛이 보이는 비율 ≥ 95%, 길 밖 걸을 수 있는 땅 ≥ 85%''')
rep('''| 잊힌 자들의 묘지 | (1005, 905) | 타원 300 × 248 m. 묘비 줄 약 1,900기,''', '''| 잊힌 자들의 묘지 | (1005, 905) | 타원 300 × 248 m. 묘비 줄 약 2,350기 (v3: 면적당 v1 이상),''')
open(p, "w", encoding="utf-8").write(s)
print("ok")
