# 장소 면적당 밀도 비교 (v1 = 저장소 데이터 world_v, v2, v3). 같은 뜻의 넓이로 나눈다
import json, math, sys, collections
S = "/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad"
GEO = {   # 판별 장소 기하 (각 판 worldgen 상수)
    "v1": dict(grave=((1000, 880), (190, 158)), swamp=((1545, 935), 300), dragon=((470, 1060), 215), lake=((720, 330), 105),
               fsw=((430, 640), 235), fne=((1470, 1420), 175), dir=S + "/world_v"),
    "v2": dict(grave=((1005, 905), (150, 124)), swamp=((1430, 950), 228), dragon=((605, 1055), 170), lake=((790, 495), 84),
               fsw=((562, 722), 185), fne=((1372, 1335), 140), dir=S + "/world_v2"),
    "v3": dict(grave=((1005, 905), (150, 124)), swamp=((1430, 950), 228), dragon=((605, 1055), 170), lake=((790, 495), 84),
               fsw=((562, 722), 185), fne=((1372, 1335), 140), dir=S + "/world_v3_wip"),
}
GRAVES = {"grave_slab_a", "grave_slab_b", "grave_slab_c", "grave_cross", "grave_sunken", "grave_obelisk", "grave_tomb"}
rows = collections.OrderedDict()
for v, g in GEO.items():
    O = json.load(open(g["dir"] + "/Data~/objects.json"))["objects"]
    T = json.load(open(g["dir"] + "/Data~/trees.json"))
    tp = T["prototypes"]
    trees = [(tp[int(t[0])], t[1], t[2]) for t in T["instances"]]
    objs = [(o["a"], o["p"][0], o["p"][2]) for o in O]
    (gx, gz), (rx, rz) = g["grave"]
    n_gr = sum(1 for a, x, z in objs if a in GRAVES and ((x - gx) / rx) ** 2 + ((z - gz) / rz) ** 2 <= 1)
    A_gr = math.pi * rx * rz
    out = {"묘비 /ha (묘지 타원)": n_gr / A_gr * 1e4, "묘비 수": n_gr}
    for key, nm in (("swamp", "늪"), ("dragon", "용의 무덤"), ("lake", "호수 물가")):
        (cx, cz), R = g[key]
        Rr = R + (35 if key == "lake" else 0)
        A = math.pi * Rr * Rr
        n = sum(1 for a, x, z in objs + trees if (x - cx) ** 2 + (z - cz) ** 2 <= Rr * Rr)
        out["%s 소품+나무 /ha" % nm] = n / A * 1e4
    for key, nm in (("fsw", "검은 숲"), ("fne", "고목 숲")):
        (cx, cz), R = g[key]
        n = sum(1 for a, x, z in trees if a.startswith("dead_tree") and (x - cx) ** 2 + (z - cz) ** 2 <= R * R)
        out["%s 죽은 나무 /ha" % nm] = n / (math.pi * R * R) * 1e4
    rows[v] = out
keys = list(rows["v1"].keys())
print("%-24s %10s %10s %10s   v3/v1" % ("", "v1", "v2", "v3"))
for k in keys:
    a, b, c = rows["v1"][k], rows["v2"][k], rows["v3"][k]
    print("%-24s %10.1f %10.1f %10.1f   %.2f" % (k, a, b, c, c / a if a else 0))
