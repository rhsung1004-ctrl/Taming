#!/bin/bash
# v3 검사 전부 (결과: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/*)
S=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad
D=$S/world_v3/Data~
Q=$S/world_v3_qa
( cd $Q/escape && python3 ../../qa_checks/escape_gate.py $D 1.19 > $Q/escape_119.txt 2>&1; python3 ../../qa_checks/escape_gate.py $D 1.0 > $Q/escape_100.txt 2>&1 ) &
( cd $S/wf_world/navigation && NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_flood.py 1.0 large 1 > $Q/nav_flood_100.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_flood.py 1.19 large 1 > $Q/nav_flood_119.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_roads.py > $Q/nav_roads.txt 2>&1; NAV_DATA=$D NAV_OUT=$Q/nav python3 nav_bridge.py > $Q/nav_bridge.txt 2>&1 ) &
( cd $S/wf_world/perf_qa && WORLD_DATA=$D PERF_OUT=$Q/perf ./run_v2.sh > $Q/perf.log 2>&1 ) &
wait
( cd $S/wf_world/placement_qa && WORLD_DATA=$D KIT_OUT=$S/kit_out ./run_all.sh > $Q/placement.log 2>&1; mkdir -p $Q/placement; cp out_*.txt ground_*.csv $Q/placement/ )
echo QA_DONE
