src = open("worldgen.py").read()
a = src.index("    # 등고선 줄 (밭 턱): 매끈한 높이의 기울기에 수직으로 따라간다")
b = src.index("    # 마른 도랑: 완만한 비탈에서 내리막을 따라")
new = open("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_qa/lines_block.py").read()
src = src[:a] + new + src[b:]
open("worldgen.py", "w").write(src)
print("ok")
