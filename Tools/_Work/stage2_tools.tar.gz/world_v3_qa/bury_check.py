# 바닥 상자 접지 큰 소품의 묻힘·뜸 (placement_qa/check_ground.py 결과 ground_objects.csv 를 쓴다: 실제 메쉬 기둥으로 잰 값)
#   python3 bury_check.py <ground_objects.csv> <_boxground.json 또는 -> [이름,이름 (boxground 가 없을 때 볼 소품)]
# 기준: 의도된 묻힘(절벽·바위·울타리·낮은 것)을 뺀 바닥 상자 접지 소품이 높이의 25% 넘게 묻히지 않고, 0.3 m 넘게 뜨지 않는다
import sys, csv, json, collections
rows = list(csv.DictReader(open(sys.argv[1])))
if sys.argv[2] != "-":
    bg = json.load(open(sys.argv[2]))["boxed"]
    sel = {int(i) for i, intended in bg if not intended}
    pick = [r for r in rows if int(r["i"]) in sel]
    print("바닥 상자 접지 %d 개 중 검사 대상(의도된 묻힘 제외) %d 개" % (len(bg), len(pick)))
else:
    names = set(sys.argv[3].split(","))
    pick = [r for r in rows if r["a"] in names]
    print("이름으로 고른 소품 %d 개: %s" % (len(pick), sorted(names)))
by = collections.defaultdict(list)
for r in pick:
    by[r["a"]].append(r)
tot_b = tot_f = 0
print("%-14s %5s %10s %10s %10s %9s" % ("종류", "개수", "묻힘>25%", "묻힘>30%", "뜸>0.3m", "최대묻힘%"))
for a, L in sorted(by.items(), key=lambda kv: -len(kv[1])):
    b = [float(r["bfrac"]) for r in L]
    f = [float(r["fmax"]) for r in L]
    nb = sum(1 for v in b if v > 0.25); nf = sum(1 for v in f if v > 0.3)
    tot_b += nb; tot_f += nf
    print("%-14s %5d %10d %10d %10d %8.0f%%" % (a, len(L), nb, sum(1 for v in b if v > 0.30), nf, max(b) * 100))
print("합: 묻힘 > 25%% %d 개, 뜸 > 0.3 m %d 개 (검사 대상 %d 개)" % (tot_b, tot_f, len(pick)))
worst = sorted(pick, key=lambda r: -float(r["bfrac"]))[:8]
print("가장 많이 묻힌 것:", "; ".join("%s #%s (%.0f, %.0f) 경사 %.2f 묻힘 %.0f%%" % (r["a"], r["i"], float(r["x"]), float(r["z"]), float(r["slope"]),
                                                                    float(r["bfrac"]) * 100) for r in worst))
worst = sorted(pick, key=lambda r: -float(r["fmax"]))[:5]
print("가장 많이 뜬 것:", "; ".join("%s #%s (%.0f, %.0f) 뜸 %.2f m" % (r["a"], r["i"], float(r["x"]), float(r["z"]), float(r["fmax"])) for r in worst))

# ── w3 (검토 반영): BURY_FREE(울타리·통나무·바위 …)도 빼지 않고 정직하게 센다 ──
print("\n[w3 정직 검사] 의도된 묻힘 표시와 상관없이 이름으로 (ground_objects.csv 의 모든 소품)")
def num(r, k):
    try:
        return float(r[k])
    except Exception:
        return 0.0
LINE = ("fence", "wall_ruin_b", "log_fallen", "wall_ruin_a", "pillar_b", "coffin", "rock_b", "rock_flat", "rubble", "cliff_a", "cliff_b", "cliff_c")
print("%-12s %5s %12s %12s %12s %10s %10s %8s" % ("종류", "개수", "묻힘>25%", "묻힘>50%", "중앙묻힘>50%", "기울>15°", "기울>20°", "최대기울"))
allrows = collections.defaultdict(list)
for r in rows:
    allrows[r["a"]].append(r)
for a in LINE:
    L = allrows.get(a, [])
    if not L:
        continue
    b = [num(r, "bfrac") for r in L]; bm = [num(r, "bmedfrac") for r in L]; t = [num(r, "tilt") for r in L]
    print("%-12s %5d %12d %12d %12d %10d %10d %7.0f°" % (a, len(L), sum(v > 0.25 for v in b), sum(v > 0.5 for v in b), sum(v > 0.5 for v in bm),
                                                       sum(v > 15 for v in t), sum(v > 20 for v in t), max(t)))
for a in ("fence", "wall_ruin_b", "log_fallen"):
    L = sorted(allrows.get(a, []), key=lambda r: -num(r, "bfrac"))[:4]
    if L:
        print("  %s 가장 많이 묻힌 것: %s" % (a, "; ".join("(%.1f, %.1f) 묻힘 %.0f%% 중앙 %.0f%% 기울 %.0f°" % (num(r, "x"), num(r, "z"), num(r, "bfrac") * 100,
                                                                                    num(r, "bmedfrac") * 100, num(r, "tilt")) for r in L)))

# ── w4: 새 소품(scenes 묶음)은 땅속 밑동이 있다 (돌담 0.30 m, 쇠 울타리 0.22 m). 밑동을 뺀 '보이는 높이' 기준 묻힘으로 센다 ──
BASE = {"stone_wall_low": (0.30, 0.99), "iron_fence": (0.22, 1.66), "standing_stone": (0.0, 3.17), "banner_torn": (0.0, 4.24), "sarcophagus": (0.04, 1.04)}
print("\n[w4 새 소품] 땅속 밑동을 뺀 보이는 높이 기준 (bmax − 밑동×배율) / (원점 위 높이×배율)")
print("%-16s %5s %12s %12s %12s %10s %8s" % ("종류", "개수", "보이는묻힘>25%", ">40%", ">50%", "기울>10°", "최대기울"))
for a, (base, vis) in BASE.items():
    L = allrows.get(a, [])
    if not L:
        continue
    vb = [(num(r, "bmax") - base * num(r, "s")) / (vis * num(r, "s")) for r in L]
    t = [num(r, "tilt") for r in L]
    print("%-16s %5d %12d %12d %12d %10d %7.0f°" % (a, len(L), sum(v > 0.25 for v in vb), sum(v > 0.4 for v in vb), sum(v > 0.5 for v in vb),
                                                    sum(v > 10 for v in t), max(t)))
    w = sorted(zip(vb, L), key=lambda q: -q[0])[:3]
    print("   가장 많이 묻힌 것: %s" % "; ".join("(%.1f, %.1f) %.0f%%" % (num(r, "x"), num(r, "z"), v * 100) for v, r in w))
