# 눈높이 합격 렌더 자리 고르기 (씨앗 고정). 채움 작업 전에 한 번 고르고 고정한다 (작업 중 자리를 고르지 않게 v2 데이터로 고른다)
#   python3 eye_spots.py <v2 월드 폴더> <출력 json>
# - 들판 8곳: 걸을 수 있는 땅(칸 기울기 ≤ 0.8, 걸어 다니는 범위 안 30 m, 물 밖), 장소 원 밖, 길 가장자리 4 m 밖. 무작위 (씨앗 20261125)
#   방향은 무작위. 단 50 m 앞이 12 m 넘게 높거나(산·벼랑을 코앞에서 봄) 범위 밖이면 반대로 돌린다
# - 길 위 4곳: 길 중심선 무작위 (길이 비례), 장소 원 + 10 m 밖. 방향 = 길을 따라 (앞/뒤 무작위)
import sys, json, math
import numpy as np

W_DIR, OUT = sys.argv[1], sys.argv[2]
D = W_DIR + "/Data~"
W = json.load(open(D + "/world.json"))
n = W["heightRes"]
h = np.fromfile(D + "/height.r16", "<u2").reshape(n, n).astype(np.float32) / 65535 * W["height"]
RD = json.load(open("/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v3_struct/_roads.json"))
(bx0, bz0), (bx1, bz1) = W["bounds"]["min"], W["bounds"]["max"]
lev = W["levels"]
POIS = [((p["p"][0], p["p"][2]), p["r"]) for p in W["pois"]]


def H(x, z):
    x = min(max(x, 0), n - 1.001); z = min(max(z, 0), n - 1.001)
    i, j = int(z), int(x); fz, fx = z - i, x - j
    return float((h[i, j] * (1 - fx) + h[i, j + 1] * fx) * (1 - fz) + (h[i + 1, j] * (1 - fx) + h[i + 1, j + 1] * fx) * fz)


gz, gx = np.gradient(h)
sl = np.hypot(gx, gz)
rp = [(np.array(r["pts"]), r["hw"]) for r in RD]


def road_d(x, z):
    best = 1e9
    for c, hw in rp:
        d = np.min(np.hypot(c[:, 0] - x, c[:, 1] - z)) - hw
        best = min(best, d)
    return best


def wet(x, z):
    hh = H(x, z)
    if math.hypot(x - 1430, z - 950) < 268 and hh < lev["swamp"] + 0.1:
        return True
    if math.hypot(x - 790, z - 495) < 114 and hh < lev["lake"] + 0.1:
        return True
    return False


rng = np.random.default_rng(20261125)
spots = []
while len([s for s in spots if s["kind"] == "field"]) < 8:
    x, z = rng.uniform(bx0 + 30, bx1 - 30), rng.uniform(bz0 + 30, bz1 - 30)
    if sl[int(z), int(x)] > 0.8 or wet(x, z) or road_d(x, z) < 4:
        continue
    if any(math.hypot(x - c[0], z - c[1]) < r for c, r in POIS):
        continue
    yw = rng.uniform(0, 360)
    t = math.radians(yw)
    fx, fz = x + math.sin(t) * 50, z + math.cos(t) * 50
    flip = H(fx, fz) - H(x, z) > 12 or not (bx0 < fx < bx1 and bz0 < fz < bz1)
    if flip:
        yw = (yw + 180) % 360
    spots.append({"id": "F%d" % (len(spots) + 1), "kind": "field", "x": round(x, 1), "z": round(z, 1), "yaw": round(yw, 1), "flipped": bool(flip)})
L = np.array([np.sum(np.linalg.norm(np.diff(c, axis=0), axis=1)) for c, _ in rp])
k = 0
while k < 4:
    i = int(rng.choice(len(rp), p=L / L.sum()))
    c, hw = rp[i]
    j = int(rng.integers(3, len(c) - 3))
    x, z = float(c[j, 0]), float(c[j, 1])
    if any(math.hypot(x - cc[0], z - cc[1]) < r + 10 for cc, r in POIS):
        continue
    d = c[j + 2] - c[j - 2]
    if rng.random() < 0.5:
        d = -d
    yw = math.degrees(math.atan2(d[0], d[1])) % 360
    k += 1
    spots.append({"id": "R%d" % k, "kind": "road", "x": round(x, 1), "z": round(z, 1), "yaw": round(yw, 1), "road": RD[i]["name"]})
json.dump(spots, open(OUT, "w"), ensure_ascii=False, indent=1)
for s in spots:
    print(s)
