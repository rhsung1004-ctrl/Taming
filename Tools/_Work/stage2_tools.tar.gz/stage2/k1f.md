# k1f 보고: 시범 4종 v3 재수정 마무리 (v3c)

## 요약
메인 세션 지적 세 가지(묘비 새것 같음, 바위 위장무늬·모서리 보풀, 나무 골 보풀·검은 점)를 고쳐 4종 최종판을 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b 에 두었습니다. wall_ruin_a 는 바꾸지 않았습니다 (i8 그대로).
전체 빌드는 소품마다 2번(바위 i12·i13, 나무 i12·i13, 묘비 i13·i14)이었고, 칠은 굽지 않는 고폴리 미리보기로 먼저 맞췄습니다. 기존 묶음 호환 빌드 6종은 모두 exit 0 입니다.

- grave_slab_a (최종 i14):
  - 오른쪽 어깨가 크게 깨졌습니다. 윗변에서 10~15 cm 안쪽까지 들어간 들쭉날쭉한 윤곽을 앞뒤로 기울여 잘랐고, 저폴리에도 들어가 6 m 실루엣에서 보입니다.
  - 깨짐에서 판 면으로 가는 금 한 줄이 뻗고, 기존 금 두 줄도 그대로 있습니다.
  - 윗변·받침 윗면에 이끼 덩어리가 붙었습니다 (moss 0.45 → 1.0, 덩어리 크게).
  - 꼭대기에서 흘러내린 빗물 때(새 rain)와 받침과 만나는 곳 흙물(새 splash), 물때 얼룩(blotch)을 넣었습니다.
  - 글자·십자가·V 홈·단단한 모서리의 또렷함은 그대로입니다. 텍스처는 1024 입니다.
- rock_b (최종 i13):
  - 지의류 반점(위장무늬)을 없앴습니다. 이끼는 윗면·틈에 큰 덩어리로 모았고, 넓은 옆면은 돌 결 줄무늬(새 strata)와 삭은 얼룩으로 돌색만 바꿨습니다.
  - 모서리의 얇은 밝은 보풀 줄을 없앴습니다. 칠한 모서리 빛을 끄고, 굽은 뒤 단단한 모서리 띠 6 화소를 섬 안쪽 값으로 다시 메웁니다 (새 finish3 flat_hard).
- dead_tree_a (최종 i13): 골을 따라 생기던 흰 보풀 줄과 검은 점을 없앴습니다.
  - 원인 1 (칠): 베벨 노드 모서리 빛의 표본 잡음 → edge 0.
  - 원인 2 (칠): 좁은 AO 잡음 → 새 cavity_s 0.2.
  - 원인 3 (굽기): 노멀맵 골 바닥의 1~2 화소 포화 점 → 새 despeck_n 0.18, 중앙값 3번.
  - 지의류도 뺐습니다.

## 바꾼 파일
- /home/user/Taming/Tools/BlenderKit/kit.py (새 함수·선택 인자만. 기본값이면 예전과 같다):
  - regrow_hard_band(): 단단한 모서리 띠를 섬 안쪽 값으로 다시 메운다. 섬 전체가 띠인 좁은 섬은 노멀을 평평하게, 색을 평균으로.
  - despeckle_normal(): 노멀맵 외딴 점·가는 줄을 5x5 중앙값으로 바꾼다 (passes).
  - finish/finish3 의 flat_hard, despeck_n. 로그 줄 FLATHARD, DESPECKN.
  - paint3 의 strata/strata_scale/strata_tilt, rain/rain_h/rain_color, splash/splash_z/splash_h, cavity_s.
- /home/user/Taming/Tools/BlenderKit/assets_graves.py: grave_slab_a 만 (큰 깨짐, 금 한 줄, 칠).
- /home/user/Taming/Tools/BlenderKit/assets_nature.py: rock_b(칠, flat_hard=6), dead_tree_a(칠, despeck_n=0.18) 만.
- /home/user/Taming/Tools/BlenderKit/README.md: 만드는 과정 v3c 인자, 종류별 권장값 표 v3c 값, '피할 것' 6줄.
- 참고: 메인 세션이 중간 커밋 5bd65b4 에 이 작업의 일부를 이미 넣었습니다. 나머지는 작업 트리에 있습니다 (커밋·푸시 안 함).

## 근거 (빌드 로그·비교)
| 소품 | 삼각형 LOD0 | 텍스처 | TEXEL px/m (uv_fill) | BAKE | 게임 시점 LUM 3 m / 6 m (이전 → 새) |
| --- | --- | --- | --- | --- | --- |
| grave_slab_a | 1506 (본체 588) | 1024 | 611 (0.713) | miss 0, steep 0.49% | 0.2355 → 0.2259 (−4%) / 0.2343 → 0.2205 (−6%), p90 0.359 → 0.386 |
| rock_b | 984 (본체 756) | 2048 | 361 (0.693) | miss 0, steep 1.87%, FLATHARD 10.6% | 0.2379 → 0.2324 (−2%) / 0.2321 → 0.2224 (−4%) |
| dead_tree_a | 7124 | 2048 | 372, 줄기 밑동 531 | miss 0, steep 2.18% (WARN 기준 2%), DESPECKN 1.62%, despeck 0.196 → 0.048% | 0.1711 → 0.1707 / 0.1671 → 0.1844 (+10.4%) |
| wall_ruin_a | 16142 | 2048 | 228 (0.472) | (i8 그대로) | (i8) |

- 용량: 4종 파일 합계 약 17 MB. 묘비 1024(가장 긴 변 1.09 m), 나머지 2048, 4096 없음. 노멀 PNG 는 save_png 최대 압축.
- 최종 비교 렌더 (왼쪽 이전 kit_out / 오른쪽 새 판):
  - /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b/_cmp_grave_slab_a_near.png, _mid.png, _game.png, _back.png
  - /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b/_cmp_rock_b_near.png, _mid.png, _game.png
  - /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b/_cmp_wall_ruin_a_near.png, _mid.png, _game.png, _back.png (i8 렌더 복사)
  - /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b/_cmp_dead_tree_a_near.png, _mid.png, _game.png
  - 4종 게임 시점 모음: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b/_cmp_sheet.png
- 빌드·비교 로그: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/v3cwork/b_*_i1[2-4].log, c_*_i1[2-4].log, run_i1*.out. 중간 렌더 v3cwork/t/.
- 기존 묶음 호환 빌드 → /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3b_compat:
  - graves skull 84 s, ruins lantern 77 s, nature rock_c 103 s, foliage weeds 0.1 s, landmarks well 164 s, bones bones_scatter 91 s.
  - 모두 exit 0, Traceback 0. 로그는 v3cwork/compat_*.log, 요약은 compat.out.
  - skull 의 BAKE miss 15.7% 는 예전 finish 경로가 여백 밖을 세는 값으로, v3b 호환 빌드(15.72%)와 같습니다.
- 새 함수 단위 시험 (가짜 그림): regrow_hard_band, despeckle_normal 모두 의도대로 동작했습니다. 기존 나무 노멀맵에 despeckle_normal 을 돌려 골 바닥 포화 점이 사라지는 것을 먼저 확인했습니다.
- C# 은 바꾸지 않아 컴파일 검사는 하지 않았습니다. Unity 는 실행하지 못했습니다.

## 남은 문제
- rock_b: 작은 계단 떨어진 자국 두 곳의 좁은 벽에 어두운 빗살이 남았습니다 (_cmp_rock_b_near.png 오른쪽 가운데 왼쪽, 게임 시점 오른쪽 위 꼭대기의 어두운 톱니 조각). 단단한 모서리로 둘러싸이지 않은 좁은 면이라 flat_hard 가 닿지 않습니다. 형태(step_spalls 겹침)를 손봐야 합니다. 빌드 2회를 다 써서 남겼습니다.
- dead_tree_a: steep 2.18% 로 WARN 이 남습니다 (형태는 이전과 같음). 6 m 게임 시점 밝기가 이전보다 10.4% 밝아 기준 ±10% 를 살짝 넘습니다 (gain 0.85 → 0.8 이면 맞음). 줄기·뿌리가 만나는 가로 이음매 고리는 이전부터 있던 것입니다.
- grave_slab_a: 빗물 때는 뒷면에서 진하고 앞면에서는 윗부분에 옅게 보입니다. 이전 판보다 여전히 조금 밝고 깨끗한 쪽입니다 (LUM −4~6%, 대비는 더 큼).
- wall_ruin_a 는 다시 빌드하지 않았습니다. 이번 kit.py 수정은 새 인자 기본값이 꺼져 있어 다시 빌드해도 같습니다.

## 62종 전체 적용 지침 (v3c 기준)

공통:
- 교체: sculpt → carve(+STONE3/ROCK3/BARK3), paint·stone_mat·rock_paint·bark_paint → paint3, finish → finish3. 묶음 덧칠(blotch, grad_dark, top_cover, moss_low, tint_near)은 paint3 위에 그대로 얹는다.
- RNG 순서: 새 형태(깨짐·금)를 더할 때는 따로 random.Random(고정 씨앗)을 써서 기존 글자·조각 모양이 바뀌지 않게 한다.
- 텍스처: finish3(size='auto') = 가장 긴 변 1.5 m 미만 1024, 그 밖 2048 (4096 금지). 노멀 PNG 는 save_png 가 최대 압축.
- 확인 순서 (소품마다, 전체 빌드는 최대 2번):
  1) 고폴리 칠 미리보기(굽기 없이 1~2분): /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/v3cwork/hipv.py (`hp.sh 태그 묶음:이름:near`) 로 형태·칠을 먼저 본다.
  2) build.py → 로그: BAKE miss 0.000%, steep 2% 미만(나무 2.2% 안팎 허용), TEXEL uv_fill 0.45 이상, FLATHARD/DESPECKN 비율.
  3) compare.py near/mid/game(+back) 을 직접 보고: 위장무늬(고른 반점), 모서리 얇은 밝은 줄, 골의 흰 줄·검은 점, 새것 같은 깨끗함, 장난감 같은 외곽선.
  4) 게임 시점 LUM 평균은 이전 판 ±10% (gain 으로), p90 은 이전 이상.

종류별:
1. 묘비·십자가·오벨리스크·무덤·가라앉은 묘 (graves: grave_slab_b/c, grave_cross, grave_obelisk, grave_tomb, grave_sunken; ruins: pillar_a/b, altar, fence 돌기둥):
   - 형태: chip → 큰 깨짐 한 군데(들쭉날쭉한 XZ 윤곽 obj_bm(bm_poly(...)) 을 x += 0.45y, z += 0.35y 로 기울여 cut — 저폴리 사본 뜨기 전에, 실루엣에서 10~15 cm 안쪽까지) → low_src = copy → 새김(engrave_v 0.011/0.007) + 깨짐에서 뻗은 금 1줄 + 긴 금 1~2줄(engrave_v 0.0075/0.005).
   - carve(0.0025, edge_from=새김 전 사본, 뒷면만 'face' 거친 다듬 자국).
   - paint3('stone', h=높이, edge_mode='attr', edge 0.8/edge_w 0.009/edge_gain 0.85, cavity 1.0, stains 0.8, moss 1.0/moss_patch 1.3, moss_low 0.7,
     rain 1.0/rain_h 0.6~0.7×높이/rain_color (0.2,0.24,0.21), splash 0.95/splash_z=받침 윗면 높이/splash_h 0.2, streaks 0.35, light 0.85, contrast 0.3, pivot 0.2, gain 1.12)
     + blotch(m, (0.3,0.31,0.27), 3.5, 0.65, 0.45, 0.62) (assets_graves.blotch).
   - finish3(cage 0.006, hard 55, uv_weight 앞면 1.0/뒷면 0.65/받침 0.7). flat_hard 는 쓰지 않는다 (모서리 빛이 지워진다).
   - 기준: TEXEL 600 px/m 이상(1024), steep 1% 안팎, 큰 깨짐이 게임 시점 6 m 에서 실루엣으로 보일 것.
2. 블록 석조 (wall_ruin_b, arch_ruin, stair_ruin, landmarks crypt, cathedral_ruin, bridge_ruin, watchtower_ruin, gate_great, well):
   - wall_ruin_a 그대로 (v3b 검토 통과): ashlar(damage=(0.14,rng)) → carve(0.009, STONE3(1.25,1.2,0.6), base=True) → low_of,
     paint3 piece_var 1.0/piece_val 0.15/grime 0.85(grime_h 0.16)/edge_w 0.022/edge_gain 1.35/ao 0.45/lichen 0.4 → finish3(cage 0.01, cage_reach 0.1, uv_margin 0.001, lod2 0.12).
   - 오래된 느낌을 더하려면 rain(0.6, rain_h 1.0)·splash 를 얹는다 (벽은 grime 이 이미 줄눈 아래 때를 낸다). uv_fill 0.45 이상, 큰 랜드마크는 200 px/m 미만이면 조각을 나눠 2048 두 장.
3. 바위·절벽 (rock_a, rock_c, rock_flat, cliff_a/b/c):
   - facet_mass + chip_convex + step_spalls(평면 바닥 + 40~45° 벽) → lowpoly(그 형태) → carve(0.005~0.02, ROCK3(k, 0.7, chisel=0.25), mode='octree', pieces=False).
   - paint3(ROCK_PAL, cells 0.7, facet_var 0.3, **edge 0, lichen 0, strata 1.0/strata_scale 2.0, moss 1.0/moss_patch 1.5**, contrast 0.28, stains 0.55, strokes 0.8).
   - finish3(cage 0.012~0.03, cage_reach 0.1~0.2, hard 38, **flat_hard 6**, uv_angle 40, uv_margin 0.002, 아랫면 uv_weight 0.55).
   - 기준: 넓은 면에 고른 반점이 없을 것, 모서리를 따라 밝은 줄이 없을 것 (FLATHARD 10% 안팎), 이끼는 윗면·틈에만.
4. 나무·그루터기·통나무·뿌리 (dead_tree_b/c, tree_giant, stump, log_fallen, roots):
   - tree_build(low_mode='tube', rho=tree_rho, fin=dict(cage 0.006, cage_reach 0.06, samples 8, margin 0, uv_margin 0.002, despeck=True, **despeck_n=0.18**)).
   - paint3(BARK_GREY, **edge 0, lichen 0, cavity 0.55, cavity_s 0.2**, ao 0.16, dirt_h 0.85, moss_low_h 0.95) + blotch(작고 어둡게) + grad_dark. 잔가지 paint3('bark_pale', k 0.5).
   - 기준: TEXEL_TRUNK 500 이상, DESPECKN 1~2%, 골을 따라 흰 줄·검은 점 없음. tree_build 를 안 쓰는 통나무·그루터기는 finish3(..., despeck_n=0.18).
5. 뼈 (bones 묶음, graves skull·bone_pile): carve(0.0016~0.003, fine=[약한 chisel + pits + cracks]), paint3(BONE_DARK|'bone', edge 0.6, moss 적게, lichen 0), finish3(cage 0.004). hard 없음.
6. 나무 판자·관(coffin, fence_gate 나무)·쇠(fence, lantern): 조각은 BARK3 대신 결 방향 chisel 약하게, paint3 rain 0.5 로 세월. 쇠는 edge 0.4.
7. 식물(foliage 12종): 바꾸지 않는다.

이번 수정에서 배운 것:
- 고르게 찍힌 작은 반점(lichen)은 크기·색과 상관없이 위장무늬로 읽힌다. 세월은 '위에서 아래로'(빗물 때)·'아래에서 위로'(흙물·이끼)·'틈에 고이는 것'처럼 방향과 원인이 있는 무늬로 넣는다.
- 모서리 밝은 띠는 석물(곧은 다듬 모서리)에는 좋고 바위(깨진 모서리)에는 장난감 외곽선이 된다.
- 굽기 결함은 칠을 바꿔서는 안 없어진다: 단단한 모서리 띠의 빗살은 flat_hard, 깊은 골 바닥의 포화 점은 despeck_n 으로 굽은 뒤 그림에서 고친다.
- 둥근 윗변 어깨는 이미 낮아 작은 커터로는 안 깨진다 — 깨짐은 실루엣에서 10 cm 이상 들어가야 6 m 에서 보인다.
- 빗물 줄이 1 cm 로 잘면 가까이서 나뭇결처럼 읽힌다 (3~5 cm).
- 칠 반복은 굽지 않는 고폴리 미리보기(1~2분)로 먼저 하고, 굽는 전체 빌드(4~7분)는 2번 안에 끝낸다.
