# k6r 진행 기록 (시범 2회차 독립 검토) — 끝남
## 한 것
- review_k6/review.py (3판, 새 뷰 G8/H9/S3/W3/K3), vignette.py (game/lamp), uvstats, 1:1 텍스처, 이끼 색 측정 모두 끝.
- 최종 보고: stage2/k6r.md
## 지금 상태
- 끝. 세 소품 모두 needs_work. 묘비(칠 1회+뒷면 노멀 점·판), 바위(벌집 pocks, 줄무늬 veins, 밝기 p90, 이끼, 땅 가시, 상자 홈), 고목(이전보다 껍질 흐림, 뿌리 얼굴, 채도).
- 62종: A 블록 석조만 '넓혀도 됨(wall_ruin_a 레시피 그대로)', B 묘비류 '조건 고친 뒤', C 바위·D 나무·E 쇠나무·F 뼈 '아직 안 됨', G 식물 그대로.
## 다음 할 것
- 메인 세션 판단. 작업자 다음 회차는 k6r.md 의 '고칠 방향'.
## 중요한 경로
- $S/review_k6/ (review_sheet.jpg, crop/, tex/, vignette_*_cmp.png, *_lum.txt, uvstats*.txt)
