# k7b 진행 기록 (블록 석조 A 묶음 넓히기)
## 한 것
- kit_v3b/wall_ruin_a.* → kit_v3c 복사, manifest_ruins.json(wall_ruin_a), _decision.json {"wall_ruin_a":"v3"}
- kit.py: paint3 선택 인자 grime_color·streaks_cover(+scale), finish/finish3 선택 인자 far_extras, 새 BLOCK3_* 상수·paint_block3()
- assets_ruins.py: wall_ruin_b, arch_ruin, stair_ruin, pillar_a, pillar_b → carve+STONE3+paint_block3+finish3 (ashlar damage)
- assets_landmarks.py: crypt, cathedral_ruin, bridge_ruin, watchtower_ruin, gate_great, well 돌 부분 → 같은 레시피, finish3(far_extras)
- KIT_FAST 시험 f1 (wall_ruin_b): 알베도 lum −24%, 채도 +19%, 이끼 hue 132 → BLOCK3_PAINT 고침(gain 1.35, piece_var 0.65, hue_var 0.3, shadow 덜 파랗게, 이끼 노랗게)
- f2: 채도 0.222(+1%), 파랑 0.074, 이끼 hue 110·명도 0.219, 흰 0.22%, lum −19% → f3 값(gain 1.5, edge_gain 1.05, moss_low 0.55, 이끼 ×0.8) 으로 정식 빌드
## 지금 상태
- ruins 5종: 1회차 끝(검토 렌더 k7bwork/rv/*_i1, 1회차 파일 k7bwork/out_i1). 2회차 빌드 진행 (build_ruins_i2.out)
  1회차 문제: 앞빛 −11~14% (wall_ruin_b, stair), 이끼 안 보임·새것 같음, arch 아치 구멍 막힘(damage 로 불리언 실패), pillar 매끈·창백, 높이 −9~10%
  2회차 고침: BLOCK3_PAINT (gain 1.6, dirt 0.55, cavity 0.85, edge_gain 0.9, 이끼 초록 짙게 moss 0.85), damage_top=False, low z −0.12,
  arch damage 뺌·h 4.2, pillar 풍화 2.0·금 1.1·빗물·gain 1.45
- landmarks: well·bridge·watchtower 1회차 끝 (bridge uv 0.31·steep 2.5%, watchtower steep 4.2% WARN). crypt·gate·cathedral 1회차 대기/진행 (새 BLOCK3 값으로)
## 다음 할 것
- landmarks 1회차 검토 렌더 → 2회차 (bridge smooth uv 이미 넣음, watchtower 저폴리 더 촘촘히?)
- publish_v3c.py 로 kit_v3c 반영 → 장면 렌더(vignette_ruins.py, shot=main/game/back) → 보고
- 빌드 횟수: ruins 5종 2회(진행), well·bridge·watchtower 1회, crypt·gate·cathedral 1회(대기)
## 중요한 경로
- 작업: $S/k7bwork (out=정식 빌드, fast=KIT_FAST, t=수치, rv=검토 렌더). 스크립트 build.sh, review.sh, fast.sh, geo.py, uvstats2.py, vignette_ruins.py, cmpsheet.py
