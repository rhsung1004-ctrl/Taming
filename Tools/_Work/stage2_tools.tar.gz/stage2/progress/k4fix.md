# k4fix 진행 기록 (덮어씀)
## 한 것
- 5종 모두 고치고 빌드 끝 (standing_stone 2, sarcophagus 2, skeleton_remains 2, soul_crystal 1, brazier 1).
- rv 검토 렌더, _game 5종, _sheet, _scale, _pv_ 갱신 끝. README scenes 절 갱신 끝.
- 보고: S/stage2/k4fix.md
## 지금 상태
- 완료. 남은 것은 보고의 '남은 문제' (칼날 끝 묻힘, 해골 steep 2.12%, 화로 offset).
## 중요한 경로
- /home/user/Taming/Tools/BlenderKit/assets_scenes.py, README.md
- S/kit_scenes, S/k4fix (rv/, t/, before/, 로그)
