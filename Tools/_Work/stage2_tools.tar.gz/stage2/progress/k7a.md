# k7a 진행 기록 (묘비 칠 마무리 + 묘비·석물 B 묶음)
## 한 것
- direction/k6/k6r/k1r 읽음. 작업 폴더 $S/k7awork (pv.py 미리보기, review.py·uvstats2.py 사본, graves_scene.py 장면, cmpsheet.py, build.sh, review.sh)
- kit.py 끝에 k7a 절: GRAVE3_MOSS/PAL/PAINT/WEATHER, moss_inverse(), paint_grave3(), GRAVE3() 조각 층, grave_uv_weight()
- assets_graves.py: grave_slab_a(칠·뒷면 층), grave_slab_b, grave_slab_c, grave_cross, grave_obelisk, grave_tomb, grave_sunken 를 v3 로 다시 씀 (아직 빌드 안 함, 문법만 확인)
- assets_ruins.py: altar 를 carve(base)+GRAVE3+paint_grave3+finish3 로 (빌드 안 함)
- 미리보기 a1~a4 (빌드 아님). a5 대기 중 (k7b 빌드가 lock 을 오래 잡음)
## 지금 상태
- a5 미리보기 결과 기다림
## 다음 할 것
- grave_slab_a 정식 빌드 1 → review/vignette(vigA 폴더: slab_a 만 새것)/uvstats2 → 판정
- 통과하면 B 묶음 미리보기→빌드, graves_scene.py 로 장면 3컷, cmpsheet, kit_v3c 복사·manifest_graves.json·manifest_ruins(altar)·_decision.json, README 절
- 정식 빌드 횟수: grave_slab_a 0/2
## 중요한 경로
- 작업: $S/k7awork (pv/ 미리보기, out/ 정식 빌드, rv/ 검토 렌더, vigA/ slab_a 장면용 링크 폴더)
