# 1단계 월드 생성기 v2: 작업자 보고

## 요약

월드 생성기 v2를 마쳤습니다. 걸을 수 있는 범위를 줄이고 빈 들판을 작은 장면으로 채웠습니다. 결과는 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2 에 있고, 요구된 검사는 모두 통과했습니다. 다만 Blender 확인 렌더는 다른 작업자가 Blender를 쓰고 있어 돌리지 못했습니다. 저장소의 월드 데이터(Assets/_Necro/Art/World/Ch1)는 아직 바꾸지 않았습니다.

1) 압축
- 지형은 2048 m 그대로 두고, 걸을 수 있는 범위를 170~1878(1.71 km)에서 360~1690(1.33 km)으로 줄였습니다.
- 장소 13곳, 길, 개울을 가운데 쪽으로 당겼습니다. 장소 가운데 사이 걷는 거리는 평균 450 m에서 346 m로 줄었습니다. 발견 원 가장자리 사이로는 84~380 m에서 37~280 m가 됐습니다.
- 바탕 언덕은 옛 지형을 가운데로 0.78배 줄여 썼습니다(`COMPRESS`). 높이도 같은 배율로 줄여 기울기는 옛 판과 같습니다.
- 바깥 360 m 띠는 큰 산입니다. 봉우리 무리가 높은 산줄기와 낮은 안부로 번갈아 오고, 300 m 근처에서 둥글게 눌러 320 m에서 잘려 평평해지지 않게 했습니다.
- 가장자리 벽과 봉인문 고갯길 규칙은 모두 `GATE`, `BOUNDS` 기준으로 바꿔 새 범위에 맞췄습니다.
- 길을 하나 더했습니다: 망루 → 대성당 서쪽(북서쪽 고리). 길은 모두 14개이고 이름은 `ROAD_NAMES`에 있습니다.

2) 작은 장면
- `lay_vignettes`가 볼거리에서 가장 먼 땅부터 장면을 놓습니다. 길가를 조금 더 좋아하고, 후보마다 흔들림을 곱해 격자 무늬가 되지 않게 했습니다. 장면 자리는 따로 씨앗을 써서 앞 단계를 바꿔도 흔들리지 않습니다.
- 장면 틀은 9종입니다: 처형터, 무너진 예배당, 길가 사당, 의식의 원, 버려진 야영지, 영혼 수정 노두, 가족 묘역, 전장의 흔적, 화로 갈림길.
- 지금 데이터는 들판 123, 숲 빈터 5, 갈림길 3, 용의 무덤 뼈 장면 3으로 모두 134곳입니다. 가장 가까운 이웃 장면까지 대개 81~108 m(중앙값 86 m)입니다.
- 장면마다 멀리서 보이는 빛(range 6 m 이상)이 하나 이상 있고, 둘레에 덤불·고목을 두르고, 길가 장면은 길에서 오솔길로 이었습니다.

3) 새 소품 14종과 대체 규칙
- 예상 META를 `NEW_PROPS` 표로 두었습니다. manifest에 이름이 생기면 다음 생성부터 진짜 소품이 쓰입니다.
- 없으면 대체 소품으로 놓습니다. 예상 광원이 대체 소품에 없으면 그 광원을 objects.json `lights`에 따로 넣습니다(지금 88개).
- 대체가 없는 hanging_cage, tent_torn은 그 자리를 비웁니다.

4) 장소 보강
- 묘지: 가운데를 도는 흙길 고리와 샛길 넷, 고리 바깥의 작은 납골당·석관·쇠 울타리 무리 넷. 큰 석관 줄은 광원 있는 것과 없는 것을 번갈아 두었습니다.
- 숲: 덤불숲과 빈터가 번갈아 와서 시야가 막혔다 열립니다. 빈터에 장면을 두었습니다.
- 늪: 돌 징검다리 세 줄(rock_flat 102개, 긴 축이 길을 가로지름), 연꽃 무리, 섬의 가라앉은 사당.
- 용의 무덤: 새끼 용의 뼈, 뼈 무더기 제단, 뼈 가시 고리.
- 마을: 어귀의 부서진 수레·교수 새장, 우물가 화로.

5) 예산 지킴이
- `trim_lights`가 걸을 수 있는 범위 4 m 격자 어디서도 80 m 안 광원이 44개를 넘지 않게, 몰린 곳의 초·버섯·연꽃부터 뺍니다.
- 큰 구조물(담·아치·납골당·석관 등)은 바닥 상자 전체가 땅에 닿게 놓아 비탈에서 뜨지 않게 했습니다.

문서와 확인 렌더 보기도 새 데이터에 맞췄습니다: Tools/WorldGen 의 README·SPEC·render_world.py 보기 좌표(새 보기 fields 추가), docs/WORLD.md 장소 표, docs/TESTING.md G3 기대값(대략값)과 G16 경로.

## 근거

전후 비교. 전 = 지금 저장소 데이터(Assets/_Necro/Art/World/Ch1/Data~, scratchpad/world_v/Data~ 와 같음), 후 = /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2/Data~

[넓이·걷는 거리]
- 걸을 수 있는 범위: 170~1878 → 360~1690.
- 시작과 이어진 걸을 수 있는 땅(기울기 ≤ 1.0): 2.77 → 1.68 km².
- 장소 가운데 사이 걷는 거리(15쌍): 평균 450 → 346 m.
  - 제단→묘지 360→274, 납골당→대성당 480→331, 대성당→봉인문 344→304
  - 묘지→늪 566→445, 늪→고목 517→408, 용의 무덤→망루 582→445
  - 제단→검은 숲 620→480, 다리→용의 무덤 274→197
- 발견 원 가장자리 사이: 84~380 → 37~280 m.

[빈 들판]
- 가장 가까운 볼거리까지 거리(장소 원 + 일반 규칙 장면; 일반 규칙 = 볼 것 소품 3개 이상 무리 또는 랜드마크):
  - 중앙값 41.8 → 31.9 m, 90% 100.2 → 79.2 m, 최대 264 → 166 m
  - 100 m 넘는 땅 10.0% → 3.2%, 60 m 넘는 땅 33.8% → 22.7%
- 생성기 장면 목록(_scenes.json)까지 넣으면 중앙값 20.6 m, 90% 43.8 m, 최대 84.3 m, 100 m 넘는 땅 0%.
- 일반 규칙은 대체 소품(바위·잔해 등)을 '볼 것'으로 세지 않아 장면을 적게 셉니다.

[빛]
- 80 m 안에 광원이 없는 땅: 5.7% → 0.1%.
- 80 m 안에 멀리 보이는 광원(range ≥ 6)이 없는 땅: 37.7% → 2.1%.
- 가장 가까운 광원 중앙값 35.7 → 30.7 m, 최대 171 → 88 m.
- 점광원 합 944 → 976 (소품 광원 883 → 785, 따로 놓은 광원 61 → 191).
- 80 m 안 광원 수: 중앙값 4 → 9, 99% 31 → 34, 최대 43 → 44 (한도 48).
- LightCuller 흉내(길 10개 걷기)에서 48개 제한 걸린 판단 0 → 0.

[삼각형·풀] (perf_qa, 같은 방법·같은 설정)
- 화면 안 합 50/90/99/100%: 6.42/7.25/7.89/8.31M → 6.27/6.92/7.52/8.20M.
- 소품+나무만: 2.85/3.45/4.03/4.39M → 2.74/3.07/3.39/3.66M.
- 그리는 물체 최대 1662 → 1615.
- 풀: 월드 전체 5.95M → 3.86M 포기 (밀도 1). 70 m 거리 안 최대 30k → 30k, 화면 안 최대 9k → 9k (5.70 → 5.42M 삼각형).

[개수]
- 지형 나무 6,748 → 5,044.
- 소품 7,722 → 6,397.
- 효과 100 → 157, 물 3, 장소 13.
- 묘비 약 3,000 → 1,930. 장면 134곳.

[검사 결과] 모두 통과
- 탈출 없음: escape_gate.py 기울기 한계 1.19와 1.0 모두에서 지형 끝 0, bounds 밖 0, 문 뒤 0칸. 문 충돌을 빼면 문 뒤 주머니에 1418/1336칸이 닿습니다 = 문만 길을 막습니다.
- 장소 도달: nav_flood 기울기 한계 1.0과 1.19에서 13/13, bounds 밖 0 m².
- 길: nav_roads 14개 길 오르내림 최대 0.43 (23°), 길 폭 안 지형 최대 0.50, 30° 넘는 구간 0, 물에 잠긴 길 0.
- 다리: nav_bridge 양 끝 턱 최대 0.205 m (stepOffset 0.35 아래). 아치 단면은 옛 판과 같습니다.
- 배치 검사(placement_qa run_all, 17개 결과):
  - 데이터 문제 없음, 땅속 광원·효과 0.
  - 범위 안에서 0.5 m 넘게 뜬 소품은 bridge_ruin 하나(옛 판과 같음)와 물 위에 뜨는 연꽃뿐.
  - 길을 막는 소품은 altar·bridge·fence_gate·statue_angel 로 옛 판과 같고, 길 14개가 모두 끝까지 이어집니다.
  - 큰 소품끼리 파고듦은 나무 가지끼리 7건뿐.

[결과 경로]
- 개요도: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2/_overview.png
- 지도: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2/map.png
- 개요도 잘라 본 것: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/ov_final.png, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/ov_final_graveyard.png
- 장면 배치 그림: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/scenes_final.png
- 숲 덤불숲·빈터 분포: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/forest_density.png
- 빈 들판 지표 전/후: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/before_empty.json, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/after_empty.json, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/final_empty.txt
- 성능 전/후: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/perf_before/, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/perf_final/
- 탈출·도달·길·다리: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/final_escape.txt, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/final_flood.txt, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/final_roads.txt, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/final_bridge.txt
- 배치 검사 결과: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/placement_final/
- 생성 로그: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2_qa/gen_final.log

같은 명령으로 다시 만들면 같은 결과가 나옵니다(world_v2c 와 world_v2 의 objects.json 일치 확인). 생성은 약 50초 걸립니다.

## 남은 문제

- 저장소의 월드 데이터(Assets/_Necro/Art/World/Ch1/Data~, map.png)는 아직 옛 판입니다. 메인 세션이 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/world_v2/Data~ 와 map.png 를 복사해야 합니다. Terrain 텍스처는 바뀌지 않았습니다.
- Blender 확인 렌더를 못 했습니다(그때 다른 작업자가 Blender 빌드 중). render_world.py 보기 좌표는 새 데이터에 맞췄고 새 보기 'fields'(제단 북쪽 길에서 서쪽 들판의 장면들)를 더했습니다. 메인 세션에서 overview, spawn, fields, graveyard, swamp 렌더를 권합니다.
- 게임 안 지도(PoiDiscovery)는 지형 2048 m 전체를 그립니다. 그래서 걸을 수 있는 범위가 지도 가운데 약 65%만 차지하고 둘레가 모두 산입니다. 범위만 크게 보이게 하려면 world.json 에 지도 범위 칸을 두고 NecroWorldBuilder 가 worldMin/worldSize 를 거기서 읽어야 합니다(C#과 SPEC 변경이라 하지 않았습니다).
- 대체 소품이 없는 hanging_cage(13곳), tent_torn(21곳)은 비워 두었습니다. 그래서 야영지가 아직 휑합니다. cart_broken → log_fallen 대체는 자리가 좁아 1곳만 놓였습니다. 진짜 소품(footprint 1.8)이 생기면 늘 것입니다.
- 새 소품이 생기면 따로 넣은 대체 광원 88개가 빠지고 프리팹 광원으로 바뀝니다. 작은 납골당 예상 광원(세기 3, range 5)은 지금 대체인 crypt 광원(7, 8)보다 약해 '멀리 보이는 빛'이 조금 줄 수 있습니다. 다시 생성한 뒤 perf_lights 와 empty_metrics 를 다시 돌리십시오. trim_lights 가 80 m 안 44개는 자동으로 지킵니다.
- 80 m 안 광원 수 중앙값이 4에서 9로 늘었습니다. 최대는 44로 한도 48 아래이고 컬링 흉내에서 제한 걸림은 0입니다. 다만 90 m 안 48개를 넘는 자리가 5곳에서 41곳으로 늘었습니다(LightCuller 여유 띠).
- 소품을 빼고 지형만 보는 placement_qa/check_escape.py 는 봉인문 뒤 골짜기가 bounds 북쪽 밖으로 35 m(z 1725까지) 이어진다고 봅니다. 문 충돌을 넣은 escape_gate.py 기준으로는 문 뒤 0칸이고, 골짜기는 약 90 m 이어진 뒤 막혀 지형 끝에 닿지 않습니다. Unity 는 world.json bounds 를 쓰지 않습니다.
- empty_metrics 의 '일반 규칙'은 대체 소품(rock_b, rubble, dead_tree_c 등)을 '볼 것'으로 세지 않아 v2 장면을 적게 셉니다(일반 규칙 89개 / 생성기 목록 134곳). 보고에는 두 값을 함께 적었습니다.
- 묘지 묘비는 옛 판처럼 모두 남쪽을 봅니다. 길 40 m 안 묘비 중 31%는 길에 등을 집니다(옛 설계 그대로).

## 넘겨받을 것

[다음 단계: 장면용 새 소품 14종 작성자에게]
이름은 그대로 써 주십시오. manifest 에 이 이름이 생기면 worldgen 이 다음 생성부터 자동으로 씁니다.

크기는 Blender 축 (x 폭, y 깊이, z 높이), 앞면 −Y 입니다. 광원 offset 은 Blender 로컬 (x, y, z) 이고 z 가 높이입니다. 장면 배치는 footprint 와 크기로 간격을 정하므로, 크기가 표와 많이 다르면 worldgen.py 의 NEW_PROPS 도 고쳐 주십시오.

| 이름 | 크기 m | footprint | kind | collider | sink | tilt | align | scale | 광원 (색, 세기, range, offset) | 지금 대체 |
|---|---|---|---|---|---|---|---|---|---|---|
| gallows 교수대 | 3.6×1.8×4.8 | 1.9 | prop | mesh | 0.05 | 2 | F | 0.95–1.1 | 없음 | dead_tree_c |
| hanging_cage 매달린 새장 (기둥·팔·새장 한 덩어리, 땅에 선다) | 2.0×1.0×3.6 | 0.9 | prop | capsule | 0.05 | 4 | F | 0.9–1.1 | SOUL [0.62,0.35,1.0], 1.5, 3, (0.7,0,1.9) | 없음(건너뜀) |
| brazier 화로 | 1.0×1.0×1.3 | 0.6 | prop | capsule | 0.04 | 2 | F | 0.9–1.1 | SPIRIT [0.45,0.95,0.9], 7, 9, (0,0,1.25) | lantern |
| banner_torn 찢긴 깃발 | 1.4×0.5×4.2 | 0.5 | prop | capsule | 0.15 | 8 | F | 0.85–1.15 | 없음 | bone_spike |
| sarcophagus 석관 (긴 축 = 로컬 X) | 2.4×1.1×1.1 | 1.3 | prop | box | 0.05 | 2 | F | 0.95–1.1 | 없음 | coffin |
| cart_broken 부서진 수레 | 3.4×1.8×1.5 | 1.8 | prop | mesh | 0.08 | 6 | T | 0.9–1.1 | 없음 | log_fallen |
| soul_crystal 영혼 수정 | 1.4×1.3×2.4 | 0.9 | prop | mesh | 0.2 | 12 | F | 0.7–1.4 | SPIRIT, 4, 7, (0,0,1.2) | rock_b ×0.6 + 따로 광원 |
| skeleton_remains 해골 유해 | 1.8×0.8×0.4 | 0.9 | scatter | none | 0.03 | 4 | T | 0.9–1.1 | 없음 | bones_scatter |
| iron_fence 쇠 울타리 (긴 축 = 로컬 X) | 3.0×0.2×1.7 | 1.5 | prop | box | 0.05 | 3 | F | 0.95–1.05 | 없음 | fence |
| mausoleum_small 작은 납골당 | 4.4×5.2×4.8 | 3.0 | landmark | mesh | 0.06 | 0 | F | 0.95–1.05 | SOUL, 3, 5, (0,−2.4,1.6) 문 안 | crypt ×0.5 |
| shrine_roadside 길가 사당 | 1.3×1.0×2.2 | 0.8 | prop | box | 0.04 | 3 | F | 0.9–1.1 | SOUL, 2.5, 5, (0,−0.35,1.2) 감실 | grave_obelisk + 따로 광원 |
| obelisk_chained 사슬 오벨리스크 | 1.5×1.5×4.6 | 1.0 | prop | box | 0.1 | 3 | F | 0.9–1.15 | 없음 | grave_obelisk ×1.6 |
| tent_torn 찢긴 천막 | 3.6×3.0×2.4 | 2.0 | prop | mesh | 0.05 | 4 | T | 0.9–1.1 | 없음 | 없음(건너뜀) |
| campfire 꺼져 가는 모닥불 | 1.4×1.4×0.5 | 0.8 | prop | none | 0.03 | 2 | T | 0.9–1.1 | EMBER [1.0,0.5,0.28], 3.5, 7, (0,0,0.5) | rubble ×0.75 + 따로 광원 |

tags 는 표에 쓰지 않았습니다. NEW_PROPS 의 값을 그대로 쓰면 됩니다.

지금 데이터에서 놓인 수(대체 포함): banner 78, brazier 16, campfire 16, gallows 9, iron_fence 85, mausoleum 18, obelisk 17, sarcophagus 28, shrine 13, skeleton 143, crystal 59, cart 1. 건너뛴 수: hanging_cage 13, tent_torn 21. 장면에서 많이 쓰이는 skeleton_remains, iron_fence, banner_torn, soul_crystal 부터 만드는 것이 효과가 큽니다. 하나하나 삼각형이 많으면 화면 예산이 바로 늡니다.

[소품이 생긴 뒤 다시 만들기와 검사]
아래 S 는 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad 입니다.

1. 생성: `cd /home/user/Taming/Tools/WorldGen && python3 worldgen.py $S/world_v2 $S/kit_out`. 로그 끝에 '아직 없는 새 소품 → 대체' 줄이 줄어드는지 봅니다.
2. 탈출: `cd $S/world_v2_qa/escape && python3 ../../qa_checks/escape_gate.py $S/world_v2/Data~ 1.19` (1.0 도).
3. 도달·길·다리: `cd $S/wf_world/navigation && NAV_DATA=$S/world_v2/Data~ NAV_OUT=$S/world_v2_qa/nav_final python3 nav_flood.py 1.0 large 1; python3 nav_roads.py; python3 nav_bridge.py`
4. 배치: `cd $S/wf_world/placement_qa && WORLD_DATA=$S/world_v2/Data~ KIT_OUT=$S/kit_out ./run_all.sh`
5. 성능: `cd $S/wf_world/perf_qa && WORLD_DATA=$S/world_v2/Data~ PERF_OUT=<결과 폴더> ./run_v2.sh`. 비교 기준은 $S/world_v2_qa/perf_before 입니다.
6. 빈 들판: `python3 $S/world_v2_qa/empty_metrics.py $S/world_v2/Data~ --scenes $S/world_v2/_scenes.json`
7. 장면 확인 그림: `python3 $S/world_v2_qa/scene_sheet.py $S/world_v2 $S/kit_out out.png`

[조절 손잡이] 모두 worldgen.py 에 있습니다.
- SCENE_STEP (지금 80): 작게 하면 장면이 더 많고 촘촘해집니다. 70이면 154곳.
- SCENES: 장면 틀별 반지름과 길가/들판 선호.
- trim_lights(limit=44).
- lay_forest: 덤불 0.75·0.55, 쓰러진 나무 0.13, 나무 ×1.05.
- lay_fields 의 채움 개수.
- 묘지는 lay_graveyard 의 흙길 고리와 납골당 무리 넷.

[메인 세션에 넘길 것]
- world_v2 의 Data~ 와 map.png 를 Assets/_Necro/Art/World/Ch1/ 로 복사한 뒤 커밋해 주십시오.
- Blender 가 비면 render_world.py 로 overview, fields, graveyard, swamp, spawn 을 렌더해 눈으로 확인하는 것을 권합니다(samples 24~32).
- 사용자 플레이 테스트는 docs/TESTING.md G16 에 들판을 걷는 항목(80~120 m 마다 다음 장면의 빛이 보이는지)을 더해 두었습니다.

# 독립 검토

## 검토 판정: needs_work

### 문제

- [장면 틀 버그: 계획한 소품이 매번 빠짐] 세 군데에서 소품이 한 번도 놓이지 않는다. Scene.put 을 감싸 실패를 센 스크립트: review_v2/dbg/run.py.
(1) 가족 묘역 등불 14/14 실패. 로컬 (1.5, 6.8) 의 등불이 앞 오른쪽 울타리 (3.1, 5.6) 와 발자국이 겹친다. 울타리 대체(fence) 발자국 1.8, 등불 0.6 이라 필요 거리는 √0.85×2.4 = 2.21 m 인데 실제 거리는 2.0 m 다. README 장면 표와 WORLD.md 에는 가족 묘역에 '등불'이 있다고 적혀 있다.
(2) 야영지 그루터기 16/16, 부서진 수레 16/16 실패. 먼저 loose 로 놓은 통나무 (∓2.5, 1.5) 는 s 0.75 에서도 발자국이 2.0 이다. 이것이 그루터기 (-4.6, 2.2) 를 막고 (거리 2.2 < 필요 2.58), 수레 (5.4, 2.4) 도 막는다 (거리 3.0 < 필요 3.5). 진짜 cart_broken(발자국 1.8)이 생겨도 같은 이유로 실패한다. 그 결과 야영지 16곳의 반지름 안 소품은 평균 6개(통나무 2, 뼈 2, 해골 1, 잔해 1)와 불빛 하나뿐이다.
(3) 마을 어귀 수레(worldgen.py:993)도 놓이지 않았다. 생성 로그의 cart_broken→log_fallen 1 은 전장 1곳의 것이다.
그런데 TESTING G16 과 WORLD.md 에는 '어귀의 수레'가 적혀 있다.
- [멀리 보이는 빛과 LightCuller 가 맞지 않음] LightCuller 기본값은 끄는 거리 = range×12, 바깥 30% 구간에서 세기가 1 → 0 으로 준다.
- 야영지 불빛과 수정 빛은 range 7 이다. 84 m 에서 꺼지고 71 m 에서 세기가 50% 다.
- 전장 영혼 빛과 대신 넣은 빛은 range 8 이다. 96 m 에서 꺼지고 82 m 에서 50% 다.
- 장면 사이 가장 가까운 거리의 중앙값은 88 m 다.
장면 가운데에서 가장 가까운 이웃 장면의 빛이 세기 50% 넘게 켜져 있는 경우는 40/134 뿐이다. 안 켜진 이웃의 틀은 battle 22, crystal 20, family 17, camp 16 등이다 (review_v2/beacon.py).
대체 소품(rubble, rock_b)에는 발광 부품이 없다. 그래서 빛이 꺼지면 아무것도 보이지 않는다.
작업자의 지표 '80 m 안에 멀리 보이는 광원이 없는 땅 2.1%'는 컬링을 무시한 값이다. TESTING G16 은 사용자에게 '80~120 m 앞에 다음 장면의 빛이 보이는지'를 확인하라고 한다.
고칠 방향: 장면의 멀리 보이는 빛을 range 10 이상으로 하거나, 장면 광원만 끄는 거리를 따로 두거나, 장면 간격을 줄인다.
- [균일한 점 무늬, 길과 무관한 배치] 가장 먼 점 고르기를 SCENE_STEP 80 으로 돌린 결과 장면이 물방울 무늬처럼 고르게 흩어졌다.
- Clark-Evans R = 1.60 (1 = 무작위, 2.15 = 완전 격자).
- 가장 가까운 이웃 거리는 장면 80% 가 81~109 m 다.
- 길에서 50 m 안 장면은 22/134 뿐이다. 길까지 거리 중앙값 135 m, 100 m 넘는 장면 86곳, 최대 412 m.
북동쪽 x 1100~1690, z 1250~1690 이 대표적이다. 길도 장소도 없는 들판에 장면 25곳 정도가 같은 간격으로 박혀 있고, 그 사이는 풀과 고목뿐이다 (review_v2/crop_ne.png).
지형 시선으로 보면 100 m 안에 장면이나 장소가 보이는 땅은 91.5% 다 (review_v2/los.py). 그래도 넓이는 줄었고 리듬은 '90 m 마다 작은 무대 하나'로 고르다. 조밀한 곳과 비운 곳의 대비, 길·언덕·개울 같은 시선과 지형과의 관계가 없다.
작업자가 새로 넣은 확인 렌더 보기 'fields' (1012,700 → 860,760) 를 내가 렌더했더니 장면이 하나도 보이지 않는다. 처형터 89 m, 야영지 165 m, 사당 168 m 가 모두 언덕에 가린다. 보이는 것은 길가 등불과 빈 비탈뿐이다 (review_v2/render/v2_fields.png).
북동쪽 들판 (1395,1440) 렌더도 87 m 앞 야영지의 작은 주황 점 하나와 고목 몇 그루뿐이다 (review_v2/render/v2_ne_field.png).
- [반복과 대체 소품 때문에 '실속'이 부풀려짐]
- 의식의 원 17곳: 언제나 가운데 오벨리스크, 반지름 7.5 m 기둥 고리 8개, 반지름 3.2 m 양초 고리 5개다. 시작 장소 '봉인의 제단'(반지름 15.5 m 기둥 고리, 양초, 해골)을 작게 베낀 모양이라 첫 랜드마크의 고유함이 묽어진다.
- 가족 묘역 14곳과 묘지 안 무리 4곳: mausoleum_small 대신 crypt 를 0.48~0.52 배로 놓았다 (5.1×5.5×4.5 m). 이름 있는 장소 '이름 없는 납골당'의 축소판이 18채 생긴 셈이다.
- 그중 5채는 box 접지로 오르막 쪽이 1.4~1.85 m 묻혔다: (436.7, 1474.0) 41%, (862.9, 1376.4) 39%, (936.3, 1559.2) 36%, (1200.3, 816.2) 35%, (1135.5, 1380.2) 32%.
- 야영지와 수정 40곳(들판 장면의 30%)은 지금 데이터에서 바위·통나무·잔해와 빛뿐이다. 들판 채움 소품과 구별되지 않는다.
- 같은 일반 규칙(볼 것 소품 3개 이상 무리)으로 세면 장면 수가 94 → 89 로 오히려 줄었다. 빈 들판 지표가 나아진 것은 대부분 넓이를 줄인 효과다.
- 150 m 안에 같은 틀 장면이 둘 이상 보이는 땅은 15.4% 다.
- [보고에 없는 절충: 핵심 장소가 작아짐] 장소를 '가운데로 당긴' 것만이 아니다. 반지름 자체가 줄었다.
- 묘지 170 → 135, 늪 230 → 180, 용의 무덤 160 → 130, 검은 숲 200 → 160, 호수 95 → 78.
- 묘비 3,570 → 2,068 (−42%), 등불 150 → 90.
README 표에는 적혀 있지만 작업자 요약에는 없다. 사용자는 '실속 없음'을 지적했는데, 가장 실속 있던 묘지와 늪을 깎고 그 자리를 작은 장면 반복으로 메운 셈이다. 메인 세션이 의도한 결정인지 확인하고 사용자에게 밝혀야 한다.
- [문서가 현재 데이터와 다름] TESTING G16 과 WORLD.md 에는 현재 데이터에 없는 것이 적혀 있다.
- 마을 '어귀의 수레': 놓이지 않음.
- '우물과 화로': 등불로 대체.
- 야영지 천막, 교수 새장: 대체 없이 빠짐.
- 가족 묘역 등불: 놓이지 않음.
- WORLD.md 의 '영혼 수정 → 빛나는 바위': rock_b 는 빛나지 않고 옆에 점광원만 있다.
- '비슷한 소품으로 대신'이라고 썼지만 hanging_cage 와 tent_torn 은 그냥 빠진다.
새 소품 14종이 생기기 전에 v2 데이터를 저장소에 넣으면 사용자의 테스트 목록과 화면이 어긋난다.
- [작은 문제]
- box 접지로 뜸은 없앴지만 묻힘이 늘었다. 묻힘이 높이의 30% 넘는 것: wall_ruin_b 19개 (전 11, 최대 76% < 전 52%), pillar_b 23개 (전 4).
- 대표 예: 예배당 (1664, 512) 의 담 (1670, 512) 은 기울기 0.51 비탈에서 2.23 m 높이 중 1.69 m 가 묻혔다. 장면 소품을 loose 로 놓을 때 기울기 한계 0.6 이 너무 크다.
- 용의 무덤 dragon_young 장면에는 range 6 이상 빛이 없다. 장면마다 하나 이상이라는 보고와 다르다 (장소 안이라 영향은 작다).
- 봉인문 문 줄 z 1634 에서 동쪽에 걸을 수 있는 땅이 1 m 생겼다 (전 0 m). 문 충돌을 넣은 플러드는 여전히 막히지만 여유가 칸 하나뿐이다.

### 메모

판정: 요구된 검사는 모두 다시 돌렸고 보고 수치와 같다. 하지만 사용자 요구("휑하다, 넓기만 하고 실속이 없다")는 반쯤만 풀렸다. 그래서 needs_work.

이번 검토에서 Blender 렌더 3장을 직접 돌렸다 (돌리기 전 Blender 를 쓰는 작업이 없음을 확인, samples 24). 이 렌더는 Blender 근사이고 Unity 화면이 아니다.

[다시 돌려 맞춘 것] 결과 폴더: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v2/
- worldgen.py 를 다시 실행했다. objects.json, trees.json, world.json, height.r16 이 world_v2 와 바이트까지 같다. 재현된다.
- 배치 검사 15종(run_all.sh): 출력이 작업자 결과(world_v2_qa/placement_final)와 전부 같다.
- 탈출: escape_gate.py 를 한계 1.00·1.19 로 돌렸다. 문 뒤 주머니 0, 범위 밖 0, 이어진 땅 1.70/1.71 km² 다. 문 충돌을 빼면 1,336/1,418 칸이라 문만 길을 막는다.
- 도달: nav_flood 로 13곳 모두 닿는다. 범위 밖 0 m², 지형 끝에 닿지 않는다.
- 길 기울기: nav_roads 결과가 같다. 가장 가파른 곳은 용의 무덤→망루 0.43(23°), 다리 서쪽→용의 무덤 0.39 다.
- 다리: nav_bridge 결과가 같다.
- 성능: run_v2.sh 출력 8개가 전부 같다. 화면 삼각형 중앙 6.27M, 최대 8.20M. 80 m 안 광원 최대 44, 컬러 48 제한은 한 번도 걸리지 않았다.
- 빈 들판 지표: empty_metrics.py 출력이 같다. 걷는 거리 평균 449.9 → 346.5 m 도 직접 계산해 확인했다.

[직접 보고 판단한 것]
- 개요도와 지도를 보면 장면이 고른 물방울 무늬로 깔려 있다 (review_v2/crop_ne.png, crop_center.png).
- 장소 사이 간격(발견 원 가장자리 37~280 m)은 산만할 만큼 붙지는 않았다.
- 바깥 산 띠와 네모난 경계는 이전 판과 같은 모양이다. v2 에서 생긴 문제는 아니다.

[제안]
1. 장면 틀의 충돌 버그 3개를 고친다: 가족 묘역 등불 자리, 야영지 그루터기·수레 자리, 마을 수레.
2. 장면 빛을 range 10 이상으로 하거나, LightCuller 에서 장면 광원만 끄는 거리를 따로 둔다.
3. 배치를 바꾼다: 장면을 길·언덕 능선·개울처럼 시선이 가는 곳에 무리 짓고, 조밀한 곳과 비운 곳의 대비를 준다. 모든 들판을 고르게 덮지 않는다.
4. 장소 반지름을 줄인 것(묘비 −42%)을 사용자에게 밝히거나 되돌린다.
5. 새 소품 14종이 생기기 전에는 v2 데이터를 저장소에 넣지 않는다. 넣는다면 crypt 를 0.5 배로 줄여 대체하는 일은 하지 않는다.
6. render_world.py 의 'fields' 보기를 장면이 보이는 자리로 옮긴다.

[만든 파일] 모두 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v2/ 안:
- gen/: 다시 만든 데이터
- pl/: 배치 검사 사본과 결과
- nav/, perf/, esc/: 길찾기·성능·탈출 결과 (esc/gatemap.py 포함)
- scene_stats.py, los.py, beacon.py: 장면 간격·시선·빛 분석
- dbg/run.py: 장면 소품 실패 집계
- render/v2_fields.png, render/v2_ne_field.png, render/v2_w_field.png: 확인 렌더
- render/rw.py: 보기만 더한 render_world.py 사본