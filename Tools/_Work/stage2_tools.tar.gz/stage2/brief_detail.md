# 1단계 근접 디테일 재질: 작업자 보고

## 요약

URP Lit Detail Inputs 로 소품 근접 디테일을 붙였다. 잔무늬 텍스처 생성기를 새로 만들어 이어 붙는 1024 텍스처 8장(돌·나무·뼈·쇠 × 색·노멀)을 만들었다. NecroWorldImport.cs 는 Main 재질을 만들 때 소품 종류에 맞는 디테일을 건다. 종류는 META "detail" 키가 있으면 그것, 없으면 이름 → tags 순으로 정한다. 타일링은 메쉬에서 계산해 실제 0.6~0.9 m 에 한 번 반복된다. 가져오기 설정은 URP 규칙대로 맞추고, 메뉴를 다시 눌러도 결과가 같다. 룩 장면 도구도 같은 MainMaterial 함수를 탄다.

[URP 6000.0 소스 대조 (줄 번호)]
- Lit.shader 37-41: _DetailMask(기본 white), _DetailAlbedoMapScale, _DetailAlbedoMap(기본 linearGrey), _DetailNormalMapScale, _DetailNormalMap.
- Lit.shader 123/265/379/431: shader_feature_local _ _DETAIL_MULX2 _DETAIL_SCALED 가 ForwardLit·GBuffer·DepthNormals·Meta 패스에 있다. 523: CustomEditor LitShader.
- LitInput.hlsl 11-13: 두 키워드 중 하나면 _DETAIL 이 켜진다. 19: _DetailAlbedoMap_ST 는 CBUFFER 안에 있다. 31-32: Scale 두 개. 124-126: 텍스처·샘플러.
- LitInput.hlsl 215-230: MULX2 는 기본 색 × (detail × 2). 224 줄이 ×2, 227 줄이 LerpWhiteTo(마스크). SCALED 는 204-213 줄.
- LitInput.hlsl 233-250: 노멀은 UnpackNormalScale(_DetailNormalMapScale, 239 줄) 후 BlendNormalRNM(246 줄)으로 겹친다.
- LitInput.hlsl 283-288: 마스크는 기본 UV 에서 .a 를 읽는다. detailUv = uv × _DetailAlbedoMap_ST 이므로 디테일 노멀도 albedo 의 _ST 를 같이 쓴다.
- LitForwardPass.hlsl 24: texcoord 는 TEXCOORD0. 177: uv = TRANSFORM_TEX(texcoord, _BaseMap). 따라서 UV0 × _BaseMap_ST × _DetailAlbedoMap_ST 이다.
- LitForwardPass.hlsl 13·84: _DETAIL 이 있으면 _NORMALMAP 없이도 탄젠트가 필요하다. FBX 를 MikkTSpace 탄젠트로 가져오므로 충족된다.
- 키워드 규칙은 LitDetailGUI.SetMaterialKeywords 와 같게 했다: 디테일 텍스처가 있고 색 Scale 이 1 이면 MULX2, 1 이 아니면 SCALED. LitDetailGUI.cs 는 받아 둔 소스에 없어서 URP 패키지 기억을 바탕으로 맞췄다.

[고친 것]
1. 생성기 Tools/BlenderKit/detailtex.py (numpy+PIL)
   - 주기 함수로만 만든다: FFT 잡음, 감싸는 Worley, np.roll 미분. 같은 씨앗이면 늘 같은 그림이 나온다.
   - albedo 는 평균 0.500 이고 sRGB 를 끄고 읽는 MULX2 용이다. 노멀은 OpenGL 방식(초록 = 위).
   - 사용자가 지적한 '녹은 밀랍' 굴곡이 생기지 않게 높이에는 중간 크기 굴곡을 빼고 알갱이·구멍·금·결 같은 잔것만 넣었다.
2. NecroWorldImport.cs
   - PropMeta.detail: manifest META 의 "detail" 키를 읽는다.
   - DetailKindFor: META → 이름 → tags 순. 모르는 값이면 경고하고 추정으로 넘어간다.
   - DetailTiling / MetersPerUv: LOD0 Main 면마다 √(실제 면적 / UV0 면적) 을 구해 면적 가중 중앙값을 내고, 그것을 반복 크기(m)로 나눈다. 근거와 측정값은 주석에 적었다.
   - ApplyDetail: Main 재질에 디테일을 걸고 키워드를 맞춘다.
   - ConfigureDetailTexture: 디테일 텍스처 가져오기 설정. 가져오기 후처리기와 0번 메뉴 1단계 양쪽에서 적용된다.
   - FindMeta: manifest 를 캐시해 두고, meta 없이 불릴 때(룩 장면 도구) 같은 결과를 낸다.
   - Console 요약에 "근접 디테일 재질: …" 한 줄을 넣었다.
   - Glow·Foliage 재질은 손대지 않았다.
3. 문서: README 는 META 절만 고쳤고(detail 키 + 추정 규칙), WORLD.md 는 '소품 프리팹 규칙' 표에 한 줄을 넣었다.

## 근거

[컴파일 점검]
- check.sh 를 Assets/_Necro 의 *.cs 전체에 돌려 종료 코드 0 (로그: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/detail_check.log).
- 일부러 틀린 호출을 넣은 파일은 종료 코드 1 이 나와, 검사가 실제로 오류를 잡는 것을 확인했다.
- Unity 를 실행할 수 없는 환경이라 Unity 2021.3 엔진 모듈 + 에디터 참조 DLL 로 한 컴파일 검사다. 쓴 API(TextureImporter.fadeout·mipmapFadeDistanceStart/End, Material.SetOverrideTag/GetTag 등)는 Unity 6 에도 있다.

[종류 판정]
- NecroWorldImport.cs 의 DetailKindFor 메서드 본문을 그대로 잘라 mono 로 manifest 62종에 돌렸다.
- Main 재질이 있는 소품 기준 예상 판정: 돌 32 · 나무 8 · 뼈 8 · 쇠 1(lantern) · 없음 2(candles, mushroom_toxic).
- 모르는 값(예: "marble")은 경고를 남기고 추정 규칙으로 넘어간다.

[UV 1 단위 = 몇 m (Blender 로 62종 측정)]
- 결과: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/detail_measure.json (스크립트 detail_measure.py, detail_measure2.py).
- 대표 값: 묘비 grave_slab_a 1.86 → 타일링 2.07, rock_a 3.55 → 3.94, coffin 4.22 → 5.63, lantern 2.24 → 3.73, dead_tree_a 14.2 → 18.9, dragon_skull 13.7 → 22.9, cliff_a 29.1 → 32.3, cathedral 300 → 333.
- 같은 해상도라도 텍셀 밀도가 7~1600 px/m 로 달라서, 크기·해상도만으로는 짐작이 안 된다. 그래서 메쉬 면적으로 계산했다.
- 섬 사이 편차: 일반 소품은 p25~p75 가 ±3 % 안이다. unwrap_smoothed 를 쓴 큰 구조물(gate_great, crypt)은 ±30 % 쯤 된다.

[텍스처 통계 (detailtex.py 출력)]
| 종류 | 색 표준편차 (×2 하면) | 노멀 기울기 RMS | 이음매/내부 차이 비 |
| --- | --- | --- | --- |
| stone | ±7 % | 13.4° | 약 1.0 |
| wood | ±5 % | 7.6° | 약 1.0 |
| bone | ±6 % | 10.3° | 약 1.0 |
| metal | ±5 % | 8.9° | 0.7~1.0 |
- 이음매/내부 차이 비가 1 근처면 끝이 이어진 것이다.
- 8장 합계 12 MB, PNG 라 .gitattributes 의 LFS 규칙을 탄다.

[합성 미리보기]
- URP 계산을 Python 으로 흉내 냈다: MULX2 곱, RNM 노멀, 삼선형 밉맵 + 밉 fade 3→7, 1080p 시야 55°.
- 결과 파일 (모두 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/ 아래):
  - detail_preview_all.png (6종 × 1 m / 3 m / 7 m, 왼쪽 굽기만 · 오른쪽 + 디테일)
  - detail_preview_grave_slab_a_1m_zoom.png
  - detail_preview_grave_slab_a.png, detail_preview_rock_a.png, detail_preview_dead_tree_a.png, detail_preview_coffin.png, detail_preview_dragon_skull.png, detail_preview_lantern.png
  - 텍스처 1:1 확대: detail_preview_textures.png, detail_sheet.png
- 판정: 1 m 에서는 흐린 면에 돌 알갱이·작은 구멍, 나무 결 홈, 뼈 잔금이 또렷해지고, 전체 색과 새긴 모양은 그대로다. 3 m 와 7 m 에서는 거의 차이가 없어 굽힌 그림과 싸우지 않는다.
- 첫 시안은 중간 크기 얼룩이 굴곡처럼 보여서, 높이에서 뺀 뒤 세기를 맞췄다.

## 남은 문제

- Unity 실행 검증이 없다. 키워드가 Inspector 를 열었을 때 URP 규칙(LitDetailGUI)과 맞는지, Material.GetTag 가 SetOverrideTag 로 넣은 태그를 돌려주는지는 플레이 테스트로 확인해야 한다. 태그를 못 읽어도 매번 계산값으로 다시 맞출 뿐이라 결과는 같고, 사람이 고친 타일링만 지켜지지 않는다.
- UV 섬 방향이 smart_project 라서 제각각이다. 나무 결은 섬마다 방향이 달라질 수 있어 홈을 얕게 했지만, 고목에서 결이 가로로 보이는 섬이 있으면 META detail 이나 _DetailNormalMapScale 로 조정해야 한다. 섬 경계에서 잔무늬가 끊기는 것도 은은하게 보일 수 있다.
- 큰 구조물은 굽기 텍셀 밀도가 아주 낮다 (cathedral_ruin 7 px/m, gate_great 48, crypt 56, tree_giant 24 — 텍셀 하나가 2~14 cm). 디테일은 잔결만 더할 뿐 이 흐림 자체는 해결하지 못한다. v3 재제작에서 재질 분할·트림 시트·큰 해상도가 필요하다.
- lantern 은 돌 기둥과 쇠가 대략 반반인데, 작업 지시대로 metal 로 판정한다. 바꾸려면 META "detail" 을 쓴다. fence 와 fence_gate 는 돌 기둥 + 쇠창살이라 stone 이다 (나무가 아님을 assets_ruins.py 에서 확인).
- 작업 중 git diff 에 kit.py·assets_graves.py 변경이 보이는데, 내 변경이 아니다 (동시에 돌고 있는 다른 작업). README 는 META 절만 고쳤다.

## 넘겨받을 것

[다음 작업자에게]
- 디테일 텍스처를 다시 만들 때: python3 Tools/BlenderKit/detailtex.py [--size 1024] [--sheet 미리보기.png]. 결과는 결정적이다. 세기는 파일 안의 GAIN 표, 반복 크기는 REPEAT_M 으로 바꾼다. REPEAT_M 을 바꾸면 NecroWorldImport.cs 의 DetailRepeat 도 같은 값으로 맞춰야 한다.
- v3 재제작으로 UV 나 크기가 바뀌어도 0번 메뉴를 다시 누르면 타일링이 다시 계산된다. 사람이 Inspector 에서 고친 타일링과 Detail 폴더 밖의 텍스처는 그대로 둔다.
- 재질별로 디테일을 끄려면 META 에 "detail": "none" 을 쓴다. META 는 assets_*.py 의 META 사전이고, build.py 가 manifest 로 그대로 옮긴다. worldgen 은 이 키를 무시하므로 영향이 없다.

[사용자가 Unity 에서 확인할 것]
1. git lfs pull 후 Tools → Necro → 월드 → 0. 소품 가져오기 설정 + 프리팹 만들기를 누른다. Console 에 "근접 디테일 재질: 돌 32 · 나무 8 · 뼈 8 · 쇠 1 · 없음 2" 와 비슷한 줄이 나오고, 디테일 텍스처가 없다는 경고가 없어야 한다.
2. Assets/_Necro/Art/Materials/Detail 의 텍스처 가져오기 설정:
   - detail_*_albedo: Texture Type Default, sRGB 꺼짐.
   - detail_*_normal: Texture Type Normal map.
   - 공통: Wrap Repeat, Fadeout Mip Maps 켜짐 (3~7), Trilinear, Aniso 8.
3. Materials/Props/grave_slab_a.mat 의 Inspector → Detail Inputs:
   - Detail Albedo x2 = detail_stone_albedo, Normal Map = detail_stone_normal.
   - Scale 두 개가 1, Tiling 약 2.07 (rock_a 약 3.94, dead_tree_a 약 18.9, dragon_skull 약 22.9, cathedral_ruin 약 333). Unity 메쉬로 다시 계산하므로 몇 % 다를 수 있다.
   - Inspector 를 열었다 닫아도 아무 값도 바뀌지 않아야 한다 (키워드 _DETAIL_MULX2 유지).
4. 룩 장면 또는 월드에서 묘비·바위에 1~2 m 까지 다가가 보기: 흐린 면에 돌 알갱이·작은 구멍·가는 금이 보이면 정상이다. 5~10 m 에서는 예전과 거의 같고, 격자 반복 무늬가 보이면 안 된다.
5. 소품 전체가 예전보다 어두워졌는지 보기: 어두워졌으면 albedo 의 sRGB 가 켜져 있는 것이다.
6. 고목·통나무·관에서 나무 결 방향을 보기: 가로로 어색하면 알려 준다.
7. 용 뼈에서 잔금·잔구멍, 등불(lantern)에서 녹 얼룩·부식 구멍을 본다.
8. 재질 하나의 Detail Tiling 을 손으로 바꾼 뒤 0번 메뉴를 다시 누르면 그 값이 유지되어야 한다.

# 독립 검토

## 검토 판정: needs_work

### 문제

- [작음·실제 불일치] lantern 이 이름 규칙(DetailKindFor 의 "lantern" → metal)으로 쇠 디테일을 받는다. 그런데 README 에 새로 적은 규칙은 '재료가 섞인 소품은 겉넓이가 큰 쪽'이고, lantern 의 Main 면은 돌 받침이 대부분이다. assets_ruins.py lantern() 형상으로 추정하면 Main 실면적 2.79 m²(detail_measure.json) 중 돌 블록 두 개가 약 1.9 m², 쇠 기둥·팔·새장이 약 0.9 m² → 돌이 약 68 %. 그래서 돌 받침 위에 녹 얼룩(면적 약 25 %, 붉은 기)이 깔린다. 고칠 방법: lantern META 에 "detail": "stone" 을 넣거나(assets_ruins.py META + Assets/.../Graveyard/manifest.json), 이름 규칙에서 lantern 을 빼기.
- [작음·문서와 코드 불일치] Tools/BlenderKit/README.md 의 자동 판정 목록이 코드보다 짧다. metal 에는 lantern·iron·cage·chain 만 적혀 있지만 코드에는 anvil·sword·bell 도 있다. wood 에도 코드의 wood·branch·barrel·crate 가 빠졌다. README 를 NecroWorldImport.cs DetailKindFor 와 같게 맞춰야 한다.
- [CLAUDE.md 검증 규칙] docs/TESTING.md 에 디테일 재질 플레이 테스트 항목이 없다. 넣을 항목 예: 0번 메뉴 Console 요약에 '근접 디테일 재질: 돌 32 · 나무 8 · 뼈 8 · 쇠 1 · 없음 2' 가 뜨는지 / 소품이 전보다 어두워지거나 밝아지지 않았는지(×2 규칙·sRGB 끔 확인) / 묘비·바위에 1 m 까지 다가가면 잔 알갱이·구멍이 보이고 5 m 밖에서는 반복 격자가 안 보이는지 / 재질 Inspector 를 열었다 닫아도 키워드·타일링이 그대로인지 / 같은 메뉴를 두 번 눌러도 재질이 바뀌지 않는지 / 멀리서 디테일 노멀이 평평하게 사라지는지(아래 미확인 항목).

### 메모

결론: URP 쪽 구현은 맞다. 코드를 크게 다시 짤 필요는 없고, 위 세 가지만 짧게 고치면 된다.

[URP 6000.0 소스와 직접 대조 — 모두 맞음]
- 보고서에 적힌 줄 번호를 전부 소스에서 확인했다. Lit.shader 37-41·123/265/379/431·523, LitInput.hlsl 11-13·19·31-32·124-126·204-213·215-231·233-250·283-288, LitForwardPass.hlsl 13·24·84·177.
- 디테일 UV 는 UV0 × _BaseMap_ST × _DetailAlbedoMap_ST 다. 디테일 노멀도 albedo 의 _ST 를 쓰고, 마스크는 기본 white 의 .a 를 base uv 에서 읽는다. 코드는 SetTextureScale("_DetailAlbedoMap") 하나만 쓰므로 맞다. Main 재질의 _BaseMap 타일링은 1 이다.
- 키워드 규칙: 디테일 텍스처가 있고 Scale == 1 이면 MULX2, 아니면 SCALED, 텍스처가 없으면 둘 다 끈다. 내가 기억하는 URP LitDetailGUI.SetMaterialKeywords 와 같다. 그래서 Inspector 의 ValidateMaterial 이나 URP MaterialPostprocessor 가 다시 맞춰도 결과가 같다.
- _DETAIL 이 켜지면 탄젠트가 쓰인다(13·84 줄). ConfigureModel 이 CalculateMikk 로 가져오므로 충족된다. DepthNormals·GBuffer·Meta 패스에도 같은 키워드가 있다.
- SRP Batcher: _DetailAlbedoMap_ST·Scale 두 개가 UnityPerMaterial CBUFFER 안에 있어 호환된다. 변형은 MULX2 하나가 늘 뿐이다. 소품마다 재질이 이미 따로라 배칭 손실은 없다. shader_feature_local 은 프리팹이 참조하는 재질 기준으로 빌드에 포함된다.
- sRGB 끔 + ×2: PNG 평균이 정확히 0.500 이라 선형 0.5 × 2 = 1 이다. 맞다.
- 노멀은 NormalMap 형식 + CompressedHQ(PC 는 BC5)다. albedo 는 BC7 이다.
- 재질 재생성: 메뉴를 여러 번 눌러도 같은지, 사람이 넣은 텍스처는 'custom' 으로 두는지, 타일링 태그로 사람이 고친 값을 지키는지 로직을 따라가 봤다. 깨지는 경우를 찾지 못했다. SetOverrideTag(tag, "") 는 태그를 지운다. URP 는 RenderType 태그만 건드린다.

[직접 확인한 것]
- 컴파일 점검: check.sh 를 Assets/_Necro 의 *.cs 전체에 돌려 종료 코드 0. 로그 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_detail_check.log. Unity 2021.3 모듈 스텁 기준이며 Unity 는 실행하지 못했다.
- detailtex.py 를 다시 돌리니 저장소 PNG 8장과 바이트 단위로 같았다(결정적).
- 8장 모두 1024², 색 평균 0.500, 노멀 길이 1±0.01, z > 0. 끝 이음매 차이 비율은 0.7~1.1 로 이어 붙는다.
- 노멀 부호를 유도해 봤다(행이 아래로 갈수록 v 가 줄어든다 → ny = +∂h/∂행). OpenGL(초록 = 위)이 맞다.
- MetersPerUv 의 면적 가중 중앙값을 Blender 로 다시 쟀다(detail_measure2.py, 11종). 대부분 전체 비율과 ±3 % 안이다. gate_great·crypt·dragon_ribs 만 p25~p75 가 약 2배 벌어져, 한 소품 안에서 무늬 크기가 최대 2배 달라진다. 받아들일 만하다.
- kit.py 는 UV 층을 하나("UVMap")만 남기고, 확장 부품(발광·잎)을 LOD0 에 합치며, FBX_SCALE_UNITS 로 내보낸다. 그래서 UV0 = 굽기 UV 이고 1 Blender m = 1 Unity m 이다.
- UV 섬 경계 렌더 확인: 디테일 albedo 만 8배로 키워 바위·통나무에 근접 렌더했다. 섬 경계에서 무늬가 끊기는 곳이 약하게 보이지만 실제 세기(±5~7 %)에서는 거의 안 보인다. 파일 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_seam/rock_a_row.png, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_seam/log_fallen_row.png. 가운데 칸은 Blender 에서 RNM 합성을 못 해 기본 노멀 대신 디테일 노멀만 넣은 것이다. 그래서 Unity 모습이 아니라 이음매 확인용이다.

[메인 세션이 알아 둘 것 (버그 아님)]
1. 효과가 보이는 거리: GAIN 은 '3 m 밖에서는 티가 거의 안 나게' 맞춰져 있다. 그런데 OrbitCamera 거리는 기본 5 m(2~9 m)다. 그래서 평소 플레이 시점에서는 주변 소품에 디테일이 거의 보이지 않고 근접(1~3 m)에서만 효과가 있다. 사용자에게 '재질 고퀄리티' 피드백의 해결책으로 소개하면 과장이다. 체감 개선은 v3 깎기가 맡아야 한다.
2. 아직 확인 못 한 것: TextureImporter.fadeout 을 NormalMap 형식에 쓰면 먼 밉이 평평한 노멀이 되는지 이 환경에서는 확인할 수 없다. PC BC5 는 xy 만 저장하고 z 를 다시 만들므로 회색(0.5, 0.5)이면 평평해야 정상이다. 플레이 테스트 항목으로 넣는 것을 권한다.
3. 2단계 새 소품 14종(교수대·천막·화로 등)은 이름 규칙에 걸리지 않으면 tags 로 넘어가 대부분 stone 이 된다(예: 화로 → stone, 교수대 → stone). 새 소품 META 에는 "detail" 을 직접 적게 해야 한다.
4. 주석 사소: NecroWorldImport.cs 의 'UV 섬 경계(미분이 튀어 가장 낮은 밉을 읽는 곳)' 는 정확하지 않다. 삼각형 래스터화에서는 2×2 묶음의 보조 화소가 같은 삼각형 값을 쓰므로 UV 이음매에서 미분이 튀지 않는다. 밉 3 ≈ 7 m 는 돌(0.9 m) 기준이고 뼈·쇠(0.6 m)는 약 4.9 m 다.
5. 이번 변경 파일은 Archive/ 를 건드리지 않았다. 새 PNG 는 .gitattributes 의 *.png LFS 규칙에 걸린다. .meta 는 Unity 가 처음 가져올 때 만든다.

검토 중 만든 파일: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_detail_seam.py, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_detail_regen/sheet.png. 저장소 파일은 고치지 않았다.