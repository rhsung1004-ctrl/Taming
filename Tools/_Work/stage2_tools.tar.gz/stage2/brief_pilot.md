# 1단계 깎기 v3 시범: 작업자 보고

## 요약

소품 깎기 품질 파이프라인 v3를 kit.py에 넣고 시범 4종(grave_slab_a, rock_b, wall_ruin_a, dead_tree_a)을 새로 만들었습니다. 4종 모두 이전 판과 나란히 렌더해 3~6번씩 고쳤고, 마지막 판은 검은 빗나감 0%, 텍셀 밀도 2.1~2.3배입니다.

기존 assets_*.py는 그대로 빌드됩니다(6개 묶음 확인). 새 기능은 새 함수와 새 선택 인자로만 넣었고, 기존 기본 동작에는 품질만 오르는 수정 세 가지만 넣었습니다.
- 기존 동작 수정 (품질만 오름):
  1. albedo 색 저장 오류: 이전 _save_jpg는 sRGB가 아니라 AgX 보기 변환을 입혀 저장해 색이 바래 있었습니다. 시험 결과 (185,122,62)가 (174,119,65)로 바뀌었습니다. 이제 Standard로 저장합니다.
  2. 굽기 중에 저폴리가 광선에 보이던 것을 숨겼습니다. 이게 AO 그늘을 가려 검게 만드는 원인이었습니다.
  3. 광선이 빗나가 검게 남은 화소를 둘레 색으로 메웁니다.

kit.py 새 함수:
- 깎기·조각:
  - carve: 리메시한 뒤 원래 표면에 되붙여 평평한 면과 곧은 모서리를 살립니다. 블록마다 'piece' 값을 매기고, 되붙이지 않은 리메시로 저폴리 바탕을 만들며, relax로 되붙임 톱니를 폅니다.
  - remesh_sharp, lowpoly, vgroove/engrave_v (V자 홈 새김).
  - STONE3, ROCK3, BARK3 층 묶음.
  - surface에 'chisel' 층 추가: 경계에서 값이 이어지는 평면 끌 자국. 복셀 계단·톱니가 생기지 않습니다.
  - cracks·plates에 warp 인자, terrace에 soft 인자.
- 칠: paint3 손칠 재질.
  - 위는 밝고 아래·틈은 보라, 차갑고 따뜻한 색 얼룩, 블록마다 색조.
  - 베벨 노드로 찾은 닳은 모서리, 자기 객체만 보는 AO 두 단계.
  - 위·틈 이끼, 땅에서 오르는 이끼, 흙물, 빗물 자국, 붓 자국, 잔 점, 삭은 얼룩(곱하기), 끌 자국 결.
- 굽기: finish3, 그리고 finish의 새 선택 인자.
  - make_cage: 정점과 면 가운데에서 광선을 쏴, 원본이 튀어나온 만큼 + 여유만큼 부풀린 굽기 우리.
  - UV 재배치는 채운 비율이 줄면 되돌리고, uv_margin을 고를 수 있습니다.
  - 자홍으로 채워 여백 없이 굽고 빈 곳을 메웁니다(fill_holes).
  - clamp_normals: 70도 넘게 누운 법선을 세웁니다.
  - hard: UV 섬 경계의 단단한 모서리.
  - 로그 줄: TEXEL, UVPACK, CAGE, BAKE(miss %, steep %).
- 새 도구 compare.py: 같은 카메라·조명으로 이전/새 판을 나란히 가까이·중간 거리로 렌더합니다. 같은 이름을 두 번 읽으면 load_fbx가 아무 LOD나 고르는 버그를 비켜 갑니다.
- README의 '미술 기준', '예산', '만드는 과정'을 v3 기준으로 다시 썼습니다. 종류별 권장값 표와 '피할 것' 목록을 넣었습니다.

## 근거

전후 수치 (이전 kit_out → v3 kit_v3). 삼각형은 LOD0(덩굴·풀 포함), 텍셀은 실측 px/m, 빌드는 초:

| 소품 | 삼각형 | 텍스처 | 텍셀 px/m | UV 채움 | 빌드 |
| --- | --- | --- | --- | --- | --- |
| grave_slab_a | 4556 → 1574 (본체 632, 깨끗한 저폴리 + 단단한 모서리 294개) | 1024 → 2048 | 540 → 1171 | 0.65 → 0.67 | 199 → 168 |
| rock_b | 8227 → 8227 | 1024 → 2048 | 174 → 394 | 0.50 → 0.73 | 163~302 → 312 |
| wall_ruin_a | 14949 → 16130 (본체 11.5k) | 2048 | 114 → 237 | 0.12 → 0.51 | 88~184 → 213 |
| dead_tree_a | 8419 → 8420 | 2048 | 143 → 313 | 0.09 → 0.42 | 63~135 → 147 |

- 굽기 결과: 4종 모두 miss 0.000%. 법선을 세운 비율(steep)은 묘비 0.59%, 벽 0.08%, 나무 3.66%, 바위 9.67%입니다. 한 장 굽는 시간은 80~130초(2048, 표본 8)입니다.

비교 렌더 (왼쪽 = 이전, 오른쪽 = v3):
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_grave_slab_a_near.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_grave_slab_a_mid.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_rock_b_near.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_rock_b_mid.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_wall_ruin_a_near.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_wall_ruin_a_mid.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_dead_tree_a_near.png
- /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/_cmp_dead_tree_a_mid.png

반복하며 찾아 고친 것:
- albedo 자홍 테두리: Blender 여백이 빈 화소와 섞여 생겼습니다 → 여백 없이 굽고 직접 메움.
- 글자 테두리 검은 점선: 수직 벽 새김 → V자 홈.
- 밀랍 같은 고리 무늬: fissure → cracks.
- 톱니 테두리: 값이 끊기는 plates/terrace → chisel(이어지는 홈).
- 저폴리 구겨짐으로 UV 섬 수천 개 → 조각 전 바탕에서 저폴리.
- 벽의 UV 여백 낭비: 0.25 → 0.51.
- 검은 점: 어두운 색 묶음에서 얼룩을 섞기(MIX)로 칠해 새까매짐 → 곱하기.
- 나무 검은 점: 극단 법선 → clamp_normals.
- 바위 떨어진 자국의 검은 톱니 → 얕게 + relax 2 + 저폴리는 떨어진 자국 전 형태.

검사 결과·로그:
- 기존 묶음 호환 빌드: 6개 모두 exit 0, BUILT. ruins lantern 57초, graves skull 59초, nature rock_c 70초, foliage weeds 0.1초, landmarks well 143초, bones bones_scatter 68초. 출력은 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3_compat/, 로그는 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/v3work/compat_*.log 입니다.
- 마지막 빌드 로그: /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/v3work/final2_*.log
- C# 은 바꾸지 않아 컴파일 검사는 하지 않았습니다. Unity 를 실행할 수 없어 Unity 안 확인도 하지 않았습니다.
- 출력 kit_v3 에는 4종의 fbx, _albedo.jpg, _normal.png, manifest가 있습니다. kit_out 과 저장소 사본은 건드리지 않았습니다.

## 남은 문제

- 바위 rock_b: 가까이 보면 얇게 떨어진 자국 테두리가 아직 얇고 어두운 톱니선으로 남는다 (이전보다 얇고 덜 검다). 근본 해결은 떨어진 자국 커터의 벽을 비스듬하게 만들거나 바위에서 그 자국을 빼는 것. 깊은 쐐기 틈 안은 검고 지저분하다.
- 죽은 나무: 줄기 위쪽 가지 이음매에 작은 어두운 점이 몇 개 남았다 (steep 3.7%). 껍질은 313 px/m 라 1m 에서는 부드럽다.
- 벽(237 px/m)·바위(394)·나무(313)의 1~2m 근접 선명도는 다른 작업자의 디테일 맵(detailtex.py)에 기대야 한다. 주인공급 구조물은 4096 이 필요할 수 있다.
- 색감: v3 albedo 는 이전보다 밝고 깨끗한 청회색이다. albedo sRGB 저장 수정도 더해져 Unity 장면 조명에서 전체 밝기·채도를 다시 봐야 한다 (paint3 의 light, shadow, piece_var 를 묶음 공통으로 조정).
- 단단한 모서리(grave_slab_a hard=55)는 FBX 분할 법선으로 나간다. Unity 쪽 모델 가져오기 설정(Normals: Import, Tangents: Mikktspace)과 노멀맵 텍스처 형식을 플레이 테스트로 확인해야 한다.
- grave_slab_a 본체가 632 삼각형이라 LOD1(35%)은 221 삼각형이다. 깨끗한 저폴리 소품은 LOD1 비율을 0.6 으로 올리거나 LOD1 을 빼는 편이 나을 수 있다.
- 기존 finish 기본 경로의 품질 수정 세 가지(sRGB 저장, 빗나간 화소 메우기, 저폴리 AO 차단) 때문에 v3 로 바꾸지 않고 다시 빌드한 예전 소품도 겉모습이 조금 달라진다.
- kit.load_fbx 는 같은 이름 FBX 를 두 번 읽으면 LOD0 대신 아무 LOD 나 고른다. compare.py 에서만 비켜 갔고 kit 자체는 그대로다 (build.py 는 한 번만 읽어 문제없음).
- 빌드 시간은 소품당 2.5~5분(2048 두 장 굽기)이다. 62종 전체 재제작은 한 번에 하나씩 돌리면 약 3~4시간이다.

## 넘겨받을 것

2단계(다른 묶음에 v3 적용) 지침. 자세한 내용은 /home/user/Taming/Tools/BlenderKit/README.md 의 '만드는 과정 (kit.py, v3)'를 본다.

0. 공통 교체: sculpt → carve(+STONE3, ROCK3, BARK3), paint/stone_mat/rock_paint/bark_paint → paint3, finish → finish3.
   - 묶음 덧칠(blotch, grad_dark, top_cover, moss_low, tint_near)은 paint3 위에 그대로 얹을 수 있다.
   - RNG 를 쓰는 호출 순서는 바꾸지 않는다 (copy, union, carve 는 RNG 를 쓰지 않는다).

1. 작은 석물: graves 의 grave_slab_b/c, grave_cross, grave_obelisk, grave_tomb, grave_sunken, ruins 의 pillar_a/b, altar, fence 돌기둥.
   - chip·chunk 로 깎은 뒤, 새기기 전에 `low_src = copy(...)`. 받침 같은 부품은 `union(low_src, [copy(부품)])` 으로 합친다.
   - 글자·선은 engrave_v(width 0.011, depth 0.007, floor 0.3).
   - `carve(body, 0.0025~0.0035, *STONE3(k), seed)` → `paint3(..., h=높이, k=크기)` → `low = lowpoly(low_src, z=-0.015)` → `finish3(name, [body], [low], extras, size=2048, cage=0.006, hard=55)`.
   - 확인: TEXEL 800 px/m 이상, steep 1% 안팎.

2. 블록 많은 석조: wall_ruin_b, arch_ruin, stair_ruin, landmarks 의 crypt, cathedral_ruin.
   - `base = carve(body, 0.008~0.01, *STONE3(1.25), seed, base=True)` → `low_of(base, N)` → `finish3(..., cage=0.01, cage_reach=0.1, uv_margin=0.001, lod2=0.12)`.
   - TEXEL 줄의 uv_fill 이 0.45 이상인지 본다.
   - crypt, cathedral 처럼 큰 것은 200 px/m 가 나오지 않으면 size=4096 을 검토한다.

3. 바위·절벽: rock_a, rock_c, rock_flat, cliff_*.
   - 떨어진 자국(spall)을 파기 전에 `base = copy(o)` 를 떠 둔다.
   - 떨어진 자국 깊이는 0.02~0.04.
   - `co, fi = ROCK3(k=크기/2)`, `carve(o, 0.009(바위)~0.02(절벽), (), co+fi, seed, pieces=False, relax=2)`.
   - `paint3(ROCK_PAL, h, k, cells=0.6~1.0, ao=0.5*k)`, `low_from(base, N)`.
   - `finish3(cage=0.015(바위)~0.03(절벽), cage_reach=0.12~0.2, uv_angle=75)`.
   - 절벽은 block_stack 블록이 많으므로 uv_margin=0.001.

4. 나무·통나무·그루터기·뿌리: dead_tree_b/c, tree_giant, log_fallen, stump, roots.
   - `tree_build(..., co+fi of BARK3(k), ..., fin=dict(cage=0.006, cage_reach=0.03, pack=True, samples=8, margin=0, uv_margin=0.001))`.
   - 줄기는 `paint3(BARK_DEAD, h=높이, light=1.0, cavity=1.0, edge=0.7, edge_w=0.01, stains=0.3)` 에 blotch(WOOD_PALE)와 grad_dark 를 얹는다.
   - 잔가지는 `paint3('bark_pale', k=0.5, cavity=0.5)` 로 밝게 해서 실루엣이 읽히게 한다.
   - tree_build 를 쓰지 않는 나무 소품은 finish3 를 그대로 쓴다.

5. 뼈: bones 묶음, graves 의 skull, bone_pile.
   - 둥근 유기 형태라 snap 은 그대로 두되 hard 는 쓰지 않는다.
   - `carve(…, 0.0016~0.003, coarse=(), fine=[chisel 약하게 + pits + cracks])`.
   - `paint3(BONE_DARK 또는 'bone', edge=0.6, moss 적게)`, `finish3(cage=0.004)`.

6. 식물(foliage)은 바꿀 것이 없다.

7. 확인 절차, 소품마다:
   - (가) `blender -b --python-exit-code 1 -P build.py -- <새 폴더> <묶음> <이름> nopreview`
   - (나) 로그에서 `BAKE … miss 0.000%`, steep 이 석물 1% 안팎·바위 10% 이하, TEXEL 이 README 예산표 기준인지 본다.
   - (다) `blender -b -P compare.py -- <이전 폴더> <새 폴더> <이름> <출력 접두사> near=x,y,z,거리,방위,앙각` 를 직접 보고 다섯 가지(밀랍, 흐림, 검은 얼룩, 뭉개진 모서리, 장난감 같음)를 판단한다.
   - Blender 는 한 번에 하나씩 돌린다.

8. 메인 세션 할 일:
   - 커밋할 파일: kit.py, compare.py(새 파일), README.md, assets_graves/nature/ruins.py 의 해당 함수.
     - assets_nature.py 에는 tree_build 의 선택 인자 fin 추가(기본은 예전과 같음)도 들어 있다.
   - kit_v3 의 4종을 저장소 Graveyard 폴더로 옮길지는 Unity 플레이 테스트 뒤 결정한다.
   - 사용자 플레이 테스트 항목:
     - 묘비를 1m 앞에서 볼 때 글자 홈이 또렷한지.
     - 모서리가 날카로운 선으로 빛나는지.
     - 벽 블록마다 색조가 다른지.
     - 바위 평면이 넓고 평평한지.
     - 검은 점·이음매가 없는지.
     - Unity 디테일 맵을 켠 상태의 근접 선명도.

# 독립 검토

## 검토 판정: needs_work

### 문제

- rock_b, 떨어진 자국(spall) 테두리가 '찢어진 종이'처럼 보임 (보고에는 고쳤다고 되어 있으나 남아 있음): 조각 테두리를 따라 흰 보풀 테두리와 검은 톱니 선이 생긴다. 위치는 _cmp_rock_b_near.png 오른쪽 가운데 아래의 세모 조각과 오른쪽 위의 어두운 조각, 확대본 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/crop_rock_chip.png, 그리고 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/rock_b_back_game.png 의 금 이음매 전부. rock_b_normal.png 를 보면 이 테두리마다 분홍·초록·청록으로 포화된 띠가 있다. steep 9.67% 는 문제가 남았다는 신호이고, clamp_normals 는 증상만 가린다. 원인: 저폴리를 '떨어진 자국 전' 형태로 떠서 깊은 조각의 벽을 우리 광선이 비스듬히 스친다. 고칠 방법: (a) 큰 slice/spall 면은 저폴리에도 넣는다 (lowpoly 를 slice 다음, 잔 조각 층 전에 뜬다). (b) 조각 벽을 45도 안팎의 경사로 얕게 한다. (c) 조각 테두리를 hard edge + UV 이음매로 만든다. 통과 기준은 steep 2% 미만이고, 가까이 렌더에 흰·검은 테두리가 없을 것.
- rock_b, 표면 결과 잡티: 넓은 면의 잔 굴곡이 돌이 아니라 구겨진 종이나 은박지처럼 읽힌다 (_cmp_rock_b_near.png 오른쪽, 노멀맵 전체에 잔주름). 윗면에는 동그란 물집 같은 고리 자국이 하나 있다 (/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/rock_b_top_near.png 오른쪽 위 가운데, 지름 약 3cm). 전체 실루엣은 둥근 덩어리에 납작한 다각형 조각을 붙인 모양이라 '정으로 깎은 바위'로 읽히지 않는다. 고칠 방법: chisel 층의 잔 주파수(scale 15, amp 0.003)를 빼거나 크게 키워 큰 평면 끌 면 몇 개로 바꾼다. pit/구멍 층의 반지름 하한을 정하거나 그 층을 뺀다. 큰 형태를 slice_rock 평면 몇 장으로 더 각지게 잘라 둥근 덩어리를 없앤다.
- dead_tree_a, 이전보다 나아지지 않음: _cmp_dead_tree_a_near.png 와 _cmp_dead_tree_a_mid.png 에서 왼쪽(이전)과 오른쪽(v3)이 거의 같고, 가까이 보면 여전히 흐리다. 줄기 왼쪽 위 가장자리에 검은 점이 한 줄로 남아 있다 (/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/crop_tree_dots.png). 나무껍질이 세로 껍질판이 아니라 그물처럼 얽힌 핏줄이나 구겨진 천처럼 읽히고, 그 위에 회색 구름 얼룩(albedo 의 흰 솜뭉치)이 덮여 있다 (/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/tree_trunk.png 오른쪽). UV 는 smart_project 로 수천 개의 작은 섬으로 쪼개졌고 (uv_fill 0.417 로 README 기준 0.45 미만), 노멀맵은 거의 잡음판이다. 고칠 방법: 줄기와 굵은 가지는 가지마다 이음매 하나로 원통형(follow quads) 전개하고, 가는 가지는 따로 반복 껍질 텍스처로 나눠 줄기 밑동 텍셀을 500 px/m 이상으로 올린다. BARK3 는 세로로 긴 껍질판과 깊은 골로 바꾸고, 회색 이끼 구름은 작고 경계가 또렷한 조각으로 줄인다.
- wall_ruin_a, 형태는 나아졌지만 재질이 밋밋하고 흐림: 벽돌 면이 평평하고 모서리가 곧아진 것은 확실히 좋아졌다. 그러나 가까이 보면 표면이 뭉개져 정보가 거의 없다 (_cmp_wall_ruin_a_near.png 오른쪽, /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/wall_break_near.png 오른쪽의 경사면, 237 px/m). 칠은 명암 차가 작은 연보라 단색이라, 중간 거리에서 새로 찍은 장난감 벽돌처럼 보인다 (_cmp_wall_ruin_a_mid.png 오른쪽은 이전 판보다 풍화·깨진 돌의 개성이 줄었다). 고칠 방법: 블록마다 명도 차를 키운다 (piece 값으로 ±15%). 모서리 닳음은 더 밝고 넓게, 줄눈 아래 흙물과 그을음은 더 짙게 한다. 깨진·이 빠진 블록을 몇 개 되살린다. 1~2m 근접은 계획대로 Unity 디테일 맵에 맡기되, Blender 비교 렌더에 디테일 맵이 없다는 점을 판정에 반영한다.
- grave_slab_a, 통과 수준이나 손볼 점: 글자·십자가·평평한 면·모서리는 이전보다 확실히 좋다. 남은 점: (1) 앞면 전체에 voronoi plates 선이 거북 등이나 금 간 유약처럼 깔려, 다듬은 묘비 면에 어울리지 않는다 (_cmp_grave_slab_a_near.png 오른쪽). 다듬은 면에서는 plates 를 빼고 긴 금 2~3줄 + 끌 자국 결로 바꾼다. (2) 뒷면이 비누처럼 밋밋하다 (/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/grave_back.png 오른쪽). (3) UV 왼쪽 위 약 20% 가 빈 회색 덩어리로 낭비된다 (albedo 왼쪽 위, uv_fill 0.67).
- 측정값이 실제 결함을 잡지 못함: 'miss 0.000%' 는 albedo 에서 정확히 0인 화소만 센다. 그런데 남은 검은·흰 테두리는 빗나감이 아니라 비스듬히 스친 광선에서 생기므로 이 수치로는 '검은 얼룩 0' 을 주장할 수 없다. 노멀맵의 steep 비율에 상한을 두거나 (예: 2% 넘으면 경고), 섬 경계 근처의 z<0.6 비율을 로그에 남긴다.
- 산출물 누락: 작업 지시가 말한 v3 새 미리보기 _pv_*.png 가 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/kit_v3/ 에 없다 (_cmp_* 8장만 있다).

### 메모

판정은 needs_work 입니다. 4종 가운데 grave_slab_a 는 확실히 좋아졌고 (녹은 밀랍 같은 면이 사라지고 글자·십자가가 또렷함), wall_ruin_a 는 형태는 좋아졌지만 칠이 밋밋합니다. rock_b 는 일부만 좋아졌고, 떨어진 자국 테두리의 흰·검은 톱니가 남았습니다. dead_tree_a 는 이전과 거의 같습니다. 사용자가 바란 '더 고퀄리티로 깎였으면' 기준으로는 묘비만 통과 수준이고, 바위와 나무가 v3 방식을 62종 전체로 넓히기 전에 다시 손봐야 할 곳입니다.

내가 따로 확인한 것 (Blender 4.0, samples 24, 한 번에 하나씩 실행):
- 조명 방향을 바꾼 다른 각도 렌더 (왼쪽 이전 / 오른쪽 v3), 모두 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/ 아래:
  - grave_side.png, grave_back.png
  - rock_b_back_game.png, rock_b_top_near.png
  - wall_break_near.png, wall_back_mid.png
  - tree_trunk.png
  - 확대본: crop_rock_chip.png, crop_tree_dots.png, crop_grave_edge.png
- 밉맵 2단계(512) 흉내 렌더: Cycles 렌더는 밉맵을 쓰지 않아 Unity 의 원거리 이음매 번짐을 놓칠 수 있어서, 텍스처를 512로 줄여 같은 카메라로 비교했습니다. 같은 폴더의 mip_wall.png, mip_tree.png, mip_rock.png 입니다. 결과: 벽(uv_margin 0.001)과 나무에서 눈에 띄는 섬 이음매는 없었습니다. 이 부분은 문제없습니다.
- 텍스처 직접 확인: 4종 모두 2048 입니다.
  - rock_b 노멀맵: 조각 테두리마다 포화된 띠가 있습니다.
  - dead_tree_a: UV 섬이 수천 개로 쪼개졌습니다.
  - grave_slab_a: 왼쪽 위 빈 영역이 큽니다.
- 기존 묶음 호환: kit_v3_compat 의 lantern·skull·rock_c 는 albedo 의 검은 빈 곳이 0% 로 메워졌고 평균 밝기가 10~20% 올랐습니다 (빈 곳 메움과 Standard 저장 때문). well·bones_scatter 는 각자 finish_lm/finish_b 를 써서 바뀌지 않았습니다. 다만 2단계에서 62종을 다시 빌드하면 albedo 가 전체로 조금 밝아집니다 (AgX → Standard). 월드 조명·포그를 다시 맞춰 봐야 할 수 있습니다.

참고: 벽·나무의 1~2m 근접 흐림은 README 설계상 Unity 디테일 맵(detailtex.py)이 맡습니다. 그 맵이 없는 Blender 비교만으로는 근접 판정이 불리하게 나옵니다. 그래도 중간 거리의 칠이 밋밋한 것, 바위·나무의 테두리와 결 문제는 디테일 맵과 상관없는 결함입니다.

C# 은 이번 검토 범위에서 바뀐 것이 없어 컴파일 검사는 돌리지 않았습니다. 저장소 파일은 수정하지 않았고, 검토용 스크립트만 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/rv.py 와 /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/review_v3/rvmip.py 에 만들었습니다.