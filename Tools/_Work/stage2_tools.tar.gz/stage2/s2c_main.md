# 메인 세션 작업 (2026-11-27 05:20~06:30 UTC) — 주간 사용량 한도로 작업자를 못 돌리는 동안

## 한 것
1. 땅 잡동사니를 지형 detail 로 깔기 (w6b 몫을 메인 세션이 했다)
   - worldgen.py: `CLUTTER` (이름, 칸당 최대, 크기 배율, 최대 기울기), `detail_list(meta)` (풀 6 + manifest 에 있는 잡동사니), `_near_map`, `clutter_density` (바위·폐허·무덤·나무 둘레 띠 + 숲·들판 마루·마른 풀밭 + 110 m 큰 무늬 × 18 m·9 m 덩이, 길 위·물 위·소품 자리 비움, 장소 바닥 60% 줄임)
   - 저장: detail_N.png 를 details 수만큼 (풀 0/1, 잡동사니 2). world.json details 12개
   - NecroWorldBuilder.cs: MaxDetails 12, detail2 읽기 (스텁 컴파일 0)
   - render_world.py: detail 이미지 수를 details 수에 맞춤
   - 크기 배율을 k9 권장보다 크게 (돌 8 cm 그대로는 8 m 넘으면 안 읽힘), 밀도: pebbles 0.9, twigs 0.8, bones 0.6, litter 0.9, shrub 0.5, mushrooms 0.5
   - 눈높이 렌더 (S/s2c/eye/c1_*): 빛나는 버섯 무리와 마루 위 마른 덤불이 보인다. 효과는 있지만 크지는 않다 (0~30 m 앞이 여전히 풀이 대부분인 자리 있음)
2. 통합 (저장소 커밋 b2d4eda, 푸시함)
   - 소품 폴더: bash S/s2c/mk_kit_final.sh → S/kit_final (kit_out + kit_scenes(돌담 칠 고친 판) + kit_clutter + _decision v3 = wall_ruin_a). publish.py kit_final → Graveyard 84종 (296 MB)
   - 월드: S/world_final (S/s2c/final_gen.sh s2c_b). 저장소 Ch1 에 Data~ 전부(cliffs.bin·detail_2.png 새로), map.png, Terrain (w5 의 flatten_low 판 — world_v3/Terrain 에서 복사. 처음에 world_final/Terrain 이 예전 판이었던 것을 고쳤다)
   - .gitattributes 에 *.bin LFS
3. 문서: WORLD.md ('작업 중' 지움, 장면·새 소품 16종·들판 채움·땅 잡동사니·산 벽 덮개 설명, Cliffs 줄, 한계 2줄, LFS 크기), TESTING.md ('작업 중' 지움, G1 84개, G3 새 기대값, G17~G21 새 항목, 느낌 질문), README 현재 단계 줄, WorldGen README(잡동사니 절)·SPEC(detail_2), docs/images/props_scenes.jpg·props_clutter.jpg. 월드 그림(world_*.jpg) 은 S/s2c/docs/d_*.png 로 다시 렌더 중
4. Tools/_Work/stage2_tools.tar.gz: 작업 기록·검사 도구 사본 (임시 폴더가 지워져도 이어 가기)

## 검사 (S/world_v3_qa/s2c_b)
탈출 0·0, 도달 13/13·13/13, 길 23°, 다리 턱 0.205 m, 화면 삼각형 99% 7.54M (소품+나무 4.03M, 풀+잡동사니 3.51M) / 8.5M, 그리는 물체 최악 1,983 / 2,000 (468,564 yaw 38), 광원 후보 최대 44 (주인공 자리 41), 결정성 다름 0, 들판 R 0.55

## 숫자 (g3_numbers.py)
지형 4타일, 지형 층 8, 풀 12종 · 약 359만, 지형 나무 8종 · 11,600, 소품 15,235 (광원 1,696), 따로 놓은 광원 103, 물 3, 효과 230, 장소 13, 장면 134, 산 벽 덮개 305조각
G1: 소품 프리팹 84개 (일반 64, 지형 나무 8, 지형 풀 12, 광원 포함 19)

## 남은 것 (12월 1일 이후 작업자 몫)
- 옛 소품 v3 넓히기: k7a (묘비 칠 + 묘비 묶음), k7b (블록 석조 11종 — 진행 기록 S/stage2/progress/k7b.md, 칠 도구 paint_block3 까지 만듦), k8 (바위·고목 3회차), 검토 kr3/kr4
- 월드 독립 검토 wr3 → 수정 w7 (산 벽 덮개 가장자리 톱니·흐린 얼룩, 0~30 m 풀만인 자리)
- 다시 통합 (i1: s2c/mk_kit_final.sh → publish → s2c/final_gen.sh → Ch1 복사), 문서 숫자·그림 (i2), 최종 검토 (fr1/fr2)
