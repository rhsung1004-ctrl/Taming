using UnityEngine; using UnityEditor;
class P { void F(TerrainData td, DetailPrototype dp){ td.SetDetailResolution(1024,16); dp.useInstancing=true; td.SetTreeInstances(new TreeInstance[0], true); var tl = new TerrainLayer(); tl.diffuseTexture=null; PrefabUtility.SaveAsPrefabAsset(null,""); } }
