#!/bin/bash
# 사용법: check.sh <.cs 파일들...>   실제 Unity 2021.3 엔진 모듈 + 2021.1 에디터 참조 어셈블리 + URP/InputSystem 스텁으로 컴파일 검사
N=/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/nuget
REFS=$(for f in $N/mods/lib/net45/*.dll; do printf -- "-r:%s " $f; done)
mcs -langversion:7.2 -nowarn:0649,0169,0414,0108,0109,0618,0219 -target:library -out:/tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/realstub/out_$$.dll $REFS -r:$N/sdk/lib/UnityEditor.dll /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/realstub/Packages.cs "$@"
r=$?; rm -f /tmp/claude-0/-home-user/6fa51ed4-c6be-5cbd-8981-dc6bcce92a91/scratchpad/realstub/out_$$.dll; exit $r
