// URP·Input System 패키지 스텁 (엔진·에디터 본체는 실제 참조 어셈블리 사용)
using System;
using UnityEngine;
namespace UnityEngine.Rendering {
  public class VolumeParameter<T> { public T value; public bool overrideState; public void Override(T v){} }
  public class VolumeComponent : ScriptableObject { public bool active; }
  public class VolumeProfile : ScriptableObject { public T Add<T>(bool o=false) where T:VolumeComponent {return null;} public bool TryGet<T>(out T c) where T:VolumeComponent {c=null;return false;} }
  public class Volume : MonoBehaviour { public bool isGlobal; public float priority, weight; public VolumeProfile sharedProfile, profile; }
}
namespace UnityEngine.Rendering.Universal {
  using UnityEngine.Rendering;
  public enum TonemappingMode { None, Neutral, ACES } public enum AntialiasingMode { None, FastApproximateAntialiasing, SubpixelMorphologicalAntiAliasing, TemporalAntiAliasing }
  public class Bloom : VolumeComponent { public VolumeParameter<float> threshold=null,intensity=null,scatter=null; public VolumeParameter<Color> tint=null; }
  public class Tonemapping : VolumeComponent { public VolumeParameter<TonemappingMode> mode=null; }
  public class ColorAdjustments : VolumeComponent { public VolumeParameter<float> postExposure=null,contrast=null,saturation=null,hueShift=null; public VolumeParameter<Color> colorFilter=null; }
  public class SplitToning : VolumeComponent { public VolumeParameter<Color> shadows=null,highlights=null; public VolumeParameter<float> balance=null; }
  public class Vignette : VolumeComponent { public VolumeParameter<float> intensity=null,smoothness=null; public VolumeParameter<Color> color=null; }
  public class LiftGammaGain : VolumeComponent { public VolumeParameter<Vector4> lift=null,gamma=null,gain=null; }
  public class ShadowsMidtonesHighlights : VolumeComponent { public VolumeParameter<Vector4> shadows=null,midtones=null,highlights=null; }
  public class FilmGrain : VolumeComponent { public VolumeParameter<float> intensity=null; }
  public class DepthOfField : VolumeComponent { }
  public class UniversalAdditionalCameraData : MonoBehaviour { public bool renderPostProcessing, renderShadows; public AntialiasingMode antialiasing; }
  public static class CameraExtensions { public static UniversalAdditionalCameraData GetUniversalAdditionalCameraData(this Camera c){return null;} }
  public enum RenderingMode { Forward, Deferred, ForwardPlus }
  public class UniversalRendererData : ScriptableObject { public RenderingMode renderingMode; }
  public class UniversalRenderPipelineAsset : RenderPipelineAsset { public float shadowDistance; public int shadowCascadeCount; public bool supportsCameraDepthTexture, supportsCameraOpaqueTexture, supportsHDR; public int maxAdditionalLightsCount; public float renderScale; public override RenderPipeline CreatePipeline(){return null;} }
}
namespace UnityEngine.InputSystem {
  using UnityEngine.InputSystem.Controls;
  public enum InputActionType { Value, Button, PassThrough }
  public class InputAction { public InputAction(string name=null, InputActionType type=InputActionType.Value, string binding=null, string interactions=null, string processors=null, string expectedControlType=null){}
    public CompositeSyntax AddCompositeBinding(string s){return new CompositeSyntax();} public void AddBinding(string s){} public void Enable(){} public void Disable(){} public void Dispose(){}
    public T ReadValue<T>() where T:struct {return default(T);} public bool WasPressedThisFrame(){return false;} public bool IsPressed(){return false;}
    public struct CompositeSyntax { public CompositeSyntax With(string a,string b){return this;} } }
  public class Keyboard { public static Keyboard current; public KeyControl this[Key k]{get{return null;}}
    public KeyControl aKey,bKey,cKey,dKey,eKey,fKey,gKey,hKey,iKey,jKey,kKey,lKey,mKey,nKey,oKey,pKey,qKey,rKey,sKey,tKey,uKey,vKey,wKey,xKey,yKey,zKey,
      leftArrowKey,rightArrowKey,downArrowKey,upArrowKey,leftShiftKey,rightShiftKey,leftCtrlKey,spaceKey,escapeKey,tabKey,enterKey,
      f1Key,f2Key,f3Key,f4Key,f5Key,f6Key,f7Key,f8Key,f9Key,f10Key,digit1Key,digit2Key,digit3Key,digit4Key,digit5Key,digit6Key,digit7Key,digit8Key,digit9Key,digit0Key,minusKey,equalsKey; }
  public enum Key { None }
  public class Mouse { public static Mouse current; public ButtonControl leftButton,rightButton,middleButton; public Vector2Control delta, scroll, position; }
  public class Gamepad { public static Gamepad current; public StickControl leftStick,rightStick; public DpadControl dpad; public ButtonControl rightTrigger,leftTrigger,rightShoulder,leftShoulder,buttonWest,buttonNorth,buttonEast,buttonSouth,startButton,selectButton,leftStickButton,rightStickButton; }
}
namespace UnityEngine.InputSystem.Controls {
  public class ButtonControl { public bool isPressed, wasPressedThisFrame, wasReleasedThisFrame; public float ReadValue(){return 0;} }
  public class KeyControl : ButtonControl {}
  public class Vector2Control { public Vector2 ReadValue(){return Vector2.zero;} public ButtonControl up,down,left,right; }
  public class StickControl : Vector2Control {} public class DpadControl : Vector2Control {}
}
